/*
 * Copyright (c) 2000 Day Management AG
 * Barfuesserplatz 6, 4001 Basel, Switzerland
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Day Management AG, ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Day.
 */
#include <stdlib.h>
#include <stdarg.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>

#include "base/base.h"


#include <fcntl.h>
#include <httpext.h>

#include "dispatcher/dispatcher.h"
#include "dispatcher/farm.h"
#include "dispatcher/cache.h"

#include <crtdbg.h>

#include <disp_msg.h>

#ifdef WITH_SSL
#include <openssl/ssl.h>
#endif

/**
 * Flag indicating whether this DLL was initialized
 */
static BOOL _initialized = FALSE;

#ifdef _CRTDBG_MAP_ALLOC

/**
 * Critical section to guard malloc_dbg calls
 */
static CRITICAL_SECTION _cs_crtdbg;

#endif

/**
 * Logging level, logs only error messages by default
 */
static int _logLevel = LL_ERROR;

/**
 * Flag indicating whether we should send server variables
 */
static BOOL _serverVariables = FALSE;

/**
 * Flag indicating whether we should replace authorization headers
 */
static BOOL _replaceAuthorization = FALSE;

/**
 * HTTP keepalive timeout in seconds
 */
static int _keepalivetimeout = 0;

/**
 * If HTTP keepalive is enabled
 */
static int _keepaliveenabled = 1;

/**
 * Flag indicating whether response will be transferred chunked.
 */
static int enable_chunked_transfer = 0;

/**
 * Log level one letter abbreviations (preceded by dummy entry for missing zero LL_ value).
 */
static const char *_log_levels = " EWIDT";

/**
 * Define our dummy context
 */
static struct log_context *lc = NULL;

/**
 * Map of internal log levels -> Event log levels
 */
static const WORD _log_level_map[] = {
    -1,                         /* dummy entry for missing zero LL_ value */
    EVENTLOG_ERROR_TYPE,
    EVENTLOG_WARNING_TYPE,
    EVENTLOG_INFORMATION_TYPE,
    EVENTLOG_SUCCESS,
    EVENTLOG_SUCCESS
};

/**
 * IIS Variables
 */
static const char *_variables[] = {
    "APPL_MD_PATH",
    "APPL_PHYSICAL_PATH",
    "AUTH_PASSWORD",
    "AUTH_TYPE",
    "AUTH_USER",
    "CERT_COOKIE",
    "CERT_FLAGS",
    "CERT_ISSUER",
    "CERT_KEYSIZE",
    "CERT_SECRETKEYSIZE",
    "CERT_SERIALNUMBER",
    "CERT_SERVER_ISSUER",
    "CERT_SERVER_SUBJECT",
    "CERT_SUBJECT",
    "CONTENT_LENGTH",
    "CONTENT_TYPE",
    "LOGON_USER",
    "HTTPS",
    "HTTPS_KEYSIZE",
    "HTTPS_SECRETKEYSIZE",
    "HTTPS_SERVER_ISSUER",
    "HTTPS_SERVER_SUBJECT",
    "INSTANCE_ID",
    "INSTANCE_META_PATH",
    "PATH_INFO",
    "QUERY_STRING",
    "REMOTE_ADDR",
    "REMOTE_HOST",
    "REMOTE_USER",
    "REQUEST_METHOD",
    "SCRIPT_NAME",
    "SERVER_NAME",
    "SERVER_PORT",
    "SERVER_PORT_SECURE",
    "SERVER_PROTOCOL",
    "SERVER_SOFTWARE",
    "URL",
    NULL,
};

/**
 * Event log section
 */
static LPCSTR _pcszEventLog = "SYSTEM\\CurrentControlSet\\Services\\EventLog\\Application";

/**
 * Application name
 */
static LPCSTR _pcszAppName = "CQ2IIS";

/**
 * Event source
 */
static HANDLE _hEventSource = NULL;

static const char *_dispatcher_include = "X-Dispatcher-Include: 1\r\n";

/**
 * Log file path name.
 */
static char _logf_path[PATH_MAX];

/**
 * Current log file path.
 */
static char _logf_path_current[PATH_MAX];

/**
 * Log file rotation time interval in seconds or 0 if not applicable.
 */
static long _logf_rotate_time = 0;

/**
 * Log file rotation size in megabytes or 0 if not applicable
 */
static long _logf_rotate_size = 0;

/**
 * Time of last log file rotation or 0 if no log file has been created yet
 */
static time_t _logf_create_timestamp = 0;

/**
 * Log file descriptor.
 */
static int _logfd = -1;

/**
 * Log file critical section.
 */
static CRITICAL_SECTION _cs_logf;

/**
 * Dispatcher configuration.
 */
static struct dispatcher_config dispatcher_config;

/**
 * A structure describing webserver specific data.
 */
struct ws_extra {
    /* extension control block */
    EXTENSION_CONTROL_BLOCK *pECB;
    /* server variables */
    struct hashtable *variables;
    /* request headers */
    struct ptrarray *req_headers;
    /* hashtable of request header names */
    struct hashtable *req_hdrnames;
    /* HTTP status line */
    char *sline;
    /* response headers */
    struct sbuffer *out_headers;
    /* converted basic authorization header */
    char basic_auth[256];
    /* HttpExtensionProc() return value after ws_deliver() */
    int deliver_ret;

    /* flag indicating whether response has a content length */
    unsigned has_clen:1;
    /* flag indicating whether response will be transferred in chunks */
    unsigned chunked:1;
    /** flag indicating whether we were included via SSI */
    unsigned ssi:1;
};

/**
 * An enumeration describing the reason for a rotation.
 */
enum rotate_reason {
    ROTATE_NONE = 0,
    ROTATE_NEW = 1,
    ROTATE_TIME = 2,
    ROTATE_SIZE = 3
} rotate_reason;

/**
 * Reason strings associated with reason enumeration above.
 */
static const char *const ROTATE_REASONS[] = {
    NULL,
    "Open a new file",
    "Time interval expired",
    "Maximum size reached",
};

/**
 * Rotate log files if necessary.
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
static void rotate_log_if_needed()
{
    enum rotate_reason reason = ROTATE_NONE;
    time_t now, period_start;
    struct tm *timeinfo;
    char path[PATH_MAX];
    int fd, old_fd = -1, ret = 0;

    time(&now);
    period_start = now;

    /* determine if a new files has to be created */
    if (_logf_create_timestamp == 0) {
        reason = ROTATE_NEW;
    } else if (_logf_rotate_size && _filelength(_logfd) > _logf_rotate_size * 1024 * 1024) {
        reason = ROTATE_SIZE;
    } else if (_logf_rotate_time && difftime(now, _logf_create_timestamp) > _logf_rotate_time) {
        reason = ROTATE_TIME;
    }

    if (reason == ROTATE_NONE) {
        return;
    }

    DBG("File rotation needed, reason: %s", ROTATE_REASONS[reason]);

    /* determine the time stamp for the name of the new file */
    if (_logf_rotate_time) {
        timeinfo = localtime(&now);
        timeinfo->tm_sec -= (((long) difftime(now, _logf_create_timestamp)) % _logf_rotate_time);
        period_start = mktime(timeinfo);
    }

    /* construct path of the new log file */
    if (strchr(_logf_path, '%')) {
        /* configured log path is pattern string */
        strftime(path, PATH_MAX, _logf_path, localtime(&period_start));
    } else {
        /* configured log path is plain text */
        if (_logf_rotate_size || _logf_rotate_time) {
            snprintf(path, PATH_MAX, "%s.%.0f", _logf_path, difftime(period_start, 0));
        } else {
            strcpy(path, _logf_path);
        }
    }

    if ((fd = _open(path,
            _O_CREAT | _O_APPEND | _O_TEXT | _O_WRONLY,
            _S_IREAD | _S_IWRITE)) == -1) {
        WARN("Unable to open log file %s: %s", path, strerror(errno));
        return;
    }

    DBG("Opened log file: %s (fd=%ld)", path, fd);

    _logf_create_timestamp = period_start;

    if (_logfd > 0) {
        DBG("Closing log file: %s (fd=%ld)", _logf_path_current, _logfd);
        ret = _close(_logfd);
    }

    old_fd = _logfd;
    _logfd = fd;

    if (ret) {
        WARN("Unable to close old log file %s: %s (fd=%ld)", _logf_path_current, strerror(errno), old_fd);
    }

    strcpy(_logf_path_current, path);
}

/**
 * Log message to a file.
 *
 * @param fd file descriptor
 * @param level log level
 * @param s message
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
static int log_to_file(int fd, enum log_level level, const char *s)
{
    char buf[2048];
    const char *nows;
    int off;
    time_t now;
    size_t len;

    off = 0;
    len = sizeof buf;

    /* Log the time */
    time(&now);
    if ((nows = ctime(&now)) != NULL) {
        off += snprintf(buf + off, len - off, "[%.24s] ", nows);
    }

    /* Log the log level and message */
    off += snprintf(buf + off, len - off, "[%c] [pid %ld (tid %ld)] %s\n",
            _log_levels[level], GetCurrentProcessId(), GetCurrentThreadId(), s);

    return _write(fd, buf, off) == -1 ? -1 : 0;
}

/**
 * Log message to Windows Event Log.
 *
 * @param handle handle to event log
 * @param level log level
 * @param s message
 */
static void log_to_eventlog(HANDLE handle, int level, const char *s)
{
    const char *params[1];
    DWORD data[2];

    params[0] = s;

    data[0] = GetCurrentProcessId();
    data[1] = GetCurrentThreadId();

    ReportEvent(handle, _log_level_map[level], 0, MSG_GENERIC,
            NULL, 1, sizeof data, params, data);
}

/** Trace a message */
#ifdef ENABLE_DIAG
#define DIAG(...)   diag_message(__FILE__, __LINE__, __VA_ARGS__)
#else
#define DIAG(...)
#endif

#ifdef ENABLE_DIAG
static void diag_message(char *file, int line, const char *fmt, ...)
{
    char buf[2048], *p;
    va_list args;
    size_t off = 0, len, count = sizeof buf;

    /* skip over path separators */
    p = strrchr(file, '\\');
    if (!p) {
        p = file;
    } else {
        p++;
    }

    if ((len = _snprintf(buf, count - 2, "%s(%d) : ", p, line)) < 0) {
        len = count - 2;
    }
    count -= len;
    off += len;

    if (count > 2) {
        va_start(args, fmt);
        if ((len = _vsnprintf(buf + off, count - 2, fmt, args)) < 0) {
            len = count - 2;
        }
        va_end(args);
        off += len;
    }

    if (_logfd != -1) {
        log_to_file(_logfd, LL_TRACE, buf);
    } else {
        OutputDebugString(buf);
    }
}
#endif

/**
 * Register event logging source
 *
 * @return TRUE if successful, else FALSE
 */
static BOOL register_event_log()
{
    CHAR szModule[MAX_PATH], szKey[256];
    HKEY hKey;
    DWORD dwTypes, dwResult;

    if (!GetModuleFileName(g_hInstDll, szModule, sizeof(szModule))) {
        WARN("GetModuleFileName failed: %08X", GetLastError());
        return FALSE;
    }

    snprintf(szKey, sizeof(szKey), "%s\\%s", _pcszEventLog, _pcszAppName);

    dwResult = RegCreateKeyEx(HKEY_LOCAL_MACHINE, szKey, 0, "", 0, KEY_WRITE, NULL, &hKey, NULL);
    if (dwResult != ERROR_SUCCESS) {
        WARN("RegCreateKeyEx(%s) failed: %08X", szKey, dwResult);
        return FALSE;
    }

    RegSetValueEx(hKey, "EventMessageFile", 0, REG_SZ, (CONST BYTE *) szModule, lstrlen(szModule) + 1);

    dwTypes = EVENTLOG_ERROR_TYPE | EVENTLOG_WARNING_TYPE | EVENTLOG_INFORMATION_TYPE;
    RegSetValueEx(hKey, "TypesSupported", 0, REG_DWORD, (LPBYTE) & dwTypes, sizeof(dwTypes));

    RegCloseKey(hKey);

    _hEventSource = RegisterEventSource(NULL, _pcszAppName);
    if (_hEventSource == NULL) {
        WARN("RegisterEventSource failed: %08X", GetLastError());
    }
    return _hEventSource != NULL;
}

/**
 * Initializes this ISAPI extension.
 *
 * @return <code>TRUE</code> if successful, else <code>FALSE</code>
 */
static BOOL initialize()
{
    char inifile[_MAX_PATH], configfile[_MAX_PATH], *sep, _logf_rotate_str[16], *rotate_size_end;
    HANDLE hFile;
    int tmplong, level;
    unsigned int seed;

    if (_initialized) {
        return TRUE;
    }

#ifdef _CRTDBG_MAP_ALLOC
    InitializeCriticalSection(&_cs_crtdbg);
#endif

    InitializeCriticalSection(&_cs_logf);

    /* Derive .ini filename from this module's filename */
    if (!GetModuleFileName(g_hInstDll, inifile, sizeof(inifile))) {
        ERR("GetModuleFileName() returned: %08X", GetLastError());
        return FALSE;
    }
    if ((sep = strrchr(inifile, '.')) == NULL) {
        ERR("File extension not found in: %s", inifile);
        return FALSE;
    }
    strcpy(sep, ".ini");

    /* Check whether file exists */
    hFile = CreateFile(inifile, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hFile == INVALID_HANDLE_VALUE) {
        ERR("Configuration file not found: %s", inifile);
        return FALSE;
    }
    CloseHandle(hFile);

    /* Read settings */
    GetPrivateProfileString("main", "configpath", "", configfile, sizeof(configfile), inifile);
    NORMALIZE_FILENAME(configfile);

    /* Account for LL_ERROR starting at 1 */
    level = GetPrivateProfileInt("main", "loglevel", 0, inifile) + LL_ERROR;
    if (level < LL_ERROR || level > LL_TRACE) {
        ERR("Invalid value for loglevel, expected value in range [%d-%d], actual: %d", LL_ERROR, LL_TRACE, level);
        return FALSE;
    }
    _logLevel = level;

    _serverVariables = GetPrivateProfileInt("main", "servervariables", 0, inifile);
    _replaceAuthorization = GetPrivateProfileInt("main", "replaceauthorization", 0, inifile);
    _keepaliveenabled = GetPrivateProfileInt("main", "keepaliveenabled", 1, inifile);
    _keepalivetimeout = GetPrivateProfileInt("main", "keepalivetimeout", DEFAULT_KEEP_ALIVE_TIMEOUT_SEC, inifile);

    enable_chunked_transfer =  GetPrivateProfileInt("main", "enable_chunked_transfer", 0, inifile);

    /* Get log file path and open log file if specified */
    GetPrivateProfileString("main", "logfile", NULL, _logf_path, sizeof(_logf_path), inifile);
    GetPrivateProfileString("main", "rotate", NULL, _logf_rotate_str, sizeof(_logf_rotate_str), inifile);

    if (*_logf_path) {
        /* parse _logf_rotate_str, if applicable */
        if ((tmplong = strtol(_logf_rotate_str, &rotate_size_end, 10)) > 0) {
            if (!strcasecmp(rotate_size_end, "M")) {
                /* rotate log files based on size */
                _logf_rotate_size = tmplong;
            } else {
                /* rotate log files based on time */
                _logf_rotate_time = tmplong;
            }
        }

        NORMALIZE_FILENAME(_logf_path);
        /* create initial log file */
        rotate_log_if_needed();
    }

    if (_logfd == -1) {
        register_event_log();
    }

    if (_keepaliveenabled) {
        DBG("HTTP keepalive is enabled, timeout is %d seconds.", _keepalivetimeout);
        init_socket_factory(lc, 1, _keepalivetimeout);
    }

    /* Initialize the rest */
    if (dispatcher_init(lc, configfile, &dispatcher_config, "iis")) {
        ERR("Dispatcher initialization failed.");
        return FALSE;
    }

#ifdef WITH_SSL
    {
        char certificate_file[_MAX_PATH], *pcertificate_file = NULL;
        char ca_certificate_file[_MAX_PATH], *pca_certificate_file = NULL;
        int check_peer_cn;

        GetPrivateProfileString("main", "certificatefile", "", certificate_file, sizeof(certificate_file), inifile);
        if (certificate_file[0]) {
            NORMALIZE_FILENAME(certificate_file);
            pcertificate_file = certificate_file;
        }
        GetPrivateProfileString("main", "cacertificatefile", "", ca_certificate_file, sizeof(ca_certificate_file), inifile);
        if (ca_certificate_file[0]) {
            NORMALIZE_FILENAME(ca_certificate_file);
            pca_certificate_file = ca_certificate_file;
        }
        check_peer_cn = GetPrivateProfileInt("main", "checkpeercn", 0, inifile);

        if (sslsockets_init(NULL, pcertificate_file, pca_certificate_file, check_peer_cn, 1)) {
            ERR("Failed to init ssl sockets, error code: %d", GetLastError());
            return FALSE;
        }
    }
#else
    if (sockets_init(1)) {
        return FALSE;
    }
#endif

    seed = (time(NULL) & 0xFFFF) | (getpid() << 16);
    TRACE("Initializing PRNG with seed: %ld", seed);
    srand(seed);

    return ((_initialized = TRUE));
}

/**
 * Terminates this extension.
 *
 * @param d points to dispatcher
 */
static void terminate(struct dispatcher *d)
{
    if (_initialized) {
#ifdef _CRTDBG_MAP_ALLOC
        DeleteCriticalSection(&_cs_crtdbg);
#endif
        DeleteCriticalSection(&_cs_logf);

#ifdef WITH_SSL
        sslsockets_cleanup();
#endif

        INFO("Dispatcher terminated.");
        _initialized = FALSE;
    }
}

/**
 * Returns the value of a server variable directly from the underlying
 * IIS mechanism
 *
 * @param d points to the dispatcher
 * @param name variable name
 *
 * @return value of server variable in a buffer allocated with <code>malloc</code>
 *         or <code>NULL</code> if the variable is unknown.
 */
static char *get_server_variable(struct ws_extra *ws, const char *name)
{
    EXTENSION_CONTROL_BLOCK *pECB = ws->pECB;
    char *value;
    int unicode = 0;
    DWORD count;
    BOOL ret;

    /* instead of requesting platform-encoded URL or PATH, ask for Unicode
     * string instead and convert to UTF-8 later */
    if (!strcmp(name, "URL")) {
        name = "UNICODE_URL";
        unicode = 1;
    }
    if (!strcmp(name, "PATH_INFO")) {
        name = "UNICODE_PATH_INFO";
        unicode = 1;
    }

    /* get size of buffer to allocate */
    count = 0;
    ret = pECB->GetServerVariable(pECB->ConnID, (LPSTR) name, NULL, &count);

    if (ret || GetLastError() != ERROR_INSUFFICIENT_BUFFER) {
        return NULL;
    }

    /* allocate space for buffer and retry */
    value = malloc(count + 1);

    ret = pECB->GetServerVariable(pECB->ConnID, (LPSTR) name, value, &count);
    if (!ret) {
        free(value);
        return NULL;
    }

    /* now convert to UTF-8 if required */
    if (unicode) {
        /* every Unicode character (2 bytes) maps to [1..4] UTF-8 bytes,
         * so double the input number of bytes for safety
         */
        char *utf8_value = malloc(2 * count);
        ucs2_to_utf8(utf8_value, (const wchar_t *) value, 2 * count);
        free(value);
        value = utf8_value;
    }
    return value;
}

/**
 * Returns the value of a variable.
 *
 * @param ws webserver specific data
 * @param name variable name
 * @return variable value, this pointer MUST NOT be freed.
 */
static const char *get_variable(struct ws_extra *ws, const char *name)
{
    const char *value;
    char *newval;

    value = hashtable_gets(ws->variables, name);
    if (value == NULL) {
        if ((newval = get_server_variable(ws, name)) != NULL) {
            hashtable_puts(ws->variables, name, newval);
            free(newval);

            value = hashtable_gets(ws->variables, name);
       }
    }
    return value;
}

/**
 * A structure holding an HTTP header.
 */
struct header {
    /* header name */
    char *name;
    /* header value */
    char *value;
    /* next header of the same name */
    struct header *next;
};

/**
 * Add a request header to our internal table.
 *
 * @param ws webserver data
 * @param name name, not null-terminated
 * @param name_len number of characters in name
 * @param value value, not null-terminated
 * @param value_len number of characters in value
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
static int add_request_header(struct ws_extra *ws,
                              const char *name, size_t name_len,
                              const char *value, size_t value_len)
{
    struct header *header;
    char *lwrname;
    unsigned i;

    lwrname = malloc(name_len + 1);

    for (i = 0; i < name_len; i++) {
        lwrname[i] = tolower(name[i]);
    }
    lwrname[name_len] = 0;

    header = malloc(sizeof(struct header));
    memset(header, 0, sizeof(struct header));

    header->name = strnumdup(name, name_len);
    header->value = strnumdup(value, value_len);

    hashtable_put(ws->req_hdrnames, lwrname, (void *) header->value, NULL);
    ptrarray_add(ws->req_headers, header);

    free(lwrname);

    return 0;
}

/**
 * Processes client headers received as a contiguous string containing
 * name:value pairs, separated by carriage return/line feed combinations.
 *
 * @param d points to dispatcher
 * @param s client headers string
 */
static void process_headers(struct dispatcher *d, const char *s)
{
    struct ws_extra *ws = d->ws;
    const char *name, *value, *sep;
    size_t name_len, value_len;

    while (*s) {
        if ((sep = strchr(s, ':')) == NULL) {
            return;
        }
        name = s;
        name_len = sep - s;

        s = sep + 1;
        while (*s == ' ') {
            s++;
        }

        value = s;
        while (*s != '\0' && *s != '\r' && *s != '\n') {
            s++;
        }
        value_len = s - value;

        if (value_len > 0) {
            add_request_header(ws, name, name_len, value, value_len);
        }
        while (*s == '\r' || *s == '\n') {
            s++;
        }
    }
}

/**
 * Frees a header and all its resources.
 *
 * @param p header
 */
static void header_free(void *p)
{
    struct header *hdr = p;

    free(hdr->name);
    free(hdr->value);
    free(hdr);
}

/**
 * Returns the HTTP request method
 *
 * @param ws points to the dispatcher
 * @return pointer to method or <code>NULL</code>
 */
static const char *get_method(struct ws_extra *ws)
{
    const char *method = get_variable(ws, "REQUEST_METHOD");
    if (method == NULL || strlen(method) == 0) {
        method = "GET";
    }
    return method;
}

/**
 * Returns the query string.
 *
 * @param ws webserver specific data
 * @return pointer to query string or NULL if the request did not contain one
 */
static const char *get_query_string(struct ws_extra *ws)
{
    const char *query = get_variable(ws, "QUERY_STRING");
    if (query == NULL || *query == 0) {
        return NULL;
    }
    return query;
}

/**
 * Returns the URL for this request.
 *
 * @param ws webserver specific data
 * @return URL
 */
static const char *get_url(struct ws_extra *ws)
{
    return get_variable(ws, "PATH_INFO");
}

static void WINAPI _io_complete(EXTENSION_CONTROL_BLOCK *pECB, void *context, DWORD cbIO, DWORD dwError)
{
    DWORD dwStatus;

    DIAG("_io_complete(%08X, %d, %d)", pECB->ConnID, cbIO, dwError);

    if (context != NULL) {
        HANDLE hFile = (HANDLE) context;
        if (!CloseHandle(hFile)) {
             INFO("CloseHandle(%08X) returned: %08X", context, GetLastError());
        }
    }

    dwStatus = HSE_STATUS_SUCCESS;
    if (!pECB->ServerSupportFunction(pECB->ConnID, HSE_REQ_DONE_WITH_SESSION,
            &dwStatus, NULL, NULL)) {
        WARN("HSE_REQ_DONE_WITH_SESSION returned: %08X", GetLastError());
    }
}

static int send_response(EXTENSION_CONTROL_BLOCK *pECB, const char *sline,
        const char *headers, int keepConn)
{
    HSE_SEND_HEADER_EX_INFO shei;

    DIAG("send_response(%08X,\"%s\")", pECB->ConnID, sline);

    memset(&shei, 0, sizeof(shei));
    shei.pszStatus = sline;
    shei.pszHeader = headers;
    shei.cchStatus = lstrlen(shei.pszStatus);
    shei.cchHeader = lstrlen(shei.pszHeader);
    shei.fKeepConn = keepConn;

    if (!pECB->ServerSupportFunction(pECB->ConnID,
            HSE_REQ_SEND_RESPONSE_HEADER_EX, &shei, NULL, NULL)) {

        WARN("HSE_REQ_SEND_RESPONSE_HEADER_EX(%s) returned: %08X",
                sline, GetLastError());
        return -1;
    }
    return 0;
}

static const char *lookup_reason(int sc)
{
    switch (sc) {
    case 200:
        return "OK";
    case 400:
        return "Bad Request";
    case 403:
        return "Forbidden";
    case 404:
        return "Not Found";
    case 500:
        return "Internal Server Error";
    case 502:
        return "Bad Gateway";
    case 503:
        return "Service Unavailable";
    case 504:
        return "Gateway Time-out";
    default:
        return "Unknown";
    }
}

/**
 * Send a HTTP status code indicating an error back to IIS.
 */
static int send_error(EXTENSION_CONTROL_BLOCK *pECB, int sc)
{
    HSE_CUSTOM_ERROR_INFO ei;
    DWORD lastError;
    char buf[50];

    DIAG("send_error(%08X,%d)", pECB->ConnID, sc);

    pECB->dwHttpStatusCode = sc;
    snprintf(buf, sizeof buf, "%d %s", sc, lookup_reason(sc));

    memset(&ei, 0, sizeof ei);
    ei.pszStatus = buf;

    if (!pECB->ServerSupportFunction(pECB->ConnID, HSE_REQ_SEND_CUSTOM_ERROR, &ei, NULL, NULL)) {
        lastError = GetLastError();
        if (lastError == ERROR_FILE_NOT_FOUND) {
            /* No custom error page defined, send back verbatim response */
            return send_response(pECB, buf, "Content-Length: 0\r\n\r\n", 1);
        }
        WARN("HSE_REQ_SEND_CUSTOM_ERROR(%d) returned: %08X", sc, lastError);
        return -1;
    }
    return 0;
}

static int prepare_user_info(struct ws_extra *ws, HSE_EXEC_URL_INFO *urlInfo, HSE_EXEC_URL_USER_INFO *userInfo)
{
    EXTENSION_CONTROL_BLOCK *pECB = ws->pECB;
    const char *auth_type;

    auth_type = get_variable(ws, "AUTH_TYPE");
    if (auth_type && !strcmp(auth_type, "Negotiate")) {
        /* If the user is authenticated we need to pass that information in
         * exec_url or the request will return a HTTP status 401.
         */
        memset(userInfo, 0, sizeof(HSE_EXEC_URL_USER_INFO));

        userInfo->pszCustomAuthType = (LPSTR) auth_type;
        userInfo->pszCustomUserName = (LPSTR) get_variable(ws, "AUTH_USER");

        if (!pECB->ServerSupportFunction(pECB->ConnID, HSE_REQ_GET_IMPERSONATION_TOKEN,
                                         &userInfo->hImpersonationToken, NULL, NULL)) {
            WARN("HSE_REQ_GET_IMPERSONATION_TOKEN returned: 0x%08x", GetLastError());
            return -1;
        }
        urlInfo->pUserInfo = userInfo;
    }
    return 0;
}

static int prepare_url_info(struct ws_extra *ws, HSE_EXEC_URL_INFO *urlInfo, HSE_EXEC_URL_USER_INFO *userInfo,
                            short ignore_current)
{
    const char *request_headers;
    char *request_headers_new;

    memset(urlInfo, 0, sizeof(HSE_EXEC_URL_INFO));

    if (prepare_user_info(ws, urlInfo, userInfo)) {
        return -1;
    }

    if (!ws->ssi && !ignore_current) {
        /* Add an X-Dispatcher header to tag the request as already seen
         * by the dispatcher. If we see such a request header during the
         * creation of the response, we know that we are handling embedded
         * content and have to disable chunked encoding.
         */
        if ((request_headers = get_variable(ws, "ALL_RAW")) == NULL) {
            WARN("GetServerVariable(ALL_RAW) returned: %08X", GetLastError());
            return -1;
        }

        request_headers_new = malloc(strlen(request_headers) + strlen(_dispatcher_include) + 1);
        strcpy(request_headers_new, request_headers);
        strcat(request_headers_new, _dispatcher_include);
        urlInfo->pszChildHeaders = request_headers_new;
    } else {
        /* Ignore further calls */
        urlInfo->dwExecUrlFlags = HSE_EXEC_URL_IGNORE_CURRENT_INTERCEPTOR;
    }
    return 0;
}

/**
 * Execute the same URL this extension received, passing this request
 * effectively to the next handler.
 */
static int exec_url(struct dispatcher *d, EXTENSION_CONTROL_BLOCK *pECB, short ignore_current)
{
    HSE_EXEC_URL_INFO urlInfo;
    HSE_EXEC_URL_USER_INFO userInfo;
    int ret = 0;
    struct ws_extra *ws = d->ws;

    DIAG("exec_url(%08X,\"%s\", \"%d\")", pECB->ConnID, pECB->lpszPathInfo, ignore_current);

    if (!pECB->ServerSupportFunction(pECB->ConnID, HSE_REQ_IO_COMPLETION, _io_complete, NULL, NULL)) {
        WARN("HSE_REQ_IO_COMPLETION returned: %08X", GetLastError());
        return -1;
    }

    if (prepare_url_info(ws, &urlInfo, &userInfo, ignore_current)) {
        WARN("Unable to prepare information required for SSI, ignoring recursive invocations.");
        urlInfo.dwExecUrlFlags = HSE_EXEC_URL_IGNORE_CURRENT_INTERCEPTOR;
    }
    if ((urlInfo.dwExecUrlFlags & HSE_EXEC_URL_IGNORE_CURRENT_INTERCEPTOR) != 0) {
        DIAG("exec_url(%08X,\"%s\") -> ignoring current interceptor", pECB->ConnID, pECB->lpszPathInfo);
    }
    if (!pECB->ServerSupportFunction(pECB->ConnID, HSE_REQ_EXEC_URL, &urlInfo, NULL, NULL)) {
        WARN("HSE_REQ_EXEC_URL(%s) returned: %08X", pECB->lpszPathInfo, GetLastError());
        ret = -1;
    }
    if (urlInfo.pszChildHeaders) {
        free(urlInfo.pszChildHeaders);
    }
    return ret;
}

/**
 * Transmit a file directly with some optional headers.
 */
static int transmit_file(EXTENSION_CONTROL_BLOCK *pECB, const char *filename, const char *headers)
{
    HSE_TF_INFO ti;
    wchar_t wfilename[PATH_MAX];

    DIAG("transmit_file(%08X,\"%s\")", pECB->ConnID, filename);

    utf8_to_ucs2(wfilename + 4, filename, PATH_MAX - 4);
    wcsncpy(wfilename, L"\\\\?\\", 4);

    memset(&ti, 0, sizeof ti);
    ti.hFile = CreateFileW(wfilename, GENERIC_READ, FILE_SHARE_READ, 0,
            OPEN_EXISTING, FILE_FLAG_SEQUENTIAL_SCAN | FILE_FLAG_OVERLAPPED, 0);
    if (ti.hFile == INVALID_HANDLE_VALUE) {
        WARN("CreateFileW(%s) returned: %08X", filename, GetLastError());
        return -1;
    }
    ti.pfnHseIO = _io_complete;
    ti.pHead = (PVOID) headers;
    ti.HeadLength = lstrlen(ti.pHead);
    ti.dwFlags = HSE_IO_ASYNC | HSE_IO_SEND_HEADERS;
    ti.pContext = ti.hFile;

    if (!pECB->ServerSupportFunction(pECB->ConnID, HSE_REQ_TRANSMIT_FILE, &ti, NULL, NULL)) {
        WARN("HSE_REQ_TRANSMIT_FILE(%s) returned: %08X", filename, GetLastError());
        return -1;
    }
    return 0;
}

/**
 * Convert authorization header to type <code>Basic</code>,
 * if <code>replaceAuthorization</code> is <code>1</code>.
 *
 * @param ws webserver specific data
 * @param value header value
 *
 * @return new header value or input value if nothing needs to be changed
 */
static const char *basic_auth(struct ws_extra *ws, const char *value)
{
    char base64_in[256], base64_out[256];
    const char *user, *domainsep;

    /* check settings and compatible authorization type */
    if (!_replaceAuthorization || !strncmp(value, "Basic", strlen("Basic"))) {
        return value;
    }
    /* retrieve user name */
    user = get_variable(ws, "LOGON_USER");
    if (!user || *user == '\0') {
        return value;
    }
    /* skip domain name if present */
    domainsep = strchr(user, '\\');
    if (domainsep != 0) {
        user = domainsep + 1;
    }
    /* base64 encode the user name and return as new header value */
    snprintf(base64_in, sizeof(base64_in), "%s:", user);
    base64_enc((unsigned char *) base64_in, base64_out, sizeof(base64_out));
    snprintf(ws->basic_auth, sizeof(ws->basic_auth), "Basic %s", base64_out);
    return ws->basic_auth;
}

/**
 * Write data back to the client.
 */
static int write_client(EXTENSION_CONTROL_BLOCK *pECB, const char *buffer, size_t length)
{
    DWORD dwLastError, dwBytes;

    dwBytes = (DWORD) length;
    if (pECB->WriteClient(pECB->ConnID, (LPVOID) buffer, &dwBytes, HSE_IO_SYNC)) {
        return dwBytes;
    }

    dwLastError = GetLastError();
    INFO("WriteClient() failed: %08X.", dwLastError);

    /* Set WinSock error code for socket_errstring */
    WSASetLastError(dwLastError);
    return -1;
}

/**
 * Writes data back to the client, looping until all bytes are written.
 */
static int write_fully(EXTENSION_CONTROL_BLOCK *pECB, const char *buffer, size_t length)
{
    size_t offset, n;

    offset = 0;
    while (offset < length) {
        if ((n = write_client(pECB, buffer + offset, length - offset)) == -1) {
            return -1;
        }
        offset += n;
    }
    return 0;
}

/**
 * Initializes the internal data structures at the beginning of a request.
 *
 * @param d points to dispatcher
 * @return <code>0</code> if successful
 */
static int initialize_request(struct dispatcher *d)
{
    struct ws_extra *ws = d->ws;
    const char *headers;

    if (create_hashtable(&ws->variables, 100) ||
            create_ptrarray(&ws->req_headers, 50, header_free) ||
            create_hashtable(&ws->req_hdrnames, 20)) {
        return -1;
    }

    ws->out_headers = create_sbuffer(8192);

    if ((headers = get_variable(ws, "ALL_RAW"))) {
        process_headers(d, headers);
    }

    return 0;
}

/**
 * Serve a request.
 *
 * @param d points to dispatcher
 * @return one of the HSE_STATUS codes
 */
static DWORD service_request(struct dispatcher *d)
{
    struct ws_extra *ws = d->ws;
    EXTENSION_CONTROL_BLOCK *pECB = ws->pECB;
    int sc;

#ifdef _DEBUG
    if (!strcmp(get_url(ws), "/break")) {
        DebugBreak();
    }
#endif

    sc = dispatcher_service(d);

    switch (sc) {
    case OK:
        /* send final chunk if necessary */
        if (ws->chunked && write_fully(pECB, "0\r\n\r\n", 5)) {
            send_error(pECB, HTTP_INTERNAL_SERVER_ERROR);
            return HSE_STATUS_ERROR;
        }
        return HSE_STATUS_SUCCESS;
    case DECLINED:
        if (!ws->deliver_ret) {
            /* request was declined but no cache file delivered, which indicates
             * that the dispatcher was denied handling this request in the config.
             * so we call next handler in chain.
             */
            ws->deliver_ret = exec_url(d, pECB, 0) ? HSE_STATUS_ERROR : HSE_STATUS_PENDING;
        }
        return ws->deliver_ret;
    default:
        send_error(pECB, sc);
        return HSE_STATUS_ERROR;
    }
}

/**
 * Terminates the request and releases any data structures held inside
 * the dispatcher server data.
 *
 * @param d points to the dispatcher
 */
static void terminate_request(struct dispatcher *d)
{
    struct ws_extra *ws = d->ws;

    hashtable_free(ws->variables);
    ptrarray_free(ws->req_headers);
    hashtable_free(ws->req_hdrnames);
    sbuffer_free(ws->out_headers);

    free(ws->sline);

    if (TryEnterCriticalSection(&_cs_logf)) {
        rotate_log_if_needed();
        LeaveCriticalSection(&_cs_logf);
    }
}


/*----------------------------------------------------------- Public methods */

void log_out(struct log_context *ctx, enum log_level level, int errnum, const char *format, ...)
{
    va_list args;
    char buf[2048], *p;
    size_t n;

    if (level < LL_ERROR || level > _logLevel) {
        return;
    }

    va_start(args, format);
    memset(buf, 0, sizeof buf);
    if ((n = _vsnprintf(buf, sizeof buf - 1, format, args)) < 0) {
        n = sizeof buf - 1;
    }
    p = &buf[n - 1];
    while (n >= 0 && (*p == '\r' || *p == '\n')) {
        *p-- = '\0';
        n--;
    }
    va_end(args);

    if (_logfd != -1 && !log_to_file(_logfd, level, buf)) {
        /* Message was successfully written */
        return;
    }
    /* Fallback: log to Windows Event Log */
    if (_hEventSource) {
        log_to_eventlog(_hEventSource, level, buf);
        return;
    }

    /* Last resort: log to debugview */
    OutputDebugString(buf);
}

int log_is_enabled(struct log_context *ctx, enum log_level level)
{
    return level <= _logLevel ? 1 : 0;
}

void ws_get_client_info(struct dispatcher *d, struct client_info *info)
{
    struct ws_extra *ws = d->ws;
    const char *s;

    info->method = get_method(ws);
    info->protocol = get_variable(ws, "HTTP_VERSION");
    info->uri = get_url(ws);
    info->host = get_variable(ws, "SERVER_NAME");
    info->query = get_query_string(ws);
    info->via = ws_get_header(d, "via");
    info->client_ip = get_variable(ws, "REMOTE_ADDR");

    s = get_variable(ws, "HTTPS");
    if (s != NULL && !strcmp(s, "on")) {
        info->https = 1;
        s = get_variable(ws, "HTTPS_KEYSIZE");
        if (s != NULL && *s) {
            info->keysize = atoi(s);
        }
    }

    if (ws_get_header(d, "x-dispatcher-include")) {
        ws->ssi = 1;
    }
}

const char *ws_get_header(struct dispatcher *d, const char *name)
{
    struct ws_extra *ws = d->ws;

    return (const char *) hashtable_get(ws->req_hdrnames, name);
}

void ws_get_pt_headers(struct dispatcher *d, struct slist *names, struct hdrarray *headers)
{
    struct ws_extra *ws = d->ws;
    const char *name, *value, **varname;
    struct header **p;

    if (names) {
        /* just return the ones requested */
        while (names) {
            if ((value = ws_get_header(d, names->s)) != NULL) {
                if (!strcasecmp(names->s, "authorization")) {
                    value = basic_auth(ws, value);
                }
                hdrarray_add(headers, names->s, value);
            }
            names = names->next;
        }
    } else {
        /* no restriction: return all end-to-end headers */
        for (p = (struct header **) ptrarray_get(ws->req_headers); *p; p++) {
            name = (*p)->name;
            value = (*p)->value;

            if (!is_hop_by_hop_header(name)) {
                if (!strcasecmp(name, "authorization")) {
                    value = basic_auth(ws, value);
                }
                hdrarray_add(headers, name, value);
            }
        }
    }

    /* spool all IIS server variables if flag is set */
    if (_serverVariables) {
        for (varname = _variables; *varname; varname++) {
            value = get_variable(d->ws, *varname);
            if (value && *value) {
                hdrarray_add(headers, *varname, value);
            }
        }
    }
}

int ws_net_read(struct dispatcher *d, void *p, size_t n, int *sc)
{
    struct ws_extra *ws = d->ws;
    EXTENSION_CONTROL_BLOCK *pECB = ws->pECB;
    DWORD size;

    if (d->read < pECB->cbAvailable) {
        /* Spool content of buffer first */
        size = pECB->cbAvailable - d->read;
        if (size > n) {
            size = (DWORD) n;
        }
        memcpy(p, pECB->lpbData + d->read, size);
    } else if (pECB->cbTotalBytes == 0xFFFFFFFF || d->read < pECB->cbTotalBytes) {
        /* Read remaining data from client itself */
        size = (DWORD) n;
        if (!pECB->ReadClient(pECB->ConnID, p, &size)) {
            DBG("ReadClient returned: %08X", GetLastError());
            return -1;
        }
    } else {
        /* No more bytes available */
        return 0;
    }
    d->read += size;
    return (int) size;
}

int ws_get_cache_action(struct dispatcher *d)
{
    return 0;
}

void ws_deliver(struct dispatcher *d)
{
    struct ws_extra *ws = d->ws;
    EXTENSION_CONTROL_BLOCK *pECB = ws->pECB;
    char msg[256];

    /* Show info about cache action decision */
    if (d->tell_reason) {
        cache_get_info(d->action, d->reason, msg, sizeof msg, 1);
        ws_set_header(d, "X-Cache-Info", msg);
    }

    if (d->farm->cache) {
        cache_deliver(d->farm->cache, d);
    }

    if (sbuffer_len(ws->out_headers) > 0) {
        /* if we have some response headers  we must transmit the file
         * instead of executing or the headers will be lost. */
        sbuffer_append(ws->out_headers, "\r\n");
        if (transmit_file(pECB, d->cachepath, sbuffer_to_string(ws->out_headers))) {
            ws->deliver_ret = HSE_STATUS_ERROR;
            return;
        }
    } else if (exec_url(d, pECB, 0)) {
        ws->deliver_ret = HSE_STATUS_ERROR;
        return;
    }
    ws->deliver_ret = HSE_STATUS_PENDING;
}

int ws_set_status(struct dispatcher *d, int status, const char *sline)
{
    struct ws_extra *ws = d->ws;
    const char *space;

    DBG("response.status = %d", status);

    if ((space = strchr(sline, ' '))) {
        sline = space + 1;
    }
    ws->pECB->dwHttpStatusCode = d->status = status;
    ws->sline = strdup(sline);

    return 0;
}

int ws_set_header(struct dispatcher *d, const char *name, const char *value)
{
    struct ws_extra *ws = d->ws;
    char hline[4096];

    DBG("response.headers[%s] = \"%s\"", name, value);

    if (!strcasecmp("content-length", name)) {
        ws->has_clen = 1;
    }
    snprintf(hline, sizeof(hline), "%s: %s\r\n", name, value);
    sbuffer_append(ws->out_headers, hline);

    return 0;
}

int ws_start_response(struct dispatcher *d)
{
    struct ws_extra *ws = d->ws;
    EXTENSION_CONTROL_BLOCK *pECB = ws->pECB;
    char msg[256];

    /* Show info about cache action decision */
    if (d->tell_reason) {
        cache_get_info(d->action, d->reason, msg, sizeof msg, 1);
        ws_set_header(d, "X-Cache-Info", msg);
    }

    if (!ws->has_clen && !ws->ssi && enable_chunked_transfer) {
        /* Switch on chunked encoding */
        sbuffer_append(ws->out_headers, "Transfer-Encoding: Chunked\r\n");
        ws->chunked = 1;
    }
    sbuffer_append(ws->out_headers, "\r\n");

    /* Upon invocation of this callback, the request will definitely not be
     * declined by the dispatcher, so we must send the response status
     * and headers before starting to write the response body */
    return send_response(pECB, ws->sline, sbuffer_to_string(ws->out_headers), 1);
}

int ws_net_write(struct dispatcher *d, const char *buffer, size_t length)
{
    struct ws_extra *ws = d->ws;
    EXTENSION_CONTROL_BLOCK *pECB = ws->pECB;
    char chunk_len[10];

    DIAG("ws_net_write(%08X,0x%p,%d)", pECB->ConnID, buffer, length);

    if (ws->chunked) {
        /* limit chunk size */
        if (length > 32768) {
            length = 32768;
        }
        snprintf(chunk_len, sizeof chunk_len, "%04X\r\n", length);
        if (write_fully(pECB, chunk_len, (int) strlen(chunk_len))) {
            return -1;
        }
    }
    if (write_fully(pECB, buffer, length)) {
        return -1;
    }
    d->written += (unsigned long) length;

    if (ws->chunked && write_fully(pECB, "\r\n", 2)) {
        return -1;
    }
    return 0;
}

int ws_net_flush(struct dispatcher *d)
{
    /* Unable to do this in an ISAPI extension */
    return 0;
}

void ws_log_request(struct dispatcher *d, const char *method, const char *uri,
                    const char *query, const char *status, const char *cache_info,
                    long req_ms, const char *farm_label, const char *backend_label)
{
    if (query) {
        INFO("\"%s %s?%s\" %s %s [%s/%s] %ldms", method, uri, query, status, cache_info,
             farm_label, backend_label, req_ms);
    } else {
        INFO("\"%s %s\" %s %s [%s/%s] %ldms", method, uri, status, cache_info, farm_label,
             backend_label, req_ms);
    }
}

/*------------------------------------------------------- ISAPI entry points */


BOOL WINAPI GetExtensionVersion(HSE_VERSION_INFO * pVer)
{
    DIAG("GetExtensionVersion().");

    pVer->dwExtensionVersion = MAKELONG(HSE_VERSION_MINOR, HSE_VERSION_MAJOR);
    strcpy(pVer->lpszExtensionDesc, "Communique IIS Dispatcher");
    return initialize();
}

DWORD WINAPI HttpExtensionProc(EXTENSION_CONTROL_BLOCK *pECB)
{
    struct dispatcher d;
    struct ws_extra ws;
    DWORD ret;
    WORD majorVersion;

    DIAG("--> HttpExtensionProc(%08X) \"%s\"", pECB->ConnID, pECB->lpszPathInfo);

    majorVersion = HIWORD(pECB->dwVersion);
    if (majorVersion < 8) {
        ERR(NULL, "IIS Version 8 or higher required, actual: %d.%d", majorVersion, LOWORD(pECB->dwVersion));
        return HSE_STATUS_ERROR;
    }

    memset(&d, 0, sizeof(struct dispatcher));
    memset(&ws, 0, sizeof(ws));

    d.ws = &ws;
    d.config = &dispatcher_config;
    ws.pECB = pECB;

    initialize_request(&d);
    ret = service_request(&d);
    terminate_request(&d);

    DIAG("<-- HttpExtensionProc(%08X) \"%s\": %d", pECB->ConnID,
        pECB->lpszPathInfo, ret);

    return ret;
}

BOOL WINAPI TerminateExtension(DWORD dwFlags)
{
    struct dispatcher d;
    struct ws_extra ws;

    DIAG("TerminateExtension(%d).", dwFlags);

    memset(&d, 0, sizeof(struct dispatcher));
    memset(&ws, 0, sizeof(ws));

    d.ws = &ws;

    terminate(&d);
    return TRUE;
}
