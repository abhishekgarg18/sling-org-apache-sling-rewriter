# Development

My favorite IDE is Visual Studio Code, although that might change in the future
(it did a couple times in the past).

In this document I'll quickly explain how to set up that
IDE and debug the dispatcher module inside Apache on **macOS**.

## Installing Visual Studio Code and extensions

Head over to [Visual Studio Code](https://code.visualstudio.com/), download and
install the IDE.

Start the IDE, and add the following 2 extensions:
* C/C++ (version 0.21.0 or higher)
* CMake Tools (version 1.1.3 or higher)

## Create a debugging configuration for Apache

With Apache installed by `brew`, add the following launch configuration in the *Debug* section
on the left side navigation:
```
{
  "version": "0.2.0",
  "configurations": [
    {
      "name": "Apache",
      "type": "cppdbg",
      "request": "launch",
      "program": "/usr/local/opt/httpd/bin/httpd",
      "args": [ "-X" ],
      "stopAtEntry": false,
      "cwd": "${workspaceFolder}",
      "environment": [],
      "externalConsole": false,
      "MIMode": "lldb"
    }
  ]
}
```
The `-X` argument tells Apache to start in foreground mode which is required for debugging.

## Start debugging

Add a breakpoint in `disp_apache2.c` at the beginning of the `dispatcher_handler` section,
start the debugger, and request a page from your browser or `curl` in a terminal window.


IMPORTANT NOTE - Due to a bug in MacOS Catalina, it's possible that debugging doesn't work on Mac. In such case, please use CodeLLDB extension, configure launch.json accordingly and you are good to go.
