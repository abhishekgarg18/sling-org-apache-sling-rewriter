/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2019 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

#include <check.h>
#include <stdint.h>
#include <stdlib.h>

#include "base/base.h"
#include "dispatcher/dispatcher.h"
#include "dispatcher/farm.h"

#include "check_optional.h"
#include "ws_extra.h"

/**
 * Our log context.
 */
static struct log_context *lc = NULL;

/**
 * Our dispatcher configuration.
 */
static const char *config_s =
    "/farms {"
    "  /everything_else {"
    "    /clientheaders { \"*\" }"
    "    /virtualhosts { \"*\" }"
    "    /renders {"
    "      /0 { /hostname \"${AEM_HOST}\" /port \"${AEM_PORT}\" }"
    "    }"
    "    /filter {"
    "      /0 { /type \"deny\" /glob \"*\" }"
    "      /1 { /type \"allow\" /url \"/content/*\" }"
    "    }"
    "  }"
    "  /products {"
    "    /clientheaders { \"*\" }"
    "    /virtualhosts { \"*/products/*\" }"
    "    /renders {"
    "      /0 { /hostname \"${AEM_HOST}\" /port \"${AEM_PORT}\" }"
    "    }"
    "    /filter {"
    "      /0 { /type \"deny\" /glob \"*\" }"
    "      /1 { /type \"allow\" /url \"/content/*\" }"
    "    }"
    "  }"
    "  /secure_products {"
    "    /clientheaders { \"*\" }"
    "    /virtualhosts { \"https://*/products/*\" }"
    "    /renders {"
    "      /0 { /hostname \"${AEM_HOST}\" /port \"${AEM_PORT}\" }"
    "    }"
    "    /filter {"
    "      /0 { /type \"deny\" /glob \"*\" }"
    "      /1 { /type \"allow\" /url \"/content/*\" }"
    "    }"
    "  }"
    "}";

static void setupEach(void)
{
    setupDispatcher(lc, config_s);
}

static void teardownEach(void)
{
    teardownDispatcher();
}

struct protocol_valid {
    const char *protocol;
    int valid;
} protocol_valid[] = {
    { "HTTP", 0 },
    { "HTTP/", 0 },
    { "HTTP/0.9", 1 },
    { "HTTP/1.1", 1 },
    { "HTTP/1.1 ", 0 },
    { "HTTP/2", 1 },
    { "HTTP/2.0", 1 },
    { NULL, 0 }
};

START_TEST(test_validate)
{
    struct ws_extra *ws;
    struct protocol_valid *pv;
    int rv;

    // check HTTP protocols above and their validity
    for (pv = &protocol_valid[0]; pv->protocol != NULL; pv++) {
        ws = create_get(lc, "/");
        ws->protocol = pv->protocol;
        rv = dispatcher_service(&ws->d);
        if (!pv->valid) {
            ck_assert_int_eq(rv, HTTP_BAD_REQUEST);
        } else {
            ck_assert_int_ne(rv, HTTP_BAD_REQUEST);
        }
        free_request(ws);
    }

    // check legacy HTTP method is no longer accepted
    ws = create_get(lc, "/");
    ws->method = "SYND_POST";
    rv = dispatcher_service(&ws->d);
    ck_assert_int_eq(rv, HTTP_BAD_REQUEST);
    free_request(ws);
}
END_TEST

START_TEST(test_filter)
{
    struct ws_extra *ws;
    int rv;

    // check filter rules are applied
    ws = create_get(lc, "/");
    rv = dispatcher_service(&ws->d);
    ck_assert_int_eq(rv, DECLINED);
    ck_assert_int_eq(ws->d.rejected, 1);
    free_request(ws);
}
END_TEST

START_TEST(test_map)
{
    struct ws_extra *ws;

    // check URIs mapping rules in /virtualhosts are applied
    ws = create_get(lc, "/products/gloves.html");
    dispatcher_service(&ws->d);
    ck_assert_str_eq(ws->d.farm->label, "products");
    free_request(ws);

    ws = create_get(lc, "/products/gloves.html");
    ws->https = 1;
    dispatcher_service(&ws->d);
    ck_assert_str_eq(ws->d.farm->label, "secure_products");
    free_request(ws);

    ws = create_get(lc, "/about.html");
    dispatcher_service(&ws->d);
    ck_assert_str_eq(ws->d.farm->label, "everything_else");
    free_request(ws);
}
END_TEST

static Suite *suite(void)
{
    Suite *s;
    TCase *tc;

    s = suite_create("Dispatcher");

    tc = tcase_create("Dispatcher");
    tcase_add_unchecked_fixture(tc, setupDocroot, teardownDocroot);
    tcase_add_checked_fixture(tc, setupEach, teardownEach);
    tcase_add_test(tc, test_validate);
    tcase_add_test(tc, test_filter);
    tcase_add_test(tc, test_map);
    suite_add_tcase(s, tc);

    return s;
}

int main(void)
{
    int number_failed;
    Suite *s;
    SRunner *sr;

    log_init(&lc, parse_log_level(getenv("LOG_LEVEL"), LL_WARN), NULL);

    if (getenv("AEM_HOST") == NULL || getenv("AEM_PORT") == NULL) {
        printf("Environment variables AEM_HOST and/or AEM_PORT are missing.\n");
        return EXIT_FAILURE;
    }

    s = suite();
    sr = srunner_create(s);

    srunner_run_all(sr, CK_NORMAL);
    number_failed = srunner_ntests_failed(sr);
    srunner_free(sr);
    return (number_failed == 0) ? EXIT_SUCCESS : EXIT_FAILURE;
}

