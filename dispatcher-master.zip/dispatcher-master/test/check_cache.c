/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2019 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

#include <check.h>
#include <stdint.h>
#include <stdlib.h>

#include "base/base.h"
#include "dispatcher/dispatcher.h"
#include "dispatcher/cache.h"

#include "check_optional.h"
#include "ws_extra.h"

/**
 * Our log context.
 */
static struct log_context *lc = NULL;

/**
 * Our dispatcher configuration.
 */
static const char *config_s =
    "/farms {"
    "  /0 {"
    "    /numberOfRetries \"1\""
    "    /clientheaders { \"*\" }"
    "    /renders {"
    "      /0 { /hostname \"${AEM_HOST}\" /port \"${AEM_PORT}\" }"
    "    }"
    "    /filter {"
    "      /0 { /type \"deny\" /glob \"*\" }"
    "      /1 { /type \"allow\" /url \"/content/*\" }"
    "      /2 { /type \"allow\" /url \"/etc.clientlibs/*\" /suffix '.*\\.(css|js|woff2)' }"
    "    }"
    "    /cache {"
    "      /docroot \"${PUBLISH_DOCROOT}\""
    "      /rules {"
    "        /0 { /type \"allow\" /glob \"*\" }"
    "      }"
    "      /invalidate {"
    "        /0 { /type \"deny\" /glob \"*\" }"
    "        /1 { /type \"allow\" /glob \"*.html\" }"
    "      }"
    "      /ignoreUrlParams {"
    "        /0 { /type \"deny\" /glob \"*\" }"
    "        /1 { /type \"allow\" /glob \"ignore\" }"
    "      }"
    "      /allowedClients {"
    "        /0 { /type \"deny\" /glob \"*\" }"
    "        /1 { /type \"allow\" /glob \"127.0.0.1\" }"
    "      }"
    "    }"
    "  }"
    "}";

static void setupEach(void)
{
    setupDispatcher(lc, config_s);
}

static void teardownEach(void)
{
    teardownDispatcher();
}

START_TEST(test_cache_hit)
{
    struct ws_extra *ws;
    int i;

    // check second request to same cacheable resource hits cache
    for (i = 0; i < 2; i++) {
        ws = create_get(lc, "/content/we-retail/us/en.html");
        dispatcher_service(&ws->d);
        if (i == 1) {
            ck_assert_int_eq(ws->d.action, CACHE_ACTION_DELIVER);
        }
        free_request(ws);
    }
}
END_TEST

START_TEST(test_private_file)
{
    struct ws_extra *ws;
    struct stat st;
    int rv;

    // invalidate some resource
    ws = create_flush(lc, "/content/else");
    dispatcher_service(&ws->d);
    free_request(ws);

    // check .stat file was created
    rv = stat_cache("/.stat", &st);
    ck_assert_int_eq(rv, 0);

    // check .stat file does not get served
    ws = create_get(lc, "/.stat");
    rv = dispatcher_service(&ws->d);
    ck_assert_int_eq(HTTP_NOT_FOUND, rv);
    free_request(ws);
}
END_TEST

START_TEST(test_flush)
{
    struct ws_extra *ws;
    int rv;

    ws = create_flush(lc, "/content/we-retail/us/en");
    rv = dispatcher_service(&ws->d);

    // check action is purged
    ck_assert_int_eq(OK, rv);
    ck_assert_int_eq(ws->d.action, CACHE_ACTION_PURGED);
    free_request(ws);

    ws = create_flush(lc, "/content/we-retail/us/en");
    ws->client_ip = "10.250.118.128";
    rv = dispatcher_service(&ws->d);

    // check flush from IP other than localhost is denied
    ck_assert_int_eq(HTTP_FORBIDDEN, rv);
    free_request(ws);
}
END_TEST

START_TEST(test_invalidate)
{
    struct ws_extra *ws;

    // cache a resource
    ws = create_get(lc, "/content/we-retail/us/en.html");
    dispatcher_service(&ws->d);
    fail_if(ws->d.action != CACHE_ACTION_CREATE && ws->d.action != CACHE_ACTION_DELIVER);
    free_request(ws);

    // sleep for 1 second (or time difference between stat file and cache is too small)
    sleep(1);

    // make an unrelated activation
    ws = create_flush(lc, "/content/else");
    dispatcher_service(&ws->d);
    free_request(ws);

    // verify cache is stale
    ws = create_get(lc, "/content/we-retail/us/en.html");
    dispatcher_service(&ws->d);
    ck_assert_int_eq(ws->d.action, CACHE_ACTION_CREATE);
    free_request(ws);
}
END_TEST

START_TEST(test_refetch)
{
    struct ws_extra *ws;
    struct stat st;
    int rv;

    // flush resource and refetch immediately
    ws = create_flush(lc, "/content/we-retail/us/en");
    add_refetch_uri(ws, "/content/we-retail/us/en.html");
    rv = dispatcher_service(&ws->d);

    // check action is purged
    ck_assert_int_eq(OK, rv);
    ck_assert_int_eq(ws->d.action, CACHE_ACTION_PURGED);
    free_request(ws);

    // verify resource is still cached
    rv = stat_cache("/content/we-retail/us/en.html", &st);
    ck_assert_int_eq(rv, 0);
}
END_TEST

START_TEST(test_refetch_query)
{
    struct ws_extra *ws;
    struct stat st;
    int rv;

    // flush resource and refetch immediately, with some query string
    ws = create_flush(lc, "/content/we-retail/us/en");
    add_refetch_uri(ws, "/content/we-retail/us/en.html?what=about");
    rv = dispatcher_service(&ws->d);

    // check action is purged
    ck_assert_int_eq(OK, rv);
    ck_assert_int_eq(ws->d.action, CACHE_ACTION_PURGED);
    free_request(ws);

    // verify resource couldn't be refetched because of query
    rv = stat_cache("/content/we-retail/us/en.html", &st);
    ck_assert_int_eq(rv, -1);
}
END_TEST

START_TEST(test_refetch_ignore_query)
{
    struct ws_extra *ws;
    struct stat st;
    int rv;

    // flush resource and refetch immediately, with some query string
    ws = create_flush(lc, "/content/we-retail/us/en");
    add_refetch_uri(ws, "/content/we-retail/us/en.html?ignore=me");
    rv = dispatcher_service(&ws->d);

    // check action is purged
    ck_assert_int_eq(OK, rv);
    ck_assert_int_eq(ws->d.action, CACHE_ACTION_PURGED);
    free_request(ws);

    // verify resource could be refetched because query was ignored
    rv = stat_cache("/content/we-retail/us/en.html", &st);
    ck_assert_int_eq(rv, 0);
}
END_TEST

START_TEST(test_ignore_query)
{
    struct ws_extra *ws;

    // cache a resource
    ws = create_get(lc, "/content/we-retail/us/en.html");
    dispatcher_service(&ws->d);
    fail_if(ws->d.action != CACHE_ACTION_CREATE && ws->d.action != CACHE_ACTION_DELIVER);
    free_request(ws);

    // request the same resource with a query string that gets ignored
    ws = create_get(lc, "/content/we-retail/us/en.html?ignore=me");
    dispatcher_service(&ws->d);
    ck_assert_int_eq(ws->d.action, CACHE_ACTION_DELIVER);
    free_request(ws);
}
END_TEST

static Suite *suite(void)
{
    Suite *s;
    TCase *tc;

    s = suite_create("Cache");

    tc = tcase_create("Cache");
    tcase_set_timeout(tc, 10);
    
    tcase_add_unchecked_fixture(tc, setupDocroot, teardownDocroot);
    tcase_add_checked_fixture(tc, setupEach, teardownEach);
    tcase_add_test(tc, test_cache_hit);
    tcase_add_test(tc, test_private_file);
    tcase_add_test(tc, test_flush);
    tcase_add_test(tc, test_invalidate);
    tcase_add_test(tc, test_ignore_query);
    tcase_add_test(tc, test_refetch);
    tcase_add_test(tc, test_refetch_query);
    tcase_add_test(tc, test_refetch_ignore_query);
    suite_add_tcase(s, tc);

    return s;
}

int main(void)
{
    int number_failed;
    Suite *s;
    SRunner *sr;

    log_init(&lc, parse_log_level(getenv("LOG_LEVEL"), LL_WARN), NULL);

    if (getenv("AEM_HOST") == NULL || getenv("AEM_PORT") == NULL) {
        printf("Environment variables AEM_HOST and/or AEM_PORT are missing.\n");
        return EXIT_FAILURE;
    }

    s = suite();
    sr = srunner_create(s);

    srunner_run_all(sr, CK_NORMAL);
    number_failed = srunner_ntests_failed(sr);
    srunner_free(sr);
    return (number_failed == 0) ? EXIT_SUCCESS : EXIT_FAILURE;
}

