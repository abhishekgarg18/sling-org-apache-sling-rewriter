/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2019 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

#include <check.h>
#include <stdint.h>
#include <stdlib.h>

#include "base/base.h"
#include "dispatcher/dispatcher.h"
#include "dispatcher/cache.h"

#include "check_optional.h"
#include "ws_extra.h"

/**
 * Our log context.
 */
static struct log_context *lc = NULL;

/**
 * Our dispatcher configuration.
 */
static const char *config_s =
    "/farms {"
    "  /0 {"
    "    /numberOfRetries \"1\""
    "    /clientheaders { \"*\" }"
    "    /renders {"
    "      /0 { /hostname \"${AEM_HOST}\" /port \"${AEM_PORT}\" }"
    "    }"
    "    /filter {"
    "      /0 { /type \"deny\" /glob \"*\" }"
    "      /1 { /type \"allow\" /url \"/content/*\" }"
    "      /2 { /type \"allow\" /url \"/etc.clientlibs/*\" /suffix '.*\\.(css|js|woff2)' }"
    "    }"
    "    /cache {"
    "      /docroot \"${PUBLISH_DOCROOT}\""
    "      /rules {"
    "        /0 { /type \"allow\" /glob \"*\" }"
    "      }"
    "      /headers {"
    "        \"Cache-Control\""
    "        \"Content-Disposition\""
    "        \"Content-Type\""
    "        \"Expires\""
    "        \"Last-Modified\""
    "        \"X-Content-Type-Options\""
    "      }"
    "      /invalidate {"
    "        /0 { /type \"deny\" /glob \"*\" }"
    "        /1 { /type \"allow\" /glob \"*.html\" }"
    "      }"
    "    }"
    "  }"
    "}";

static void setupEach(void)
{
    setupDispatcher(lc, config_s);
}

static void teardownEach(void)
{
    teardownDispatcher();
}

START_TEST(test_private_file)
{
    struct ws_extra *ws;
    struct stat st;
    int rv;

    // fetch resource that generates .h file
    ws = create_get(lc, "/content/we-retail/us/en.html");
    dispatcher_service(&ws->d);
    fail_if(ws->d.action != CACHE_ACTION_CREATE && ws->d.action != CACHE_ACTION_DELIVER);
    free_request(ws);

    // check private file was generated
    rv = stat_cache("/content/we-retail/us/en.html.h", &st);
    ck_assert_int_eq(rv, 0);

    // check private file does not get served
    ws = create_get(lc, "/content/we-retail/us/en.html.h");
    rv = dispatcher_service(&ws->d);
    ck_assert_int_eq(HTTP_NOT_FOUND, rv);
    free_request(ws);
}
END_TEST

static Suite *suite(void)
{
    Suite *s;
    TCase *tc;

    s = suite_create("Cache Headers");

    tc = tcase_create("Cache Headers");
    tcase_add_unchecked_fixture(tc, setupDocroot, teardownDocroot);
    tcase_add_checked_fixture(tc, setupEach, teardownEach);
    tcase_add_test(tc, test_private_file);
    suite_add_tcase(s, tc);

    return s;
}

int main(void)
{
    int number_failed;
    Suite *s;
    SRunner *sr;

    log_init(&lc, parse_log_level(getenv("LOG_LEVEL"), LL_WARN), NULL);

    if (getenv("AEM_HOST") == NULL || getenv("AEM_PORT") == NULL) {
        printf("Environment variables AEM_HOST and/or AEM_PORT are missing.\n");
        return EXIT_FAILURE;
    }

    s = suite();
    sr = srunner_create(s);

    srunner_run_all(sr, CK_NORMAL);
    number_failed = srunner_ntests_failed(sr);
    srunner_free(sr);
    return (number_failed == 0) ? EXIT_SUCCESS : EXIT_FAILURE;
}

