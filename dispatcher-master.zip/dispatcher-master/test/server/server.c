/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2019 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

#include "base/base.h"

#include "request.h"

/**
 * Global log context
 */
static struct log_context *lc;

/**
 * Document root
 */
static const char *docroot = NULL;

/**
 * Listener port.
 */
static int port = 0;

static int parse_args(int argc, char *argv[])
{
    struct stat st;
    char *endptr;
    int i;

    for (i = 1; i < argc; i++) {
        char *arg = argv[i];

        if (strlen(arg) != 2 || arg[0] != '-') {
            break;
        }
        switch (arg[1]) {
        case 'd':
            if (i == argc) {
                printf("** missing argument to %s\n", arg);
                return -1;
            }
            docroot = argv[++i];
            if (stat(docroot, &st) || !S_ISDIR(st.st_mode)) {
                printf("** document root not found: %s\n", arg);
                return -1;
            }
            break;
        case 'h':
            printf("Usage: %s [options...]\n"
                   "Options:\n"
                   "  -d document root\n"
                   "  -l port to listen on\n",
                   argv[0]);
            return -1;
            break;
        case 'l':
            if (i == argc) {
                printf("** missing argument to %s\n", arg);
                return -1;
            }
            port = strtol(argv[++i], &endptr, 10);
            if (*endptr != 0) {
                printf("** bad numeric arument for port: %s\n", arg);
            }
            break;
        default:
            printf("** unknown option: %s\n", arg);
            return -1;
        }
    }
    return i;
}

static int map_url_to_file(const char *url, char *file, struct stat *st)
{
    size_t docroot_len = strlen(docroot), url_len = strlen(url), total_len;
    char buf[256];
    ssize_t link_len;

    total_len = docroot_len + url_len + 1;
    if (total_len > PATH_MAX) {
        return -1;
    }
    snprintf(file, PATH_MAX, "%s%s", docroot, url);

    if (lstat(file, st)) {
        return -1;
    }
    if (S_ISLNK(st->st_mode)) {
        if ((link_len = readlink(file, buf, sizeof buf - 1)) == -1) {
            return -1;
        }
        buf[link_len] = 0;
        snprintf(file, PATH_MAX, "/%s", buf);
        return 0;
    }
    if (S_ISDIR(st->st_mode)) {
        if (url_len == 0 || url[url_len - 1] != '/') {
            snprintf(file, PATH_MAX, "%s/", url);
        } else {
            snprintf(file, PATH_MAX, "%sindex.html", url);
        }
        return 0;
    }
    if (S_ISREG(st->st_mode)) {
        return 0;
    }
    return -1;
}

static int handler(struct http_request *req, struct request_info *info)
{
    char file[PATH_MAX];
    struct stat st;

    if (strcasecmp(info->method, "GET") != 0) {
        return http_request_send_error(req, 405, NULL);
    }
    if (docroot == NULL) {
        return http_request_send_error(req, 500, NULL);
    }
    if (map_url_to_file(info->url, file, &st)) {
        INFO("Unable to map URL to file: %s", info->url);
        return -1;
    }
    if (S_ISLNK(st.st_mode) || S_ISDIR(st.st_mode)) {
        return http_request_send_redirect(req, file);
    }
    return http_request_send_file(req, file);
}

static void doprocessing(int sock)
{
    struct http_request *req;

    req = create_http_request(lc, sock);
    http_request_handle(req, handler);
    http_request_free(req);
}

int main(int argc, char *argv[])
{
    int sockfd, newsockfd, enable;
    socklen_t clilen, servlen;
    struct sockaddr_in serv_addr, cli_addr;
    pid_t pid;

    log_init(&lc, parse_log_level(getenv("LOG_LEVEL"), LL_INFO), NULL);

    if (parse_args(argc, argv) < 0) {
        exit(1);
    }

    /* First call to socket() function */
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        perror("ERROR opening socket");
        exit(1);
    }

    /* Reuse same address */
    enable = 1;
    if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &enable, sizeof(enable)) < 0) {
        perror("ERROR setting socket option");
        exit(1);
    }

    /* Initialize socket structure */
    bzero((char *) &serv_addr, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    serv_addr.sin_port = htons(port);

    /* Now bind the host address using bind() call.*/
    if (bind(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0) {
        perror("ERROR on binding");
        exit(1);
    }

    servlen = sizeof(serv_addr);
    if (getsockname(sockfd, (struct sockaddr *) &serv_addr, &servlen) < 0) {
        perror("ERROR on getsockname");
        exit(1);
    }

    /* Propagate our port selected if it was random */
    if (port == 0) {
        printf("%d\n", ntohs(serv_addr.sin_port));
    }
    fflush(stdout);

    /* Now start listening for the clients, here
     * process will go in sleep mode and will wait
     * for the incoming connection
     */
    listen(sockfd, 5);
    clilen = sizeof(cli_addr);

    for (;;) {
        newsockfd = accept(sockfd, (struct sockaddr *) &cli_addr, &clilen);
        if (newsockfd < 0) {
            perror("ERROR on accept");
            exit(1);
        }

        /* Fork handler */
        switch ((pid = fork())) {
            case -1:
                /* an error occurred */
                perror("ERROR on fork");
                exit(1);
                break;
            case 0:
                /* child process */
                close(sockfd);
                doprocessing(newsockfd);
                close(newsockfd);
                exit(0);
                break;
            default:
                /* parent process */
                close(newsockfd);
                break;
        }
    }
}