/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2019 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

#include "base/base.h"

#include "request.h"

/**
 * A structure holding a character buffer.
 */
struct buffer {
    /* input buffer */
    char buf[65536];
    /* current position */
    int pos;
    /* total available bytes */
    int count;
};

/**
 * A structure holding a request.
 */
struct http_request {
    /** log context */
    struct log_context *lc;
    /** message */
    char msg[256];
    /** socket */
    int socket;

    /** buffer */
    struct buffer in;
    /** request line */
    char *rline;
    /** method */
    char *method;
    /** url */
    char *url;
    /** query */
    char *query;
    /** request headers */
    struct http_headers *req_headers;

    /** response status */
    int status;
    /** response headers */
    struct http_headers *res_headers;
};

/**
 * Parse states.
 */
#define PS_PRE 0
#define PS_INIT 1
#define PS_START 2
#define PS_BEFORE_LF 3
#define PS_BEFORE_CR_2 4
#define PS_BEFORE_LF_2 5
#define PS_HEADER 6
#define PS_FINISHED 7

/**
 * Read more bytes from the underlying socket.
 *
 * @param req request
 *
 * @return number of bytes read if successful;
 *         <code>-1</code> otherwise
 */
static int read_bytes(struct http_request *req)
{
    struct log_context *lc = req->lc;
    struct buffer *in = &req->in;
    int read;

    if ((read = recv(req->socket, in->buf, sizeof in->buf, 0)) < 0) {
        ERR("Reading from remote peer failed: %s", strerror(errno));
        return -1;
    }
    in->pos = 0;
    in->count = read;
    return read;
}

/**
 * Add a request header to our internal structure
 *
 * @param req request
 * @param line header line
 */
static void add_request_header(struct http_request *req, char *line)
{
    struct http_header *header;

    header = http_headers_add(req->req_headers, line);
    if (header != NULL) {
        // TODO: if header value is important
    }
}

/**
 * Set the request line in our internal structure
 *
 * @param req request
 * @param line request line
 *
 * @return <code>0</code> read if successful;
 *         <code>-1</code> otherwise
 */
static int set_request_line(struct http_request *req, const char *line)
{
    const char *p, *q;

    req->rline = strdup(line);

    for (p = line; *p && !WS(*p); p++)
        ;

    req->method = strnumdup(line, p - line);

    while (*p && WS(*p)) {
        p++;
    }
    if (!(*p)) {
        // no url
        return -1;
    }
    for (q = p; *q && !WS(*q); q++)
        ;
    req->url = strnumdup(p, q - p);

    if ((req->query = strchr(req->url, '?')) != NULL) {
        *req->query++ = 0;
    }
    return 0;
}

/**
 * Parse an incoming request.
 *
 * @param req request
 * @param line request line
 *
 * @return <code>0</code> if successful;
 *         <code>-1</code> otherwise
 */
static int parse_request(struct http_request *req)
{
    struct buffer *in = &req->in;
    char ch, *buf, line[8192];
    const int line_len = sizeof(line);
    int state, writeptr, read;
    const char *error;

    state = PS_PRE;
    buf = in->buf;
    writeptr = 0;
    error = NULL;

    while (state != PS_FINISHED && error == NULL) {
        if (in->pos >= in->count) {
            if ((read = read_bytes(req)) == 0) {
                error = "no more bytes available (remote peer closed connection)";
                break;
            } else if (read < 0) {
                break;
            }
        }
        ch = buf[in->pos++];

        switch (state) {
        case PS_PRE:
            state = PS_INIT;
            /* fall through */
        case PS_INIT:
            if (!WS(ch)) {
                line[writeptr++] = ch;
                state = PS_START;
            }
            break;
        case PS_START:
            if (ch == '\r' || ch == '\n') {
                line[writeptr] = '\0';
                set_request_line(req, line);
                writeptr = 0;
                if (ch == '\r') {
                    state = PS_BEFORE_LF;
                } else if (ch == '\n') {
                    state = PS_BEFORE_CR_2;
                }
            } else if (writeptr >= line_len) {
                error = "request line too long";
            } else {
                line[writeptr++] = ch;
            }
            break;
        case PS_BEFORE_LF:
            if (ch == '\n') {
                state = PS_BEFORE_CR_2;
            } else if (ch == '\r') {
                state = PS_FINISHED;
            }
            break;
        case PS_BEFORE_CR_2:
            if (ch == '\r') {
                state = PS_BEFORE_LF_2;
            } else if (ch == '\n') {
                state = PS_FINISHED;
            } else {
                state = PS_HEADER;
                line[writeptr++] = ch;
            }
            break;
        case PS_BEFORE_LF_2:
            if (ch == '\n') {
                state = PS_FINISHED;
            } else {
                error = "no second CR LF";
            }
            break;
        case PS_HEADER:
            if (ch == '\r' || ch == '\n') {
                line[writeptr] = '\0';
                add_request_header(req, line);
                writeptr = 0;
                if (ch == '\r') {
                    state = PS_BEFORE_LF;
                } else if (ch == '\n') {
                    state = PS_BEFORE_CR_2;
                }
            } else if (writeptr >= line_len) {
                error = "header too long";
            } else {
                line[writeptr++] = ch;
            }
            break;
        default:
            break;
        }
    }
    if (!error && state != PS_FINISHED) {
        error = "premature end in HTTP request";
    }
    if (error) {
        if (req->rline) {
            snprintf(req->msg, sizeof req->msg, "%s, request line: %s", error, req->rline);
        } else {
            snprintf(req->msg, sizeof req->msg, "%s", error);
        }
        return -1;
    }
    return 0;
}

/**
 * Map an HTTP status to its associated message.
 *
 * @param status status code
 *
 * @return message
 */
static const char *map_status(int status)
{
    switch (status) {
        case 200:
            return "OK";
        case 302:
            return "Found";
        case 400:
            return "Bad Request";
        case 404:
            return "Not Found";
        default:
            return "???";
    }
}

/**
 * Map a file extension to its content type.
 *
 * @param file file with extension
 *
 * @return content type
 */
static const char *map_extension(const char *file)
{
    const char *ext;

    if ((ext = strrchr(file, '.')) != NULL) {
        if (!strcasecmp(ext, ".html")) {
            return "text/html";
        }
        if (!strcasecmp(ext, ".js")) {
            return "application/javascript";
        }
        if (!strcasecmp(ext, ".c")) {
            return "text/plain";
        }
    }
    return "application/octet-stream";
}

/**
 * Send the HTTP response line and all headers.
 *
 * @param req request
 *
 * @return <code>0</code> if successful;
 *         <code>-1</code> otherwise
 */
static int send_headers(struct http_request *req)
{
    char buf[1024];
    int i;

    if (req->status == 0) {
        req->status = 200;
    }

    snprintf(buf, sizeof buf, "HTTP/1.1 %d %s\r\n", req->status, map_status(req->status));
    if (send(req->socket, buf, strlen(buf), 0) < 0) {
        return -1;
    }

    for (i = 0; i < http_headers_size(req->res_headers); i++) {
        struct http_header *hdr = http_headers_at(req->res_headers, i);

        snprintf(buf, sizeof buf, "%s: %s\r\n", hdr->name, hdr->value);
        if (send(req->socket, buf, strlen(buf), 0) < 0) {
            return -1;
        }
    }
    if (send(req->socket, "Connection: Close\r\n\r\n", 21, 0) < 0) {
        return -1;
    }
    return 0;
}

/**
 * Add all response headers found in a .h file lying next to the resource
 * requested.
 *
 * @param req request
 * @param file resource requested
 *
 * @return <code>0</code> if successful;
 *         <code>-1</code> if no file is found or an error occurs
 */
static int add_response_headers(struct http_request *req, const char *file)
{
    char h_file[PATH_MAX], *contents, *line, *sep, *eol;
    size_t file_len;
    struct stat st;

    if ((file_len = strlen(file) + 2 + 1) > sizeof(h_file)) {
        return -1;
    }
    snprintf(h_file, sizeof h_file, "%s.h", file);
    if (stat(h_file, &st) || !S_ISREG(st.st_mode)) {
        return -1;
    }

    if ((contents = mallocbinfile(h_file)) == NULL) {
        return -1;
    }

    line = contents;
    while (*line) {
        if ((eol = strchr(line, '\n')) == NULL || (sep = strchr(line, ':')) == NULL || sep > eol) {
            break;
        }
        *sep++ = 0;
        *eol++ = 0;
        http_headers_add_nv(req->res_headers, line, sep);
        line = eol;
    }
    free(contents);
    return 0;
}

/**
 * Send a file's contents in chunks.
 *
 * @param req request
 * @param fd file descriptor
 * @param file_size size of file
 *
 * @return <code>0</code> if successful;
 *         <code>-1</code> if an error occurs
 */
int send_file_chunked(struct http_request *req, int fd, off_t file_size)
{
    char buf[8192], chunk[10];
    off_t total, rd;
    ssize_t wr;

    for (total = 0, rd = 0, wr = 0; total < file_size; total += rd) {
        if ((rd = read(fd, buf, sizeof(buf))) < 0) {
            break;
        }
        snprintf(chunk, sizeof chunk, "%04X\r\n", (unsigned int) rd);
        if ((wr = send(req->socket, chunk, strlen(chunk), 0)) < 0) {
            break;
        }
        if ((wr = send(req->socket, buf, rd, 0)) < 0) {
            break;
        }
        if ((wr = send(req->socket, "\r\n", 2, 0)) < 0) {
            break;
        }
    }
    if (rd >= 0 && wr >= 0) {
        wr = send(req->socket, "0\r\n\r\n", 5, 0);
    }
    return rd >= 0 && wr >= 0 ? 0 : -1;
}

/* -------------------------------------------------------------- PUBLIC API */

struct http_request *create_http_request(struct log_context *lc, int socket)
{
    struct http_request *req;

    req = malloc(sizeof(struct http_request));
    memset(req, 0, sizeof(struct http_request));

    req->lc = lc;
    req->socket = socket;

    req->req_headers = create_http_headers();
    req->res_headers = create_http_headers();

    return req;
}

int http_request_handle(struct http_request *req,
                        int (*h)(struct http_request *, struct request_info *))
{
    int rv;

    if ((rv = parse_request(req)) < 0) {
        http_request_send_error(req, 400, req->msg);
        return -1;
    }

    {
        struct request_info info = {req->method, req->url, req->query};
        if (!h(req, &info)) {
            return 0;
        }
    }
    http_request_send_error(req, 404, NULL);
    return 0;
}

void http_request_add_header(struct http_request *req, const char *n, const char *v)
{
    http_headers_add_nv(req->res_headers, n, v);
}

int http_request_send_file(struct http_request *req, const char *file)
{
    struct stat st;
    int fd, rv;

    if (stat(file, &st) || !S_ISREG(st.st_mode)) {
        return -1;
    }
    add_response_headers(req, file);

    http_headers_add_nv(req->res_headers, "Transfer-Encoding", "chunked");

    if (http_headers_get(req->res_headers, "content-type") == NULL) {
        http_headers_add_nv(req->res_headers, "Content-Type", map_extension(file));
    }
    send_headers(req);

    if ((fd = open(file, O_RDONLY)) == -1) {
        return -1;
    }
    rv = send_file_chunked(req, fd, st.st_size);
    close(fd);
    return rv;
}

int http_request_send_redirect(struct http_request *req, const char *location)
{
    req->status = 302;
    http_headers_add_nv(req->res_headers, "Location", location);

    return send_headers(req);
}

int http_request_send_error(struct http_request *req, int status, const char *msg)
{
    char buf[1024];

    req->status = status;
    if (msg) {
        snprintf(buf, sizeof buf, "%zd", strlen(msg));
        http_headers_add_nv(req->res_headers, "Content-Length", buf);
        http_headers_add_nv(req->res_headers, "Content-Type", "text/plain");
    }
    if (!send_headers(req)) {
        return -1;
    }
    if (msg) {
        if (send(req->socket, msg, strlen(msg), 0) < 0) {
            return -1;
        }
    }
    return 0;
}

void http_request_free(struct http_request *req)
{
    http_headers_free(req->req_headers);
    http_headers_free(req->res_headers);

    free(req->rline);
    free(req->method);
    free(req->url);

    free(req);
}
