/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * __________________
 *
 *  Copyright 2019 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

#ifndef __REQUEST_H___
#define __REQUEST_H___

/**
 * Declaration of an HTTP request.
 */
struct http_request;

/**
 * Create a request
 *
 * @param lc log context
 * @param socket socket for communication
 *
 * @return request
 */
struct http_request *create_http_request(struct log_context *lc, int socket);

/**
 * Request info
 */
struct request_info {
    /* Method */
    const char *method;
    /* URL */
    const char *url;
    /* Query string (or NULL) */
    const char *query;
};

/**
 * Handle a single request.
 *
 * @param req request
 * @param h callback invoked when the request has been parsed
 *
 * @return <code>0</code> if request was processed;
 *         <code>-1</code> otherwise
 */
int http_request_handle(struct http_request *req,
                        int (*h)(struct http_request *, struct request_info *));

/**
 * Send a file back as response.
 *
 * @param req request
 * @param file file to send
 *
 * @return <code>0</code> if no error occurred;
 *         <code>-1</code> otherwise
 */
int http_request_send_file(struct http_request *req, const char *file);

/**
 * Send a redirect to some location.
 *
 * @param req request
 * @param location location
 *
 * @return <code>0</code> if no error occurred;
 *         <code>-1</code> otherwise
 */
int http_request_send_redirect(struct http_request *req, const char *location);

/**
 * Send av error message back.
 *
 * @param req request
 * @param status status code
 * @param msg optional message (or NULL)
 *
 * @return <code>0</code> if no error occurred;
 *         <code>-1</code> otherwise
 */
int http_request_send_error(struct http_request *req, int status, const char *msg);

/**
 * Free request
 *
 * @param req request
 */
void http_request_free(struct http_request *req);

#endif /* __REQUEST_H___ */
