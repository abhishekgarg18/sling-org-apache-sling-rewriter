/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2019 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

/* Add check macros that were introduced after 0.9.9, which is the last
   official release available on RHEL/CentOS */

#ifndef ck_assert_ptr_nonnull
#define ck_assert_ptr_nonnull(p) ck_assert((p) != NULL)
#endif

#ifndef ck_assert_ptr_null
#define ck_assert_ptr_null(p) ck_assert((p) == NULL)
#endif

#ifndef ck_assert_pstr_eq
#define ck_assert_pstr_eq(s1,s2) ck_assert(((s1) == NULL && (s2) == NULL) || \
        ((s1) != NULL && (s2) != NULL && strcmp((s1), (s2)) == 0))
#endif

#ifndef ck_assert_mem_eq
#define ck_assert_mem_eq(m1,m2,l) ck_assert(memcmp((m1),(m2),(l)) == 0)
#endif
