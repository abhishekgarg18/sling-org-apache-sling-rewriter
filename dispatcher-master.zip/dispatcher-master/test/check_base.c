/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2019 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

#include <stdlib.h>
#include <stdint.h>
#include <check.h>

#include "base/base.h"
#include "check_optional.h"

static void setup(void)
{

}

static void teardown(void)
{

}

START_TEST(test_trim)
{
    char value[256], *dest;

    strcpy(value, " \t name: value\t  ");
    dest = trim(value, " \t");
    ck_assert_str_eq(dest, "name: value");
}
END_TEST

START_TEST(test_glob)
{
    int rv;

    rv = strglobcmp("a*b", "acccb");
    ck_assert_int_eq(0, rv);
    rv = strglobcmp("a*b", "acccB");
    ck_assert_int_ne(0, rv);
    rv = strglobcasecmp("a*b", "acccB");
    ck_assert_int_eq(0, rv);
}
END_TEST

START_TEST(test_qstrtok)
{
    const char **ptr, *expected[] = {
        "a=1", "b=2", "c=3", NULL
    };
    char value[256], *c, *cend, subst;

    strcpy(value, "a=1;b=2;c=3");
    c = value; cend = c; subst = *c;
    ptr = &expected[0];

    qstrtok(&c, &cend, &subst, ";");
    while (c) {
        ck_assert_str_eq(c, *ptr);
        qstrtok(&c, &cend, &subst, ";");
        ptr++;
    }
}
END_TEST

START_TEST(test_strlwrcpy)
{
    char value[256];
    int rv;

    strcpy(value, "aBcDe");
    rv = strlwrcpy(value, value);
    ck_assert_str_eq(value, "abcde");
    ck_assert_int_eq(rv, strlen("abcde"));

    strcpy(value, "aBcDe");
    rv = strlwrncpy(value, sizeof(value), value);
    ck_assert_str_eq(value, "abcde");
    ck_assert_int_eq(rv, strlen("abcde"));

    strcpy(value, "aBcDe");
    rv = strlwrncpy(value, 4, value);
    ck_assert_str_eq(value, "abc");
    ck_assert_int_eq(rv, strlen("abc"));
}
END_TEST

START_TEST(test_strescape)
{
    char output[256];
    int rv;

    rv = strescape(output, "\"\\`$", sizeof(output));
    ck_assert_str_eq(output, "\\\"\\\\\\`\\$");
    ck_assert_int_eq(rv, 0);

    rv = strescape(output, "\"\\`$", 6);
    ck_assert_int_eq(rv, -1);
}
END_TEST

START_TEST(test_strglobcmp)
{
    int rv;

    rv = strglobcmp("* *.css *", "GET /crx/de/index.jsp?a=.css HTTP/1.1");
    ck_assert_int_eq(rv, 0);
}
END_TEST

START_TEST(test_strrep)
{
    char value[256];

    strcpy(value, "/a/b/c");
    strrep(value, '/', '\\');
    ck_assert_str_eq(value, "\\a\\b\\c");
}
END_TEST

START_TEST(test_date)
{
    time_t input, output;
    struct tm *tm;
    char formatted[256];

    input = time(NULL);
    tm = gmtime(&input);
    strftime(formatted, sizeof(formatted), "%a, %d %h %G %H:%M:%S %Z", tm);
    output = date_parse_http(formatted);
    ck_assert_int_eq(output, input);
}
END_TEST

START_TEST(test_urlenc)
{
    char encoded[256], *dest;
    int rv;

    dest = urlenc_ex(encoded, sizeof(encoded), "/test /me", NULL);
    ck_assert_ptr_nonnull(dest);
    ck_assert_str_eq(dest, "/test%20/me");
    rv = url_unescape(dest);
    ck_assert_int_eq(rv, 0);
    ck_assert_str_eq(dest, "/test /me");
}
END_TEST

START_TEST(test_decompose)
{
    /* Selectors are prefixed by their total length */
    static const char *args[] = {
        "/a/b", "/a/b", NULL, NULL, NULL,
        "/a/b.html", "/a/b", NULL, "html", NULL,
        "/a/b.s1.html", "/a/b", "\3s1", "html", NULL,
        "/a/b.s1.s2.html", "/a/b", "\6s1\0s2", "html", NULL,
        "/a/b/c/d", "/a/b/c/d", NULL, NULL, NULL,
        "/a/b./c/d", "/a/b", NULL, NULL, "/c/d",
        "/a/b.html/c/d", "/a/b", NULL, "html", "/c/d",
        "/a/b.s1.html/c/d", "/a/b", "\3s1", "html", "/c/d",
        "/a/b.s1.s2.html/c/d", "/a/b", "\6s1\0s2", "html", "/c/d",
        "/a/b/c/d.s.txt", "/a/b/c/d", "\2s", "txt", NULL,
        "/a/b.html/c/d.s.txt", "/a/b", NULL, "html", "/c/d.s.txt",
        "/a/b.s1.html/c/d.s.txt", "/a/b", "\3s1", "html", "/c/d.s.txt",
        "/a/b.s1.s2.html/c/d.s.txt", "/a/b", "\6s1\0s2", "html", "/c/d.s.txt",
        NULL
    };
    const char **input;
    const char *selectors, *extension;
    char *rpath, *suffix;

    for (input = &args[0]; *input != NULL; input += 5) {
        decompose_url(input[0], &rpath, &selectors, &extension, &suffix);
        ck_assert_pstr_eq(rpath, input[1]);
        if (input[2] == NULL) {
            ck_assert_ptr_null(selectors);
        } else {
            int len = input[2][0];
            ck_assert_mem_eq(selectors, &input[2][1], len);
        }
        ck_assert_pstr_eq(extension, input[3]);
        ck_assert_pstr_eq(suffix, input[4]);
        free(rpath);
        free(suffix);
    }
}
END_TEST

START_TEST(test_str_iseq)
{
    int value;

    value = str_iseq("abecd","abecd") ;
    ck_assert_int_eq(value, 0) ;
    value = str_iseq("Abecd","abecd") ;
    ck_assert_int_eq(value, 1) ;
    value = str_iseq("abecd","abcd") ;
    ck_assert_int_eq(value, 1) ;
    value = str_iseq("abd","abcd") ;
    ck_assert_int_eq(value, 1) ;
}
END_TEST

START_TEST(test_strip_field)
{
    static const char *args[] = {
        "", NULL,
        "private", NULL,
        "max-age=300", "",
        "max-age=300, private", "private",
        "no-cache, max-age=300", "no-cache",
        "no-cache, max-age=300, private", "no-cache, private",
        NULL
    };

    const char **input;
    char *output;

    for (input = &args[0]; *input != NULL; input += 2) {
        output = strip_field(input[0], "max-age=", ',');
        ck_assert_pstr_eq(output, input[1]);
        free(output);
    }
}
END_TEST

static Suite * suite(void)
{
    Suite *s;
    TCase *tc_url, *tc_string;

    s = suite_create("Base");

    tc_string = tcase_create("String");
    tcase_add_checked_fixture(tc_string, setup, teardown);
    tcase_add_test(tc_string, test_trim);
    tcase_add_test(tc_string, test_glob);
    tcase_add_test(tc_string, test_qstrtok);
    tcase_add_test(tc_string, test_strlwrcpy);
    tcase_add_test(tc_string, test_strescape);
    tcase_add_test(tc_string, test_strglobcmp);
    tcase_add_test(tc_string, test_strrep);
    tcase_add_test(tc_string,test_str_iseq);
    tcase_add_test(tc_string, test_date);
    tcase_add_test(tc_string, test_strip_field);
    suite_add_tcase(s, tc_string);

    tc_url = tcase_create("URL");
    tcase_add_checked_fixture(tc_url, setup, teardown);
    tcase_add_test(tc_url, test_urlenc);
    tcase_add_test(tc_url, test_decompose);
    suite_add_tcase(s, tc_url);

    return s;
}

int main(void)
{
    int number_failed;
    Suite *s;
    SRunner *sr;

    s = suite();
    sr = srunner_create(s);

    srunner_run_all(sr, CK_NORMAL);
    number_failed = srunner_ntests_failed(sr);
    srunner_free(sr);
    return (number_failed == 0) ? EXIT_SUCCESS : EXIT_FAILURE;
}
