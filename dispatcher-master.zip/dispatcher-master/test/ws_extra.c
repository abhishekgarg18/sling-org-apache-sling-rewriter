/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2019 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

#include "base/base.h"

#include "dispatcher/dispatcher.h"
#include "dispatcher/farm.h"
#include "dispatcher/cache.h"

#include "ws_extra.h"

/* Setup/Teardown of test cases */

static const char *docroot;
static char temp_dir[PATH_MAX];
static int temp_dir_created = 0;

void setupDocroot(void)
{
    const char *docroot_var;

    docroot_var = getenv("PUBLISH_DOCROOT");
    if (docroot_var == NULL) {
        strncpy(temp_dir, "/tmp/cache.XXXXXX", sizeof temp_dir);
        if (mkdtemp(temp_dir) == NULL) {
            perror("Unable to create temporary directory");
            abort();
        }
        setenv("PUBLISH_DOCROOT", temp_dir, 0);
        temp_dir_created = 1;
        docroot_var = temp_dir;
    }
    docroot = docroot_var;
}

static int rmdir_r(const char *name)
{
    DIR *dir;
    char path[PATH_MAX];
    struct dirent *entry;
    struct stat st;

    if (stat(name, &st) != 0 || !S_ISDIR(st.st_mode)) {
        return 0;
    }
    if ((dir = opendir(name)) != NULL) {
        while ((entry = readdir(dir)) != NULL) {
            if (!strcmp(entry->d_name, ".") || !strcmp(entry->d_name, "..")) {
                continue;
            }
            snprintf(path, sizeof path, "%s%c%s", name, FILE_SEPARATOR_CHAR, entry->d_name);
            if (stat(path, &st)) {
                continue;
            }
            if (!S_ISDIR(st.st_mode)) {
                remove(path);
            } else {
                rmdir_r(path);
            }
        }
        closedir(dir);
    }
    return remove(name);
}

void teardownDocroot(void)
{
    if (temp_dir_created) {
        rmdir_r(temp_dir);
    }
}

static struct dispatcher_config config;

struct dispatcher_config *setupDispatcher(struct log_context *lc, const char *config_s)
{
    struct any_item *item;
    int rv;

    item = any_parse(lc, config_s);
    rv = dispatcher_init_config(lc, item, &config, "test");
    any_free(item);

    if (rv != 0) {
        printf("Unable to initialize dispatcher\n");
        abort();
    }
    return &config;
}

void teardownDispatcher()
{
    dispatcher_terminate(&config);
}

int stat_cache(const char *uri, struct stat *st)
{
    char path[PATH_MAX];
    size_t path_len;

    path_len = strlen(docroot) + strlen(uri) + 1;
    if (path_len >= sizeof path) {
        return -1;
    }
    snprintf(path, sizeof path, "%s%s", docroot, uri);
    return stat(path, st);
}

/* Request creation */

struct ws_extra *create_get(struct log_context *lc, const char *url)
{
    struct ws_extra *ws;
    const char *sep;

    ws = malloc(sizeof(struct ws_extra));
    memset(ws, 0, sizeof(struct ws_extra));
    ws->d.config = &config;
    ws->d.ws = ws;
    ws->d.lc = lc;

    ws->req_headers = create_http_headers();
    ws->res_headers = create_http_headers();

    ws->method = "GET";
    ws->protocol = "HTTP/1.1";

    sep = strchr(url, '?');
    if (sep == NULL) {
        ws->uri = strdup(url);
    } else {
        ws->uri = strnumdup(url, sep - url);
        ws->query = strdup(sep + 1);
    }
    return ws;
}

struct ws_extra *create_post(struct log_context *lc, const char *url)
{
    struct ws_extra *ws;
    const char *sep;

    ws = malloc(sizeof(struct ws_extra));
    memset(ws, 0, sizeof(struct ws_extra));
    ws->d.config = &config;
    ws->d.ws = ws;
    ws->d.lc = lc;

    ws->req_headers = create_http_headers();
    ws->res_headers = create_http_headers();

    ws->method = "POST";
    ws->protocol = "HTTP/1.1";
    ws->body = create_sbuffer(256);

    sep = strchr(url, '?');
    if (sep == NULL) {
        ws->uri = strdup(url);
    } else {
        ws->uri = strnumdup(url, sep - url);
        ws->query = strdup(sep + 1);
    }
    return ws;
}

struct ws_extra *create_flush(struct log_context *lc, const char *handle)
{
    struct ws_extra *ws;

    ws = create_post(lc, "/dispatcher/invalidate.cache");
    http_headers_add_nv(ws->req_headers, "CQ-Action", "Activate");
    http_headers_add_nv(ws->req_headers, "CQ-Handle", handle);
    http_headers_add_nv(ws->req_headers, "Content-Type", "text/plain");

    return ws;
}

void add_refetch_uri(struct ws_extra *ws, const char *uri)
{
    sbuffer_append(ws->body, uri);
    sbuffer_append(ws->body, "\n");
}

void free_request(struct ws_extra *ws)
{
    if (ws == NULL) {
        return;
    }
    http_headers_free(ws->req_headers);
    http_headers_free(ws->res_headers);
    sbuffer_free(ws->body);
    free(ws->uri);
    free(ws->query);
    free(ws->sline);
    free(ws);
}

/** ws_XXX callbacks */

void ws_get_client_info(struct dispatcher *d, struct client_info *info)
{
    struct ws_extra *ws = d->ws;

    info->https = ws->https;
    info->method = ws->method;
    info->protocol = ws->protocol;
    info->uri = ws->uri;
    info->query = ws->query;
    info->host = ws_get_header(d, "host");
    info->via = ws_get_header(d, "via");
    info->client_ip = ws->client_ip ? ws->client_ip : "127.0.0.1";
}

const char *ws_get_header(struct dispatcher *d, const char *name)
{
    struct ws_extra *ws = d->ws;
    struct http_header *header;

    header = http_headers_get(ws->req_headers, name);
    if (header != NULL) {
        return header->value;
    }
    return NULL;
}

void ws_get_pt_headers(struct dispatcher *d, struct slist *names, struct hdrarray *headers)
{
    struct ws_extra *ws = d->ws;
    struct http_header *header;
    int i, size;

    if (names) {
        /* just return the ones requested */
        const char *value;
        while (names) {
            if ((value = ws_get_header(d, names->s)) != NULL) {
                hdrarray_add(headers, names->s, value);
            }
            names = names->next;
        }
    } else {
        /* no restriction: return all end-to-end headers */
        size = http_headers_size(ws->req_headers);
        for (i = 0; i < size; i++) {
            header = http_headers_at(ws->req_headers, i);
            if (!is_hop_by_hop_header(header->name)) {
                hdrarray_add(headers, header->name, header->value);
            }
        }
    }
}

int ws_net_read(struct dispatcher *d, void *p, size_t n, int *sc)
{
    struct ws_extra *ws = d->ws;
    const char *s;
    size_t avail;

    if (ws->body == NULL) {
        return -1;
    }
    avail = sbuffer_len(ws->body) - d->read;
    if (n > avail) {
        n = avail;
    }
    if (n != 0) {
        s = sbuffer_to_string(ws->body);
        memcpy(p, s + d->read, n);
        d->read += n;
    }
    return n;
}

int ws_get_cache_action(struct dispatcher *d)
{
    return 0;
}

void ws_deliver(struct dispatcher *d)
{
    if (d->farm->cache) {
        cache_deliver(d->farm->cache, d);
    }
}

int ws_set_status(struct dispatcher *d, int status, const char *sline)
{
    struct ws_extra *ws = d->ws;

    ws->status = status;
    if (sline) {
        ws->sline = strdup(sline);
    }
    return 0;
}

int ws_set_header(struct dispatcher *d, const char *name, const char *value)
{
    struct ws_extra *ws = d->ws;

    http_headers_add_nv(ws->res_headers, name, value);
    return 0;
}

int ws_start_response(struct dispatcher *d)
{
    return 0;
}

int ws_net_write(struct dispatcher *d, const char *buffer, size_t length)
{
    struct ws_extra *ws = d->ws;

    ws->res_len += length;
    return 0;
}

int ws_net_flush(struct dispatcher *d)
{
    return 0;
}

void ws_log_request(struct dispatcher *d, const char *method, const char *uri,
                    const char *query, const char *status, const char *cache_info,
                    long req_ms, const char *farm_label, const char *backend_label)
{
    struct log_context *lc = d->lc;

    if (query) {
        INFO("\"%s %s?%s\" %s %s [%s/%s] %ldms", method, uri, query, status, cache_info,
             farm_label, backend_label, req_ms);
    } else {
        INFO("\"%s %s\" %s %s [%s/%s] %ldms", method, uri, status, cache_info, farm_label,
             backend_label, req_ms);
    }
}
