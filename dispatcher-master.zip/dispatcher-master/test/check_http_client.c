/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2019 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

#include <stdlib.h>
#include <stdint.h>
#include <check.h>

#include "base/base.h"
#include "check_optional.h"

/**
 * Endpoint to connect to.
 */
static struct endpoint endpoint_argv;

/**
 * Our log context.
 */
static struct log_context *lc = NULL;

/**
 * Setup and teardown
 */
static void setup(void)
{
    init_socket_factory(NULL, 1, 60);
}

static void teardown(void)
{
    free_socket_factory();
}

static int body_readall(struct http_client *client, const char *path) {
    char buf[8192];
    int read;
    long long total = 0, clen;

    for (;;) {
        if ((read = http_client_read(client, buf, sizeof buf)) < 0) {
            printf("Error while reading from remote server: %s\n", http_client_get_error(client));
            return -1;
        } else if (!read) {
            break;
        }
    }
    total = http_client_get_read(client);
    if ((clen = http_client_get_clen(client)) != -1 && clen != total) {
        printf("Content length mismatch for %s, expected: %llu, actual: %llu\n", path, clen, total);
        return -1;
    }
    return 0;
}

START_TEST(test_get_simple)
{
    struct http_client *client;
    struct endpoint ep;
    const char *sline;
    int status;

    memset(&ep, 0, sizeof ep);
    memcpy(&ep, &endpoint_argv, sizeof ep);

    ep.file = "/";

    client = create_http_client(lc, &ep);
    status = http_client_get_status(client, &sline);
    if (status == HC_ECONN) {
        printf("%s\n", http_client_get_error(client));
    } else if (status < 0 || status >= 400) {
        printf("Received bad status line: %s\n", sline);
    }
    http_client_free(client);
}
END_TEST

START_TEST(test_get_gzipped)
{
    struct http_client *client;
    struct http_headers *headers;
    struct endpoint ep;
    const char *sline;
    int rv, status;

    memset(&ep, 0, sizeof ep);
    memcpy(&ep, &endpoint_argv, sizeof ep);

    ep.file = "/etc.clientlibs/weretail/clientlibs/clientlib-dependencies.js";

    client = create_http_client(lc, &ep);
    http_client_add_header(client, "Accept-Encoding", "gzip");
    status = http_client_get_status(client, &sline);
    if (status == HC_ECONN) {
        printf("%s\n", http_client_get_error(client));
    } else if (status < 0 || status >= 400) {
        printf("Received bad status line: %s\n", sline);
    } else {
        headers = http_client_get_headers(client);
        rv = http_headers_is(headers, "transfer-encoding", "chunked", NULL);
        ck_assert_int_eq(rv, 1);
        rv = http_headers_is(headers, "content-encoding", "gzipped", NULL);
        ck_assert_int_eq(rv, 0);
        rv = body_readall(client, ep.file);
        ck_assert_int_eq(rv, 0);
    }
    http_client_free(client);
}
END_TEST

START_TEST(test_retry)
{
    struct http_client *client;
    struct endpoint ep;
    const char *sline;
    char buf[8192];
    int i, rv, status;

    memset(&ep, 0, sizeof ep);
    memcpy(&ep, &endpoint_argv, sizeof ep);

    ep.file = "/etc.clientlibs/weretail/clientlibs/clientlib-dependencies.js";
    ep.receive_timeout = 1000;

    client = create_http_client(lc, &ep);
    http_client_add_header(client, "Accept-Encoding", "gzip");

    for (i = 1; i <= 2; i++) {
        status = http_client_get_status(client, &sline);
        if (status == HC_ECONN) {
            printf("Try %d: %s\n", i, http_client_get_error(client));
        } else if (status < 0 || status >= 400) {
            printf("Try %d: received bad status line: %s\n", i, sline);
        } else {
            rv = http_client_read(client, buf, sizeof buf);
            if (rv < 0) {
                printf("Try %d: read failed: %s\n", i, http_client_get_error(client));
            }
            ck_assert_int_ge(rv, 0);
        }
        // Do a retry: this should succeed and not leak any memory
        rv = http_client_init_retry(client);
        if (rv != 0) {
            printf("Try %d: reconnect failed: %s\n", i, http_client_get_error(client));
        }
        ck_assert_int_eq(rv, 0);
    }
    http_client_free(client);
}
END_TEST

static Suite * suite(void)
{
    Suite *s;
    TCase *tc;

    s = suite_create("HTTP Client");

    tc = tcase_create("HTTP Client");
    tcase_add_checked_fixture(tc, setup, teardown);
    tcase_add_test(tc, test_get_simple);
    tcase_add_test(tc, test_get_gzipped);
    tcase_add_test(tc, test_retry);
    suite_add_tcase(s, tc);

    return s;
}

int main(void)
{
    int number_failed;
    Suite *s;
    SRunner *sr;

    log_init(&lc, parse_log_level(getenv("LOG_LEVEL"), LL_WARN), NULL);

    if (getenv("AEM_HOST") == NULL || getenv("AEM_PORT") == NULL) {
        printf("Environment variables AEM_HOST and/or AEM_PORT are missing.\n");
        return EXIT_FAILURE;
    }

    memset(&endpoint_argv, 0, sizeof endpoint_argv);
    endpoint_argv.host = getenv("AEM_HOST");
    endpoint_argv.port = atoi(getenv("AEM_PORT"));

    s = suite();
    sr = srunner_create(s);

    srunner_run_all(sr, CK_NORMAL);
    number_failed = srunner_ntests_failed(sr);
    srunner_free(sr);
    return (number_failed == 0) ? EXIT_SUCCESS : EXIT_FAILURE;
}
