# Document root for local web server

This folder contains the document root of the local web server.
It includes all files requested by the test cases, as they would
appear on an AEM 6.4 instance.

