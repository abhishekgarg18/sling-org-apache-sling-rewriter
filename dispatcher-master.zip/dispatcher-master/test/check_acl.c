/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2019 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

#include <stdlib.h>
#include <stdint.h>
#include <check.h>

#include "base/base.h"
#include "check_optional.h"

/**
 * Our log context.
 */
static struct log_context *lc = NULL;

/**
 * Setup and teardown
 */
static void setup(void)
{

}

static void teardown(void)
{

}

START_TEST(test_acl)
{
    const char *acl_s = "/0 { /type \"deny\" /glob \"*\" } /1 { /type \"allow\" /glob \"a*\" }";
    struct acl* acl;
    struct any_item *root, *item;
    struct ace* ace;

    root = any_parse(lc, acl_s);
    ck_assert_ptr_nonnull(root);
    item = any_get_item(root, "0");
    ck_assert_ptr_nonnull(item);
    acl = acl_create(lc, item, NULL);
    ck_assert_ptr_nonnull(acl);
    ace = acl_allowed(lc, acl, "ab");
    ck_assert_ptr_nonnull(ace);
    ace = acl_allowed(lc, acl, "bb");
    ck_assert_ptr_null(ace);

    acl_free(acl);
    any_free(root);
}
END_TEST

static Suite * suite(void)
{
    Suite *s;
    TCase *tc;

    s = suite_create("ACL");

    tc = tcase_create("ACL");
    tcase_add_checked_fixture(tc, setup, teardown);
    tcase_add_test(tc, test_acl);
    suite_add_tcase(s, tc);

    return s;
}

int main(void)
{
    int number_failed;
    Suite *s;
    SRunner *sr;

    s = suite();
    sr = srunner_create(s);

    srunner_run_all(sr, CK_NORMAL);
    number_failed = srunner_ntests_failed(sr);
    srunner_free(sr);
    return (number_failed == 0) ? EXIT_SUCCESS : EXIT_FAILURE;
}
