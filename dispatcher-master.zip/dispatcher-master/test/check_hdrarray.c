/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2019 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

#include <stdlib.h>
#include <stdint.h>
#include <check.h>

#include "base/base.h"
#include "check_optional.h"

static void setup(void)
{

}

static void teardown(void)
{

}

static const char *kv[] = {"A", "1", "B", "2", "C", "3", NULL};

START_TEST(test_hdrarray)
{
    struct hdrarray *ha;
    const char **p, *k, *v;
    int i;

    ha = create_hdrarray(10);
    for (p = &kv[0]; *p != NULL; p += 2) {
        hdrarray_add(ha, *p, *(p + 1));
    }

    ck_assert_int_eq(hdrarray_size(ha), 3);
    for (i = 0; i < 3; i++) {
        ck_assert_int_eq(hdrarray_at(ha, i, &k, &v), 0);
        ck_assert_str_eq(k, kv[i * 2]);
        ck_assert_str_eq(v, kv[i * 2 + 1]);
    }
    ck_assert_int_eq(hdrarray_at(ha, 4, &k, &v), -1);

    hdrarray_free(ha);
}
END_TEST

static Suite * suite(void)
{
    Suite *s;
    TCase *tc;

    s = suite_create("Header Array");

    tc = tcase_create("Header Array");
    tcase_add_checked_fixture(tc, setup, teardown);
    tcase_add_test(tc, test_hdrarray);
    suite_add_tcase(s, tc);

    return s;
}

int main(void)
{
    int number_failed;
    Suite *s;
    SRunner *sr;

    s = suite();
    sr = srunner_create(s);

    srunner_run_all(sr, CK_NORMAL);
    number_failed = srunner_ntests_failed(sr);
    srunner_free(sr);
    return (number_failed == 0) ? EXIT_SUCCESS : EXIT_FAILURE;
}
