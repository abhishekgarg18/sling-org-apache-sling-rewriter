# Unit tests

This folder contains the unit tests that can be run on the dispatcher code. They require
the [Check unit testing framework](https://libcheck.github.io/check/).

## Installing the prerequisites

Install the check unit testing library, version 0.9.9 or higher is required.

### macOS

Install the latest check unit testing library with [brew](https://brew.sh/):
```
$ brew install check
```

### CentOS/RHEL

Install the check unit testing library and development files:
```
# yum install check-devel
```

## Running the tests

Some tests require a running AEM instance, with *we-retail* sample content installed. The
host and port of that instance are expected in environment variables *AEM_HOST* and
*AEM_PORT*, e.g.:
```
$ export AEM_HOST=localhost AEM_PORT=4503
$ make test
```

The default log level for all tests is *warn*. If you want to have a different log level you
can pass it in the environment variable *LOG_LEVEL*:
```
$ LOG_LEVEL=trace ./cache.test
```

## Finding memory leaks

In order to find memory leaks, the tests can be run together with [valgrind](http://valgrind.org/):
```
$ make valgrind
```

In order to run valgrind with a single test, add *CK_FORK=no*:
```
$ CK_FORK=no valgrind --leak-check=full ./base.test
```
This disables forking when running tests, or valgrind might show false positives. For more
information, see the related section [Finding memory leaks](https://libcheck.github.io/check/doc/check_html/check_4.html#Finding-Memory-Leaks) in check's documentation.

**Note**: valgrind is not supported on macOS Mojave (10.14) yet, because the kernel sources were not
made available until recently, see [related issue](https://bugs.kde.org/show_bug.cgi?id=399584).