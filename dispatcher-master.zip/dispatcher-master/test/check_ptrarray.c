/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2019 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

#include <stdlib.h>
#include <stdint.h>
#include <check.h>

#include "base/base.h"
#include "check_optional.h"

static void setup(void)
{

}

static void teardown(void)
{

}

static const char *values[] = {"A", "B", "C", NULL};

START_TEST(test_ptrarray)
{
    struct ptrarray *pa;
    char **p;

    create_ptrarray(&pa, 10, free);
    for (p = (char **) &values[0]; *p != NULL; p++) {
        ptrarray_add(pa, strdup(*p));
    }

    ck_assert_int_eq(ptrarray_size(pa), 3);
    ck_assert_str_eq(ptrarray_at(pa, 0), "A");
    ck_assert_str_eq(ptrarray_at(pa, 2), "C");
    ck_assert_ptr_null(ptrarray_at(pa, 3));

    ptrarray_clear(pa);
    ck_assert_int_eq(ptrarray_size(pa), 0);
    ck_assert_ptr_null(ptrarray_at(pa, 0));

    ptrarray_free(pa);
}
END_TEST

static Suite * suite(void)
{
    Suite *s;
    TCase *tc;

    s = suite_create("Pointer Array");

    tc = tcase_create("Pointer Array");
    tcase_add_checked_fixture(tc, setup, teardown);
    tcase_add_test(tc, test_ptrarray);
    suite_add_tcase(s, tc);

    return s;
}

int main(void)
{
    int number_failed;
    Suite *s;
    SRunner *sr;

    s = suite();
    sr = srunner_create(s);

    srunner_run_all(sr, CK_NORMAL);
    number_failed = srunner_ntests_failed(sr);
    srunner_free(sr);
    return (number_failed == 0) ? EXIT_SUCCESS : EXIT_FAILURE;
}
