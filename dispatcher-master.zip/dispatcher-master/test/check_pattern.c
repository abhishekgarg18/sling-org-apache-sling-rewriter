/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2019 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

#include <stdlib.h>
#include <stdint.h>
#include <check.h>

#include "base/base.h"
#include "check_optional.h"

static void setup(void)
{

}

static void teardown(void)
{

}

START_TEST(test_glob_pattern)
{
    struct pattern p;
    int rv;

    rv = create_glob_pattern(&p, "a*");
    ck_assert_int_eq(rv, 0);
    rv = pattern_match(NULL, &p, "ab");
    ck_assert_int_eq(rv, 1);
    rv = pattern_match(NULL, &p, "bb");
    ck_assert_int_eq(rv, 0);
    pattern_free(&p);
}
END_TEST

START_TEST(test_regex_pattern)
{
    struct pattern p;
    int rv;

    rv = create_regex_pattern(NULL, &p, "a.*");
    ck_assert_int_eq(rv, 0);
    rv = pattern_match(NULL, &p, "ab");
    ck_assert_int_eq(rv, 1);
    rv = pattern_match(NULL, &p, "bb");
    ck_assert_int_eq(rv, 0);
    pattern_free(&p);
}
END_TEST

static Suite * suite(void)
{
    Suite *s;
    TCase *tc_glob, *tc_regex;

    s = suite_create("Pattern");

    tc_glob = tcase_create("Glob");
    tcase_add_checked_fixture(tc_glob, setup, teardown);
    tcase_add_test(tc_glob, test_glob_pattern);
    suite_add_tcase(s, tc_glob);

    tc_regex = tcase_create("Regex");
    tcase_add_checked_fixture(tc_regex, setup, teardown);
    tcase_add_test(tc_regex, test_regex_pattern);
    suite_add_tcase(s, tc_regex);

    return s;
}

int main(void)
{
    int number_failed;
    Suite *s;
    SRunner *sr;

    s = suite();
    sr = srunner_create(s);

    srunner_run_all(sr, CK_NORMAL);
    number_failed = srunner_ntests_failed(sr);
    srunner_free(sr);
    return (number_failed == 0) ? EXIT_SUCCESS : EXIT_FAILURE;
}
