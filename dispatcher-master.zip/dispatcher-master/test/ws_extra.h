/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2019 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

#ifndef __WS_EXTRA_H__
#define __WS_EXTRA_H__

#include "base/http_headers.h"

struct ws_extra {
    /* Dispatcher section */
    struct dispatcher d;

    /* Request section */
    int https;
    const char *method;
    const char *protocol;
    char *uri;
    char *query;
    const char *client_ip;
    struct http_headers *req_headers;
    struct sbuffer *body;
    size_t read;

    /* Response section */
    int status;
    char *sline;
    struct http_headers *res_headers;
    long long res_len;
};

/**
 * Setup document root.
 */
void setupDocroot(void);

/**
 * Teardown document root.
 */
void teardownDocroot(void);

/**
 * Setup dispatcher.
 */
struct dispatcher_config *setupDispatcher(struct log_context *lc, const char *config_s);

/**
 * Tear down dispatcher.
 */
void teardownDispatcher();

/**
 * Obtain information about a resource in the cache.
 *
 * @param uri uri of resource
 * @param st stat to fill
 *
 * @return <code>0</code> on success; <code>-1</code> on error
 */
int stat_cache(const char *uri, struct stat *st);

/**
 * Create a GET request.
 *
 * @param lc log context
 * @param url url, may contain a query string
 *
 * @return request
 */
struct ws_extra *create_get(struct log_context *lc, const char *url);

/**
 * Create a flush request.
 *
 * @param lc log context
 * @param handle handle that we want to flush
 */
struct ws_extra *create_flush(struct log_context *lc, const char *handle);

/**
 * Add refetch URI.
 * 
 * @param ws ws extra
 * @param uri refetch URI
 */
void add_refetch_uri(struct ws_extra *ws, const char *uri);

/**
 * Free a request.
 *
 * @param ws request to free
 */
void free_request(struct ws_extra *ws);

#endif // __WS_EXTRA_H__