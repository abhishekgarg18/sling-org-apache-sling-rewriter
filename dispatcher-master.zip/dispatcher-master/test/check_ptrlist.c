/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2019 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

#include <stdlib.h>
#include <stdint.h>
#include <check.h>

#include "base/base.h"
#include "check_optional.h"

static void setup(void)
{

}

static void teardown(void)
{

}

static const char *values[] = {"A", "B", "C", NULL};

START_TEST(test_ptrlist)
{
    struct ptrlist *pl;
    struct ptr_entry *e;

    char **p, *ptr;
    int i;

    create_ptrlist(&pl, free);
    for (p = (char **) &values[0]; *p != NULL; p++) {
        ptrlist_add(pl, strdup(*p));
    }
    ck_assert_int_eq(ptrlist_size(pl), 3);

    for (i = 0, e = ptrlist_first(pl); e != NULL; i++, e = ptrlist_next(e)) {
        ptr = (char *) ptrlist_get(e);
        ck_assert_str_eq(ptr, values[i]);
    }
    ck_assert_int_eq(i, 3);

    for (i = 0; i < 3; i++) {
        ptr = (char *) ptrlist_remove(pl);
        ck_assert_str_eq(ptr, values[i]);
        ck_assert_int_eq(ptrlist_size(pl), 3 - i - 1);
        free(ptr);
    }

    ptrlist_free(pl);
}
END_TEST

static Suite * suite(void)
{
    Suite *s;
    TCase *tc;

    s = suite_create("Pointer List");

    tc = tcase_create("Pointer List");
    tcase_add_checked_fixture(tc, setup, teardown);
    tcase_add_test(tc, test_ptrlist);
    suite_add_tcase(s, tc);

    return s;
}

int main(void)
{
    int number_failed;
    Suite *s;
    SRunner *sr;

    s = suite();
    sr = srunner_create(s);

    srunner_run_all(sr, CK_NORMAL);
    number_failed = srunner_ntests_failed(sr);
    srunner_free(sr);
    return (number_failed == 0) ? EXIT_SUCCESS : EXIT_FAILURE;
}
