/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2019 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

#include <stdlib.h>
#include <stdint.h>
#include <check.h>

#include "base/base.h"
#include "check_optional.h"

static void setup(void)
{

}

static void teardown(void)
{

}

static const char *kv[] = { "A", "1", "B", "2", "C", "3", NULL };

START_TEST(test_hashtable)
{
    struct hashtable *ht, *ht2;
    struct ht_entry *e;
    char **p, *k, *v;
    int i;

    create_hashtable(&ht, 10);
    for (p = (char **) &kv[0]; *p != NULL; p += 2) {
        hashtable_puts(ht, *p, *(p+1));
    }
    ck_assert_int_eq(hashtable_size(ht), 3);
    ck_assert_str_eq(hashtable_gets(ht, "B"), "2");
    ck_assert_ptr_null(hashtable_gets(ht, "D"));

    v = hashtable_puts(ht, "B", "4");
    ck_assert_ptr_nonnull(v);
    ck_assert_int_eq(hashtable_size(ht), 3);
    free(v);

    hashtable_dup(&ht2, ht);
    hashtable_free(ht);
    ht = ht2;

    ck_assert_int_eq(hashtable_size(ht), 3);
    ck_assert_str_eq(hashtable_gets(ht, "B"), "4");

    ck_assert_int_eq(hashtable_remove(ht, "A"), 0);
    ck_assert_int_eq(hashtable_remove(ht, "D"), -1);

    for (i = 0, e = hashtable_first(ht); e != NULL; i++, e = hashtable_next(e)) {
        hashtable_getentry(e, (const char **) &k, (const void **) &v);
        if (!strcmp(k, "B")) {
            ck_assert_str_eq(v, "4");
        } else if (!strcmp(k, "C")) {
            ck_assert_str_eq(v, "3");
        } else {
            fail("Unexpected key/value in hashtable: %s/%s", k, v);
        }
    }
    ck_assert_int_eq(i, 2);

    hashtable_clear(ht);
    ck_assert_int_eq(hashtable_size(ht), 0);

    hashtable_free(ht);
}
END_TEST

static Suite * suite(void)
{
    Suite *s;
    TCase *tc;

    s = suite_create("Hashtable");

    tc = tcase_create("Hashtable");
    tcase_add_checked_fixture(tc, setup, teardown);
    tcase_add_test(tc, test_hashtable);
    suite_add_tcase(s, tc);

    return s;
}

int main(void)
{
    int number_failed;
    Suite *s;
    SRunner *sr;

    s = suite();
    sr = srunner_create(s);

    srunner_run_all(sr, CK_NORMAL);
    number_failed = srunner_ntests_failed(sr);
    srunner_free(sr);
    return (number_failed == 0) ? EXIT_SUCCESS : EXIT_FAILURE;
}
