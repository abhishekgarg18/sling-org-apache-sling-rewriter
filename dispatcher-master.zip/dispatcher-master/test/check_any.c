/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2019 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

#include <stdlib.h>
#include <stdint.h>
#include <check.h>

#include "base/base.h"
#include "check_optional.h"

/**
 * Our log context.
 */
static struct log_context *lc = NULL;

/**
 * Setup and teardown
 */
static void setup(void)
{

}

static void teardown(void)
{

}

START_TEST(test_any)
{
    const char *any_s = "/A { /B1 c1 /B2 \"c2\" /B3 'c3' /B4 2 } /C { \"d\" }";
    struct any_item *root, *item, *child;
    const char *value;
    int nvalue;

    root = any_parse(lc, any_s);
    ck_assert_ptr_nonnull(root);

    item = any_get_item(root, "A");
    ck_assert_ptr_nonnull(item);
    value = any_get_string(item, "B1");
    ck_assert_str_eq(value, "c1");
    value = any_get_string(item, "B2");
    ck_assert_str_eq(value, "c2");
    value = any_get_regex(item, "B2");
    ck_assert_ptr_null(value);
    value = any_get_regex(item, "B3");
    ck_assert_str_eq(value, "c3");
    value = any_get_string(item, "B3");
    ck_assert_ptr_null(value);
    nvalue = any_get_number(lc, item, "B4", 0);
    ck_assert_int_eq(nvalue, 2);
    nvalue = any_get_boolean(item, "B4");
    ck_assert_int_eq(nvalue, 1);
    nvalue = any_get_number(lc, item, "B5", 0);
    ck_assert_int_eq(nvalue, 0);
    child = any_get_first_child(root, "C");
    ck_assert_ptr_nonnull(child);
    ck_assert_int_eq(child->type, STRING);
    ck_assert_str_eq(child->value.p, "d");

    any_free(root);
}
END_TEST

static Suite * suite(void)
{
    Suite *s;
    TCase *tc;

    s = suite_create("Any");

    tc = tcase_create("Any");
    tcase_add_checked_fixture(tc, setup, teardown);
    tcase_add_test(tc, test_any);
    suite_add_tcase(s, tc);

    return s;
}

int main(void)
{
    int number_failed;
    Suite *s;
    SRunner *sr;

    log_init(&lc, LL_WARN, NULL);

    s = suite();
    sr = srunner_create(s);

    srunner_run_all(sr, CK_NORMAL);
    number_failed = srunner_ntests_failed(sr);
    srunner_free(sr);
    return (number_failed == 0) ? EXIT_SUCCESS : EXIT_FAILURE;
}
