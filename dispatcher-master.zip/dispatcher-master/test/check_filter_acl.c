/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2019 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

#include <stdlib.h>
#include <stdint.h>
#include <check.h>

#include "base/base.h"
#include "dispatcher/dispatcher.h"
#include "dispatcher/filter_acl.h"

#include "check_optional.h"

/**
 * Our log context.
 */
static struct log_context *lc = NULL;

static const char *filter_acl_bad =
    "/filter {"
    "  /0 { /type \"deny\" /glob \"*\" }"
    "  /1 { /type \"allow\" /method \"POST\" /url \"/content/[.]*.model.json\" }"
    "}";

static const char *filter_acl_right =
    "/filter {"
    "  /0 { /type \"deny\" /glob \"*\" }"
    "  /1 { /type \"allow\" /method \"POST\" /url \"/content/*.model.json\" }"
    "}";

/**
 * Setup and teardown
 */
static void setup(void)
{

}

static void teardown(void)
{

}

START_TEST(test_filter_acl_bad_syntax)
{
    struct filter_acl* acl;
    struct any_item *root, *item;
    struct client_info info;
    int ret;

    root = any_parse(lc, filter_acl_bad);
    ck_assert_ptr_nonnull(root);
    item = any_get_item(root, "filter.0");
    ck_assert_ptr_nonnull(item);
    acl = filter_acl_create(lc, item, NULL);
    ck_assert_ptr_nonnull(acl);

    memset(&info, 0, sizeof(struct client_info));
    info.method = "POST";
    info.uri = "/content/core-components-examples/library/button/_jcr_content/root/responsivegrid"
               "/demo_1160408466/component/button.model.json";
    ret = filter_acl_allowed(lc, acl, &info);
    ck_assert_int_eq(ret, 0);

    filter_acl_free(acl);
    any_free(root);
}
END_TEST

START_TEST(test_filter_acl_right_syntax)
{
    struct filter_acl *acl;
    struct any_item *root, *item;
    struct client_info info;
    int ret;

    root = any_parse(lc, filter_acl_right);
    ck_assert_ptr_nonnull(root);
    item = any_get_item(root, "filter.0");
    ck_assert_ptr_nonnull(item);
    acl = filter_acl_create(lc, item, NULL);
    ck_assert_ptr_nonnull(acl);

    memset(&info, 0, sizeof(struct client_info));
    info.method = "POST";
    info.uri = "/content/core-components-examples/library/button/_jcr_content/root/responsivegrid"
               "/demo_1160408466/component/button.model.json";
    ret = filter_acl_allowed(lc, acl, &info);
    ck_assert_int_eq(ret, 1);

    filter_acl_free(acl);
    any_free(root);
}
END_TEST

static Suite * suite(void)
{
    Suite *s;
    TCase *tc;

    s = suite_create("Filter ACL");

    tc = tcase_create("Filter ACL");
    tcase_add_checked_fixture(tc, setup, teardown);
    tcase_add_test(tc, test_filter_acl_bad_syntax);
    tcase_add_test(tc, test_filter_acl_right_syntax);
    suite_add_tcase(s, tc);

    return s;
}

int main(void)
{
    int number_failed;
    Suite *s;
    SRunner *sr;

    log_init(&lc, LL_WARN, NULL);

    s = suite();
    sr = srunner_create(s);

    srunner_run_all(sr, CK_NORMAL);
    number_failed = srunner_ntests_failed(sr);
    srunner_free(sr);
    return (number_failed == 0) ? EXIT_SUCCESS : EXIT_FAILURE;
}
