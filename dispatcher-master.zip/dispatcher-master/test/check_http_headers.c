/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2019 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

#include <stdlib.h>
#include <stdint.h>
#include <check.h>

#include "base/base.h"
#include "check_optional.h"

static void setup(void)
{

}

static void teardown(void)
{

}

START_TEST(test_http_headers)
{
    struct http_headers *headers;
    struct http_header *header;
    const char *values1[] = { "B", "C", NULL };
    int rv, size;

    headers = create_http_headers();

    // add an illegal header (without :) and check it doesn't get added
    http_headers_add(headers, "A B");
    ck_assert_int_eq(http_headers_size(headers), 0);

    // add a valid header (with :) and check it gets added
    http_headers_add(headers, "A: B");
    header = http_headers_get(headers, "a");
    ck_assert_ptr_nonnull(header);
    ck_assert_str_eq(header->name, "A");
    ck_assert_str_eq(header->value, "B");

    // add another header in (name, value) notation
    http_headers_add_nv(headers, "C", "D");
    size = http_headers_size(headers);
    ck_assert_int_eq(size, 2);
    header = http_headers_at(headers, 1);
    ck_assert_ptr_nonnull(header);
    header = http_headers_at(headers, 2);
    ck_assert_ptr_null(header);

    // check the value of header A matches one of the above
    rv = http_headers_is_one_of(headers, "a", values1, NULL);
    ck_assert_int_eq(rv, 1);

    // check there is no match for inexistant header C
    rv = http_headers_is_one_of(headers, "c", values1, NULL);
    ck_assert_int_eq(rv, 0);

    // check clear removes all headers
    http_headers_clear(headers);
    rv = http_headers_size(headers);
    ck_assert_int_eq(rv, 0);

    http_headers_free(headers);
}
END_TEST

static Suite * suite(void)
{
    Suite *s;
    TCase *tc;

    s = suite_create("HTTP Headers");

    tc = tcase_create("HTTP Headers");
    tcase_add_checked_fixture(tc, setup, teardown);
    tcase_add_test(tc, test_http_headers);
    suite_add_tcase(s, tc);

    return s;
}

int main(void)
{
    int number_failed;
    Suite *s;
    SRunner *sr;

    s = suite();
    sr = srunner_create(s);

    srunner_run_all(sr, CK_NORMAL);
    number_failed = srunner_ntests_failed(sr);
    srunner_free(sr);
    return (number_failed == 0) ? EXIT_SUCCESS : EXIT_FAILURE;
}
