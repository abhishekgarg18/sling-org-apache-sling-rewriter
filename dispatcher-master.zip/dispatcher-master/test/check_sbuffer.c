/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2019 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

#include <stdlib.h>
#include <stdint.h>
#include <check.h>

#include "base/base.h"
#include "check_optional.h"

static void setup(void)
{

}

static void teardown(void)
{

}

START_TEST(test_sbuffer)
{
    struct sbuffer *sb;

    sb = create_sbuffer(256);
    ck_assert_int_eq(sbuffer_len(sb), 0);
    sbuffer_append(sb, "Hello ");
    ck_assert_int_eq(sbuffer_len(sb), 6);
    sbuffer_append(sb, "world");
    ck_assert_int_eq(sbuffer_len(sb), 11);
    ck_assert_str_eq(sbuffer_to_string(sb), "Hello world");
    sbuffer_free(sb);
}
END_TEST

static Suite * suite(void)
{
    Suite *s;
    TCase *tc;

    s = suite_create("String Buffer");

    tc = tcase_create("String Buffer");
    tcase_add_checked_fixture(tc, setup, teardown);
    tcase_add_test(tc, test_sbuffer);
    suite_add_tcase(s, tc);

    return s;
}

int main(void)
{
    int number_failed;
    Suite *s;
    SRunner *sr;

    s = suite();
    sr = srunner_create(s);

    srunner_run_all(sr, CK_NORMAL);
    number_failed = srunner_ntests_failed(sr);
    srunner_free(sr);
    return (number_failed == 0) ? EXIT_SUCCESS : EXIT_FAILURE;
}
