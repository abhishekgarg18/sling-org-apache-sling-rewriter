/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2019 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

#include <stdlib.h>
#include <stdint.h>
#include <check.h>

#include "base/base.h"
#include "check_optional.h"

/**
 * Endpoint to connect to.
 */
static struct endpoint endpoint_argv;

/**
 * Our log context.
 */
static struct log_context *lc = NULL;

/**
 * Setup and teardown
 */
static void setup(void)
{
    init_socket_factory(lc, 1, 60);
}

static void teardown(void)
{
    free_socket_factory();
}

START_TEST(test_factory)
{
    struct connection_factory *factory;
    struct connection *conn;
    struct endpoint ep;
    char input[256], output[256];
    int nread;

    factory = get_socket_factory();
    ck_assert_ptr_nonnull(factory);
    ck_assert_int_eq(factory->keepalive(factory), 1);

    memset(&ep, 0, sizeof ep);
    memcpy(&ep, &endpoint_argv, sizeof ep);

    conn = factory->create(lc, factory, &ep, sizeof(struct endpoint), 1);
    if (conn == NULL) {
        ck_abort_msg("Unable to create connection: %s", factory->errmsg(factory));
    }
    strncpy(input, "GET / HTTP/1.1\r\nHost: localhost\r\n\r\n", sizeof input);
    conn->write(conn, input, strlen(input));
    conn->flush(conn);

    nread = conn->read(conn, output, sizeof(output));
    ck_assert_int_gt(nread, 0);

    conn->close(conn, 1);
}
END_TEST

static Suite * suite(void)
{
    Suite *s;
    TCase *tc;

    s = suite_create("Socket Factory");

    tc = tcase_create("Socket Factory");
    tcase_add_checked_fixture(tc, setup, teardown);
    tcase_add_test(tc, test_factory);
    suite_add_tcase(s, tc);

    return s;
}

int main(void)
{
    int number_failed;
    Suite *s;
    SRunner *sr;

    log_init(&lc, parse_log_level(getenv("LOG_LEVEL"), LL_WARN), NULL);

    if (getenv("AEM_HOST") == NULL || getenv("AEM_PORT") == NULL) {
        printf("Environment variables AEM_HOST and/or AEM_PORT are missing.\n");
        return EXIT_FAILURE;
    }

    memset(&endpoint_argv, 0, sizeof endpoint_argv);
    endpoint_argv.host = getenv("AEM_HOST");
    endpoint_argv.port = atoi(getenv("AEM_PORT"));

    s = suite();
    sr = srunner_create(s);

    srunner_run_all(sr, CK_NORMAL);
    number_failed = srunner_ntests_failed(sr);
    srunner_free(sr);
    return (number_failed == 0) ? EXIT_SUCCESS : EXIT_FAILURE;
}
