# Dispatcher

## Status
[![Build Status](https://jenkins-granite.bsl.eur.adobe.com/buildStatus/icon?job=dispatcher.ci)](https://jenkins-granite.bsl.eur.adobe.com/job/dispatcher.ci)

## Development

Building the dispatcher requires a *build environment* as well as some *third party libraries* in
source distribution. Please check the appropriate section for your operating system.

---
## Build environment

### Linux:

Install `gcc` and `gmake`, e.g. on CentOS/RHEL:
```
# yum install gcc gmake
```

### macOS:

Install the Xcode command line tools, as well as the packages *apr* and *apr-util*
with [brew](https://brew.sh/):
```
$ brew install apr apr-util
```
**Note**: it is possible to build the dispatcher against the includes and libraries provided
by the operating system; for more information, see the section *Making*, on *Linux and macOS*.

### Windows:

Install the Windows DDK 7.1.0.

---
## Third party libraries

- Download the *zlib* source distribution package from https://zlib.net/, extract and
  move the extracted folder *zlib-x.y.z* underneath `srclib`, and rename to *zlib*
- On Windows, download the *pcre* source distribution package from https://www.pcre.org/,
  extract and move the extract folder *pcre-x.y.z* underneath `srclib`, and
  rename to *pcre*

---
## Making

### Linux and macOS:

Enter `make` in the top directory:
```
$ make
```

**Note**: On macOS, the dispatcher will be built against the includes and libraries provided by [brew](https://brew.sh/). If you want to compile against the built-in Apache and its includes in `/usr/include` instead,  use NO_BREW:
```
$ NO_BREW=1 make
```

In order to build 32-bit binaries on Linux, specify the architecture when invoking make as follows:
```
$ export ARCH=i686
$ make
```

### Windows:

Depending on whether you want to create a 64 or 32-bit binary, open either a _x64_ or _x86 Free Build environment_, and invoke NMAKE:
```
$ nmake
```

---
## SSL builds

SSL builds are made when **WITH_SSL** is defined:
```
$ WITH_SSL=1.0 make   # Creates a build that links dynamically to OpenSSL 1.0.x
$ WITH_SSL=1.1 make   # Creates a build that links dynamically to OpenSSL 1.1.x
```

Complation will verify that the included OpenSSL version matches the one required. If they don't
match, you'll see an error message:
```
 # error Bad OpenSSL version detected
```

If the version you want to compile and link against is not found at the default location,
additionally specify the OpenSSL installation path:
```
$ WITH_SSL_DIR=/usr/local/opt/openssl make
```

**Note**: On Linux and macOS, it suffices to specify **WITH_SSL_DIR**, only. Its version is
automatically derived from the include files found there.

**Note**: On macOS, you'll have to install the *openssl* packages with `brew` first. On Windows,
download and install a full [OpenSSL](https://slproweb.com/products/Win32OpenSSL.html)
distribution package, either for 64 or 32-bit.

---
## Packaging

Building a dispatcher distribution package is done by executing the make tool with the _package_ target:
```
$ make package
```

