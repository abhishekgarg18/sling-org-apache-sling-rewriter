/*
 * Copyright (c) 2004 Day Management AG
 * Barfuesserplatz 6, 4001 Basel, Switzerland
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Day Management AG, ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Day.
 */
#include <stdio.h>
#include <sys/stat.h>

#include "httpd.h"
#include "http_config.h"
#include "http_core.h"
#include "http_log.h"
#include "http_main.h"
#include "http_protocol.h"
#include "http_connection.h"
#include "util_script.h"
#include "http_request.h"
#include "apr_strings.h"
#include "mod_ssl.h" /* for the ssl_var_lookup optional function defn */
#include "ap_mpm.h"

#include "base/base.h"

#include "dispatcher/any_dtd.h"
#include "dispatcher/dispatcher.h"
#include "dispatcher/farm.h"
#include "dispatcher/cache.h"

#ifdef WITH_SSL
#include <openssl/ssl.h>
#include <openssl/err.h>
#endif

#ifdef WITH_BREW
#include <dlfcn.h>
#endif

#ifndef DISPATCHER_VERSION
#define DISPATCHER_VERSION "internal"
#endif

/*
 * This macro was defined in Apache 2, but dropped in Apache 2.2. As long
 * as we have one source file for both, we need to conditionally define it.
 */
#ifndef APR_STATUS_IS_SUCCESS
#define APR_STATUS_IS_SUCCESS(st) ((st) == APR_SUCCESS)
#endif

/*
 * APLOG_MARK usually includes file/line numbers, which we don't want to
 * expose so we define our own macro that passes NULL as file.
 */
#define STRIP_FILE_LINE_MARK NULL, 0, APLOG_MODULE_INDEX

/**
 * Maximum secret size
 */
#define MAX_SECRET_SIZE 255

/*
 * Name of our input filters
 */
static const char *HOST_FILTER_NAME = "DIPATCHER_PATCH_HOST";

/*
 * Name of our output filters
 */
static const char *EXP_FILTER_NAME = "DISPATCHER_OUT_EXPIRES";
static const char *ETAG_FILTER_NAME = "DISPATCHER_OUT_ETAG";

/**
 * Server-wide configuration structure
 */
typedef struct server_config server_config;

struct server_config {
    /* configuration file name */
    const char *config_filename;
    /* log file name */
    const char *log_filename;
    /* flag indicating whether to decline root (unused) */
    int decline_root;
    /* flag indicating whether to use processed URL */
    int use_processed_url;
    /* flag indicating whether to respond in HTTP 1.0 */
    int use_http10;
    /* flag indicating whether to use the X-Forwarded-Host header for virtual hosting */
    int use_forwarded_host;
    /* secret file name for X-Forwarded-Host */
    const char *fh_secret_filename;
    /* flag indicating whether to use server name in via directive */
    int use_servername_in_via;
    /* flag indicating whether to pass the raw URL to the backend */
    int no_canon_url;
    /* keep alive timeout in seconds */
    int keep_alive_timeout;
    /* flag indicating whether to cache SSI files */
    int no_cache_ssi;
    /* flag indicating whether to force uncacheable content to private or not */
    int restrict_uncacheable_content;
    /* bitset controlling what codes should be passed to Apache */
    unsigned char pass_error_set[RESPONSE_CODES];

    /* dispatcher configuration */
    struct dispatcher_config dispatcher_config;
    /* log file */
    apr_file_t *log_file;
    /* log level */
    int log_level;
    /* X-Forwarded-Host secret */
    char fh_secret[MAX_SECRET_SIZE + 1];


#ifdef WITH_SSL
    /* client certificate */
    const char *certificate_filename;
    /* CA certificate */
    const char *ca_certificate_filename;
    /* flag indicating whether to check the peer CN */
    int check_peer_cn;
#endif

    /* whether keep alive timeout was set */
    unsigned keep_alive_timeout_set:1;
};


/* A structure describing webserver specific data */
struct ws_extra {
    /* request record */
    request_rec *r;
    /* server record, may be NULL */
    server_rec *s;
    /* flag indicating whether client was setup to read */
    unsigned client_setup:1;
    /* whether to pass error to Apache for *this* request */
    unsigned pass_error:1;
};

/* Our log context */
struct log_context {
    /* server configuration */
    server_config *c;
    /* server record, may be NULL */
    server_rec *s;
    /* request record, may be NULL */
    request_rec *r;
};

static apr_status_t close_log(void *data)
{
    apr_file_t *logf = (apr_file_t *) data;

    apr_file_close(logf);

    return APR_SUCCESS;
}

/**
 * Log level one letter abbreviations (preceded by dummy entry for missing zero LL_ value).
 */
static const char *log_levels = " EWIDT";

/**
 * Map of internal log levels -> Apache log levels
 */
static const int log_level_map[] = {
    -1,             /* dummy entry for missing zero LL_ value */
    APLOG_ALERT,
    APLOG_WARNING,
    APLOG_INFO,
    APLOG_DEBUG,
    APLOG_TRACE1
};

/**
 * Declare ourselves so the configuration routines can find and know us.
 * We'll fill it in at the end of the module.
 */
module AP_MODULE_DECLARE_DATA dispatcher_module;

/**
 * Flag indicating whether this module is initialized.
 */
static int module_initialized = 0;

/**
 * Index of 500 error code.
 */
static int index500 = 0;

/**
 * Optional function used to lookup SSL variables.
 */
static APR_OPTIONAL_FN_TYPE(ssl_var_lookup) *ssl_lookup = NULL;

/**
 * Flag indicating whether Apache is threaded.
 */
static int is_threaded = 0;

/**
 * Open a log file
 *
 * @param s server record
 * @param p memory allocation pool to use
 * @param name filename to use
 *
 * @return file reference, NULL if the opening failed
 */
static apr_file_t *open_log(server_rec *s, apr_pool_t *p, const char *name)
{
    apr_status_t st;
    apr_file_t *logf;
    piped_log *pl;

    if (*name == '|') {
        pl = ap_open_piped_log(p, name + 1);
        if (pl == NULL) {
            ap_log_error(STRIP_FILE_LINE_MARK, APLOG_ALERT | APLOG_NOERRNO, 0, s,
                         "Unable to open piped log for %s.", name + 1);
            return NULL;
        }
        logf = ap_piped_log_write_fd(pl);
    } else {
        name = ap_server_root_relative(p, name);
        st = apr_file_open(&logf, name, APR_CREATE | APR_WRITE | APR_APPEND, APR_OS_DEFAULT, p);
        if (!APR_STATUS_IS_SUCCESS(st)) {
            ap_log_error(STRIP_FILE_LINE_MARK, APLOG_ALERT | APLOG_NOERRNO, st, s,
                         "Unable to open log file %s.", name);
            return NULL;
        }
        apr_pool_cleanup_register(p, logf, close_log, apr_pool_cleanup_null);
    }
    return logf;
}

/**
 * Create server configuration
 *
 * @param p pool to use for allocations
 * @param s server record
 * @return server configuration
 */
static void *create_server_config(apr_pool_t *p, server_rec *s)
{
    server_config *sc;

    sc = (server_config *) apr_pcalloc(p, sizeof(server_config));
    memset(sc, 0, sizeof(server_config));

    return sc;
}

/**
 * Merge server configuration
 *
 * @param p pool to use for allocations
 * @param basev base configuration
 * @param addv configuration to merge with
 * @return merged configuration
 */
static void *merge_server_config(apr_pool_t *p, void *basev, void *addv)
{
    server_config *rec = (server_config *) apr_pcalloc(p, sizeof(server_config));
    server_config *base = (server_config *) basev;
    server_config *add = (server_config *) addv;
    int i;

    rec->config_filename = add->config_filename ? add->config_filename : base->config_filename;
    rec->log_filename = add->log_filename ? add->log_filename : base->log_filename;
    rec->decline_root = add->decline_root ? add->decline_root : base->decline_root;
    rec->use_processed_url = add->use_processed_url ? add->use_processed_url : base->use_processed_url;
    rec->use_http10 = add->use_http10 ? add->use_http10 : base->use_http10;
    rec->use_forwarded_host = add->use_forwarded_host ? add->use_forwarded_host : base->use_forwarded_host;
    rec->fh_secret_filename = add->fh_secret_filename ? add->fh_secret_filename : base->fh_secret_filename;
    rec->use_servername_in_via = add->use_servername_in_via ? add->use_servername_in_via : base->use_servername_in_via;
    rec->no_canon_url = add->no_canon_url ? add->no_canon_url : base->no_canon_url;
    rec->no_cache_ssi = add->no_cache_ssi? add->no_cache_ssi : base->no_cache_ssi;
    rec->restrict_uncacheable_content = add->restrict_uncacheable_content? add->restrict_uncacheable_content : base->restrict_uncacheable_content;

    if (add->keep_alive_timeout_set) {
        rec->keep_alive_timeout_set = 1;
        rec->keep_alive_timeout = add->keep_alive_timeout;
    } else {
        rec->keep_alive_timeout_set = base->keep_alive_timeout_set;
        rec->keep_alive_timeout = base->keep_alive_timeout;
    }
    for (i = 0; i < RESPONSE_CODES; i++) {
        rec->pass_error_set[i] = add->pass_error_set[i] ? add->pass_error_set[i] : base->pass_error_set[i];
    }

    rec->log_level = add->log_level ? add->log_level : base->log_level;

#ifdef WITH_SSL
    rec->certificate_filename = add->certificate_filename ? add->certificate_filename : base->certificate_filename;
    rec->ca_certificate_filename = add->ca_certificate_filename ? add->ca_certificate_filename : base->ca_certificate_filename;
    rec->check_peer_cn = add->check_peer_cn ? add->check_peer_cn : base->check_peer_cn;
#endif

    return rec;
}

/**
 * Set a filename inside the configuration section.
 *
 * @param cmd command parameters
 * @param struct_ptr structure pointer
 * @param arg argument
 * @return error message if directive could not be processed, otherwise NULL
 */
static const char *cmd_set_file_slot(cmd_parms * cmd, void *struct_ptr, const char *arg)
{
    server_rec *s;
    server_config *config;

    s = cmd->server;
    config = ap_get_module_config(s->module_config, &dispatcher_module);

    return ap_set_file_slot(cmd, config, arg);
}

/**
 * Set the log file name inside the configuration section.
 *
 * @param cmd command parameters
 * @param struct_ptr structure pointer
 * @param arg argument
 * @return error message if directive could not be processed, otherwise NULL
 */
static const char *cmd_set_log_file(cmd_parms *cmd, void *struct_ptr, const char *arg)
{
    server_rec *s;
    server_config *config;

    s = cmd->server;
    config = ap_get_module_config(s->module_config, &dispatcher_module);

    return ap_set_string_slot(cmd, config, arg);
}

static const char *cmd_set_log_level(cmd_parms *cmd, void *struct_ptr, const char *arg)
{
    server_rec *s;
    server_config *config;
    char *endptr;
    int level;

    s = cmd->server;
    config = ap_get_module_config(s->module_config, &dispatcher_module);

    if (!strcasecmp(arg, "error")) {
        config->log_level = LL_ERROR;
    } else if (!strcasecmp(arg, "warn")) {
        config->log_level = LL_WARN;
    } else if (!strcasecmp(arg, "info")) {
        config->log_level = LL_INFO;
    } else if (!strcasecmp(arg, "debug")) {
        config->log_level = LL_DEBUG;
    } else if (!strcasecmp(arg, "trace")) {
        config->log_level = LL_TRACE;
    } else {
        /* Account for LL_ERROR starting at 1 */
        level = (int) strtol(arg, &endptr, 10) + LL_ERROR;

        if ((*arg == '\0') || (*endptr != '\0')) {
            return apr_psprintf(cmd->pool,
                         "Invalid value for directive %s, expected integer",
                         cmd->directive->directive);
        }
        if (level < LL_ERROR || level > LL_TRACE) {
            return apr_psprintf(cmd->pool,
                         "Invalid value for directive %s, expected value in range [%d-%d], actual: %d",
                         cmd->directive->directive, LL_ERROR, LL_TRACE, level);
        }
        config->log_level = level;
    }
    return NULL;
}

/**
 * Set a flag inside the configuration section, that might be specified as
 * an integer (0 or 1).
 *
 * @param cmd command parameters
 * @param struct_ptr structure pointer
 * @param arg argument
 * @return error message if directive could not be processed, otherwise NULL
 */
static const char *cmd_set_int_flag_slot(cmd_parms *cmd, void *struct_ptr, const char *arg)
{
    server_rec *s;
    server_config *config;

    s = cmd->server;
    config = ap_get_module_config(s->module_config, &dispatcher_module);

    if (!strcasecmp(arg, "off") || !strcasecmp(arg, "on")) {
        return ap_set_flag_slot(cmd, config, strcasecmp(arg, "off") != 0);
    }
    return ap_set_int_slot(cmd, config, arg);
}

/**
 * Set the keep alive timeout. Separate function to track that some (even zero)
 * timeout was set.
 *
 * @param cmd command parameters
 * @param struct_ptr structure pointer
 * @param arg argument
 * @return error message if directive could not be processed, otherwise NULL
 */
static const char *cmd_set_keep_alive_timeout(cmd_parms *cmd, void *struct_ptr, const char *arg)
{
    server_rec *s;
    server_config *config;

    s = cmd->server;
    config = ap_get_module_config(s->module_config, &dispatcher_module);
    config->keep_alive_timeout_set = 1;

    return ap_set_int_slot(cmd, config, arg);
}

/**
 * Called for deprecated commands.
 *
 * @param cmd command parameters
 * @param struct_ptr structure pointer
 * @param arg argument
 * @return error message if directive could not be processed, otherwise NULL
 */
static const char *cmd_deprecated(cmd_parms *cmd, void *struct_ptr, const char *arg)
{
    ap_log_error(STRIP_FILE_LINE_MARK, APLOG_WARNING, 0, cmd->server,
                 "The %s directive in %s at line %d is deprecated and will be removed in a future release.",
                 cmd->cmd->name, cmd->directive->filename,
                 cmd->directive->line_num);
    return NULL;
}


#ifdef WITH_SSL

/**
 * Set a flag inside the configuration section. Used in SSL configurations,
 * only.
 *
 * @param cmd command parameters
 * @param struct_ptr structure pointer
 * @param arg argument
 *
 * @return error message if directive could not be processed, otherwise NULL
 */
static const char *cmd_set_flag_slot(cmd_parms * cmd, void *struct_ptr, int arg)
{
    server_rec *s;
    server_config *config;

    s = cmd->server;
    config = ap_get_module_config(s->module_config, &dispatcher_module);

    return ap_set_flag_slot(cmd, config, arg);
}

#endif /* WITH_SSL */

static const char *parse_code_range(cmd_parms *cmd, char *s, unsigned char *set)
{
    char *sep;
    int index, index_end, code, code_end;

    if ((sep = strchr(s, '-')) == NULL) {
        // single value
        code = atoi(s);
        if ((index = ap_index_of_response(code)) == index500 &&
                code != HTTP_INTERNAL_SERVER_ERROR) {
            return apr_pstrcat(cmd->pool,
                    "Unsupported HTTP response code ", s, NULL);
        } else if (index >= RESPONSE_CODES) {
            return apr_psprintf(cmd->pool,
                                "Index of response code %d out of range [0-%d]: %d",
                                code, RESPONSE_CODES - 1, index);
        }
        set[index] = 1;
    } else {
        // range
        *sep = 0;
        code = atoi(s);
        code_end = atoi(sep + 1);
        if (code >= code_end) {
            return apr_pstrcat(cmd->pool,
                    "HTTP response code range invalid: range start ", s,
                    " is not smaller than ", sep + 1, NULL);
        }
        if ((index = ap_index_of_response(code)) == index500 &&
                code != HTTP_INTERNAL_SERVER_ERROR) {
            return apr_pstrcat(cmd->pool,
                    "Unsupported HTTP response code ", s, NULL);
        } else if (index >= RESPONSE_CODES) {
            return apr_psprintf(cmd->pool,
                                "Index of response code %d out of range [0-%d]: %d",
                                code, RESPONSE_CODES - 1, index);
        }
        if ((index_end = ap_index_of_response(code_end)) == index500 &&
                code_end != HTTP_INTERNAL_SERVER_ERROR) {
            return apr_pstrcat(cmd->pool,
                    "Unsupported HTTP response code ", sep + 1, NULL);
        } else if (index_end >= RESPONSE_CODES) {
            return apr_psprintf(cmd->pool,
                                "Index of response code %d out of range [0-%d]: %d",
                                code_end, RESPONSE_CODES - 1, index_end);
        }
        while (index <= index_end) {
            set[index++] = 1;
        }
    }
    return NULL;
}

static const char *cmd_set_pass_error(cmd_parms *cmd, void *struct_ptr,
        const char *arg)
{
    server_rec *s;
    server_config *config;
    int i, index400;

    s = cmd->server;
    config = ap_get_module_config(s->module_config, &dispatcher_module);

    if (index500 == 0) {
        index500 = ap_index_of_response(HTTP_INTERNAL_SERVER_ERROR);
    }

    if (!strcmp(arg, "0")) {
        // old style switch off: nothing to be done
    } else if (!strcmp(arg, "1")) {
        // old style switch on: set all error codes to true
        index400 = ap_index_of_response(HTTP_BAD_REQUEST);
        for (i = index400; i < RESPONSE_CODES; i++) {
            config->pass_error_set[i] = 1;
        }
    } else {
        // new style: parse status codes (comma-separated, may include ranges)
        const char *sep, *start = arg, *error_str;
        char buf[256];
        size_t n;

        while (*start) {
            if ((sep = strchr(start, ',')) == NULL) {
                n = strlen(start);
            } else {
                n = sep - start;
            }
            if (n >= sizeof(buf) - 1) {
                return apr_pstrcat(cmd->pool, "Argument ", start, " too long", NULL);
            }
            strncpy(buf, start, n);
            buf[n] = 0;
            if ((error_str = parse_code_range(cmd, buf, config->pass_error_set)) != NULL) {
                return error_str;
            }
            start += n;
            if (sep) start++;
        }
    }
    return NULL;
}

static const char *cmd_set_forwarded_host(cmd_parms *cmd, void *struct_ptr, const char *arg)
{
    server_rec *s;
    server_config *config;

    s = cmd->server;
    config = ap_get_module_config(s->module_config, &dispatcher_module);

    if (!strcasecmp(arg, "off") || !strcmp(arg, "0")) {
        config->use_forwarded_host = 0;
        return NULL;
    }
    if (!strcasecmp(arg, "on") || !strcmp(arg, "1")) {
        config->use_forwarded_host = 1;
        ap_log_error(STRIP_FILE_LINE_MARK, APLOG_WARNING, 0, cmd->server,
                     "%s:%d: the %s directive is set without a shared secret which is unsafe.",
                     cmd->directive->filename, cmd->directive->line_num, cmd->cmd->name);
        return NULL;
    }
    /* Neither On nor Off, so we have a secret in a file */
    config->use_forwarded_host = 1;
    return ap_set_file_slot(cmd, config, arg);
}

/**
 * Dispatcher handler. Invoked every time a request arrives.
 *
 * @param r request record
 * @return how to proceed with the request
 */
static int dispatcher_handler(request_rec *r)
{
    struct log_context *lc;
    struct dispatcher *d;
    struct ws_extra *ws;
    int sc;
    server_rec *s;
    server_config *c;

    /* Make sure, we're the one */
    if (strcmp(r->handler, "dispatcher-handler")) {
        return DECLINED;
    }

    s = r->server;
    c = ap_get_module_config(s->module_config, &dispatcher_module);

    /* initialize log context */
    lc = apr_pcalloc(r->pool, sizeof(struct log_context));
    lc->c = c;
    lc->r = r;
    lc->s = s;

    if (c->dispatcher_config.farm == NULL) {
        WARN("Dispatcher set as handler, but not configured in server [%s].", s->server_hostname);
        return DECLINED;
    }

    /* initialize dispatcher and webserver specific information */
    ws = apr_pcalloc(r->pool, sizeof(struct ws_extra));
    ws->r = r;
    ws->s = s;

    d = apr_pcalloc(r->pool, sizeof(struct dispatcher));
    d->lc = lc;
    d->ws = ws;
    d->config = &c->dispatcher_config;

    ap_add_output_filter(EXP_FILTER_NAME, d, r, r->connection);
    ap_add_output_filter(ETAG_FILTER_NAME, d, r, r->connection);

    sc = dispatcher_service(d);

    switch (sc) {
    case OK:
        /* Some response was generated, but it is ok for other modules to
         * handle this stage. Pass error status code to Apache if we're
         * told to do so */
        if (ws->pass_error && ap_is_HTTP_ERROR(d->status)) {
            return d->status;
        }
        return OK;

    case DECLINED:
        /* If request was rejected, HTTP_NOT_FOUND should be returned.
         * Otherwise request may get served from cache (if content is cached)
         */
        if (d->rejected) {
            return HTTP_NOT_FOUND;
        }
        /* No response was generated, the target is in the cache and can
         * be delivered.
         */
        return DECLINED;

    default:
        /* There was some error processing the request, no response was
         * generated, so just return the status code.
         */
        return sc;
    }
}

static void dump_any(apr_file_t *f, struct any_item *parent, int level)
{
    struct any_item *current = parent->first;
    int i;

    while (current != 0) {
        for (i = 0; i < level; i++) {
            apr_file_printf(f, "  ");
        }
        if (strcmp(current->label, "")) {
            apr_file_printf(f, "/%s ", current->label);
        }
        switch (current->type) {
            case NUMBER:
                apr_file_printf(f, "%d\n", current->value.d);
                break;
            case STRING:
                apr_file_printf(f, "\"%s\"\n", current->value.p);
                break;
            case REGEXP:
                apr_file_printf(f, "\'%s\'\n", current->value.p);
                break;
            case NODE:
                apr_file_printf(f, "{\n");
                dump_any(f, current, level + 1);
                for (i = 0; i < level; i++) {
                    apr_file_printf(f, "  ");
                }
                apr_file_printf(f, "}\n");
                break;
        }
        current = current->next;
    }
}

/**
 * Context passed to resolve_env()
 */
struct resolve_env_context {
    /* Log context */
    struct log_context *lc;
    /* Pool used to make allocations */
    apr_pool_t *p;
};

static char *resolve_env(const char *name, void *u)
{
    struct resolve_env_context *rc = (struct resolve_env_context *) u;
    struct log_context *lc = rc->lc;
    char buf[256];

    if (strlen(name) > sizeof(buf) - 3) {
        WARN("Unable to resolve environment variable '%s': length exceeds %d bytes.", name, sizeof(buf) - 3);
        return NULL;
    }
    snprintf(buf, sizeof buf, "${%s}", name);
    return (char *) ap_resolve_env(rc->p, buf);
}

/**
 * Test the dispatcher configuration of a server, either the main one or
 * all the virtual ones.
 *
 * @param p pool
 * @param s server's dispatcher configuration to initialize
 * @param first_virtual first virtual server or <code>NULL</code> if
 *                      there are no virtual servers
 */
static void test_server(struct log_context *lc, apr_pool_t *p, server_rec *s, server_rec *first_virtual, struct any_item *dtd)
{
    struct resolve_env_context rc;
    server_config *c, *c2;
    server_rec *v;
    char config_filename[PATH_MAX];
    struct any_item *root;

    c = ap_get_module_config(s->module_config, &dispatcher_module);
    if (!c->config_filename) {
        return;
    }

    /* Does a previously passed server have the same configuration? */
    for (v = first_virtual; v && v != s; v = v->next) {
        c2 = ap_get_module_config(v->module_config, &dispatcher_module);
        if (c2->config_filename && !strcmp(c2->config_filename, c->config_filename)) {
            /* Yes, so skip testing that */
            return;
        }
    }

    /* No: so we need to test it */
    strcpy(config_filename, c->config_filename);
    NORMALIZE_FILENAME(config_filename);

    rc.lc = lc;
    rc.p = p;
    root = any_import(lc, config_filename, resolve_env, &rc);

    if (root && ap_exists_config_define("DUMP_ANY")) {
        apr_file_t *thefile = NULL;
        apr_file_open_stdout(&thefile, p);
        apr_file_printf(thefile, "# Dispatcher configuration: (%s)\n", config_filename);
        dump_any(thefile, root, 0);
    }

    if (root && dtd) {
        any_validate(lc, root, dtd);
    }
}

/**
 * Hook invoked when the Apache's configuration is tested (either through apachectl configtest or
 * httpd -t).
 *
 * @param p pool used to allocate configuration space
 * @param s server record
 */
static void test_config(apr_pool_t* p, server_rec* s)
{
    struct log_context mylc, *lc = &mylc;
    struct any_item *dtd;
    server_rec *v;

    memset(lc, 0, sizeof(struct log_context));
    lc->s = s;

    dtd = any_parse(lc, ANY_DTD);

    if (!s->next) {
        /* No virtual hosts configured, just test the main server */
        test_server(lc, p, s, NULL, dtd);
    } else {
        /* Virtual hosts configured, test all *but* the main server */
        for (v = s->next; v; v = v->next) {
            test_server(lc, p, v, s->next, dtd);
        }
    }
    if (dtd) {
        any_free(dtd);
    }
}

static apr_status_t config_free(void *data)
{
    struct dispatcher_config *c = (struct dispatcher_config *) data;

    dispatcher_terminate(c);

    return APR_SUCCESS;
}

static apr_status_t module_free(void *data)
{
    module_initialized = 0;

    return APR_SUCCESS;
}

/**
 * Initialize the dispatcher configuration of a server, either the main one or
 * all the virtual ones.
 *
 * @param s server's dispatcher configuration to initialize
 * @param first_virtual first virtual server or <code>NULL</code> if
 *                      there are no virtual servers
 * @param p pool
 */
static int initialize_any(struct log_context *lc, server_rec *s, server_rec *first_virtual,
                          apr_pool_t *p, server_config *c)
{
    server_rec *v;
    char config_filename[PATH_MAX];
    struct any_item *root;
    int ret;

    /* Does a previously passed server have the same configuration? */
    for (v = first_virtual; v && v != s; v = v->next) {
        server_config *c2 = ap_get_module_config(v->module_config, &dispatcher_module);
        if (c2->config_filename && !strcmp(c2->config_filename, c->config_filename)) {
            /* Yes: so just copy it over */
            DBG("Server [%s] has identical configuration as [%s].",
                s->server_hostname, v->server_hostname);
            memcpy(&c->dispatcher_config, &c2->dispatcher_config, sizeof(struct dispatcher_config));
            return 0;
        }
    }

    /* No: so we need to initialize it properly */
    strcpy(config_filename, c->config_filename);
    NORMALIZE_FILENAME(config_filename);

    if ((root = any_import(lc, config_filename, resolve_env, p)) == NULL) {
        ERR("Unable to import config file: %s", config_filename);
        return -1;
    }
    ret = dispatcher_init_config(lc, root, &c->dispatcher_config, "apache-2.4");
    if (!ret) {
        apr_pool_cleanup_register(p, &c->dispatcher_config, config_free, apr_pool_cleanup_null);
    }
    any_free(root);
    return ret;
}

static int initialize_log(server_rec *s, server_rec *first_virtual, apr_pool_t *p, server_config *c)
{
    server_rec *v;

    /* Does a previously passed server have the same log file configured? */
    for (v = first_virtual; v && v != s; v = v->next) {
        server_config *c2 = ap_get_module_config(v->module_config, &dispatcher_module);
        if (c2->log_filename && !strcmp(c2->log_filename, c->log_filename)) {
            /* Yes: so just copy the file handle */
            c->log_file = c2->log_file;
            return 0;
        }
    }

    /* No: so we need to initialize it properly */
    if ((c->log_file = open_log(s, p, c->log_filename)) == NULL) {
        return -1;
    }
    return 0;
}

/**
 * Initialize the dispatcher configuration of a server, either the main one or
 * all the virtual ones.
 *
 * @param s server's dispatcher configuration to initialize
 * @param first_virtual first virtual server or <code>NULL</code> if
 *                      there are no virtual servers
 * @param p pool
 */
static int initialize_server(struct log_context *lc, server_rec *s, server_rec *first_virtual, apr_pool_t *p)
{
    server_config *c;
    char *p1, *p2;

    c = ap_get_module_config(s->module_config, &dispatcher_module);

    /* Initialize log file */
    if (c->log_filename && initialize_log(s, first_virtual, p, c)) {
        return -1;
    }

    /* Initialize any structure */
    if (!c->config_filename) {
        INFO("Server [%s] has no dispatcher configuration.", s->server_hostname);
    } else if (initialize_any(lc, s, first_virtual, p, c)) {
        // TODO: should lc be the parent or *this* server?
        return -1;
    }

    /* Initialize secret */
    if (c->fh_secret_filename) {
        p1 = mallocbinfile(c->fh_secret_filename);
        if (p1 == NULL) {
            ERR("Unable to load secret file %s: %s", c->fh_secret_filename, strerror(errno));
            return -1;
        }
        p2 = trim(p1, " \r\n");
        if (strlen(p2) >= MAX_SECRET_SIZE) {
            ERR("Unable to load secret file %s: size exceeds %d characters", c->fh_secret_filename, MAX_SECRET_SIZE);
            free(p1);
            return -1;
        }
        strncpy(c->fh_secret, p2, MAX_SECRET_SIZE);
        c->fh_secret[MAX_SECRET_SIZE] = 0;
        free(p1);
    }
    return 0;
}

/**
 * Module initializer. Invoked once when the configuration has been completely
 * processed.
 *
 * @param p pool used to allocate configuration space
 * @param plog pool used to allocate memory
 * @param ptemp pool used to allocate temporary memory
 * @param s server record
 * @return OK if everything went fine; otherwise some HTTP_mumble code
 */
static int post_config(apr_pool_t *p, apr_pool_t *plog, apr_pool_t *ptemp, server_rec *s)
{
    struct log_context mylc, *lc = &mylc;
    server_config *config;
    server_rec *v;
    char server_header[256];
    int result, keep_alive_timeout;

    if (module_initialized) {
        return OK;
    }

    config = ap_get_module_config(s->module_config, &dispatcher_module);

    memset(lc, 0, sizeof(struct log_context));
    lc->c = config;
    lc->s = s;

#ifdef WITH_BREW
    if (dlsym(RTLD_DEFAULT, "apr_stat$INODE64") != NULL) {
        ERR("Unable to run in macOS builtin Apache, please use brew's Apache instead");
        return HTTP_INTERNAL_SERVER_ERROR;
    }
#endif
    if (ap_mpm_query(AP_MPMQ_IS_THREADED, &result) == APR_SUCCESS) {
        is_threaded = result;
    }

#ifdef WITH_SSL
    if (sslsockets_init(lc, config->certificate_filename, config->ca_certificate_filename, config->check_peer_cn, is_threaded)) {
        ERR("SSL library initialization failed.");
        return HTTP_INTERNAL_SERVER_ERROR;
    }
#else
    if (sockets_init(is_threaded)) {
        return HTTP_INTERNAL_SERVER_ERROR;
    }
#endif

    if (index500 == 0) {
        index500 = ap_index_of_response(HTTP_INTERNAL_SERVER_ERROR);
    }

    module_initialized = 1;

    apr_pool_cleanup_register(p, s, module_free, apr_pool_cleanup_null);

    snprintf(server_header, sizeof(server_header), "Communique/%s", DISPATCHER_VERSION);
    ap_add_version_component(p, server_header);

    ssl_lookup = APR_RETRIEVE_OPTIONAL_FN(ssl_var_lookup);

    if (!s->next) {
        /* No virtual hosts configured, just initialize the main server */
        DBG("No virtual hosts detected, initializing main server [%s].", s->server_hostname);
        if (initialize_server(lc, s, NULL, p)) {
            ERR("Dispatcher initialization failed.");
            return HTTP_INTERNAL_SERVER_ERROR;
        }
    } else {
        /* Virtual hosts configured, initialize all *but* the main server */
        for (v = s->next; v; v = v->next) {
            DBG("Initializing virtual host [%s].", v->server_hostname);
            if (initialize_server(lc, v, s->next, p)) {
                ERR("Dispatcher initialization failed.");
                return HTTP_INTERNAL_SERVER_ERROR;
            }
        }
    }

    keep_alive_timeout = config->keep_alive_timeout_set ? config->keep_alive_timeout : DEFAULT_KEEP_ALIVE_TIMEOUT_SEC;
    if (keep_alive_timeout > 0) {
        DBG("HTTP keepalive is enabled, timeout is %d seconds.", keep_alive_timeout);
    }

    return OK;
}

/**
 * List of directives to our module
 */
static const command_rec command_table[] = {

  AP_INIT_TAKE1("DispatcherConfig", cmd_set_file_slot,
                (void *) APR_OFFSETOF(server_config, config_filename),
                RSRC_CONF, "Dispatcher config file name"),

  AP_INIT_TAKE1("DispatcherLog", cmd_set_log_file,
                (void *) APR_OFFSETOF(server_config, log_filename),
                RSRC_CONF, "Dispatcher log file name"),

  AP_INIT_TAKE1("DispatcherLogLevel", cmd_set_log_level,
                NULL,
                RSRC_CONF, "Dispatcher log level"),

  AP_INIT_TAKE1("DispatcherNoServerHeader", cmd_deprecated,
                NULL,
                RSRC_CONF, "Whether to suppress our own server header"),

  AP_INIT_TAKE1("DispatcherDeclineRoot", cmd_set_int_flag_slot,
                (void *) APR_OFFSETOF(server_config, decline_root),
                RSRC_CONF, "Whether to handle requests to /"),

  AP_INIT_TAKE1("DispatcherUseProcessedURL", cmd_set_int_flag_slot,
                (void *) APR_OFFSETOF(server_config, use_processed_url),
                RSRC_CONF, "Whether to use the URL already processed "
                "by handlers preceeding the dispatcher instead of the original "
                "one passed to the web server"),

  AP_INIT_TAKE1("DispatcherUseHttp10", cmd_set_int_flag_slot,
                (void *) APR_OFFSETOF(server_config, use_http10),
                RSRC_CONF, "Whether to use HTTP 1.0 protocol in the "
                "communication to the server regardless of the client request"),

  AP_INIT_TAKE1("DispatcherUseForwardedHost", cmd_set_forwarded_host,
                (void *) APR_OFFSETOF(server_config, fh_secret_filename),
                RSRC_CONF, "Use the X-Forwarded-Host header to determine the VirtualHost "
                "if present, otherwise use the Host header"),

  AP_INIT_TAKE1("DispatcherPassError", cmd_set_pass_error,
                NULL,
                RSRC_CONF, "Contains either a flag or a range of HTTP status codes, "
                "controlling whether a remote response should be returned to Apache "
                "instead of spooling it to the client"),

  AP_INIT_TAKE1("DispatcherUseServerNameInVia", cmd_set_int_flag_slot,
                (void *) APR_OFFSETOF(server_config, use_servername_in_via),
                RSRC_CONF, "Whether to put the server name in the Via header."),

  AP_INIT_TAKE1("DispatcherKeepAliveTimeout", cmd_set_keep_alive_timeout,
                (void *) APR_OFFSETOF(server_config, keep_alive_timeout),
                RSRC_CONF, "Specifies the number of seconds to keep connections to "
                "some backend alive. Disables this feature if set to 0. Default is 60."),

  AP_INIT_TAKE1("DispatcherNoCanonURL", cmd_set_int_flag_slot,
                (void *) APR_OFFSETOF(server_config, no_canon_url),
                RSRC_CONF, "Whether to pass the raw URL to the backend instead of "
                           "the canonicalised one"),

  AP_INIT_TAKE1("DispatcherSSINoCache", cmd_set_int_flag_slot,
                (void *) APR_OFFSETOF(server_config, no_cache_ssi),
                RSRC_CONF, "Whether to cache SSI files or not"),

  AP_INIT_TAKE1("DispatcherRestrictUncacheableContent", cmd_set_int_flag_slot,
                (void *) APR_OFFSETOF(server_config, restrict_uncacheable_content),
                RSRC_CONF, "Whether to force uncacheable content to private or not"),

#ifdef WITH_SSL

  AP_INIT_TAKE1("DispatcherCertificateFile", cmd_set_file_slot,
                (void *) APR_OFFSETOF(server_config, certificate_filename),
                RSRC_CONF, "Client certificate file, containing the unencrypted private key "
                           "as well, used when SSL server requests client certificate."),

  AP_INIT_TAKE1("DispatcherCACertificateFile", cmd_set_file_slot,
                (void *) APR_OFFSETOF(server_config, ca_certificate_filename),
                RSRC_CONF, "CA certificate file, used if the SSL server presents a CA that "
                           "is not trusted by a root authority."),

  AP_INIT_FLAG("DispatcherCheckPeerCN", cmd_set_flag_slot,
               (void *) APR_OFFSETOF(server_config, check_peer_cn),
               RSRC_CONF, "Whether to enable host name checking for remote server certificates"),

#endif

  { NULL }
};

/**
 * Child exit method, invoked when a child process is about to be terminated.
 */
static apr_status_t child_exit(void *data)
{
#ifdef WITH_SSL
    sslsockets_cleanup();
#endif

    return APR_SUCCESS;
}

static void set_expires_note(struct dispatcher *d, request_rec *r)
{   
    /* check the configuration set in dispatcher configuration */
    if (d->lc->c->restrict_uncacheable_content) {
        if (!d->hit && !d->miss) {
            if (apr_table_get(r->headers_out, "Expires") == NULL && 
                    apr_table_get(r->headers_out, "Cache-Control") == NULL) {
                apr_table_set(r->notes, "dispatcher-no-expire", "1");
            }
        }
    }
}

static void unset_expires(request_rec *r)
{
    if (apr_table_get(r->notes, "dispatcher-no-expire")) {
        /* Remove headers generated by mod_expires */
        apr_table_unset(r->headers_out, "Expires");
        apr_table_unset(r->headers_out, "Cache-Control");
    }
}

static void unset_etag(request_rec *r)
{
    if (apr_table_get(r->notes, "dispatcher-custom-etag")) {
        /* Suppress the no-etag marker that would eventually remove our custom ETag */
        apr_table_unset(r->notes, "no-etag");
    }
}

/**
 * Output filter that:
 * - removes the request note that would suppress our ETag
 * - removes generated expiry headers in case our response should not be cached
 *
 * This filter is called twice, once for remembering the state of the cache control
 * headers before mod_expires runs and then another time to eventually undo
 * what mod_expires did and keep our custom ETag.
 *
 * @param f filter structure
 * @param bb bocket brigade
 * @return status
 */
static apr_status_t output_filter(ap_filter_t *f, apr_bucket_brigade *bb)
{
    request_rec *r = f->r;
    struct dispatcher *d = f->ctx;
    int second_call;

    second_call = strcasecmp(f->frec->name, ETAG_FILTER_NAME) == 0 ? 1 : 0;
    if (second_call) {
        unset_expires(r);
        unset_etag(r);
    } else {
        set_expires_note(d, r);
    }

    /* remove ourselves from the filter chain */
    ap_remove_output_filter(f);

    /* send the data up the stack */
    return ap_pass_brigade(f->next, bb);
}

/**
 * Child init method, invoked when a child process is created.
 */
static void child_init(apr_pool_t *p, server_rec *s)
{
    struct log_context mylc, *lc = &mylc;
    server_config *config;
    int keep_alive_timeout;
    unsigned int seed;

    apr_pool_cleanup_register(p, s, child_exit, apr_pool_cleanup_null);

    config = ap_get_module_config(s->module_config, &dispatcher_module);

    memset(lc, 0, sizeof(struct log_context));
    lc->c = config;
    lc->s = s;

    keep_alive_timeout = config && config->keep_alive_timeout_set ? config->keep_alive_timeout : DEFAULT_KEEP_ALIVE_TIMEOUT_SEC;

    if (keep_alive_timeout > 0) {
        init_socket_factory(lc, 1, keep_alive_timeout);
    }

    seed = (time(NULL) & 0xFFFF) | (getpid() << 16);
    TRACE("Initializing PRNG with seed: %ld", seed);
    srand(seed);
}

/**
 * Return the first entry of a header value, trimmed.
 *
 * @param pool pool
 * @param header header value
 * @param ws characters considered whitespace
 *
 * @return first entry
 */
static const char *get_first_entry(apr_pool_t *pool, const char *header, const char *ws)
{
    char *sep, *entry;
    size_t len;

    sep = strchr(header, ',');
    if (sep == NULL) {
        return header;
    }
    len = sep - header;
    entry = apr_pstrndup(pool, header, len);
    return trim(entry, ws);
}

static void pre_read_request(request_rec *r, conn_rec *c)
{
    server_config *config;
    const char *forwarded_host, *original_host, *edge_key, *new_host;

    config = ap_get_module_config(r->server->module_config, &dispatcher_module);
    if (!config->use_forwarded_host) {
        /* Not enabled */
        return;
    }

    original_host = apr_table_get(r->headers_in, "Host");
    forwarded_host = apr_table_get(r->headers_in, "X-Forwarded-Host");

    if (forwarded_host == NULL ) {
        if (original_host == NULL) {
            /* No headers at all, so switch to filter mode */
            ap_add_input_filter(HOST_FILTER_NAME, NULL, r, c);
        }
        return;
    }
    if (config->fh_secret[0]) {
        edge_key = apr_table_get(r->headers_in, "X-Edge-Key");
        if (edge_key == NULL || str_iseq(config->fh_secret, edge_key) != 0) {
            ap_log_rerror(STRIP_FILE_LINE_MARK, APLOG_WARNING | APLOG_NOERRNO, 0, r,
                "X-Forwarded-Host not accepted, no matching secret provided.");
            return;
        }
    }
    if (original_host != NULL) {
        apr_table_set(r->headers_in, "X-Original-Host", original_host);
    }
    new_host = get_first_entry(r->pool, forwarded_host, " \t");
    ap_log_rerror(STRIP_FILE_LINE_MARK, APLOG_DEBUG | APLOG_NOERRNO, 0, r,
        "Changing Host header to: %s.", new_host);
    apr_table_set(r->headers_in, "Host", new_host);
}

/**
 * Macros to shorten debug and trace statements.
 */
#define AP_DEBUG(...)                                                                              \
    ap_log_rerror(STRIP_FILE_LINE_MARK, APLOG_DEBUG | APLOG_NOERRNO, 0, f->r, __VA_ARGS__);
#define AP_TRACE1(...)                                                                             \
    ap_log_rerror(STRIP_FILE_LINE_MARK, APLOG_TRACE1 | APLOG_NOERRNO, 0, f->r, __VA_ARGS__);

/* Not going to handle FQDN > 511 bytes. */
#define MAX_HEADER_LENGTH 512

/**
 * Headers filter context
 */
struct hf_context {
    /* The original Host value */
    char *original_host;
    /* The value of X-Forwarded-Host */
    char *forwarded_host;
    /* The value of X-Edge-Key */
    char *edge_key;
    /* Flag indicating whether we still need to send end of headers line */
    unsigned send_eohl;
};

/**
 * Header processing.
 */
static struct hf_processing {
    /* Name */
    const char *name;
    /* Name length */
    size_t name_len;
    /* Whether to suppress */
    unsigned suppress;
    /* Offset within struct hf_context */
    size_t offset;
}
hf_processing[] = {
    { "Host:", 5, 1, APR_OFFSETOF(struct hf_context, original_host) },
    { "X-Forwarded-Host:", 17, 0, APR_OFFSETOF(struct hf_context, forwarded_host)  },
    { "X-Edge-Key:", 11, 1, APR_OFFSETOF(struct hf_context, edge_key) },
    { NULL, 0, 0, 0 }
};

/**
 * Process a request header line. If the header name matches one of the above,
 * we will store its value and eventually suppress it, so we can provide a
 * replacement later.
 *
 * @param f filter
 * @param header request header line
 * @param pctx where to return a newly created context
 *
 * @return <code>1</code> to suppress the header;
 *         <code>0</code> otherwise
 */
static int process_header(ap_filter_t *f, char *header, struct hf_context **pctx) {
    struct hf_context *ctx = f->ctx;
    struct hf_processing *p;

    for (p = &hf_processing[0]; p->name != NULL; p++) {
        if (!strncasecmp(header, p->name, p->name_len)) {
            if (ctx == NULL) {
                *pctx = ctx = f->ctx = apr_pcalloc(f->r->pool, sizeof(struct hf_context));
            }
            /* Store the trimmed header value in the respective struct field */
            *(char **)((char*) ctx + p->offset) =
                apr_pstrdup(f->r->pool, trim(&header[p->name_len], " \t"));
            return p->suppress;
        }
    }
    return 0;
}

/**
 * Check whether we're allowed to replace the Host header. If we have a secret
 * configured, the client needs to send a matching edge key.
 */
static unsigned allowed_to_replace(ap_filter_t *f) {
    struct hf_context *ctx = f->ctx;
    server_config *config;

    config = ap_get_module_config(f->r->server->module_config, &dispatcher_module);
    if (config && config->fh_secret[0]) {
        if (ctx->edge_key == NULL || str_iseq(config->fh_secret, ctx->edge_key)) {
            ap_log_rerror(STRIP_FILE_LINE_MARK, APLOG_WARNING | APLOG_NOERRNO, 0, f->r,
                "X-Forwarded-Host not accepted, no matching secret provided.");
            return 0;
        }
    }
    return 1;
}

/**
 * Input filter that rewrites Host header to the value of X-Forwarded-Host
 * if available.
 *
 * Internally, we stow away the Host header found. When the terminating
 * end of headers line is encountered, we inject our (eventually modified)
 * Host header, and in the next call, we send the (still missing) terminating
 * end of headers line.
 */
static apr_status_t filter_headers(ap_filter_t *f, apr_bucket_brigade *bb,
    ap_input_mode_t mode, apr_read_type_e block, apr_off_t readbytes)
{
    apr_off_t length;
    apr_status_t status;
    char header[MAX_HEADER_LENGTH];
    const char *new_host;
    struct hf_context *ctx = f->ctx;
    apr_size_t header_length = MAX_HEADER_LENGTH -1;

    if (mode != AP_MODE_GETLINE || f->r == NULL) {
        /* We don't know how to handle those */
        ap_remove_input_filter(f);
        return ap_get_brigade(f->next, bb, mode, block, readbytes);
    }

    if (ctx && ctx->send_eohl) {
        /* Called after we sent back our host header
           we still need to send the end of headers line */
        ap_remove_input_filter(f);
        apr_brigade_cleanup(bb);
        return apr_brigade_putstrs(bb, NULL, NULL, "\r\n", NULL);
    }

    while (1) {
        /* Invoke the next filter */
        status = ap_get_brigade(f->next, bb, mode, block, readbytes);
        if (status != APR_SUCCESS) {
            break;
        }
        /* Fetch the next line received */
        apr_brigade_length(bb, 0, &length);
        apr_brigade_flatten(bb, header, &header_length);

        /* Trim away white space on the right */
        header[header_length] = 0;
        while (header_length > 0 && WS(header[header_length - 1])) {
            header[--header_length] = '\0';
        }
        if (header_length > 0) {
            if (process_header(f, header, &ctx)) {
                /* Suppress that header, ask for the next */
                apr_brigade_cleanup(bb);
                continue;
            }
            break;
        }

        /* Found the terminating end of headers line */
        if (ctx && ctx->original_host) {
            apr_brigade_cleanup(bb);
            if (ctx->forwarded_host && allowed_to_replace(f)) {
                /* Return a modified Host header */
                new_host = get_first_entry(f->r->pool, ctx->forwarded_host, " \t");
                AP_DEBUG("Changing Host header to: %s.", new_host);
                apr_brigade_putstrs(bb, NULL, NULL, "Host: ", new_host, "\r\n", NULL);
                apr_table_set(f->r->headers_in, "X-Original-Host", ctx->original_host);
            } else {
                /* Return the original Host header */
                apr_brigade_putstrs(bb, NULL, NULL, "Host: ", ctx->original_host, "\r\n", NULL);
            }
            /* Remember to send the terminating end of headers line in the next call */
            ctx->send_eohl = 1;
        }
        break;
    }
    return status;
}


static void register_hooks(apr_pool_t * p)
{
    ap_hook_pre_read_request(pre_read_request, NULL, NULL, APR_HOOK_MIDDLE);

    /* with this filter we can patch the host header if configured */
    ap_register_input_filter(HOST_FILTER_NAME, filter_headers, NULL, AP_FTYPE_PROTOCOL);

    /* with this type we get called first before mod_expires executes */
    ap_register_output_filter(EXP_FILTER_NAME, output_filter, NULL, AP_FTYPE_CONTENT_SET - 3);
    /* with this type we get called after mod_expires has executed */
    ap_register_output_filter(ETAG_FILTER_NAME, output_filter, NULL, AP_FTYPE_CONTENT_SET);

    ap_hook_child_init(child_init, NULL, NULL, APR_HOOK_MIDDLE);
    ap_hook_handler(dispatcher_handler, NULL, NULL, APR_HOOK_MIDDLE);
    ap_hook_test_config(test_config, NULL, NULL, APR_HOOK_MIDDLE);
    ap_hook_post_config(post_config, NULL, NULL, APR_HOOK_MIDDLE);
}


/**
 * This directive, introduced in 2.3, adds our module prefix when logging to error.log.
 *
 * Note: 2.4 modules use AP_DECLARE_MODULE(name) which combines APLOG_USE_MODULE and AP_MODULE_DECLARE_DATA.
 */
#ifdef APLOG_USE_MODULE
APLOG_USE_MODULE(dispatcher);
#endif

/**
 * List of callback routines
 */
module AP_MODULE_DECLARE_DATA dispatcher_module = {
    STANDARD20_MODULE_STUFF,
    NULL,                        /* per-directory config creator */
    NULL,                        /* dir config merger */
    create_server_config,        /* server config creator */
    merge_server_config,         /* server config merger */
    command_table,               /* command table */
    register_hooks
};

/**
 * Return the protocol sent to the main request. This walks up the stack of
 * included requests (with protocol "INCLUDED") until the main request and
 * returns that protocol. If an error occurs, NULL is returned.
 *
 * @return valid protocol
 */
static const char *get_protocol(struct log_context *lc, request_rec *r)
{
    while (r->protocol != NULL && !strcmp(r->protocol, "INCLUDED")) {
        if (r->main == NULL) {
            WARN("Included request has no parent.");
            return NULL;
        }
        r = r->main;
    }
    if (r->protocol == NULL) {
        WARN("Request protocol is NULL.");
        return NULL;
    }
    return r->protocol;
}

static const char *request_ssl_var(request_rec *r, char *name)
{
    if (ssl_lookup) {
        const char *val = ssl_lookup(r->pool, r->server, r->connection, r, name);
        if (val && val[0]) {
            return val;
        }
    }
    return NULL;
}


/*----------------------------------------------------------- Public methods */

static void log_out_to_file(apr_file_t *log_file, enum log_level level, const char *fmt, va_list args)
{
    const int line_len = 8192, eol_len = sizeof(APR_EOL_STR);
    char line[8192], now[256];
    int len = 0;

    apr_ctime(now, apr_time_now());
    len += apr_snprintf(line + len, sizeof(line) - len, "[%s] ", now);
    len += apr_snprintf(line + len, sizeof(line) - len, "[%c] ", log_levels[level]);

    if (is_threaded) {
        apr_os_thread_t tid = apr_os_thread_current();
        len += apr_snprintf(line + len, sizeof(line) - len,
                            "[pid %" APR_PID_T_FMT ":tid %pT] ", getpid(), &tid);
    } else {
        len += apr_snprintf(line + len, sizeof(line) - len,
                            "[pid %" APR_PID_T_FMT "] ", getpid());
    }

    len += vsnprintf(line + len, sizeof(line) - len, fmt, args);

    if (len > line_len - eol_len) {
        len = line_len - eol_len;
    }
    strcpy(line + len, APR_EOL_STR);

    apr_file_puts(line, log_file);
    apr_file_flush(log_file);
}

static void log_out_to_ap(server_rec *s, request_rec *r, enum log_level level, int errnum,
                          const char *fmt, va_list args)
{
    int aplog_level;
    char aplogno[10], line[8192];

    vsnprintf(line, sizeof(line), fmt, args);

    aplog_level = log_level_map[level] | APLOG_NOERRNO;
    if (errnum == ENOSPC) {
        snprintf(aplogno, sizeof(aplogno), "%s", APLOGNO(90028));
    } else {
        aplogno[0] = 0;
    }

    if (r) {
        ap_log_rerror(STRIP_FILE_LINE_MARK, aplog_level, APR_SUCCESS, r, "%s%s", aplogno, line);
    } else {
        ap_log_error(STRIP_FILE_LINE_MARK, aplog_level, APR_SUCCESS, s, "%s%s", aplogno, line);
    }
}

static void log_out_(struct log_context *lc, enum log_level level, int errnum, const char *fmt,
                     va_list args)
{
    enum log_level current;

    if (lc->c != NULL && lc->c->log_file != NULL) {
        current = lc->c->log_level ? (enum log_level) lc->c->log_level : LL_WARN;
        if (current >= level) {
            log_out_to_file(lc->c->log_file, level, fmt, args);
        }
    } else {
        log_out_to_ap(lc->s, lc->r, level, errnum, fmt, args);
    }
}

void log_out(struct log_context *lc, enum log_level level, int errnum, const char *fmt, ...)
{
    va_list args;

    if (lc == NULL) {
        ap_log_error(STRIP_FILE_LINE_MARK, APLOG_ALERT, APR_SUCCESS, NULL, "No log context!");
        return;
    }

    va_start(args, fmt);
    log_out_(lc, level, errnum, fmt, args);
    va_end(args);
} 

int log_is_enabled(struct log_context *lc, enum log_level level)
{
    enum log_level current;

    if (lc == NULL) {
        return 0;
    }
    if (lc->c != NULL && lc->c->log_file != 0) {
        current = lc->c->log_level ? (enum log_level) lc->c->log_level : LL_WARN;
        return current >= level;
    }
    return 1;
}

void ws_get_client_info(struct dispatcher *d, struct client_info *info)
{
    struct log_context *lc = d->lc;
    struct ws_extra *ws = d->ws;
    request_rec *r = ws->r;
    server_config *config;
    const char *scheme;
    apr_port_t server_port;

    config = ap_get_module_config(r->server->module_config, &dispatcher_module);

    info->method = r->method;
    info->protocol = config->use_http10 ? "HTTP/1.0" : get_protocol(lc, r);
    info->uri = !config->use_processed_url ? r->parsed_uri.path : r->uri;
    info->raw_uri = r->unparsed_uri;
    info->query = r->args;
    info->host = apr_table_get(r->headers_in, "host");
    info->via = apr_table_get(r->headers_in, "via");

#if AP_SERVER_MAJORVERSION_NUMBER == 2 && AP_SERVER_MINORVERSION_NUMBER == 4
    info->client_ip = r->connection->client_ip;
#else
    info->client_ip = r->connection->remote_ip;
#endif

#if !defined(AP_SERVER_MAJORVERSION_NUMBER) || AP_SERVER_MINORVERSION_NUMBER == 0
    /* ap_http_scheme was wrongly called ap_http_method in Apache 2.0 */
    scheme = ap_http_method(r);
#else
    scheme = ap_http_scheme(r);
#endif

    if (scheme != NULL && !strcmp(scheme, "https")) {
        info->https = 1;
        info->cipher = request_ssl_var(r, "SSL_CIPHER");
        info->session_id = request_ssl_var(r, "SSL_SESSION_ID");
    }

    if (config->use_servername_in_via) {
        info->server_name = ap_get_server_name(r);
        if (info->server_name == r->hostname) {
            info->server_name = r->server->server_hostname;
        }
        server_port = ap_get_server_port(r);
        if (!ap_is_default_port(server_port, r)) {
            snprintf(info->server_port, sizeof info->server_port, ":%d", server_port);
        }
    }

    info->no_canon_url = (unsigned) config->no_canon_url;
}

const char *ws_get_header(struct dispatcher *d, const char *name)
{
    return apr_table_get(d->ws->r->headers_in, name);
}

void ws_get_pt_headers(struct dispatcher *d, struct slist *names, struct hdrarray *headers)
{
    struct ws_extra *ws = d->ws;

    if (names) {
        /* just return the ones requested */
        const char *value;

        while (names) {
            if ((value = ws_get_header(d, names->s)) != NULL) {
                hdrarray_add(headers, names->s, value);
            }
            names = names->next;
        }
    } else {
        /* no restriction: return all end-to-end headers */
        apr_table_t *headers_in = ws->r->headers_in;
        apr_table_entry_t *e;
        int i;

        e = (apr_table_entry_t *) apr_table_elts(headers_in)->elts;
        for (i = 0; i < apr_table_elts(headers_in)->nelts; i++) {
            if (!is_hop_by_hop_header(e[i].key)) {
                hdrarray_add(headers, e[i].key, e[i].val);
            }
        }
    }
    /* add user name if available */
    if (ws->r->user) {
        hdrarray_add(headers, "REMOTE_USER", ws->r->user);
    }
}

int ws_net_read(struct dispatcher *d, void *p, size_t n, int *sc)
{
    struct ws_extra *ws = d->ws;
    int sc_local, rv, read_policy;

    if (!sc) {
        sc = &sc_local;
    }
    if (!ws->client_setup) {
        read_policy = d->chunked ? REQUEST_CHUNKED_DECHUNK : REQUEST_CHUNKED_ERROR;
        if ((*sc = ap_setup_client_block(ws->r, read_policy))) {
            return -1;
        }
        if (!ap_should_client_block(ws->r)) {
            *sc = HTTP_BAD_REQUEST;
            return -1;
        }
        ws->client_setup = 1;
    }
    if ((rv = ap_get_client_block(ws->r, p, n)) > 0) {
        d->read += rv;
    }
    return rv;
}

int ws_get_cache_action(struct dispatcher *d)
{
    struct log_context *lc = d->lc;
    struct ws_extra *ws = d->ws;
    request_rec *r = ws->r;
    server_config *config;

    config = ap_get_module_config(r->server->module_config, &dispatcher_module);

    // If it's SSI included file, return flag set in configuration
    if (r->main != NULL && config->no_cache_ssi) {
        DBG("Not caching SSI included file");
        d->action = CACHE_ACTION_NONE;
        d->reason = CA_REASON_NO_CACHE;
        return -1;
    }
    // It's not an SSI included file, proceed normally
    return 0;
}

void ws_deliver(struct dispatcher *d)
{
    struct ws_extra *ws = d->ws;
    request_rec *r = ws->r;
    char msg[256];

    /* Show info about cache action decision */
    cache_get_info(d->action, d->reason, msg, sizeof msg, 1);
    if (d->tell_reason) {
        apr_table_set(r->headers_out, "X-Cache-Info", msg);
    }
    apr_table_set(r->subprocess_env, "CACHE_INFO", msg);

    apr_stat(&r->finfo, d->cachepath, APR_FINFO_MIN, r->pool);
    r->filename = apr_pstrdup(r->pool, d->cachepath);
    r->path_info = apr_pstrdup(r->pool, "");

    if (d->farm->cache) {
        cache_deliver(d->farm->cache, d);
    }

    /* Apache always expects a path with slashes */
    if (FILE_SEPARATOR_CHAR != '/') {
        strrep(r->filename, FILE_SEPARATOR_CHAR, '/');
    }
}

int ws_set_status(struct dispatcher *d, int status, const char *sline)
{
    struct log_context *lc = d->lc;
    int index;
    struct ws_extra *ws = d->ws;
    request_rec *r = ws->r;
    server_rec *s = r->server;
    server_config *config;

    d->status = status;

    /* Do not set Apache's internal status if we are handling a custom response */
    request_rec *r_1st_err = r;
    while (r_1st_err->prev && (r_1st_err->prev->status != HTTP_OK)) {
        r_1st_err = r_1st_err->prev;  /* Get back to original error */
    }
    if (r_1st_err != r) {
        return 0;
    }

    /* Check whether we should allow Apache to process the error */
    config = ap_get_module_config(s->module_config, &dispatcher_module);
    if ((index = ap_index_of_response(status)) == index500 &&
            status != HTTP_INTERNAL_SERVER_ERROR) {
        WARN("Unsupported HTTP response code: %d, "
                "unable to determine whether to pass error to Apache", status);
    } else if (index >= RESPONSE_CODES) {
        WARN("Index of response code %d out of range [0-%d]: %d",
             status, RESPONSE_CODES - 1, index);
    } else if ((ws->pass_error = config->pass_error_set[index])) {
        return 0;
    }

    DBG("response.status = %d", status);

    ws->r->status = status;

    return 0;
}

int ws_set_header(struct dispatcher *d, const char *name, const char *value)
{
    struct log_context *lc = d->lc;
    struct ws_extra *ws = d->ws;
    request_rec *r = ws->r;
    time_t lastm;
    short cache_delivery;

    /* Stop here if we should allow Apache to process the error */
    if (ws->pass_error) {
        if (d->status == HTTP_UNAUTHORIZED && !strcasecmp(name, "WWW-Authenticate")) {
            /* Set WWW-Authenticate for 401s */
            apr_table_set(r->err_headers_out, name, value);
        }
        return 0;
    }

    DBG("response.headers[%s] = \"%s\"", name, value);

    /* Check whether we're producing a cache response */
    cache_delivery = (d->action == CACHE_ACTION_CREATE || d->action == CACHE_ACTION_DELIVER);

    if (!strcasecmp(name, "content-type")) {
        ap_set_content_type(r, apr_pstrdup(r->pool, value));
    } else if (!strcasecmp(name, "content-length")) {
        ap_set_content_length(r, atoll(value));
    } else if (!strcasecmp(name, "connection")) {
        /* always ignore hop-by-hop header */
    } else if (!strcasecmp(name, "server")) {
        apr_table_set(r->headers_out, name, value);
    } else if (!strcasecmp(name, "last-modified")) {
        if (cache_delivery && (lastm = date_parse_http(value)) != -1) {
            r->finfo.mtime = r->mtime = apr_time_from_sec(lastm);
        } else {
            apr_table_set(r->headers_out, name, value);
        }
    } else if (!strcasecmp(name, "date") && d->farm->date_header_stored) {
        time_t date;
        if (cache_delivery && (date = date_parse_http(value)) != -1) {
            r->request_time = apr_time_from_sec(date);
        }
    } else if (!strcasecmp(name, "etag") && d->farm->etag_header_stored) {
        /* Store our ETag as well as a marker that will keep it alive */
        apr_table_set(r->notes, "dispatcher-custom-etag", "1");
        apr_table_set(r->headers_out, name, value);
    } else {
        apr_table_add(r->headers_out, name, value);
    }
    return 0;
}

int ws_start_response(struct dispatcher *d)
{
    struct ws_extra *ws = d->ws;
    request_rec *r = ws->r;
    char msg[256];

    /* Show info about cache action decision */
    cache_get_info(d->action, d->reason, msg, sizeof msg, 1);
    if (d->tell_reason) {
        apr_table_set(r->headers_out, "X-Cache-Info", msg);
    }
    apr_table_set(r->subprocess_env, "CACHE_INFO", msg);

    /* if the response status is 401 (UNAUTHORIZED), make sure we
     * put the WWW-Authenticate header into err_headers_out or
     * it will be discarded by ap_send_error_response
     */
    if (r->status == HTTP_UNAUTHORIZED) {
        const char *buf;
        const char *wa = "WWW-Authenticate";

        if ((buf = apr_table_get(r->headers_out, wa))) {
            apr_table_set(r->err_headers_out, wa, buf);
            apr_table_unset(r->headers_out, wa);
        }
    }
    return 0;
}

int ws_net_write(struct dispatcher *d, const char *buffer, size_t length)
{
    struct ws_extra *ws = d->ws;
    int written;

    /* Stop here if we should allow Apache to process the error */
    if (ws->pass_error) {
        return 0;
    }

    if ((written = ap_rwrite(buffer, length, ws->r)) > 0) {
        d->written += written;
    }
    return written >= 0 ? 0 : -1;
}

int ws_net_flush(struct dispatcher *d)
{
    struct ws_extra *ws = d->ws;
    request_rec *r = ws->r;

    /* Stop here if we should allow Apache to process the error */
    if (ws->pass_error) {
        return 0;
    }
    ap_rflush(r);
    return 0;
}

void ws_log_request(struct dispatcher *d, const char *method, const char *uri,
                    const char *query, const char *status, const char *cache_info,
                    long req_ms, const char *farm_label, const char *backend_label)
{
    struct log_context *lc = d->lc;
    struct ws_extra *ws = d->ws;
    request_rec *r = ws->r;
    char ratio[40], backend[256];

    if (lc != NULL && lc->c != NULL && lc->c->log_file != NULL) {
        /* We have a separate dispatcher log, so log there */
        if (query) {
            INFO("\"%s %s?%s\" %s %s [%s/%s] %ldms", method, uri, query, status, cache_info,
                 farm_label, backend_label, req_ms);
        } else {
            INFO("\"%s %s\" %s %s [%s/%s] %ldms", method, uri, status, cache_info, farm_label,
                 backend_label, req_ms);
        }
        return;
    }

    apr_table_set(r->subprocess_env, "dispatcher:uri", uri);
    apr_table_set(r->subprocess_env, "dispatcher:status", status);

    snprintf(backend, sizeof backend, "%s/%s", farm_label, backend_label);
    apr_table_set(r->subprocess_env, "dispatcher:backend", backend);

    apr_table_set(r->subprocess_env, "dispatcher:cache", cache_info);

    snprintf(ratio, sizeof ratio, "%ld/%ld/%ld", req_total, req_hits, req_misses);
    apr_table_set(r->subprocess_env, "dispatcher:ratio", ratio);
}