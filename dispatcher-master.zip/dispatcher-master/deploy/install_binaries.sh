#!/bin/bash
#
# Script to install binaries in local mvn repository
#
# Usage: install_binaries *.tar.gz *.zip
#

GROUP_ID=com.adobe.aem.dispatcher

install_file() {
  local file=$1
  local artifact=$2
  local version=$3
  local packaging=$4

  mvn install:install-file -DgeneratePom=false -DgroupId=${GROUP_ID} -DartifactId=${artifact} -Dversion=${version} -Dpackaging=${packaging} -Dfile=${file}
}

for file in "$@"
do
  name=$(basename $file)
  args=$(echo $name | sed -n -E 's/(dispatcher-[^-]+-[^-]+-[^-]+(-ssl1\.[01])?)-([1-9]\.[0-9]\.[0-9])\.(.*)/\1 \3 \4/p')
  install_file $file $args
done

