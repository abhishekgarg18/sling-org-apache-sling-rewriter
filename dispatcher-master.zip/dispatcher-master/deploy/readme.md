AEM Dispatcher Upload on download.macromedia.com
==================================================

These instructions assume you have created all distribution packages and put
them in the SMB share `smb://du1isi01.corp.adobe.com/share/dispatcher_binaries`.

The scripts invoked further assume that you have mounted that SMB share in
`/Volumes/dispatcher_binaries`.

Prepare the upload
----------------

1. Edit `pom.xml` and change `dispatcher_version` property accordingly.
2. Install the binaries to your local maven repo with `install_binaries.sh`
   ```
   $ ./install_binaries.sh /Volumes/dispatcher_binaries/v${dispatcher_version}/*
   ```

Deploy to Staging
-----------------
The Maven deploy plugin can be used to upload the dispatcher binaries to stage.

1. From this directory run:
   ````
   $ mvn clean deploy
   ````
2. Verify that the uploaded binaries on stage match the ones in your SMB share:
   ```
   $ verify_macromedia.sh <version> stage`
   ```

**Note**: The binaries are deployed to the server using `scp` using the distribution credentials
        defined in the `~/.m2/settings.xml`, using valid Adobe LDAP credentials:
```
<servers>
   ...
   <server>
      <id>stage.macromedia.com</id>
      <username>LDAP Username</username>
      <password>LDAP Password</password>
   </server>
   ...
```
see https://maven.apache.org/guides/mini/guide-encryption.html for details about password encryption.


Pushing the binaries to Production
---------------------------------
1. Access the [WebPush UI](https://webpush.corp.adobe.com/webpush/download.macromedia.com/index.cgi?SUBDIR=/docs/dispatcher)
2. Select the file(s) to push to production (using the checkbox near the file/directory)
3. Click on “Push/Copy/Delete” button
4. Wait for few minutes
5. Verify that the pushed binaries on prod match the ones in your SMB share:
   ```
   $ verify_macromedia.sh <version> public
   ```


Change the download links on docs.adobe.com
-------------------------------------------
1. Open the [Release notes page](https://git.corp.adobe.com/AdobeDocs/experience-manager-dispatcher.en/blob/master/help/using/release-notes.md)
2. Update the version number, change history and download links
3. Verify that the links in your release notes page, when followed, will return the same binary as the one on your SMB share:
   ```
   $ verify_release_notes.sh <version> <release-notes.md>
   ```
4. Create a git branch for your changes, commit and push your changes to that
5. Create a PR, wait for Jenkins job to push changes to docs.adobe.com
6. Activate the page manually in [Docs Author](https://docs-author.corp.adobe.com/siteadmin#/content/help/en/experience-manager-dispatcher/using/getting-started)
7. Verify that the links in the public release notes page on docs.adobe.com, when followed, will return the same binary as the one on your SMB share:
   ```
   $ verify_docs.sh
   ```

There's a [wiki](https://wiki.corp.adobe.com/pages/viewpage.action?spaceKey=aemdoc&title=Editing+Using+Markdown+and+GitHub) page containing more information on those steps

Purging old download links
--------------------------
1. Invoke `generate_purgelist.sh <old-version>` to generate the list of URLs to purge
2. Follow the steps on *Clearing the cache on Akamai* below, and paste the list of URLs
3. After having purged the links, verify the links are no longer available


Clearing the cache on Akamai
----------------------------
download.macromedia.com is served via Akamai. When you make any changes at source, you have to purge the Akamai cache as well in order for the changes to take effect immediately.

You can use our CCP Portal do so. Here is how you do that:

1. Access the [CCP Akamai Purge portal](https://ccp.corp.adobe.com/akamai.php)
2. Login with your LDAP credentials
3. Go to Self Service Tools > Akamai Purge Tool
4. In the URLs text box, enter the URLs whose cache needs to be purged.
5. Leave all the other options at default values and click "Purge" button

It usually takes up to 5 seconds for the cache to get purged.
