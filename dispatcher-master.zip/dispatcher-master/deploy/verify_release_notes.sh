#!/bin/bash
#
# Checks all links on local release notes page, after having been checked out
# in git-repo
#
# Usage: verify_release_notes.sh version release-notes.md
#

[ $# -eq 2 ] || { echo usage: $0 version release-notes.md; exit 1; }

VERSION=$1
RELEASE_NOTES="$2"
STAGE_URL=http://download.stage.macromedia.com/dispatcher/download

# Find download links
#LINKS=`egrep 'download/' ${TMPFILE} | sed -n -E 's/.* href="([^"]*)".*/\1/p'`
LINKS=`egrep '\[dispatcher-' $RELEASE_NOTES | sed -nE 's/.*\[(dispatcher-[^]]*)\]\(([^)]*)\).*/\1|\2/p'`
echo Number of downloads found: `echo ${LINKS} | wc -w`

# Check SMB share is available
SMBDIR="/Volumes/dispatcher_binaries/v${VERSION}"
[ -d "${SMBDIR}" ] || { echo "SMB share not available: ${SMBDIR}"; exit 1; }

for link in $LINKS; do
  read name href <<< $(echo $link | tr '|' ' ')
  expected_name=$(basename $href)
  [ "$name" = "$expected_name" ] || { echo "Name in ${href} does not match expected base name: ${expected_name}"; exit 1; }

  dirname=$(dirname $href)
  expected_dirname="https://download.macromedia.com/dispatcher/download"
  [ "$dirname" = "$expected_dirname" ] || { echo "Base URL in ${href} does not match expected base URL: ${expected_dirname}"; exit 1; }

  # As this is not live yet, check on stage
  stage_href="${STAGE_URL}/${name}"

  echo "Verifying ${name}..."
  md5_web=`curl -s ${stage_href} | md5`
  md5_smb=`md5 -q ${SMBDIR}/${name}`
  [ "${md5_web}" = "${md5_smb}" ] || { echo "** MD5 (${md5_web}) from download (${stage_href}) does not match the MD5 (${md5_smb}) in ${SMBDIR}/${name} "; exit 1; }
done
