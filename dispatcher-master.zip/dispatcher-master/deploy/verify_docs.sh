#!/bin/bash
#
# Checks all links on AEM dispatcher release page, downloading the distribution
# packages and comparing their MD5 against the one on the SMB share.
#
# Usage: verify_docs.sh
#

[ $# -eq 0 ] || { echo usage: $0; exit 1; }

URL=https://docs.adobe.com/content/help/en/experience-manager-dispatcher/using/getting-started/release-notes.html

# Store download page in tmp file
TMPFILE=$(mktemp /tmp/dispatcher.XXXX)
curl -k -s "${URL}" > ${TMPFILE}

# Find download links (all prefixed by "download/")
LINKS=`egrep 'download/' ${TMPFILE} | sed -n -E 's/.* href="([^"]*)".*/\1/p'`
echo Number of downloads found: `echo ${LINKS} | wc -w`

SMBDIR="/Volumes/dispatcher_binaries/v"
VERSION=""

for link in $LINKS
do
  echo ${link} | grep -q '.stage' && { echo "Download link is internal: ${link}"; exit 1; }
  name=$(basename $link)

  # Derive version from first download link
  if [ -z "${VERSION}" ]; then
    VERSION=$(echo ${name} | sed -E -n 's/dispatcher-[^-]+-[^-]+-[^-]+-([1-9]\.[0-9]\.[0-9])\.(.*)/\1/p')

    # Check SMB share is available
    SMBDIR="${SMBDIR}${VERSION}"
    [ -d "${SMBDIR}" ] || { echo "SMB share not available: ${SMBDIR}"; exit 1; }
  fi

  echo "Verifying ${name}..."
  md5_web=`curl -s ${link} | md5`
  md5_smb=`md5 -q ${SMBDIR}/${name}`
  [ "${md5_web}" = "${md5_smb}" ] || { echo "** MD5 from download (${md5_web}) does not match the one in ${SMBDIR}/${name} (${md5_smb})"; exit 1; }

done
