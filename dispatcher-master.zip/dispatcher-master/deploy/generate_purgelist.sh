#!/bin/bash
#
# Checks all downloads on either macromedia stage or macromedia public,
# downloading packages and comparing their MD5 against the one on the SMB share.
#
# Usage: verify_macromedia.sh version (stage|public)
#

[ $# -eq 1 ] || { echo usage: $0 version; exit 1; }

VERSION=$1
URL=http://download.macromedia.com/dispatcher/download/

# Check SMB share is available
SMBDIR="/Volumes/dispatcher_binaries/v${VERSION}"
[ -d "${SMBDIR}" ] || { echo "SMB share not available: ${SMBDIR}"; exit 1; }

for binary in ${SMBDIR}/*
do
  name=$(basename $binary)
  echo ${URL}${name}
done
