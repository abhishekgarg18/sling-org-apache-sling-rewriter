#!/bin/bash
#
# Checks all downloads on either macromedia stage or macromedia public,
# downloading packages and comparing their MD5 against the one on the SMB share.
#
# Usage: verify_macromedia.sh version (stage|public)
#

[ $# -eq 2 ] || { echo usage: $0 version \(stage\|public\); exit 1; }

VERSION=$1
case $2 in
  stage)
    URL=http://download.stage.macromedia.com/dispatcher/download/
    ;;
  public)
    URL=https://download.macromedia.com/dispatcher/download/
    ;;
  *)
    echo usage: $0 version \(stage\|public\); exit 1
    ;;
esac

# Check SMB share is available
SMBDIR="/Volumes/dispatcher_binaries/v${VERSION}"
[ -d "${SMBDIR}" ] || { echo "SMB share not available: ${SMBDIR}"; exit 1; }

for binary in ${SMBDIR}/*
do
  name=$(basename $binary)

  echo "Verifying ${name}..."
  md5_web=$(curl -s ${URL}${name} | md5)
  md5_smb=$(md5 -q ${binary})
  [ "${md5_web}" = "${md5_smb}" ] || { echo "** MD5 from download (${md5_web}) does not match the one in ${SMBDIR}/${name} (${md5_smb})"; exit 1; }

done
