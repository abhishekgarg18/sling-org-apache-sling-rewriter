/*
 * Copyright (c) 2010 Day Management AG
 * Barfuesserplatz 6, 4001 Basel, Switzerland
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Day Management AG, ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Day.
 */
#ifndef __CACHE_H___
#define __CACHE_H___

/**
 * Flush action enum.
 */
enum flush_action {
    ACTION_NONE,
    ACTION_TEST,
    ACTION_ACTIVATE,
    ACTION_DEACTIVATE,
    ACTION_DELETE
};

/**
 * Action scope enum.
 */
enum action_scope {
    SCOPE_NONE,
    SCOPE_ALL,
    SCOPE_RESOURCE_ONLY
};

/**
 * An enumeration for every conceivable cache action.
 */
enum cache_action {
    /** do not cache the file, deliver from backend */
    CACHE_ACTION_NONE,
    /** create cache file, deliver from backend */
    CACHE_ACTION_CREATE,
    /** deliver from cache file */
    CACHE_ACTION_DELIVER,
    /** purged */
    CACHE_ACTION_PURGED
};

/**
 * An enumeration explaining the reason for a cache action decision.
 */
enum ca_reason {
    /** no reason */
    CA_REASON_NONE,
    /** no document root specified */
    CA_REASON_NO_DOCUMENT_ROOT,
    /** file path exceeds limit */
    CA_REASON_FILE_PATH_TOO_LONG,
    /** temporary file path exceeds limit */
    CA_REASON_TEMP_FILE_PATH_TOO_LONG,
    /** no extension in URI */
    CA_REASON_NO_EXTENSION,
    /** method is neither GET nor HEAD */
    CA_REASON_NOT_GET_HEAD,
    /** has a query string */
    CA_REASON_QUERY_STRING,
    /** session manager didn't authenticate */
    CA_REASON_SESSION_MANAGER_NO_AUTH,
    /** contains authorization */
    CA_REASON_AUTHORIZATION,
    /** is a directory */
    CA_REASON_DIRECTORY,
    /** trailing slash */
    CA_REASON_TRAILING_SLASH,
    /** not in cache rules */
    CA_REASON_NOT_IN_RULES,
    /** stat file newer */
    CA_REASON_STAT_FILE_NEWER,
    /** stat file newer */
    CA_REASON_TTL_EXPIRED,
    /** authorization checker denied access */
    CA_REASON_AUTH_CHECKER,
    /** session is not valid */
    CA_REASON_SESSION_NOT_VALID,
    /** dispatcher: no-cache */
    CA_REASON_NO_CACHE,
    /** Content length was zero */
    CA_REASON_ZERO_LENGTH,
    /** Status code not 200 (OK) */
    CA_REASON_STATUS_NOT_200,
    /** Request was rejected */
    CA_REASON_REJECTED
};

/**
 * Cache configuration.
 */
struct cache {
    /** cache root */
    char *docroot;
    /** ACL for cache rules */
    struct cache_acl *rules_acl;
    /** ACL for cache invalidate */
    struct acl *invalidate_acl;
    /** ACL for allowed flush clients */
    struct acl *flush_clients_acl;
    /** ACL for ignored URL params */
    struct acl *ignored_params_acl;
    /** stat file for cache */
    char statfile[PATH_MAX];
    /** invalidate handler script */
    char *invalidate_handler;
    /** cache headers */
    struct cache_headers *headers;
    /** cache file stat level */
    int statLevel;
    /** grace period */
    int grace_period;
    /** mode for creating directories and files */
    int mode;

    /** flag indicating whether to unconditionally cache authorized pages */
    unsigned cache_authorized:1;
    /** flag indicating whether stale content should be served */
    unsigned serve_stale_on_error:1;
    /** flag indicating whether TTL response header evaluation is enabled */
    unsigned ttl_enabled:1;
};

/**
 * Parse cache settings.
 *
 * @param config config root
 *
 * @return cache or <code>NULL</code> if no docroot was specified
 */
struct cache *cache_create(struct log_context *lc, struct any_item *config);

/**
 * Try to quickly handle an incoming request, without having to pass it on
 * to the next stage.
 *
 * @param d dispatcher
 *
 * @return <code>0</code> if processing should continue;
 *         <code>DECLINED</code> if the request was declined;
 *         some HTTP status otherwise
 */
int cache_quick_handler(struct dispatcher *d);

/**
 * Fixup cache at the end of a request.
 *
 * @param d dispatcher
 * @param sc current status code
 *
 * @return status code to return
 */
int cache_fixup(struct dispatcher *d, int sc);

/**
 * Return the message string associated with a cache action decision.
 *
 * @param action action
 * @param reason reason
 * @param buf character array
 * @param buf_len available characters
 * @param detailed whether to include detail
 *
 * @return number of bytes written
 */
int cache_get_info(enum cache_action action, enum ca_reason reason, char *buf, size_t buf_len, int detailed);

/**
 * Deliver from cache.
 *
 * @param cache cache
 * @param d dispatcher structure
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> otherwise
 */
int cache_deliver(struct cache *cache, struct dispatcher *d);

/**
 * Return a flag indicating whether the response headers indicate that the
 * response must not be cached.
 *
 * @param hc http client
 * @param line optional, where to return the actual response header
 *
 * @return <code>1</code> if caching is denied;
 *         <code>0</code> otherwise
 */
int cache_control_denies(struct http_client *hc, const char **line);

/**
 * Store the response body of an HTTP request to a cache file.
 *
 * @param hc HTTP client
 * @param path destination path
 * @param cmd optional command to execute, may be <code>NULL</code>
 * @param fptemp temporary file pointer, used to return a temporarily created
 *               cache file that was deleted in the file system but is still
 *               readable
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> if writing the cache file fails;
 *         <code>-2</code> if reading from the backend fails or content length
 *                         and bytes read do not match;
 *         <code>-3</code> if renaming the temporary file fails
 */
int cache_write_file(struct log_context *lc, struct cache *cache, struct http_client *hc,
                     const char *path, const char *cmd, FILE **fptemp);

/**
 * Flush the cache in a farm for some URI.
 *
 * @param farm farm
 * @param uri URI in flush request
 * @param action flush action
 * @param scope action scope
 * @param refetch_uris array of URIs to refetch later
 * @param headers headers to send along when refetching, may be <code>NULL</code>
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
int cache_flush(struct log_context *lc, struct farm *farm, const char *uri, enum flush_action action,
                enum action_scope scope, const char **refetch_uris,
                struct hdrarray *headers);

/**
 * Free memory associated with a cache.
 *
 * @param cache cache, may be <code>NULL</code>
 */
void cache_free(struct cache *cache);

#endif /* __CACHE_H___ */
