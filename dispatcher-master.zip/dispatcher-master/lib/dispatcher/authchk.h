/*
 * Copyright (c) 2007 Day Management AG
 * Barfuesserplatz 6, 4001 Basel, Switzerland
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Day Management AG, ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Day.
 */
#ifndef __AUTHCHK_H__
#define __AUTHCHK_H__

/**
 * @file authchk.h
 * @brief HTTP authorization checker
 */

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @defgroup authchk HTTP authorization checker
 * @{
 */

/**
 * Create authorization checker.
 *
 * @param config configuration section
 * @param farm parent farm
 *
 * @return authorization checker or <code>NULL</code>
 */
struct auth_checker *authchk_create(struct log_context *lc, struct any_item * config, struct farm *farm);

/**
 * Set headers in the webserver plugin that match the ones configured in
 * the authorization checker.
 *
 * @param ac authorization checker
 * @param uri request URI
 * @param hc HTTP client containing response headers
 * @param d dispatcher
 *
 * @return 0 if the access is granted, <>0 otherwise
 */
int authchk_set_headers(struct auth_checker *ac, const char *uri,
                        struct http_client *hc, struct dispatcher *d);

/**
 * Determine whether auth checker protects a URI
 *
 * @param lc log context
 * @param ac authorization checker
 * @param uri URI to check
 *
 * @return <code>1</code> if auth checker will validate
 *         <code>0</code> otherwise
 */
int authchk_protects(struct log_context *lc, struct auth_checker *auth_checker, const char *uri);

/**
 * Check authorization for a specific request.
 *
 * @param ac authorization checker
 * @param header first response header to be returned;
 *               if <code>NULL</code>, connect to remote server
 * @param d dispatcher
 *
 * @return <code>0</code> is access is granted;
 *         <code>1</code> if a response was generated;
 *         <code>-1</code> otherwise
 */
int authchk_check(struct auth_checker *ac, struct dispatcher *d);

/**
 * Free authorization checker.
 *
 * @param ac authorization checker to free, may be <code>NULL</code>
 */
void authchk_free(struct auth_checker *ac);

#ifdef __cplusplus
}
#endif

/** @} */

#endif  /* __AUTHCHK_H__ */
