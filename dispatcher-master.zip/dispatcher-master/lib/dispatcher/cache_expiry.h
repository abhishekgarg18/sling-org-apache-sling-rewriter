/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2014 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

#ifndef __CACHE_EXPIRY_H___
#define __CACHE_EXPIRY_H___

/**
 * Returns an expiry time, by looking at the response headers.
 *
 * @param headers HTTP headers
 * @return expiry time or <code>-1</code> if no time was found
 */
time_t cache_expiry_get_time(struct http_headers *headers);

/**
 * Store expiry date found in response headers in the file system.
 *
 * @param headers HTTP response headers
 * @param path path where response body is stored
 * @param mode permissions, as in chmod
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
int cache_expiry_store(struct log_context *lc, struct http_headers *headers, const char *body_path, int mode);

/**
 * Return a flag indicating whether the indicated path points to a file where headers are stored
 * and that should not be delivered.
 *
 * @param path path to check
 * @return <code>1</code> if it is private;
 *         <code>0</code> otherwise
 */
int cache_expiry_is_private(const char *path);

/**
 * Return a signed int indicating whether the the indicated resource has expired.
 *
 * @param path path to check
 * @param expiry expiry date
 *
 * @return <code>1</code> if it has expired;
 *         <code>0</code> if it hasn't;
 *         <code>-1<code> if no expiry information is available
 */
int cache_expiry_is_expired(const char *path, time_t *expiry);

/**
 * Set expiry to a given date.
 *
 * @param path path of cache entry
 * @param expiry expiry date
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
int cache_expiry_set(struct log_context *lc, const char *path, time_t expiry);

/**
 * Add age related headers to the response.
 *
 * @param d dispatcher structure
 */
void cache_expiry_deliver(struct dispatcher *d);

#endif /* __CACHE_EXPIRY_H___ */
