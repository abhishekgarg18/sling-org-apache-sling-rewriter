/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2013 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

#include "base/base.h"

#include "dispatcher.h"
#include "farm.h"
#include "cache.h"
#include "cache_headers.h"
#include "authchk.h"
#include "poller.h"
#include "sessmgr.h"
#include "filter_acl.h"
#include "vanity_urls.h"

/*------------------------------------------------------------------ Globals */

/** A structure defining headers that should be forwarded (static) */
struct client_header {
    /** name */
    const char *name;
    /** flags, e.g. valid for 1.1 only */
    int flags;
};

#define DISP_HEADER_HTTP10 0x1000
#define DISP_HEADER_HTTP11 0x1001

static struct client_header client_headers[] = {        /* consider lower-case !!! */
    {"referer", DISP_HEADER_HTTP10},
    {"user-agent", DISP_HEADER_HTTP10},
    {"authorization", DISP_HEADER_HTTP10},
    {"from", DISP_HEADER_HTTP10},
    {"if-modified-since", DISP_HEADER_HTTP10},
    {"content-type", DISP_HEADER_HTTP10},
    {"content-length", DISP_HEADER_HTTP10},
    {"accept-charset", DISP_HEADER_HTTP11},
    {"accept-encoding", DISP_HEADER_HTTP11},
    {"accept-language", DISP_HEADER_HTTP11},
    {"accept", DISP_HEADER_HTTP11},
    {"host", DISP_HEADER_HTTP11},
    {"if-match", DISP_HEADER_HTTP11},
    {"if-none-match", DISP_HEADER_HTTP11},
    {"if-range", DISP_HEADER_HTTP11},
    {"if-unmodified-since", DISP_HEADER_HTTP11},
    {"max-forwards", DISP_HEADER_HTTP11},
    {"proxy-authorization", DISP_HEADER_HTTP11},
    {"proxy-connection", DISP_HEADER_HTTP11},
    {"range", DISP_HEADER_HTTP11},
    {"cookie", DISP_HEADER_HTTP11},
    {"cq-action", DISP_HEADER_HTTP11},
    {"cq-handle", DISP_HEADER_HTTP11},
    {"handle", DISP_HEADER_HTTP11},
    {"action", DISP_HEADER_HTTP11},
    {"cqstats", DISP_HEADER_HTTP11},

    /* WebDAV headers */
    {"depth", DISP_HEADER_HTTP11},
    {"destination", DISP_HEADER_HTTP11},
    {"if", DISP_HEADER_HTTP11},
    {"lock-token", DISP_HEADER_HTTP11},
    {"overwrite", DISP_HEADER_HTTP11},
    {"timeout", DISP_HEADER_HTTP11},
    {0, 0}
};

/**
 * Parse a render configuration given as any item.
 *
 * @param config render configuration
 * @param index render index
 * @param parent parent farm
 * @return new render or <code>NULL</code> if there was an error
 */
static struct render *render_create(struct log_context *lc, struct any_item *config, int index, struct farm *parent)
{
    struct render *p = NULL;
    int i, ret;
    const char *hostname;
    struct addrinfo *ai, hints;
    char service[10];

    hostname = any_get_string(config, "hostname");
    if (hostname == NULL) {
        WARN("Backend %s has no hostname: entry ignored", config->label);
        return NULL;
    }

    /* create render */
    p = malloc(sizeof(struct render));
    memset(p, 0, sizeof(struct render));
    for (i = 0; i < RENDER_STAT_MAX; i++) {
        p->stats[i].vtime = 10000;
    }
    p->farm = parent;
    p->index = index;

    strncpy(p->label, config->label, sizeof(p->label));
    p->label[sizeof(p->label) - 1] = 0;
    p->secure = any_get_boolean(config, "secure");
    p->timeout = (unsigned) any_get_number(lc, config, "timeout", 0);
    p->receiveTimeout = (unsigned) any_get_number(lc, config, "receiveTimeout", 600000);
    p->port = any_get_number(lc, config, "port", p->secure ? 443 : 80);
    p->ipv4 = any_get_boolean(config, "ipv4");
    p->vtbl = p->ipv4 ? &IPv4_VTABLE : &IPv6_VTABLE;

#ifndef WITH_SSL
    if (p->secure) {
        ERR("%s:%d: SSL support not enabled, secure sockets not available.",
                config->filename, config->line);
        return NULL;
    }
#endif

    memset(&hints, 0, sizeof hints);
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_flags = AI_NUMERICSERV;
    snprintf(service, sizeof(service), "%d", p->port);

    if ((ret = p->vtbl->getaddrinfo(hostname, service, &hints, &ai)) != 0) {
        WARN("Looking up host failed (%s): %s; entry ignored.", hostname, p->vtbl->gai_strerror(ret));
        free(p);
        return NULL;
    }
    if (!any_get_boolean(config, "always-resolve")) {
        p->ai = ai;
    } else {
        INFO("IP list for backend %s will be resolved on every request.", p->label);
        p->vtbl->freeaddrinfo(ai);
    }
    p->host = strdup(hostname);

    return p;
}

/**
 * Free memory associated with a backend.
 *
 * @param render backend, may be <code>NULL</code>
 */
static void render_free(struct render *backend)
{
    if (backend == NULL) {
        return;
    }

    if (backend->ai) {
        backend->vtbl->freeaddrinfo(backend->ai);
    }
    free(backend->host);
    free(backend);
}

/**
 * Parse a domain configuration given as any item.
 *
 * @param config configuration
 * @param farm parent parm
 *
 * @return new domain configuration
 */
static struct domain_glob *domain_create(struct any_item *config, struct farm *farm)
{
    struct domain_glob *dom;
    const char *ptr;
    char *uri;

    dom = malloc(sizeof(struct domain_glob));
    memset(dom, 0, sizeof(struct domain_glob));

    ptr = config->value.p;
    if (!strncmp("https://", ptr, 8)) {
        dom->scheme_mask = dom->https = 1;
        ptr += 8;
    } else if (!strncmp("http://", ptr, 7)) {
        dom->scheme_mask = 1;
        ptr += 7;
    }
    dom->hostname_pattern = strdup(ptr);

    uri = strchr(dom->hostname_pattern, '/');
    if (uri) {
        dom->uri_pattern = strdup(uri);
        uri[0] = '\0';
    }
    dom->farm = farm;

    return dom;
}

/**
 * Create linked list of strings.
 *
 * @param item first config entry or <code>NULL</code>
 *
 * @return pointer to first string of a linked list,
 *         or <code>NULL</code> if list is empty
 */
static struct slist *create_slist(struct any_item *item)
{
    struct slist *first, *previous, *p;

    first = previous = NULL;

    while (item && item->type == STRING) {
        p = malloc(sizeof(struct slist));
        p->s = strdup(item->value.p);
        p->next = NULL;

        if (previous) {
            previous->next = p;
        } else {
            first = p;
        }
        previous = p;
        item = item->next;
    }
    return first;
}

/**
 * Create single string list item.
 *
 * @param s string
 *
 * @return pointer to item
 */
static struct slist *create_slist_item(const char *s)
{
    struct slist *p;

    p = malloc(sizeof(struct slist));
    p->s = strdup(s);
    p->next = NULL;

    return p;
}

/**
 * Free memory associated with a string list.
 *
 * @param first first item in list, may be <code>NULL</code>
 */
static void slist_free(struct slist *first)
{
    struct slist *p;

    while (first) {
        p = first;
        first = first->next;

        free(p->s);
        free(p);
    }
}

/**
 * Create linked list of passthrough headers.
 *
 * @param item first config entry or <code>NULL</code>
 *
 * @return pointer to first passthrough header
 */
static struct slist *create_pt_headers(struct any_item *item)
{
    struct slist *p, *last;
    struct client_header *chdr;

    last = NULL;

    if (!item || item->type != STRING) {
        /* Read entries from static section */
        for (chdr = client_headers; chdr->name; chdr++) {
            p = malloc(sizeof(struct slist));
            p->s = strdup(chdr->name);
            p->next = last;
            last = p;
        }
        return last;
    }
    if (!strcmp(item->value.p, "*")) {
        /* include all */
        return NULL;
    }
    return create_slist(item);
}

/**
 * Scan a port number in a host header, either in IPv4 or IPv6 format.
 *
 * @param host host header
 * @param port number or <code>-1</code>
 */
static int scan_port_in_host(const char *host)
{
    int port = -1;
    const char *start = NULL, *sep;

    if (*host == '[') {
        /* IPv6 format: look for terminating bracket */
        if ((sep = strchr(host, ']')) != NULL) {
            sep++;
            if (*sep == ':') {
                start = sep + 1;
            }
        }
    } else {
        if ((sep = strchr(host, ':')) != NULL) {
            start = sep + 1;
        }
    }
    if (start != NULL) {
        port = atoi(start);
    }
    return port;
}

/**
 * Add all request headers to the selected backend.
 *
 * @param d dispatcher
 * @param hc HTTP client
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
static int add_request_headers(struct dispatcher *d, struct http_client *hc)
{
    struct log_context *lc = d->lc;
    struct hdrarray *headers;
    unsigned i, size;
    int forwarded_port;
    const char *name, *value, *protocol, *client_ip, *forwarded_for;
    char buf[2048];
    struct client_info *info = &d->info;

    if ((headers = get_pt_headers(d)) == NULL) {
        ERR("Unable to obtain headers.");
        return -1;
    }

    size = hdrarray_size(headers);
    for (i = 0; i < size; i++) {
        hdrarray_at(headers, i, &name, &value);

        if (!strcasecmp(name, "if-modified-since") && d->action != CACHE_ACTION_NONE) {
            /* Spooling this header might return a 304 (NOT MODIFIED) and an
             * empty answer, which will not allow us to create a cache file.
             */
            continue;
        }
        if (!strcasecmp(name, "expect") && !strcmp(value, "100-continue")) {
            /* Do not forward this header, let HTTP client decide */
            continue;
        }
        if (!strcasecmp(name, "via") || !strcasecmp(name, "x-forwarded-for")) {
            /* We extend these headers with some information (see below)  */
            continue;
        }
        http_client_add_header(hc, name, value);
    }
    hdrarray_free(headers);

    /* Via: header */
    protocol = info->protocol;
    if (!strncasecmp(protocol, "http/", strlen("http/"))) {
        protocol += 5;
    }
    if (info->via) {
        snprintf(buf, sizeof buf, "%s, %s %s%s (dispatcher)",
                info->via,  protocol, info->server_name, info->server_port);
    } else {
        snprintf(buf, sizeof buf, "%s %s%s (dispatcher)",
                protocol, info->server_name, info->server_port);
    }
    http_client_add_header(hc, "Via", buf);

    /* X-Forwarded-For: header */
    client_ip = info->client_ip;
    if (client_ip == NULL) {
        client_ip = "unknown";
    }
    forwarded_for = ws_get_header(d, "x-forwarded-for");
    if (forwarded_for) {
        snprintf(buf, sizeof buf, "%s, %s", forwarded_for, client_ip);
    } else {
        snprintf(buf, sizeof buf, "%s", client_ip);
    }
    http_client_add_header(hc, "X-Forwarded-For", buf);

    /* X-Forwarded-SSL: headers */
    if (info->https) {
        http_client_add_header(hc, "X-Forwarded-SSL", "on");
        if (info->cipher) {
            http_client_add_header(hc, "X-Forwarded-SSL-Cipher", info->cipher);
        }
        if (info->session_id) {
            http_client_add_header(hc, "X-Forwarded-SSL-Session-ID", info->session_id);
        }
        if (info->keysize) {
            snprintf(buf, sizeof buf, "%d", info->keysize);
            http_client_add_header(hc, "X-Forwarded-SSL-Keysize", buf);
        }

        /* X-Forwarded-Port header */
        forwarded_port = scan_port_in_host(info->host);
        if (forwarded_port != -1) {
            snprintf(buf, sizeof buf, "%d", forwarded_port);
            http_client_add_header(hc, "X-Forwarded-Port", buf);
        }
    }
    http_client_add_header(hc, "Server-Agent", "Communique-Dispatcher");
    return 0;
}

/**
 * Spool the request body to the selected backend.
 *
 * @param d dispatcher
 * @param hc HTTP client
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> if writing to the backend fails
 *         some HTTP error code if reading from the client fails
 */
static int send_request_body(struct dispatcher *d, struct http_client *hc)
{
    struct log_context *lc = d->lc;
    const char *value;
    const int POST_MAX_SIZE = 32768;
    unsigned char *p;
    int sc = 0, n;
    long long total = 0, clen = -1;

    if (d->chunked) {
        http_client_add_header(hc, "Transfer-Encoding", "chunked");
    } else if ((value = ws_get_header(d, "content-length"))) {
        clen = atoll(value);
    } else {
        /* there's no body, just send headers */
        return http_client_send_headers(hc) ? -1 : 0;
    }

    /* Check whether server is ready to accept data before we start consuming the request body. */
    if (http_client_send_headers(hc)) {
        return -1;
    }

    DBG("Sending request body to remote server");

    p = malloc(POST_MAX_SIZE);

    if (clen != -1 && clen < POST_MAX_SIZE) {
        if (d->req_body == NULL) {
            /* store away request body */
            unsigned long clenS = (unsigned long) clen, off = 0;

            while (off < clenS) {
                if ((n = ws_net_read(d, p + off, clenS - off, &sc)) == -1) {
                    ERR("Error while reading request body.");
                    d->read_error = 1;
                    free(p);
                    return sc ? sc : HTTP_BAD_REQUEST;
                } else if (n == 0) {
                    break;
                }
                off += n;
            }
            d->req_body = p;
            d->req_body_len = clenS;
        }
        if (http_client_write(hc, d->req_body, d->req_body_len)) {
            ERR("Error while forwarding request body to remote server: %s", http_client_get_error(hc));
            return -1;
        }
        total = clen;
    } else {
        /* body too large or chunked, so spool */
        while (d->chunked || total < clen) {
            if ((n = ws_net_read(d, p, POST_MAX_SIZE, &sc)) == -1) {
                ERR("Error while reading request body.");
                d->read_error = 1;
                free(p);
                return sc ? sc : HTTP_BAD_REQUEST;
            } else if (n == 0) {
                break;
            }
            if (http_client_write(hc, p, n)) {
                ERR("Error while forwarding request body to remote server: %s", http_client_get_error(hc));
                free(p);
                return -1;
            }
            total += n;
        }
        free(p);
    }

    if (clen != -1 && total != clen) {
        WARN("Spooling request body failed: expected %llu bytes, but only %llu received.", clen, total);
        return HTTP_BAD_REQUEST;
    }

    DBG("Request body sent to remote server");
    return 0;
}

static void to_endpoint(struct render *backend, struct endpoint *ep)
{
    ep->host = backend->host;
    ep->port = backend->port;
    ep->ai = backend->ai;
    ep->ipv4 = backend->ipv4;
    ep->timeout = backend->timeout;
    ep->receive_timeout = backend->receiveTimeout;
    ep->secure = backend->secure;
}

/**
 * Check whether some backend is unhealthy. This is performed by probing the
 * backend with a preconfigured URL.
 *
 * @param backend backend
 * @param strict if <code>1</code> backend must answer 200;
 *               if <code>0</code> backend must not answer 500
 *
 * @return <code>0</code> if backend is healthy
 *         <code>1</code> if it isn't
 */
static int is_unhealthy(struct log_context *lc, struct render *backend, int strict)
{
    struct farm *farm = backend->farm;
    struct endpoint ep;
    struct http_client *hc;
    int ret, status;

    if (farm->probe_url == NULL) {
        /* unable to check */
        return 0;
    }

    DBG("Checking health of backend: %s", backend->label);

    /* Prepare endpoint */
    memset(&ep, 0, sizeof ep);
    to_endpoint(backend, &ep);
    ep.file = farm->probe_url;
    ep.method = "HEAD";
    ep.protocol = HTTP_1_0;

    if ((hc = create_http_client(lc, &ep)) == NULL) {
        ERR("Unable to create HTTP client.");
        return 0;
    }

    /* Check status code */
    if ((status = http_client_get_status(hc, NULL)) < 0) {
        ERR("Unable to retrieve health status from %s: %s",
                ep.host, http_client_get_error(hc));
        ret = 1;
    } else {
        DBG("Backend %s returned HTTP status: %d", backend->label, status);
        ret = strict ? (status != HTTP_OK) : (status == HTTP_INTERNAL_SERVER_ERROR);
    }
    http_client_free(hc);
    return ret;
}

/**
 * Check whether we should failover to some other backend instead of spooling
 * back the response received.
 *
 * @param backend backend
 * @param sc HTTP status code
 *
 * @return <code>0</code> if no failover should follow
 *         <code>1</code> if failover should happen
 */
int farm_failover(struct log_context *lc, struct render *backend, int sc)
{
    if (!backend->farm->failover_enabled) {
        return 0;
    }

    /* check HTTP status before spooling response */
    if (sc == HTTP_SERVICE_UNAVAILABLE) {
        /* 503 -> immediately ask next render */
        DBG("Backend %s (%s:%d) returned %d, trying next...",
                backend->label, backend->host, backend->port, sc);
        return 1;
    } else if (sc >= HTTP_INTERNAL_SERVER_ERROR) {
        /* 5xx -> perform health check */
        DBG("Backend %s (%s:%d) returned %d, performing health check...",
                backend->label, backend->host, backend->port, sc);
        if (is_unhealthy(lc, backend, 1)) {
            INFO("Backend %s considered unhealthy.", backend->label, sc);
            /* do not retry this render */
            return 1;
        }
    }
    return 0;
}

int render_process_location(struct dispatcher *d, struct render *backend, const char *location)
{
    const char *start;
    struct client_info *info = &d->info;
    char buf[2048];

     /* if web server and backend use same scheme, nothing needs to be done */
    if (backend->secure == info->https) {
        return 0;
    }

     /* compare host:port in location to host header received in request */
    if ((start = strstr(location, "://")) == NULL) {
        return 0;
    }
    start += 3;
    if (strchr(start, '/') == NULL) {
        return 0;
    }
    if (strncmp(start, info->host, strlen(info->host)) != 0) {
        return 0;
    }

    /* redirect location is on our host, adapt scheme */
    snprintf(buf, sizeof buf, "%s://%s", info->https ? "https" : "http", start);
    ws_set_header(d, "Location", buf);
    return 1;
}

/**
 * Spool the response headers back to client.
 *
 * @param d dispatcher
 * @param backend backend
 * @param hc HTTP client
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
static int set_response_headers(struct dispatcher *d, struct render *backend, struct http_client *hc)
{
    struct log_context *lc = d->lc;
    struct http_headers *headers;
    struct farm *farm = backend->farm;
    char buf[2048];
    struct slist *p;
    int i, buf_len;
    const int buf_avail = sizeof(buf);

    if (farm->sticky_paths && !d->info.id[0]) {
        for (p = farm->sticky_paths; p; p = p->next) {
            if (strstr(d->info.uri, p->s) == d->info.uri) {
                break;
            }
        }
        if (p) {
            DBG("Setting sticky connection to %s", backend->label);
            buf_len = snprintf(buf, sizeof buf, "renderid=%s; path=%s", backend->label, p->s);
            if (buf_len < buf_avail && farm->domain) {
                buf_len += snprintf(buf + buf_len, buf_avail - buf_len, "; domain=%s", farm->domain);
            }
            if (buf_len < buf_avail && farm->httpOnly) {
                snprintf(buf + buf_len, buf_avail - buf_len, "; httpOnly");
            }
            if (buf_len < buf_avail && (farm->secure || d->info.https)) {
                snprintf(buf + buf_len, buf_avail - buf_len, "; secure");
            }
            ws_set_header(d, "Set-Cookie", buf);
        }
    }

    if ((headers = http_client_get_headers(hc)) == NULL) {
        ERR("Unable to obtain response headers.");
        return -1;
    }

    for (i = 0; i < http_headers_size(headers); i++) {
        struct http_header *header = http_headers_at(headers, i);
        if (is_hop_by_hop_header(header->name) && strcasecmp(header->name, "Content-Encoding")) {
            /* We allow Content-Encoding as well as Content-Length at this point,
             * because we pass the incoming response body unchanged.
             * (see http_client_keep_compressed)
             */
            continue;
        }
        if (!strcasecmp(header->name, "Location") && render_process_location(d, backend, header->value)) {
            continue;
        }
        if (!strcasecmp(header->name, "Server")) {
            continue;
        }
        ws_set_header(d, header->name, header->value);
    }
    ws_start_response(d);
    return 0;
}

/**
 * Spool the response body back to the client. This either uses a temporary
 * file pointer that must have been rewound, or asks the HTTP client passed
 * directly.
 *
 * @param d dispatcher
 * @param hc HTTP client
 * @param fptemp temporary file pointer to use, may be <code>NULL</code>
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
static int write_response_body(struct dispatcher *d, struct http_client *hc, FILE *fptemp)
{
    struct log_context *lc = d->lc;
    void *p;
    int n, no_buffer;

    if ((no_buffer = http_headers_is(http_client_get_headers(hc), "dispatcher", "no-buffer", NULL))) {
        DBG("Detected: dispatcher should flush on every write");
    }

    p = malloc(32768);

    for (;;) {
        n = (int) (fptemp ? fread(p, 1, 32768, fptemp) : http_client_read(hc, p, 32768));
        if (n < 0) {
            free(p);
            return -1;
        } else if (n == 0) {
            break;
        }
        if (ws_net_write(d, p, n)) {
            free(p);
            return -1;
        }
        if (no_buffer) {
            ws_net_flush(d);
        }
    }

    free(p);
    return 0;
}

#define DEFAULT_PENALITY 50     /* default penalty; should be configurable */
#define DEFAULT_ERROR    500    /* default penalty, if error occurs, should be configurable */

/**
 * Update statistics of a backend after having served a request.
 *
 * @param backend backend
 * @param stats backend stats
 * @param response_start time when response handling started
 * @param sc HTTP status code
 */
static void update_stats(struct log_context *lc, struct render *backend, struct render_stat *stats,
                         struct timeval *response_start, int sc)
{
    struct timeval response_end;

    if (response_start->tv_sec == 0 && response_start->tv_usec == 0) {
        return;
    }

    gettimeofday(&response_end, 0);

    stats->time += (response_end.tv_sec - response_start->tv_sec) * 100
            + (response_end.tv_usec - response_start->tv_usec) / 10000;
    stats->vtime += ((response_end.tv_sec - response_start->tv_sec) * 100
            + (response_end.tv_usec - response_start->tv_usec) / 10000);
    stats->vtime -= DEFAULT_PENALITY;

    if (sc >= HTTP_INTERNAL_SERVER_ERROR) {
        if (sc == HTTP_INTERNAL_SERVER_ERROR && !is_unhealthy(lc, backend, 0)) {
            return;
        }
        stats->vtime += DEFAULT_ERROR;
    }
}

/**
 * Return the render that is best suited to provide an answer. This is decided in
 * the following way:
 *
 * - if we have a render cookie, return the associated render
 * - otherwise return the render with the smallest load based on
 *   the given URI, unless it is marked unavailable
 * - as a fallback, return the first render
 *
 * @param farm             farm where renders should be taken from
 * @param uri              uri providing information about category
 * @param id               render cookie or an empty string
 * @param stats            if non-NULL, contains selected render's category
 *                         stats section upon return
 * @param unavailable_mask mask of renders that should not be considered in
 *                         the load comparison
 *
 * @return render selected
 */
static struct render* render_get(struct farm *farm, const char *uri, const char *id,
                                 struct render_stat **stats, int unavailable_mask)
{
    struct render *backend = NULL;
    int i, category, render_bit, random_value;
    unsigned long vtime_max;
    struct render *candidates[FARM_RENDERS_MAX];
    unsigned candidates_len = 0, candidates_index;

    /* get category */
    for (category = 0; category < farm->numstats; category++) {
        if (!strglobcmp(farm->stats[category].glob, uri)) {
            break;
        }
    }

    /* determine best render */
    vtime_max = 0;

    for (i = 0; i < farm->numrenders; i++) {
        /* skip backend that we returned in a previous iteration */
        render_bit = 1 << i;
        if ((render_bit & unavailable_mask) != 0) {
            continue;
        }

        /* if we have a render cookie, select the associated backend */
        if (!strcmp(farm->renders[i]->label, id)) {
            backend = farm->renders[i];
            break;
        }

        /* if we don't have a candidate yet, or one with equal or smaller load, grab it */
        if (vtime_max == 0 || farm->renders[i]->stats[category].vtime <= vtime_max) {
            if (farm->renders[i]->stats[category].vtime < vtime_max) {
                /* truly smaller load, so this is our best and only candidate */
                candidates_len = 0;
            }
            vtime_max = farm->renders[i]->stats[category].vtime;
            candidates[candidates_len++] = farm->renders[i];
        }
    }

    /* If we have multiple candidates, take one randomly. If we have no candidates at all,
     * return the first backend registered as fallback
     */
    if (backend == NULL) {
        switch (candidates_len) {
            case 0:
                backend = farm->renders[0];
                break;
            case 1:
                backend = candidates[0];
                break;
            default:
                random_value = rand();
                candidates_index = (random_value % candidates_len);
                backend = candidates[candidates_index];
                break;
        }
    }
    if (stats) {
        (*stats) = &(backend->stats[category]);
    }
    return backend;
}

/**
 * Write the response body to a cache file.
 *
 * @param d dispatcher
 * @param hc HTTP client
 * @param sc status code
 * @param fptemp temporary file pointer
 *
 * @return <code>DECLINED</code> if a cache file is available;
 *         <code>0</code> if some aspect of the response forbids to cache;
 *         some HTTP error code if streaming the response body failed
 */
static int create_cache_file(struct dispatcher *d, struct http_client *hc, int sc, FILE **fptemp)
{
    struct log_context *lc = d->lc;
    struct farm *farm = d->farm;
    const char *cmd, *line;
    int ret;

    if (d->action != CACHE_ACTION_CREATE) {
        return 0;
    }
    if (sc != HTTP_OK) {
        d->action = CACHE_ACTION_NONE;
        d->reason = CA_REASON_STATUS_NOT_200;
        return 0;
    }

    if (cache_control_denies(hc, &line)) {
        DBG("Backend forbids caching, sent: \'%s\'", line);
        d->action = CACHE_ACTION_NONE;
        d->reason = CA_REASON_NO_CACHE;
        return 0;
    }
    if (http_client_get_clen(hc) == 0) {
        INFO("Zero content length, cache file %s won't be created", d->cachepath);
        d->action = CACHE_ACTION_NONE;
        d->reason = CA_REASON_ZERO_LENGTH;
        return 0;
    }
    cmd = d->qaexec;
    if ((ret = cache_write_file(lc, farm->cache, hc, d->cachepath, cmd, fptemp))) {
        if (ret == -3 || http_client_get_read(hc) == 0) {
            /* body still available */
            return 0;
        }
        return (ret == -2) ? (http_client_get_errno(hc) == SOCKET_ETIMEDOUT ?
                              HTTP_GATEWAY_TIME_OUT : HTTP_BAD_GATEWAY) : HTTP_INTERNAL_SERVER_ERROR;
    }

    DBG("Cache file successfully created: %s", d->cachepath);
    if (farm->auth_checker) {
        authchk_set_headers(farm->auth_checker, d->info.uri, hc, d);
    }
    d->miss = 1;
    ws_deliver(d);
    return DECLINED;
}

/**
 * Service a request after some HTTP client connection has been established
 * to a backend.
 *
 * @param d dispatcher
 * @param backend selected backend
 * @param hc HTTP client
 * @param response_start time when HTTP client started returning response
 *
 * @return <code>OK</code> if a response was generated;
 *         <code>DECLINED</code> if the request was declined;
 *         some HTTP status code otherwise
 */
static int render_service(struct dispatcher *d, struct render *backend, struct http_client *hc,
                          struct timeval *response_start)
{
    struct log_context *lc = d->lc;
    const char *sline;
    short retry = 0;
    int sc, ret, no_answer = 0;
    FILE *fptemp = NULL;

    /* 1) Add request headers */
    add_request_headers(d, hc);

    for (;;) {
        /* 2) Send request body */
        if ((sc = send_request_body(d, hc)) >= HTTP_BAD_REQUEST) {
            /* client failure */
            return sc;
        }
        gettimeofday(response_start, 0);

        /* 3) Check response status */
        if ((sc = http_client_get_status(hc, &sline)) > 0) {
            /* We have a valid response */
            break;
        }

        /* 4) Response malformed, so set a sensitive status code for socket errors */
        sc = (http_client_get_errno(hc) == SOCKET_ETIMEDOUT) ? HTTP_GATEWAY_TIME_OUT : HTTP_BAD_GATEWAY;
        if (d->read && d->req_body == NULL) {
            WARN("Unable to retry: request body consumed.");
        } else if (!retry) {
            if (http_client_init_retry(hc)) {
                WARN("Unable to retry: %s", http_client_get_error(hc));
                return HTTP_BAD_GATEWAY;
            }
            retry = 1;
            continue;
        }

        /* 5) We have no answer and no more retries */
        no_answer = 1;
        break;
    }

    if (no_answer || (sc >= HTTP_INTERNAL_SERVER_ERROR && backend->farm->failover_enabled)) {
        /* mark backend as unavailable and retry */
        d->unavailable_mask |= (1 << backend->index);
        return sc;
    }

    // 3) Write cache file or spool response to client
    if ((ret = create_cache_file(d, hc, sc, &fptemp))) {
        /* Cache file created or fatal error occurred */
        return ret;
    } else if ((sc == HTTP_BAD_GATEWAY || sc == HTTP_SERVICE_UNAVAILABLE || sc == HTTP_GATEWAY_TIME_OUT) && d->touch_time) {
        /* We might have stale content */
        return sc;
    } else {
        /* Forward response to client */
        ws_set_status(d, sc, sline);
        set_response_headers(d, backend, hc);
        http_client_keep_compressed(hc);
        write_response_body(d, hc, fptemp);
        if (fptemp) {
            fclose(fptemp);
        }
        return OK;
    }
}


/*----------------------------------------------------------- Public methods */


struct farm *farm_create(struct log_context *lc, struct any_item *config, struct domain_glob **domains)
{
    struct farm *farm = NULL;
    struct domain_glob *dom;
    struct any_item *child, *first;
    struct render *backend;
    const char *ptr;

    /* create new farm */
    farm = malloc(sizeof(struct farm));
    memset(farm, 0, sizeof(struct farm));
    strcpy(farm->label, config->label);

    /* get numbers */
    if ((farm->retries = any_get_number(lc, config, "numberOfRetries", 5)) < 1) {
        ERR("Illegal value for numberOfRetries: '%d'. Must be at least 1.",
                 farm->retries);
        return NULL;
    }
    farm->retrydelay = any_get_number(lc, config, "retryDelay", 1);
    farm->unavailable_penalty = any_get_number(lc, config, "unavailablePenalty", 1);

    /* get homepage where / should be redirected to */
    if (any_get_string(config, "homepage") != NULL) {
        WARN("/homepage directive no longer supported, please use IIS URL Rewrite instead");
    }

    /* retrieve session management, poller and authorization checker */
    if ((child = any_get_item(config, "sessionmanagement"))) {
        if ((farm->sessionMgr = sessmgr_create(lc, child)) == NULL) {
            return NULL;
        }
    }
    if ((child = any_get_item(config, "poller"))) {
        if ((farm->poller = poller_create(lc, child, farm)) == NULL) {
            return NULL;
        }
    }
    if ((child = any_get_item(config, "auth_checker"))) {
        if ((farm->auth_checker = authchk_create(lc, child, farm)) == NULL) {
            return NULL;
        }
    }

    /* get client headers which should be passed through to the render */
    if ((child = any_get_first_child(config, "clientheaders")) == NULL) {
        WARN("No pass-through client-headers configured");
    }
    farm->pt_header = create_pt_headers(child);

    /* get domain globs */
    child = any_get_first_child(config, "virtualhosts");
    while (child && child->type == STRING) {
        dom = domain_create(child, farm);

        if (domains) {
            /* store domains in reverse order, for historical reasons */
            dom->next = *domains;
            *domains = dom;
        }
        child = child->next;
    }

    /* get renders */
    child = any_get_first_child(config, "renders");
    while (child) {
        if (farm->numrenders == FARM_RENDERS_MAX) {
            WARN("Farm has configured too many backends: only the first %d "
                    "are taken into account.", FARM_RENDERS_MAX);
            break;
        }
        backend = render_create(lc, child, farm->numrenders, farm);
        if (backend != NULL) {
            farm->renders[farm->numrenders++] = backend;
        }
        child = child->next;
    }

    /* if we have no backend, abort (actually we should just disable thiz farm */
    if (!farm->numrenders) {
        ERR("No correct backend found in farm %s", farm->label);
        return NULL;
    }

    /* init statistics */
    child = any_get_first_child(config, "statistics.categories");
    while (child) {
        if (farm->numstats == RENDER_STAT_MAX) {
            WARN("Farm has configured too many statistics categories: only the "
                    "first %d are taken into account.", RENDER_STAT_MAX);
            break;
        }
        if ((ptr = any_get_string(child, "glob"))) {
            strcpy(farm->stats[farm->numstats++].glob, ptr);
        }
        child = child->next;
    }

    /* read cache section */
    if ((child = any_get_item(config, "cache"))) {
        farm->cache = cache_create(lc, child);
    }
    if (farm->cache) {
        DBG("farms[%s].cache.docroot = %s", farm->label, farm->cache->docroot);
        if (farm->cache->headers != NULL) {
            farm->date_header_stored = (cache_headers_is_stored(farm->cache->headers, "Date") ? 1 : 0);
            farm->etag_header_stored = (cache_headers_is_stored(farm->cache->headers, "ETag") ? 1 : 0);
        }
    } else {
        INFO("No document root was provided in farms[%s].cache.docroot, "
                "disabling cache", farm->label);
    }

    /* read the propagate flag */
    if ((ptr = any_get_string(config, "propagateSyndPost"))) {
        if (!strcasecmp(ptr, "true") || !strcasecmp(ptr, "1")
                || !strcasecmp(ptr, "yes")) {
            farm->propSyndPost = 1;
            DBG("Propagate Syndication Post enabled for farm: %s", farm->label);
        }
    }

    /* read the stickyConnections settings */
    if ((child = any_get_item(config, "stickyConnections"))) {
        first = any_get_first_child(child, "paths");
        ptr = any_get_string(child, "path");

        if (first == NULL && ptr == NULL) {
            ERR("%s:%d: missing path or paths in stickyConnections.",
                    child->filename, child->line);
            return NULL;
        } else if (first && ptr) {
            ERR("%s:%d: stickyConnections can have path or paths, "
                    "but not both", child->filename, child->line);
            return NULL;
        }
        if (first) {
            farm->sticky_paths = create_slist(first);
            DBG("Sticky Connections enabled below multiple paths for farm: %s", farm->label);
        } else {
            farm->sticky_paths = create_slist_item(ptr);
            DBG("Sticky Connections enabled below %s for farm: %s", ptr, farm->label);
        }
        if ((ptr = any_get_string(child, "domain"))) {
            farm->domain = strdup(ptr);
        }
        farm->httpOnly = any_get_boolean(child, "httpOnly");
        farm->secure = any_get_boolean(child, "secure");
    }

    if ((ptr = any_get_string(config, "stickyConnectionsFor"))) {
        if (farm->sticky_paths) {
            WARN("stickyConnections specified: stickyConnectionsFor setting ignored.");
        } else {
            farm->sticky_paths = create_slist_item(ptr);
            DBG("Sticky Connections enabled below %s for farm: %s", ptr, farm->label);
        }
    }

    /* read filter ACL */
    if ((child = any_get_first_child(config, "filter"))) {
        if ((farm->filter_acl = filter_acl_create(lc, child, "Filter rule")) == NULL) {
           return NULL;
        }
    }

    /* read probe URL */
    if ((ptr = any_get_string(config, "health_check.url"))) {
        farm->probe_url = strdup(ptr);
        DBG("Backend health for farm %s will be checked at: %s",
                farm->label, farm->probe_url);
    }

    /* read failover value */
    if ((farm->failover_enabled = any_get_boolean(config, "failover"))) {
        DBG("Failover enabled for farm: %s", farm->label);
    }

    farm->info_enabled = any_get_boolean(config, "info");

    /* read vanity urls */
    if ((child = any_get_item(config, "vanity_urls"))) {
        farm->vanity_urls = vanity_urls_create(lc, child,farm);
    }

    return farm;
}

struct http_client *farm_connect(struct log_context *lc, struct farm *farm, struct endpoint *ep,
                                 char *id, struct render **render, struct render_stat **stats,
                                 int *unavailable_mask)
{
    int i, mask = 0;
    struct http_client *hc = NULL;
    struct render *backend;

    if (!unavailable_mask) {
        unavailable_mask = &mask;
    }

    for (i = 0; i < farm->numrenders; i++) {
        backend = render_get(farm, ep->file, id ? id : "", stats, *unavailable_mask);
        to_endpoint(backend, ep);

        if ((hc = create_http_client(lc, ep)) == NULL) {
            ERR("Unable to create HTTP client.");
            return NULL;
        }
        if (!farm->failover_enabled) {
            /* Backward compatibility: older backends may not support this */
            http_client_set_options(hc, OPTION_DISABLE_CONTINUE, 1);
        }
        if (!http_client_connect(hc)) {
            if (render) {
                *render = backend;
            }
            break;
        }

        WARN("%s", http_client_get_error(hc));
        http_client_free(hc);
        hc = NULL;
        (*unavailable_mask) |= 1 << backend->index;

        if (stats) {
            (*stats)->vtime += farm->unavailable_penalty * 100;
        }
        if (id && !strcmp(backend->label, id)) {
            DBG("sticky connection invalidated.");
            *id = 0;
        }
    }
    return hc;
}

int farm_service(struct dispatcher *d, struct render **render)
{
    struct log_context *lc = d->lc;
    struct http_client *hc;
    struct render *backend;
    struct render_stat *stats;
    struct client_info *info;
    struct endpoint ep;
    struct timeval response_start = { 0, 0 };
    char url[4096];
    const char *allowed = ";/:~$-_.+!*'(),@&=";
    int sc;

    info = &d->info;
    memset(&ep, 0, sizeof ep);

    if (info->no_canon_url && info->raw_uri) {
        ep.file = info->raw_uri;
    } else {
        /* encode URL to pass */
        if (strchr(info->uri, ';') && info->raw_uri) {
            if (strchr(info->raw_uri, ';') == NULL) {
                /* encode ';' if it wasn't contained in the original URI */
                allowed++;
            }
        }
        ep.file = urlenc_ex(url, sizeof url, info->uri, allowed);
        ep.query = d->info.query;
    }

    /* connect to backend */
    ep.method = info->method;

    hc = farm_connect(lc, d->farm, &ep, info->id, &backend, &stats, &d->unavailable_mask);
    if (hc == NULL) {
        WARN("Unable to connect to any backend in farm %s", d->farm->label);
        return HTTP_BAD_GATEWAY;
    }

    DBG("Connected to backend %s (%s:%d)", backend->label, backend->host, backend->port);
    *render = backend;
    stats->vtime += DEFAULT_PENALITY; /* to be configured */

    /* do service */
    sc = render_service(d, backend, hc, &response_start);

    /* fixup */
    http_client_free(hc);
    update_stats(lc, backend, stats, &response_start, sc);

    return sc;
}

void farm_free(struct farm *farm)
{
    int i;

    if (farm == NULL) {
        return;
    }

    sessmgr_free(farm->sessionMgr);
    poller_free(farm->poller);
    authchk_free(farm->auth_checker);
    slist_free(farm->pt_header);

    for (i = 0; i < farm->numrenders; i++) {
        render_free(farm->renders[i]);
    }

    vanity_urls_free(farm->vanity_urls);
    cache_free(farm->cache);

    free(farm->domain);
    slist_free(farm->sticky_paths);

    filter_acl_free(farm->filter_acl);

    free(farm->probe_url);

    free(farm);
}

