/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2014 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/
#ifndef __VANITY_URLS_H__
#define __VANITY_URLS_H__

/**
 * @file vanity_urls.h
 * @brief Handle Vanity URLs.
 */

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * @defgroup vanity_url Vanity URLs
 * @{
 */

/**
 * Create a vanity URLs handler from an any structure.
 *
 * @param config config section
 *
 * @return vanity URLs or <code>NULL</code> if an error occurred
 */
struct vanity_urls *vanity_urls_create(struct log_context *lc, struct any_item *config,struct farm *farm);

/**
 * Check a possible vanity URL.
 *
 * @param urls vanity URLs, may be <code>NULL</code>
 * @param farm farm
 * @param info client info
 *
 * @return <code>1</code> if the incoming URL is a vanity URL;
 *         <code>0</code> otherwise
 */
int vanity_urls_is(struct log_context *lc, struct vanity_urls *urls, 
                   struct farm *farm, struct client_info *info);

/**
 * Destroy a vanity URLs handler.
 *
 * @param urls vanity URLs, may be <code>NULL</code>
 */
void vanity_urls_free(struct vanity_urls *urls);

/** @} */

#ifdef __cplusplus
}
#endif

#endif /* __FILTER_ACL_H__ */
