/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2013 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

#ifndef __FARM_H___
#define __FARM_H___


/** Number of renders per farm */
#define FARM_RENDERS_MAX 16

/** Number of statistics per render */
#define RENDER_STAT_MAX 8

/** A structure containing render statistics */
struct render_stat {
    /** globbing of pages belonging to this slot */
    char glob[64];
    /** number of bytes transmitted */
    unsigned long bytes;
    /** time used for page retrieval */
    unsigned long time;
    /** virtual time */
    unsigned long vtime;
};

/** A structure referring to a render in a farm */
struct render {
    /** zero-based index */
    int index;
    /** render label */
    char label[64];
    /** host associated with render */
    char *host;
    /** port associated with render */
    int port;
    /** socket address */
    struct addrinfo *ai;
    /** connect timeout in milliseconds */
    unsigned timeout;
    /** receive timeout in milliseconds */
    unsigned receiveTimeout;
    /** number of requests sent */
    int reqsent;
    /** number of requests that were successfully handled */
    int reqok;
    /** number of failed requests */
    int reqfailed;
    /** statistics about this render */
    struct render_stat stats[RENDER_STAT_MAX];
    /** info function table pointer */
    struct ip_info_vtable *vtbl;
    /** parent farm */
    struct farm* farm;
    /** whether to use SSL */
    unsigned secure:1;
    /** whether to use IPv4 */
    unsigned ipv4:1;
};

/** A structure referring to a farm in a website */
struct farm {
    /** farm label */
    char label[64];
    /** renders in this farm */
    struct render* renders[FARM_RENDERS_MAX];
    /** next farm in chain */
    struct farm *next;
    /** default value for statistics */
    struct render_stat stats[RENDER_STAT_MAX];
    /** number of stats */
    int numstats;
    /** number of retries before aborting request */
    int retries;
    /** delay between subsequent retries, in seconds */
    int retrydelay;
    /** penalty to apply if remote host is unavailable */
    int unavailable_penalty;
    /** number of renders */
    int numrenders;

    /** sticky connection paths */
    struct slist *sticky_paths;
    /** domain to set in sticky cookie */
    char *domain;

    /** probe URL */
    char *probe_url;

    /** cache settings */
    struct cache *cache;

    /** ACL for farm filter */
    struct filter_acl *filter_acl;

    /** vanity url mapper */
    struct vanity_urls *vanity_urls;

    /** linked list of client headers which should be forwarded to the render */
    struct slist *pt_header;
    /** session management */
    struct session_mgr *sessionMgr;
    /** poller */
    struct poller *poller;
    /** authorization checker */
    struct auth_checker *auth_checker;

    /** flag indicating whether to ignore EINTR */
    unsigned ignore_eintr:1;
    /** whether to forward syndication posts to render */
    unsigned propSyndPost:1;
    /** flag indicating whether failover is enabled */
    unsigned failover_enabled:1;
    /** flag indicating whether information will be sent in a response header */
    unsigned info_enabled:1;
    /** flag indicating whether httpOnly should be set in cookies */
    unsigned httpOnly:1;
    /** flag indicating whether secure should be set in cookies */
    unsigned secure:1;
    /** flag indicating whether Date response header is stored */
    unsigned date_header_stored:1;
    /** flag indicating whether ETag response header is stored */
    unsigned etag_header_stored:1;
};

/** A structure holding domain globbing */
struct domain_glob {
    /** host name pattern */
    char *hostname_pattern;
    /** uri pattern */
    char *uri_pattern;
    /** farm this globbing is associated with */
    struct farm *farm;
    /** next globbing in chain */
    struct domain_glob *next;
    /** whether virtual host has an https prefix */
    unsigned https:1;
    /** whether scheme masking should be applied */
    unsigned scheme_mask:1;
};


/**
 * Parse a farm configuration.
 *
 * @param config configuration root
 * @param domains domain linked list start, may be <code>NULL</code>
 *
 * @return farm or <code>NULL</code> in an error occurs
 */
struct farm *farm_create(struct log_context *lc, struct any_item *config, struct domain_glob **domains);

/**
 * Connect to the next available render in a farm.
 *
 * @param farm farm
 * @param ep endpoint information where the file member determines what
 *           render to prefer
 * @param id render id to prefer, may be <code>NULL</code>. If non-null
 *           and connecting to this render fails, will be set to an
 *           empty string on return
 * @param render selected render on return, may be <code>NULL</code>
 * @param stats selected render stats on return, may be <code>NULL</code>
 * @param unavailable_mask bit mask with renders marked unavailable,
 *                         may be <code>NULL</code>
 *
 * @return HTTP client on success;
 *         <code>NULL</code> on failure
 */
struct http_client *farm_connect(struct log_context *lc, struct farm *farm, struct endpoint *ep,
                                 char *id, struct render **render, struct render_stat **stats,
                                 int *unavailable_mask);

/**
 * Main service method for a farm. Connects to some backend in the farm,
 * spools the request received by the web server, and handles the
 * response returned by the backend.
 *
 * @param d dispatcher
 * @param backend selected backend
 *
 * @return <code>OK</code> if a response was generated;
 *         <code>DECLINED</code> if the request was declined;
 *         some HTTP status code otherwise
 */
int farm_service(struct dispatcher *d, struct render **backend);

/**
 * Check whether we should failover to some other backend instead of spooling
 * back the response received.
 *
 * @param backend backend
 * @param sc HTTP status code
 *
 * @return <code>0</code> if no failover should follow
 *         <code>1</code> if failover should happen
 */
int farm_failover(struct log_context *lc, struct render *backend, int sc);

/**
 * Free memory associated with a farm.
 *
 * @param farm farm, may be <code>NULL</code>
 */
void farm_free(struct farm *farm);

/**
 * Process <code>Location</code> response header. If backend and web server have
 * different schemes, adapt it.
 *
 * @param d dispatcher
 * @param backend backend
 * @param location location header
 *
 * @return <code>0</code> if location header remains unchanged;
 *         <code>1</code> if it was adapted and already set
 */
int render_process_location(struct dispatcher *d, struct render *backend, const char *location);


#endif /* __FARM_H___ */
