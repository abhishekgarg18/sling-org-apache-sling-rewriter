/*
 * Copyright (c) 2006 Day Management AG
 * Barfuesserplatz 6, 4001 Basel, Switzerland
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Day Management AG, ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Day.
 */
#include "base/base.h"

#include "dispatcher.h"
#include "farm.h"
#include "cache.h"
#include "poller.h"

/**
 * Component name.
 */
static const char *_component = "Poller";

/**
 * A structure holding a poller.
 */
struct poller {
    /* Parent farm */
    struct farm *farm;
    /* Configured URL to contact */
    char *url;
    /* Frequency in seconds */
    int frequency;
    /* Flag indicating whether poller is running */
    int running;
    /* Last time of successful contact since the Epoch, in seconds */
    time_t lastChecked;
};


/**
 * Do the actual poll against a connected backend.
 *
 * @param poller poller
 * @param hc HTTP client
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
static int do_poll(struct log_context *lc, struct poller *poller, struct http_client *hc)
{
    char line[1024];
    int sc, ret;

    if ((sc = http_client_get_status(hc, NULL)) != 200) {
        DBG("%s: backend answered with status code: %d", _component, sc);
        return -1;
    }
    for (;;) {
        if ((ret = http_client_readline(hc, line, sizeof line)) == -1) {
            WARN("%s: reading the next line failed: %s", http_client_get_error(hc));
            return -1;
        } else if (ret == 0) {
            break;
        }
        cache_flush(lc, poller->farm, line, ACTION_ACTIVATE, SCOPE_ALL, NULL, NULL);
    }
    return 0;
}


/*----------------------------------------------------------- Public methods */


struct poller *poller_create(struct log_context *lc, struct any_item *config, struct farm *farm)
{
    struct poller *poller;
    const char *ptr;

    if ((ptr = any_get_string(config, "url")) == NULL) {
        ERR("%s: URL not configured.", _component);
        return NULL;
    }

    poller = malloc(sizeof(struct poller));
    memset(poller, 0, sizeof(struct poller));

    poller->farm = farm;
    poller->url = strdup(ptr);
    poller->frequency = any_get_number(lc, config, "frequency", 10);
    poller->lastChecked = time(0);
    return poller;
}

void poller_run(struct log_context *lc, struct poller *poller, const char *uri)
{
    struct http_client *hc;
    struct render *backend;
    struct endpoint ep;
    char query[256];
    time_t now;

    if (poller->running) {
        return;
    }
    now = time(0);
    if (now <= poller->lastChecked + poller->frequency) {
        return;
    }
    poller->running = 1;

    memset(&ep, 0, sizeof(ep));
    ep.file = poller->url;
    ep.protocol = HTTP_1_0;
    snprintf(query, sizeof query, "lastChecked=%ld", poller->lastChecked);
    ep.query = query;

    if ((hc = farm_connect(lc, poller->farm, &ep, NULL, &backend, NULL, NULL))) {
        DBG("%s: connected to backend %s (%s:%d)", _component,
                backend->label, backend->host, backend->port);
        do_poll(lc, poller, hc);
        http_client_free(hc);
    }
    poller->running = 0;
}

void poller_free(struct poller *poller)
{
    if (!poller) {
        return;
    }
    free(poller->url);
    free(poller);
}
