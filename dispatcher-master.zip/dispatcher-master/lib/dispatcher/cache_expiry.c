/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2015 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

#include "base/base.h"

#include "dispatcher.h"
#include "cache_expiry.h"

/**
 * File extension used to store expiry date.
 */
static const char *_expiry_ext = ".ttl";

/**
 * Return an age specified in seconds in a string.
 *
 * @param buf where to find the seconds
 * @param field field to find
 * @param secs where to return seconds
 *
 * @return <code>0</code> if no age was found; otherwise <code>1</code>
 *
 */
static int get_age_in_seconds(const char *buf, const char *field, unsigned long *secs)
{
    char *sep, *start, *end;
    unsigned long n;

    sep = strstr(buf, field);
    if (sep != NULL) {
        start = sep + strlen(field);
        n = (unsigned long) strtol(start, &end, 10);
        if (start != end) {
            (*secs) = n;
            return 1;
        }
    }
    return 0;
}

/*----------------------------------------------------------- Public methods */

time_t cache_expiry_get_time(struct http_headers *headers)
{
    struct http_header *header;
    unsigned long secs;

    if ((header = http_headers_get(headers, "cache-control"))) {
        if (get_age_in_seconds(header->value, "s-maxage=", &secs) ||
            get_age_in_seconds(header->value, "max-age=", &secs)) {
            return time(NULL) + secs;
        }
    }
    return http_headers_get_date(headers, "expires");
}

int cache_expiry_store(struct log_context *lc, struct http_headers *headers, const char *body_path, int mode)
{
    char path[PATH_MAX];
    time_t expires;
    struct utimbuf ut;
    struct stat st;
    int fd;

    if (snprintf(path, sizeof path, "%s%s", body_path, _expiry_ext) >= (int) sizeof path) {
        WARN("Unable to store expiry date, file path too long: %s%s", path, _expiry_ext);
        return -1;
    }

    expires = cache_expiry_get_time(headers);
    if (expires != -1) {
        if (stat(path, &st) < 0) {
            if ((fd = open(path, O_CREAT, mode & 0666)) == -1) {
                WARNE("Unable to create file %s: %s", path, strerror(errno));
                return -1;
            }
            close(fd);
        }
        ut.actime = ut.modtime = expires;
        if (utime(path, &ut)) {
            WARNE("Unable to set file time for %s: %s", path, strerror(errno));
            return -1;
        }
    } else if (!stat(path, &st)) {
        /* No more Cache-Control/Expires returned, so remove that file */
        unlink(path);
    }
    return 0;
}

int cache_expiry_is_private(const char *path)
{
    const char *ext;
    char buf[PATH_MAX];
    unsigned len;
    struct stat st;

    ext = strrchr(path, '.');
    if (ext != NULL && !strcasecmp(ext, _expiry_ext)) {
        len = (unsigned) strlen(path) - 4;
        strncpy(buf, path, len);
        buf[len] = 0;
        if (!stat(buf, &st)) {
            return 1;
        }
    }
    return 0;
}

int cache_expiry_is_expired(const char *path, time_t *expiry)
{
    char ttl_path[PATH_MAX];
    struct stat st;

    if (snprintf(ttl_path, sizeof ttl_path, "%s%s", path, _expiry_ext) >= (int) sizeof ttl_path) {
        return -1;
    }
    if (stat(ttl_path, &st) < 0) {
        return -1;
    }
    *expiry = st.st_mtime;
    return st.st_mtime < time(NULL) ? 1 : 0;
}

int cache_expiry_set(struct log_context *lc, const char *path, time_t expiry)
{
    char ttl_path[PATH_MAX];
    struct utimbuf ut;

    if (snprintf(ttl_path, sizeof ttl_path, "%s%s", path, _expiry_ext) >= (int) sizeof ttl_path) {
        return -1;
    }
    ut.actime = ut.modtime = expiry;
    if (utime(ttl_path, &ut)) {
        WARNE("Unable to set file time for %s: %s", path, strerror(errno));
        return -1;
    }
    return 0;
}

void cache_expiry_deliver(struct dispatcher *d)
{
    struct stat st;
    time_t now;
    int age;
    char age_value[10];

    if (stat(d->cachepath, &st) < 0) {
        return;
    }
    now = time(NULL);
    age = (int) (now - st.st_mtime);
    if (age < 0) {
        age = 0;
    }
    snprintf(age_value, sizeof(age_value), "%d", age);
    ws_set_header(d, "Age", age_value);
}
