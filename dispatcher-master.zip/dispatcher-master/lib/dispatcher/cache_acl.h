/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2013 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

#ifndef __CACHE_ACL_H__
#define __CACHE_ACL_H__

/**
 * @file cache_acl.h
 * @brief Cache ACLs used to determine whether a response should be cached.
 */

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * @defgroup cacher_acl Access control lists
 * @{
 */

/**
 * Create a cache ACL from an any structure, starting at the first child.
 *
 * @param first first child of list
 * @param name optional name, may be <code>NULL</code>
 *
 * @return ACL or <code>NULL</code> if an error occurred
 */
struct cache_acl *cache_acl_create(struct log_context *lc, struct any_item *first, const char *name);

/**
 * Match a URI against the elements in a cache ACL.
 *
 * @param acl ACL to scan, may be <code>NULL</code>
 * @param uri URI
 *
 * @return <code>1</code> if the URI is allowed to be cached, otherwise <code>0</code>.
 */
int cache_acl_allowed(struct log_context *lc, struct cache_acl *acl, const char *uri, const char **qaexec);

/**
 * Destroy a cache access control list.
 *
 * @param acl access control list, may be <code>NULL</code>
 */
void cache_acl_free(struct cache_acl *acl);

/** @} */

#ifdef __cplusplus
}
#endif

#endif /* __CACHE_ACL_H__ */
