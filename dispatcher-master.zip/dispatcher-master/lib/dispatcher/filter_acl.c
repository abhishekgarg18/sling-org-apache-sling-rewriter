/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2013 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

#include <string.h>
#include <stdlib.h>

#include "base/base.h"

#include "dispatcher.h"
#include "filter_acl.h"

static const char *dispatcher_doc_url = "https://www.adobe.com/go/docs_dispatcher_config_en";

/**
 * Match a list of selectors against a pattern. The selectors are stored consecutively
 * in memory, separated by zero terminators.
 *
 * @param p pattern
 * @param start first selector, or <code>NULL</code>
 * @param end end of selectors
 */
static unsigned match_any_selector(struct log_context *lc, struct pattern *p, const char *start, const char *end)
{
    const char *selector;

    if (start == NULL) {
        return pattern_match(lc, p, NULL);
    }
    for (selector = start; selector != end; selector += strlen(selector) + 1) {
        if (pattern_match(lc, p, selector)) {
            return 1;
        }
    }
    return 0;
}

/**
 * Structure representing a filter ACE.
 */
struct filter_ace {
    /* label, <code>NULL</code> if not in trace mode */
    char *label;
    /* glob */
    char *glob;
    /* method */
    struct pattern method;
    /* url */
    struct pattern url;
    /* query */
    struct pattern query;
    /* protocol */
    struct pattern protocol;
    /* resource path */
    struct pattern rpath;
    /* selectors */
    struct pattern selectors;
    /* extension */
    struct pattern extension;
    /* suffix */
    struct pattern suffix;
    /* 1 if allowed, 0 if denied  */
    unsigned allowed:1;
    /* next ace item */
    struct filter_ace *next;
};

/**
 * Structure representing ACL.
 */
struct filter_acl {
    /* first ace item */
    struct filter_ace *ace;
    /* optional name */
    char *name;
    /* flag indicating trace is enabled */
    unsigned trace:1;
};


static struct filter_ace *ace_create_glob(const char *glob)
{
    struct filter_ace *ace;

    ace = malloc(sizeof(struct filter_ace));
    memset(ace, 0, sizeof(struct filter_ace));

    ace->glob = strdup(glob);

    return ace;
}

static struct filter_ace *ace_create(struct log_context *lc, struct any_item *method, struct any_item *url, struct any_item *query,
                                     struct any_item *protocol, struct any_item *rpath, struct any_item *selectors,
                                     struct any_item *extension, struct any_item *suffix)
{
    struct filter_ace *ace;

    ace = malloc(sizeof(struct filter_ace));
    memset(ace, 0, sizeof(struct filter_ace));

    if (create_pattern(lc, &ace->method, method) ||
            create_pattern(lc, &ace->url, url) ||
            create_pattern(lc, &ace->query, query) ||
            create_pattern(lc, &ace->protocol, protocol) ||
            create_pattern(lc, &ace->rpath, rpath) ||
            create_pattern(lc, &ace->selectors, selectors) ||
            create_pattern(lc, &ace->extension, extension) ||
            create_pattern(lc, &ace->suffix, suffix)) {
        return NULL;
    }
    return ace;
}

static void ace_free(struct filter_ace *ace)
{
    free(ace->label);
    free(ace->glob);
    pattern_free(&ace->method);
    pattern_free(&ace->url);
    pattern_free(&ace->query);
    pattern_free(&ace->protocol);
    pattern_free(&ace->rpath);
    pattern_free(&ace->selectors);
    pattern_free(&ace->extension);
    pattern_free(&ace->suffix);
    free(ace);
}

/**
 * Remove consecutive slashes in a URI.
 *
 * @param uri uri to process
 * @param processed URI, to be freed after use, or NULL
 *
 * @return processed URI or original URI, if no slashes had to be removed
 */
static const char *preprocess_uri(const char *uri, char **processed) {
    char *new_uri;
    size_t i, j, uri_len;

    // quick check for consecutive slashes
    if (strstr(uri, "//") == NULL) {
        *processed = NULL;
        return uri;
    }

    uri_len = strlen(uri);
    new_uri = malloc(uri_len + 1);
    for (i = 0, j = 0; i < uri_len; i++) {
        char ch = uri[i];
        if (ch == '/' && j > 0 && new_uri[j - 1] == '/') {
            continue;
        }
        new_uri[j++] = ch;
    }
    new_uri[j] = 0;
    return (*processed = new_uri);
}

static int request_allowed(struct log_context *lc, struct filter_acl *acl, const char *method,
                           const char *uri, const char *safe_uri,
                           const char *query, const char *protocol)
{
    struct filter_ace *ace, *match_ace = NULL;
    const char *selectors, *extension;
    char line[8192], *rpath, *suffix;
    int match;

    if (acl == NULL) {
        /* if no ACL is defined, a request is allowed */
        return 1;
    }

    if (query) {
        snprintf(line, sizeof line, "%s %s?%s %s",
                 method, uri, query, protocol);
    } else {
        snprintf(line, sizeof line, "%s %s %s",
                 method, uri, protocol);
    }

    decompose_url(uri, &rpath, &selectors, &extension, &suffix);

    TRACE("Decomposing URL :");
    TRACE("uri : %s ", uri);
    TRACE("suffix : %s ", (suffix == NULL) ? "No suffix" : suffix);
    TRACE("extension : %s ", (extension == NULL) ? "No extension" : extension);
    TRACE("selector : %s ", (selectors == NULL) ? "No selectors" : selectors);
    TRACE("Decomposing Complete");

    for (ace = acl->ace; ace; ace = ace->next) {
        if (ace->glob) {
            match = !strglobcmp(ace->glob, line);
        } else {
            match = pattern_match(lc, &ace->method, method) &&
                    pattern_match(lc, &ace->url, uri) &&
                    pattern_match(lc, &ace->query, query) &&
                    pattern_match(lc, &ace->protocol, protocol) &&
                    pattern_match(lc, &ace->rpath, rpath) &&
                    match_any_selector(lc, &ace->selectors, selectors, extension) &&
                    pattern_match(lc, &ace->extension, extension) &&
                    pattern_match(lc, &ace->suffix, suffix);
        }
        if (match) {
            match_ace = ace;
        }
    }
    free(rpath);
    free(suffix);

    if (match_ace && acl->trace) {
        if (query) {
            snprintf(line, sizeof line, "%s %s?%s %s",
                     method, safe_uri, query, protocol);
        } else {
            snprintf(line, sizeof line, "%s %s %s",
                     method, safe_uri, protocol);
        }
        TRACE("%s entry /%s %s '%s'", acl->name ? acl->name : "ACL",
              match_ace->label, match_ace->allowed ? "allowed" : "blocked", line);
    }
    return match_ace && match_ace->allowed ? 1 : 0;
}


/*----------------------------------------------------------- Public methods */


struct filter_acl *filter_acl_create(struct log_context *lc, struct any_item *first, const char *name)
{
    const char *type, *glob;
    struct any_item *method, *url, *query, *protocol, *rpath, *selectors, *extension, *suffix;
    struct filter_acl *acl;
    struct filter_ace *ace, *last = NULL;
    unsigned warned_once_about_allow_glob = 0;

    acl = malloc(sizeof(struct filter_acl));
    memset(acl, 0, sizeof(struct filter_acl));

    if (name) {
        acl->name = strdup(name);
        acl->trace = log_is_enabled(lc, LL_TRACE);
    }

    while (first) {
        glob = any_get_string(first, "glob");
        method = any_get_item(first, "method");
        url = any_get_item(first, "url");
        query = any_get_item(first, "query");
        protocol = any_get_item(first, "protocol");
        rpath = any_get_item(first, "path");
        selectors = any_get_item(first, "selectors");
        extension = any_get_item(first, "extension");
        suffix = any_get_item(first, "suffix");

        if (glob) {
            if (method || url || query || protocol || rpath || selectors || extension || suffix) {
                ERR("%s:%d: Entry can have glob or a combination of "
                        "method/url/query/protocol/path/selectors/extension/suffix, but not both.",
                        first->filename, first->line);
                filter_acl_free(acl);
                return NULL;
            }
            ace = ace_create_glob(glob);
        } else {
            if (!method && !url && !query && !protocol && !rpath && !selectors && !extension && !suffix) {
                ERR("%s:%d: Entry must have either glob or a combination "
                            "of method/url/query/protocol/path/selectors/extension/suffix.",
                    first->filename, first->line);
                filter_acl_free(acl);
                return NULL;
            }
            ace = ace_create(lc, method, url, query, protocol, rpath, selectors, extension, suffix);
            if (ace == NULL) {
                return NULL;
            }
        }

        type = any_get_string(first, "type");
        ace->allowed = type && !strcasecmp("allow", type) ? 1 : 0;

        if (ace->glob != NULL && ace->allowed && warned_once_about_allow_glob == 0) {
            WARN("%s:%d: Allowing requests with globs is considered unsafe. "
                         "Please consult the documentation at '%s' on how to "
                         "use attributes method/url/query/protocol/path/selectors/extension/suffix instead.",
                 first->filename, first->line, dispatcher_doc_url);
            warned_once_about_allow_glob = 1;
        }
        if (acl->trace) {
            ace->label = strdup(first->label);
        }
        if (last) {
            last->next = ace;
        } else {
            acl->ace = ace;
        }
        last = ace;
        first = first->next;
    }
    return acl;
}

int filter_acl_allowed(struct log_context *lc, struct filter_acl *acl, struct client_info *info)
{
    int result;
    char *processed;

    result = request_allowed(lc, acl, info->method, preprocess_uri(info->uri, &processed),
                             info->safe_uri, info->query, info->protocol);
    free(processed);
    return result;
}

void filter_acl_free(struct filter_acl *acl)
{
    struct filter_ace *ace, *next;

    if (!acl) {
        return;
    }
    ace = acl->ace;
    while (ace) {
        next = ace->next;
        ace_free(ace);
        ace = next;
    }
    free(acl->name);
    free(acl);
}
