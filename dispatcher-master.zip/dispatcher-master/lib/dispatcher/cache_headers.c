/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2014 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

#include "base/base.h"

#include "dispatcher.h"
#include "cache_headers.h"

/**
 * Cache headers.
 */
struct cache_headers {
    /* first configured header */
    struct header *first;
};

/**
 * Header element.
 */
struct header {
    /* name (case-sensitive) */
    char *name;
    /* name (lowercase) */
    char *lwrname;
    /* next header */
    struct header *next;
};

/**
 * File extension used to store headers.
 */
static const char *_headers_ext = ".h";


/*----------------------------------------------------------- Public methods */


struct cache_headers *cache_headers_create(struct log_context *lc, struct any_item *first)
{
    struct cache_headers *p;
    struct header *hdr, *last = NULL;
    const char *name;
    struct any_item *child;

    p = malloc(sizeof(struct cache_headers));
    memset(p, 0, sizeof(struct cache_headers));

    for (child = first; child != NULL && child->type == STRING; child = child->next) {
        name = child->value.p;
        if (strchr(name, '*') != NULL || strchr(name, '?') != NULL) {
            WARN("Header names to be cached must be literal, wildcards are not allowed: %s", name);
            continue;
        }

        hdr = malloc(sizeof(struct header));
        memset(hdr, 0, sizeof(struct header));
        hdr->name = strdup(name);
        hdr->lwrname = strdup(hdr->name);
        strlwrcpy(hdr->lwrname, hdr->lwrname);

        if (!last) {
            p->first = hdr;
        } else {
            last->next = hdr;
        }
        last = hdr;
    }
    return p;
}

/**
 * Store headers found in response into a file.
 *
 * @param headers cache headers
 * @param http_headers HTTP headers
 * @param path path to headers file
 * @param fp file pointer
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure or if no headers had to be stored
 */
static int store_headers(struct log_context *lc, struct cache_headers *headers, struct http_headers *http_headers,
                         const char *path, FILE *fp)
{
    struct header *hdr;
    unsigned count = 0;
    int ret = 0;

    for (hdr = headers->first; hdr != NULL && ret == 0; hdr = hdr->next) {
        struct http_header *http_header = http_headers_get(http_headers, hdr->lwrname);
        while (http_header != NULL) {
            ret = (fputs(hdr->name, fp) >= 0 &&
                   fputs(":", fp) >= 0 &&
                   fputs(http_header->value, fp) >= 0 &&
                   fputs("\n", fp) >= 0) ? 0 : -1;
            count++;
            http_header = http_header->next;
        }
    }
    if (ret) {
        ERRE("Unable to store cache headers in %s: %s", path, strerror(errno));
    }
    return ret < 0 || count == 0 ? -1 : 0;
}

int cache_headers_store(struct log_context *lc, struct cache_headers *headers, struct http_headers *http_headers,
                        const char *body_path, int mode)
{
    char path[PATH_MAX], tmppath[PATH_MAX];
    FILE *fp;
    int ret;

    if (snprintf(path, sizeof path, "%s%s", body_path, _headers_ext) >= (int) sizeof path) {
        WARN("Unable to cache headers, file path too long: %s%s", path, _headers_ext);
        return -1;
    }

    if (create_temp_file(lc, path, tmppath, &fp, mode)) {
        return -1;
    }

    ret = store_headers(lc, headers, http_headers, tmppath, fp);
    fclose(fp);

    if (ret) {
        unlink(tmppath);
        return ret;
    }

    remove(path);
    return rename(tmppath, path);
}

void cache_headers_deliver(struct cache_headers *headers, struct dispatcher *d)
{
    struct log_context *lc = d->lc;
    char path[PATH_MAX], *contents, *line, *sep, *eol;
    struct stat st;

    if (snprintf(path, sizeof path, "%s%s", d->cachepath, _headers_ext) >= (int) sizeof path) {
        WARN("Unable to load cache headers, file path too long: %s%s", path, _headers_ext);
        return;
    }
    if (stat(path, &st)) {
        return;
    }
    if ((contents = mallocbinfile(path)) == NULL) {
        ERRE("Unable to load cache headers in %s: %s", path, strerror(errno));
        return;
    }

    line = contents;
    while (*line) {
        if ((eol = strchr(line, '\n')) == NULL || (sep = strchr(line, ':')) == NULL || sep > eol) {
            break;
        }

        /* Terminate name and value (removing ':' and LF) */
        *sep++ = 0;
        *eol++ = 0;

        ws_set_header(d, line, sep);

        line = eol;
    }
    free(contents);
}

void cache_headers_free(struct cache_headers *headers)
{
    struct header *hdr, *next;

    if (headers == NULL) {
        return;
    }

    hdr = headers->first;
    while (hdr) {
        next = hdr->next;
        free(hdr->name);
        free(hdr->lwrname);
        free(hdr);
        hdr = next;
    }
    free(headers);
}

int cache_headers_is_private(const char *path)
{
    const char *ext;
    char buf[PATH_MAX];
    unsigned len;
    struct stat st;

    ext = strrchr(path, '.');
    if (ext != NULL && !strcasecmp(ext, _headers_ext)) {
        len = (unsigned) strlen(path) - 2;
        strncpy(buf, path, len);
        buf[len] = 0;
        if (!stat(buf, &st)) {
            return 1;
        }
    }
    return 0;
}

int cache_headers_is_stored(struct cache_headers *headers, const char *name)
{
    struct header *hdr;

    for (hdr = headers->first; hdr != NULL; hdr = hdr->next) {
        if (!strcasecmp(name, hdr->name)) {
            return 1;
        }
    }
    return 0;
}
