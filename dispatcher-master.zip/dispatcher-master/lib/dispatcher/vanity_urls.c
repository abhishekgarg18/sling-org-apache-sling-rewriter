/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2014 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/
#include <string.h>
#include <stdlib.h>

#include "base/base.h"

#include "dispatcher.h"
#include "farm.h"
#include "vanity_urls.h"

/**
 * Structure representing a vanity URL handler.
 */
struct vanity_urls
{
    /* URL on backend where list of vanity URLs are available */
    char *url;
    /* File where Vanity URLs are stored */
    char *file;
    /* Reload delay in seconds */
    int reloadDelay;
    /* Set of Vanity URLs */
    struct hashtable *set;
    /* Last observed file time, in seconds */
    time_t filetime;
    /* Last check time, in seconds */
    time_t checktime;
    /* Lock */
    struct lock *lock;
};


static int store_output(struct log_context *lc, struct http_client *hc, const char *path)
{
    char tmppath[PATH_MAX], buf[PATH_MAX];
    FILE *fp;
    int ret;

    if (create_temp_file(lc, path, tmppath, &fp, 0755)) {
        return -1;
    }

    ret = http_client_store(hc, fp, tmppath);
    fclose(fp);

    if (ret) {
        unlink(tmppath);
        return ret;
    }
    remove(strcpy(buf, path));
    return rename(tmppath, path);
}

/**
 * Fetch vanity URLs from backend and store as file.
 *
 * @param urls vanity URLs handler
 * @param farm farm
 * @return <code>0</code> on success;
 *         <code>-1</code> otherwise
 */
static int fetch_from_backend(struct log_context *lc, struct vanity_urls * urls, struct farm *farm)
{
    struct endpoint ep;
    struct http_client *hc;
    int status;
    const char *sline;
    char buf[256];

    /* Connect to some backend */
    memset(&ep, 0, sizeof ep);
    ep.file = urls->url;

    if ((hc = farm_connect(lc, farm, &ep, NULL, NULL, NULL, NULL)) == NULL) {
        ERR("Unable to fetch vanity URLs on farm %s: no backend available.", farm->label);
        return -1;
    }

    /* Check response status */
    snprintf(buf, sizeof buf, "Unable to fetch vanity URLs from %s:%d%s",
            ep.host, ep.port, ep.file);

    if ((status = http_client_get_status(hc, &sline)) != HTTP_OK) {
        switch (status) {
        case HC_ESEND:
            WARN("%s: error while sending request to remote server.", buf);
            break;
        case HC_ERECV:
            WARN("%s: error while receiving response from remote server.", buf);
            break;
        default:
            WARN("%s: remote server returned: %s", buf, sline);
            break;
        }
        http_client_free(hc);
        return -1;
    }

    /* Store output */
    store_output(lc, hc, urls->file);
    http_client_free(hc);
    return 0;
}
/**
 * sleep for milliseconds.
 */
static void sleepMS(int sleepInMilliseconds) {
    #ifdef WIN32
        Sleep(sleepInMilliseconds);
    #else  
        usleep(sleepInMilliseconds * 1000); 
    #endif
}

/**
 * Load vanity URLs from file.
 *
 * @param urls vanity URLs
 * @param set set to populate
 * @return <code>0</code> on success;
 *         <code>-1</code> otherwise
 */
static int load_from_file(struct log_context *lc, struct vanity_urls *urls)
{
    char *p, *p2, *end, *lf;
    struct hashtable *new_set, *old_set;

    if ((p = mallocbinfile(urls->file)) == NULL) {
        ERRE("Unable to read file %s: %s", urls->file, strerror(errno));
        return -1;
    }

    p2 = p;

    create_hashtable(&new_set, 10007);
    end = p + strlen(p);

    while (p < end) {
        lf = strchr(p, '\r');
        if (lf == NULL) {
            lf = strchr(p, '\n');
        }
        if (lf == NULL) {
            lf = p + strlen(p);
        }
        while (WS(*lf)) {
            *lf++ = 0;
        }
        hashtable_puts(new_set, p, p);

        p = lf;
    }

    free(p2);
    p2 = NULL;
    
    DBG("Loaded %d vanity URLs from file %s", hashtable_size(new_set), urls->file);

    old_set = urls->set;
    urls->set = new_set;
    sleepMS(10);
    hashtable_free(old_set);
    return 0;
}

static int refresh_vanity_urls(struct log_context *lc, struct vanity_urls *urls, struct farm *farm)
{
    struct stat st;
    long currentsecs;

    currentsecs = (long) (gettimemillis() / 1000L);
    
    if (urls->set && urls->checktime > currentsecs) {
        /* we have an up-to-date set, nothing to do */
        DBG("vanity urls set are up-to-date");
        return 0;
    }

  
    if (!lock_acquire(urls->lock) ) {
        DBG("Acquired vanity lock, loading vanity urls ");
        // Double checking of urls->set.
        if (urls->set && urls->checktime > currentsecs) {
            DBG("Releasing vanity lock, vanity urls set are up-to-date");
            lock_release(urls->lock);
            return 0;
        }
        
        if (stat(urls->file, &st)) {
            DBG("Vanity URL file (%s) not found, fetching...", urls->file);
            if (fetch_from_backend(lc, urls, farm)) {
                DBG("Releasing vanity lock, couldn't fetch from backend");
                lock_release(urls->lock);
                return -1;
            }
            stat(urls->file, &st);
            load_from_file(lc, urls);
        } else if (urls->filetime == st.st_mtime) {
            DBG("Vanity URL file (%s) outdated, fetching...", urls->file);
            if (!fetch_from_backend(lc, urls, farm)) {
                stat(urls->file, &st);
                load_from_file(lc, urls);
            }
        } else if (urls->filetime == 0) {
            /* Never loaded */
            if (st.st_mtime + urls->reloadDelay < currentsecs) {
                DBG("Vanity URL file (%s) too old on startup, fetching...", urls->file);
                if (!fetch_from_backend(lc, urls, farm)) {
                    stat(urls->file, &st);
                }
            } else {
                DBG("Vanity URL file (%s) found, loading...", urls->file);
            }
            load_from_file(lc, urls);
        } else if (urls->filetime != st.st_mtime) {
            /* Modified since last seen */
            DBG("Vanity URL file (%s) modified, reloading...", urls->file);
            load_from_file(lc, urls);
        }
        urls->filetime = st.st_mtime;
        urls->checktime = urls->filetime + urls->reloadDelay;
        lock_release(urls->lock);
        DBG("Released vanity lock");
        return 0;

    } 
    DBG("Unable to acquire lock, using old cached vanity values.");   
    return 0;
    
}


/*----------------------------------------------------------- Public methods */


struct vanity_urls *vanity_urls_create(struct log_context *lc, struct any_item *config,struct farm *farm)
{
    struct vanity_urls *urls;
    struct lock *lock;
    const char *url, *file;

    if ((url = any_get_string(config, "url")) == NULL) {
        WARN("%s:%d: Missing url property in vanity url mapper, not configured.", config->filename, config->line);
        return NULL;
    }
    if ((file = any_get_string(config, "file")) == NULL) {
        WARN("%s:%d: Missing file property in vanity url mapper, not configured.", config->filename, config->line);
        return NULL;
    }
    if ((lock = create_lock(lc)) == NULL) {
        WARN("Unable to create lock.");
        return NULL;
    }

    urls = malloc(sizeof(struct vanity_urls));
    memset(urls, 0, sizeof(struct vanity_urls));

    urls->url = strdup(url);
    urls->file = strdup(file);
    urls->reloadDelay = any_get_number(lc, config, "delay", 300);
    urls->lock = lock;
    // load vanity urls when  we are creating farm.
    refresh_vanity_urls(lc, urls, farm);
    return urls;
}

int vanity_urls_is(struct log_context *lc, struct vanity_urls *urls, struct farm *farm, struct client_info *info)
{
    const char *uri = info->uri, *selectors, *extension;
    char *rpath, *suffix;
    int is_vanity = 0;

    if (urls == NULL) {
        return 0;
    }
    if (refresh_vanity_urls(lc, urls, farm)) {
        return 0;
    }
    if (urls->set == NULL) {
        return 0;
    }

    decompose_url(uri, &rpath, &selectors, &extension, &suffix);

    if (hashtable_gets(urls->set, rpath)) {
        if (extension == NULL || !strcmp(extension, "html")) {
            DBG("Request URL is a vanity URL: %s", uri);
            is_vanity = 1;
        } else {
            DBG("Not allowing extension for vanity URL %s: %s", rpath, extension);
        }
    }

    free(rpath);
    free(suffix);

    return is_vanity;
}

void vanity_urls_free(struct vanity_urls *urls)
{
    if (!urls) {
        return;
    }
    lock_free(urls->lock);
    hashtable_free(urls->set);
    free(urls->file);
    free(urls->url);
    free(urls);
}
