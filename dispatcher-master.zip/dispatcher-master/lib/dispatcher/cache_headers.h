/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2014 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

#ifndef __CACHE_HEADERS_H___
#define __CACHE_HEADERS_H___

/**
 * Parse settings.
 *
 * @param config config root
 *
 * @return cache headers
 */
struct cache_headers *cache_headers_create(struct log_context *lc, struct any_item *first);

/**
 * Extract headers found in response and store them in the file system.
 *
 * @param headers cache headers
 * @param http_headers HTTP headers
 * @param path path where response body is stored
 * @param mode permissions, as in chmod
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
int cache_headers_store(struct log_context *lc, struct cache_headers *headers, struct http_headers *http_headers, 
                        const char *body_path, int mode);

/**
 * Add stored headers to the response.
 *
 * @param headers headers
 * @param d dispatcher structure
 */
void cache_headers_deliver(struct cache_headers *headers, struct dispatcher *d);

/**
 * Free memory associated with cache headers.
 *
 * @param headers headers, may be <code>NULL</code>
 */
void cache_headers_free(struct cache_headers *headers);

/**
 * Return a flag indicating whether the indicated path points to a file where headers are stored
 * and that should not be delivered.
 *
 * @param path path to check
 * @return <code>1</code> if it is private;
 *         <code>0</code> otherwise
 */
int cache_headers_is_private(const char *path);

/**
 * Return a flag indicating whether the indicated header is stored.
 *
 * @param headers headers
 * @param name header name
 * @return <code>1</code> if it is stored;
 *         <code>0</code> otherwise
 */
int cache_headers_is_stored(struct cache_headers *headers, const char *name);

#endif /* __CACHE_HEADERS_H___ */
