/*
 * Copyright (c) 2006 Day Management AG
 * Barfuesserplatz 6, 4001 Basel, Switzerland
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Day Management AG, ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Day.
 */
#ifndef __POLLER_H__
#define __POLLER_H__

/**
 * @file poller.h
 * @brief HTTP poller
 */

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @defgroup poller HTTP poller
 * @{
 */

/**
 * Initialize poller.
 *
 * @param config configuration section
 * @param farm parent farm
 *
 * @return pointer to session manager if initialization successful;
 *         otherwise 0.
 */
struct poller *poller_create(struct log_context *lc, struct any_item *config, struct farm *farm);

/**
 * Run poller. If current time is greater than last checking time plus
 * frequency, connect to some render, ask for changes since last checking
 * time and flush caches for handles returned.
 *
 * @param poller poller
 * @param uri uri to connect to
 */
void poller_run(struct log_context *lc, struct poller *poller, const char *uri);

/**
 * Free memory associated with a poller.
 *
 * @param poller poller, may be <code>NULL</code>
 */
void poller_free(struct poller *poller);

/** @} */

#ifdef __cplusplus
}
#endif

#endif  /* __POLLER_H__ */
