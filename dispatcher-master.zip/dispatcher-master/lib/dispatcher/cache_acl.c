/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2013 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

#include <string.h>
#include <stdlib.h>

#include "base/base.h"

#include "dispatcher.h"
#include "cache_acl.h"

/**
 * Match a list of selectors against a pattern. The selectors are stored consecutively
 * in memory, separated by zero terminators.
 *
 * @param p pattern
 * @param start first selector, or <code>NULL</code>
 * @param end end of selectors
 */
static unsigned match_any_selector(struct log_context *lc, struct pattern *p, const char *start, const char *end)
{
    const char *selector;

    if (start == NULL) {
        return pattern_match(lc, p, NULL);
    }
    for (selector = start; selector != end; selector += strlen(selector) + 1) {
        if (pattern_match(lc, p, selector)) {
            return 1;
        }
    }
    return 0;
}

/**
 * Structure representing a cache ACE.
 */
struct cache_ace {
    /* label, <code>NULL</code> if not in trace mode */
    char *label;
    /* qaexec */
    char *qaexec;
    /* glob */
    char *glob;
    /* url */
    struct pattern url;
    /* resource path */
    struct pattern rpath;
    /* selectors */
    struct pattern selectors;
    /* extension */
    struct pattern extension;
    /* suffix */
    struct pattern suffix;
    /* 1 if allowed, 0 if denied  */
    unsigned allowed:1;
    /* next ace item */
    struct cache_ace *next;
};

/**
 * Structure representing ACL.
 */
struct cache_acl {
    /* first ace item */
    struct cache_ace *ace;
    /* optional name */
    char *name;
    /* flag indicating trace is enabled */
    unsigned trace:1;
};


static struct cache_ace *ace_create_glob(const char *glob)
{
    struct cache_ace *ace;

    ace = malloc(sizeof(struct cache_ace));
    memset(ace, 0, sizeof(struct cache_ace));

    ace->glob = strdup(glob);

    return ace;
}

static struct cache_ace *ace_create(struct log_context *lc, 
                                    struct any_item *url, struct any_item *rpath, struct any_item *selectors,
                                    struct any_item *extension, struct any_item *suffix)
{
    struct cache_ace *ace;

    ace = malloc(sizeof(struct cache_ace));
    memset(ace, 0, sizeof(struct cache_ace));

    if (create_pattern(lc, &ace->url, url) ||
            create_pattern(lc, &ace->rpath, rpath) ||
            create_pattern(lc, &ace->selectors, selectors) ||
            create_pattern(lc, &ace->extension, extension) ||
            create_pattern(lc, &ace->suffix, suffix)) {
        return NULL;
    }
    return ace;
}

static void ace_free(struct cache_ace *ace)
{
    free(ace->label);
    free(ace->glob);
    pattern_free(&ace->url);
    pattern_free(&ace->rpath);
    pattern_free(&ace->selectors);
    pattern_free(&ace->extension);
    pattern_free(&ace->suffix);
    free(ace);
}


/*----------------------------------------------------------- Public methods */


struct cache_acl *cache_acl_create(struct log_context *lc, struct any_item *first, const char *name)
{
    const char *type, *glob, *qaexec;
    struct any_item *url, *rpath, *selectors, *extension, *suffix;
    struct cache_acl *acl;
    struct cache_ace *ace, *last = NULL;

    acl = malloc(sizeof(struct cache_acl));
    memset(acl, 0, sizeof(struct cache_acl));

    if (name) {
        acl->name = strdup(name);
        acl->trace = log_is_enabled(lc, LL_TRACE);
    }

    while (first) {
        glob = any_get_string(first, "glob");
        url = any_get_item(first, "regex");
        rpath = any_get_item(first, "path");
        selectors = any_get_item(first, "selectors");
        extension = any_get_item(first, "extension");
        suffix = any_get_item(first, "suffix");

        if (glob) {
            if (url || rpath || selectors || extension || suffix) {
                ERR("%s:%d: Entry can have glob or a combination of "
                        "regex/path/selectors/extension/suffix, but not both.",
                        first->filename, first->line);
                cache_acl_free(acl);
                return NULL;
            }
            ace = ace_create_glob(glob);
        } else {
            if (!url && !rpath && !selectors && !extension && !suffix) {
                ERR("%s:%d: Entry must have either glob or a combination "
                            "of regex/path/selectors/extension/suffix.",
                    first->filename, first->line);
                cache_acl_free(acl);
                return NULL;
            }
            ace = ace_create(lc, url, rpath, selectors, extension, suffix);
            if (ace == NULL) {
                return NULL;
            }
        }

        type = any_get_string(first, "type");
        ace->allowed = type && !strcasecmp("allow", type) ? 1 : 0;

        if (acl->trace) {
            ace->label = strdup(first->label);
        }
        qaexec = any_get_string(first, "qaexec");
        if (qaexec) {
            ace->qaexec = strdup(qaexec);
        }

        if (last) {
            last->next = ace;
        } else {
            acl->ace = ace;
        }
        last = ace;
        first = first->next;
    }
    return acl;
}

int cache_acl_allowed(struct log_context *lc, struct cache_acl *acl, const char *uri, const char **qaexec)
{
    struct cache_ace *ace, *match_ace = NULL;
    const char *selectors, *extension;
    char *rpath, *suffix;
    int match;

    if (acl == NULL) {
        /* if no ACL is defined, caching is forbidden */
        return 0;
    }

    decompose_url(uri, &rpath, &selectors, &extension, &suffix);

    for (ace = acl->ace; ace; ace = ace->next) {
        if (ace->glob) {
            match = !strglobcmp(ace->glob, uri);
        } else {
            match = pattern_match(lc, &ace->url, uri) &&
                    pattern_match(lc, &ace->rpath, rpath) &&
                    match_any_selector(lc, &ace->selectors, selectors, extension) &&
                    pattern_match(lc, &ace->extension, extension) &&
                    pattern_match(lc, &ace->suffix, suffix);
        }
        if (match) {
            match_ace = ace;
        }
    }
    free(rpath);
    free(suffix);

    if (match_ace) {
        if (acl->trace) {
            char encoded_url[4096];

            urlenc_ex(encoded_url, sizeof encoded_url, uri, NULL);
            TRACE("%s entry /%s %s '%s'", acl->name ? acl->name : "ACL",
                  match_ace->label, match_ace->allowed ? "allowed" : "blocked", encoded_url);
        }
        if (qaexec) {
            *qaexec = match_ace->qaexec;
        }
    }
    return match_ace && match_ace->allowed ? 1 : 0;
}

void cache_acl_free(struct cache_acl *acl)
{
    struct cache_ace *ace, *next;

    if (!acl) {
        return;
    }
    ace = acl->ace;
    while (ace) {
        next = ace->next;
        ace_free(ace);
        ace = next;
    }
    free(acl->name);
    free(acl);
}
