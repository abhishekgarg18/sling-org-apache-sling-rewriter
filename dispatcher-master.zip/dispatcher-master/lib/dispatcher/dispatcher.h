/*
 * Copyright (c) 1999 Day Management AG
 * Barfuesserplatz 6, 4001 Basel, Switzerland
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Day Management AG, ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Day.
 */
#ifndef __DISPATCHER_H__
#define __DISPATCHER_H__

/**
 * @file dispatcher.h
 * @brief Dispatcher
 */

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @defgroup dispatcher Dispatcher
 * @{
 */


/**
 * @defgroup HTTP_Status HTTP Status Codes
 * @{
 */
#ifndef HTTP_OK

/* A response was generated */
#define OK                                 0

/* We declined to handle */
#define DECLINED                           (-1)

#define HTTP_CONTINUE                      100
#define HTTP_SWITCHING_PROTOCOLS           101
#define HTTP_PROCESSING                    102
#define HTTP_OK                            200
#define HTTP_CREATED                       201
#define HTTP_ACCEPTED                      202
#define HTTP_NON_AUTHORITATIVE             203
#define HTTP_NO_CONTENT                    204
#define HTTP_RESET_CONTENT                 205
#define HTTP_PARTIAL_CONTENT               206
#define HTTP_MULTI_STATUS                  207
#define HTTP_MULTIPLE_CHOICES              300
#define HTTP_MOVED_PERMANENTLY             301
#define HTTP_MOVED_TEMPORARILY             302
#define HTTP_SEE_OTHER                     303
#define HTTP_NOT_MODIFIED                  304
#define HTTP_USE_PROXY                     305
#define HTTP_TEMPORARY_REDIRECT            307
#define HTTP_BAD_REQUEST                   400
#define HTTP_UNAUTHORIZED                  401
#define HTTP_PAYMENT_REQUIRED              402
#define HTTP_FORBIDDEN                     403
#define HTTP_NOT_FOUND                     404
#define HTTP_METHOD_NOT_ALLOWED            405
#define HTTP_NOT_ACCEPTABLE                406
#define HTTP_PROXY_AUTHENTICATION_REQUIRED 407
#define HTTP_REQUEST_TIME_OUT              408
#define HTTP_CONFLICT                      409
#define HTTP_GONE                          410
#define HTTP_LENGTH_REQUIRED               411
#define HTTP_PRECONDITION_FAILED           412
#define HTTP_REQUEST_ENTITY_TOO_LARGE      413
#define HTTP_REQUEST_URI_TOO_LARGE         414
#define HTTP_UNSUPPORTED_MEDIA_TYPE        415
#define HTTP_RANGE_NOT_SATISFIABLE         416
#define HTTP_EXPECTATION_FAILED            417
#define HTTP_UNPROCESSABLE_ENTITY          422
#define HTTP_LOCKED                        423
#define HTTP_FAILED_DEPENDENCY             424
#define HTTP_UPGRADE_REQUIRED              426
#define HTTP_INTERNAL_SERVER_ERROR         500
#define HTTP_NOT_IMPLEMENTED               501
#define HTTP_BAD_GATEWAY                   502
#define HTTP_SERVICE_UNAVAILABLE           503
#define HTTP_GATEWAY_TIME_OUT              504
#define HTTP_VERSION_NOT_SUPPORTED         505
#define HTTP_VARIANT_ALSO_VARIES           506
#define HTTP_INSUFFICIENT_STORAGE          507
#define HTTP_NOT_EXTENDED                  510

#endif /* HTTP_OK */

/** Status code eligible for a stale answer */
#define HTTP_STALE(sc) ((sc) == HTTP_BAD_GATEWAY || (sc) == HTTP_SERVICE_UNAVAILABLE || (sc) == HTTP_GATEWAY_TIME_OUT)

#define DEFAULT_KEEP_ALIVE_TIMEOUT_SEC     60

/** @} */

/** A structure defining a string list */
struct slist {
    /** string */
    char *s;
    /** next string in list */
    struct slist* next;
};

/** A structure holding client information */
struct client_info {
    /** protocol, e.g. HTTP/1.1 */
    const char *protocol;
    /** URI, possibly modified by modules that handled the request in
     * an earlier stage. */
    const char *uri;
    /** raw URI (including query string) or NULL, if that information is not available */
    const char *raw_uri;
    /** safe URI for logging */
    char safe_uri[4096];
    /** query string */
    const char *query;
    /** HTTP method, e.g. POST */
    const char *method;
    /** host header value */
    const char *host;
    /** IP of remote client */
    const char *client_ip;
    /** render ID */
    char id[64];
    /** via header */
    const char *via;
    /** server name */
    const char *server_name;
    /** server port */
    char server_port[20];

    /** cipher suite, e.g. "AES-256" */
    const char *cipher;
    /** SSL session ID */
    const char *session_id;
    /** key size, e.g. 256 */
    unsigned int keysize;

    /** flag indicating whether we support HTTP/1.1 */
    unsigned http11:1;
    /** flag indicating whether the incoming request was https */
    unsigned https:1;
    /** flag indicating whether this is a HEAD request */
    unsigned head:1;
    /** flag indicating whether to pass the original URL to the backend */
    unsigned no_canon_url:1;
};

/** A structure holding configuration */
struct dispatcher_config {
    /** first farm in chain */
    struct farm *farm;
    /** number of farms */
    unsigned farms;
    /** first domain globbing */
    struct domain_glob *domain;
};

/** A structure holding dispatcher data */
struct dispatcher {
    /** log context */
    struct log_context *lc;
    /** configuration */
    struct dispatcher_config *config;
    /** target farm */
    struct farm *farm;
    /** target backend */
    struct render *backend;
    /** request information. */
    struct client_info info;
    /** request time */
    long req_ms;

    /** cache file path */
    char cachepath[PATH_MAX];
    /** enum indicating what happens with the server's response */
    int action;
    /** enum explaining reason for cache action decision */
    int reason;
    /** the command to execute in the last matched ace, if a file is being cached */
    const char *qaexec;
    /** previous timestamp of temporarily touched file */
    time_t prev_time;
    /** timestamp of temporarily touched file */
    time_t touch_time;
    /** session */
    struct session *session;

    /** webserver-specific extra data */
    struct ws_extra *ws;
    /** mask of unavailable renders */
    int unavailable_mask;
    /** status code */
    int status;
    /** number of bytes read from client */
    unsigned long read;
    /** number of bytes written to client */
    unsigned long written;
    /** cached request body */
    void *req_body;
    /** request body length */
    unsigned long req_body_len;

    /** flag indicating whether reason should be returned as header */
    unsigned tell_reason:1;
    /** flag indicating whether request body is chunked */
    unsigned chunked:1;
    /** flag indicating whether a read error occurred */
    unsigned read_error:1;
    /** flag indicating whether we will deliver stale content */
    unsigned serve_stale:1;
    /** flag indicating whether we rejected a request */
    unsigned rejected:1;
    /** flag indicating this is a cache hit */
    unsigned hit:1;
    /** flag indicating this is a cache miss */
    unsigned miss:1;
};

/**
 * Number of requests so far.
 */
extern unsigned long req_total;

/**
 * Number of cache hits.
 */
extern unsigned long req_hits;

/**
 * Number of cache misses.
 */
extern unsigned long req_misses;

/**
 * @defgroup WS_Specific Webserver-specific methods
 * @{
 *
 * All methods prefixed ws_ have to be implemented
 * in the webserver-specific source file.
 */

/**
 * Retrieve information about client making request.
 *
 * @param d dispatcher
 * @param info client info structure to fill out
 */
void ws_get_client_info(struct dispatcher *d, struct client_info *info);

/**
 * Return a specfic request header.
 *
 * @param d dispatcher
 * @param name header name
 * @return header value or <code>NULL</code>
 */
const char *ws_get_header(struct dispatcher *d, const char *name);

/**
 * Adds all request headers that should be passed through to the remote
 * server.
 *
 * @param d dispatcher
 * @param names header names list or <code>NULL</code> to
 *              add all request headers that are end-to-end
 * @param headers array to populate
 */
void ws_get_pt_headers(struct dispatcher *d, struct slist *names, struct hdrarray *headers);

/**
 * Read bytes from the client.
 *
 * @param d dispatcher
 * @param p where to return data
 * @param n number of bytes
 * @param sc status code to return to client, may be <code>NULL</code>
 *
 * @return number of bytes actually read;
 *         <code>0</code> on EOF;
 *         <code>-1</code> if an error occurred
 */
int ws_net_read(struct dispatcher *d, void *p, size_t n, int *sc);

/**
 * Allows webserver to override the cache action.
 *
 * @param d dispatcher
 *
 * @return <code>0</code> if processing should continue;
 *         <code>-1</code> if web server overrode cache action
 */
int ws_get_cache_action(struct dispatcher *d);

/**
 * Deliver the file stored in <code>d->cachepath</code>
 *
 * @param d dispatcher
 */
void ws_deliver(struct dispatcher *d);

/**
 * Invoked when a forwarded request's response code has been processed.
 *
 * @param d dispatcher
 * @param status HTTP status code
 * @param sline HTTP status line
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
int ws_set_status(struct dispatcher *d, int status, const char *sline);

/**
 * Invoked when a forwarded request's response header has been processed
 *
 * @param d dispatcher
 * @param name header name
 * @param value header value
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 *
 * @note: name and value are only valid during the context of this call.
 */
int ws_set_header(struct dispatcher *d, const char *name, const char *value);

/**
 * Invoked when the last header has been set and the response body is about
 * to be sent.
 *
 * @param d dispatcher
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
int ws_start_response(struct dispatcher *d);

/**
 * Write some characters back to the client.
 *
 * @param d dispatcher
 * @param buffer character pointer
 * @param length number of characters to write
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
int ws_net_write(struct dispatcher *d, const char *buffer, size_t length);

/**
 * Flush all of the data for the current request to the client.
 *
 * @param d dispatcher
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
int ws_net_flush(struct dispatcher *d);

/**
 * Callback invoked to log the request.
 *
 * @param d dispatcher
 * @param method HTTP method
 * @param uri URI
 * @param query query or <code>NULL</code>
 * @param status proxy status
 * @param cache_info cache info
 * @param req_ms request time in milliseconds
 * @param farm_label farm label
 * @param backend_label render label
 */
void ws_log_request(struct dispatcher *d, const char *method, const char *uri,
                    const char *query, const char *status, const char *cache_info,
                    long req_ms, const char *farm_label, const char *backend_label);

/** @} */

/**
 * @defgroup Main_methods Main dispatcher entry points
 * @{
 */

/**
 * Initialize the dispatcher module with a configuration path.
 *
 * @param lc log context
 * @param config_file config file path
 * @param config dispatcher configuration
 * @param ws_desc web server description
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
int dispatcher_init(struct log_context *lc, const char *config_file,
                    struct dispatcher_config *config, const char *ws_desc);

/**
 * Initialize the dispatcher module with a parsed any structure.
 *
 * @param lc log context
 * @param root any structure
 * @param config_file config file path
 * @param ws_desc web server description
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
int dispatcher_init_config(struct log_context *lc, struct any_item *root,
                           struct dispatcher_config *config, const char *ws_desc);

/**
 * Main service method.
 *
 * @param d dispatcher
 *
 * @return <code>OK</code> if a response was generated;
 *         <code>DECLINED</code> if the request was declined;
 *         some HTTP status code otherwise
 */
int dispatcher_service(struct dispatcher *d);

/**
 * Terminate dispatcher, freeing all memory acquired in dispatcher_init.
 */
void dispatcher_terminate(struct dispatcher_config *config);

/** @} */

/**
 * @defgroup Utility_routines Utility routines
 * @{
 */

/**
 * Return an array of passthrough headers - name and value - that should be
 * forwarded to the remote server.
 *
 * @param d dispatcher
 *
 * @return headers or <code>NULL</code> if a failure occurs
 */
struct hdrarray *get_pt_headers(struct dispatcher *d);

/**
 * Return a flag indicating whether a request header is a hop-by-hop header
 * (see HTTP 1.1 spec 13.5.1).
 *
 * @param name header name
 * @return <code>1</code> if it is a hop-by-hop header;
 *         <code>0</code> otherwise
 */
int is_hop_by_hop_header(const char *name);

/**
 * Execute a command. All arguments are escaped with double quotes. If an argument
 * is <code>null</code>, it is replaced by an empty string.
 *
 * @param cmd command
 * @param argc number of arguments
 * @param argv arguments
 *
 * @return <code>0</code> if the command was successfully executed;
 *         otherwise a non-zero exit code
 */
int exec_command(struct log_context *lc, const char *cmd, int argc, const char *argv[]);

/** @} */

#ifdef WIN32

/**
 * Handle to the DLL instance: this is the base address of the DLL itself. This
 * must be known in order to load the module's version information.
 */
extern HINSTANCE g_hInstDll;

#endif /* WIN32 */

/** @} */

#ifdef __cplusplus
}
#endif

#endif /* __DISPATCHER_H__ */
