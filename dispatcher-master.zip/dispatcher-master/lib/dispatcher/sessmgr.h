/*
 * Copyright (c) 2004 Day Management AG
 * Barfuesserplatz 6, 4001 Basel, Switzerland
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Day Management AG, ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Day.
 */
#ifndef __SESSMGR_H__
#define __SESSMGR_H__

/**
 * @file sessmgr.h
 * @brief Session management
 */

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * @defgroup session Session management
 * @{
 */

/**
 * Initialize session manager.
 *
 * @param config configuration section of session manager
 *
 * @return pointer to session manager if initialization successful;
 *         otherwise 0.
 */
struct session_mgr *sessmgr_create(struct log_context *lc, struct any_item *config);

/**
 * Return the session found in the client headers.
 *
 * @param mgr session manager
 * @param d dispatcher
 *
 * @return session found in the client headers; 0 if no client id
 *         information is present
 */
struct session *sessmgr_get_session(struct session_mgr *mgr, struct dispatcher *d);

/**
 * Free memory associated with a session manager.
 *
 * @param mgr session manager, may be <code>NULL</code>
 */
void sessmgr_free(struct session_mgr *mgr);

/** @} */

#ifdef __cplusplus
}
#endif

#endif  /* __SESSMGR_H__ */
