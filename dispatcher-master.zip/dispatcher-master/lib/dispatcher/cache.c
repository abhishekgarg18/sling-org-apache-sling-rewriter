/*
 * Copyright (c) 2010 Day Management AG
 * Barfuesserplatz 6, 4001 Basel, Switzerland
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Day Management AG, ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Day.
 */
#include "base/base.h"

#include "dispatcher.h"
#include "farm.h"
#include "cache.h"
#include "cache_acl.h"
#include "cache_expiry.h"
#include "cache_headers.h"
#include "authchk.h"
#include "poller.h"
#include "sessmgr.h"
#include "session.h"

/**
 * Name of stat files inside document root
 */
static const char *_stat_file_name = ".stat";

/**
 * Cache action literals.
 */
static const char *_cache_actions[] = {
    "NONE",
    "CREATE",
    "DELIVER",
    "PURGE"
};

/**
 * Cache action literals, used in combination with reasons.
 */
static const char *_cache_actions2[] = {
    "none",
    "miss",
    "hit",
    "purge"
};

/**
 * Cache action reason literals.
 */
static const char *_ca_reasons[] = {
    NULL,
    "no document root",
    "cache file path too long",
    "temporary file path too long",
    "request URL has no extension",
    "request method is neither GET nor HEAD",
    "request contains a query string",
    "session manager authorization failed",
    "request contains authorization",
    "target is a directory",
    "request URL has trailing slash",
    "request URL not in cache rules",
    "stat file is more recent",
    "TTL expired",
    "authorization checker denied access",
    "session not valid",
    "response contains no_cache",
    "response content length is zero",
    "response status is not 200",
    "request is rejected by filter"
};

/**
 * Checks whether a URI is canonical, i.e. whether
 * it is absolute and contains no '.' or '..'.
 *
 * @param uri URI to test
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
static int canonical(const char *uri)
{
    const char *start, *end;
    size_t len;

    start = uri;
    if (*start++ != '/') {
        return -1;
    }

    for (;;) {
        if ((end = strchr(start, '/')) == NULL) {
            len = strlen(start);
        } else {
            len = end - start;
        }
        if (len == 1 && !strncmp(".", start, len)) {
            return -1;
        }
        if (len == 2 && !strncmp("..", start, len)) {
            return -1;
        }
        if (end == NULL) {
            return 0;
        }
        start = end + 1;
    }
}

#ifdef WIN32

/**
 * Trim a path name, removing any trailing dots or spaces, since they will lead
 * to illegal path names that can not be deleted easily.
 *
 * @param file pathname
 */
static void trim_filepath(char *path)
{
    char *f, *s, *p, *q;

    /*
     * Canonicalize cache path, removing any trailing dots
     * or spaces, since they will lead to illegal path names
     * that can not be deleted easily. (see bug #8667)
     */
    f = path;

    /*
     * Remove any trailing '.'. Also, blow away any
     * directories with 3 or more '.'
     */
    for (p = f, s = f; *s; s++, p++) {
        if (*s == FILE_SEPARATOR_CHAR) {
            q = p;
            while (p > f && *(p - 1) == '.')
                p--;
            if (p == f && q - p <= 2 && *p == '.')
                p = q;
            else if (p > f && p < q && *(p - 1) == FILE_SEPARATOR_CHAR) {
                if (q - p > 2)
                    p--;
                else
                    p = q;
            }
        }
        *p = *s;
    }
    *p = '\0';

    /*
     * Blow away any final trailing '.' since on Win32
     * foo.bat == foo.bat. == foo.bat... etc.
     * Also blow away any trailing spaces since
     * "filename" == "filename "
     */
    q = p;
    while (p > f && (*(p - 1) == '.' || *(p - 1) == ' '))
        p--;
    if ((p > f) || (p == f && q - p > 2))
        *p = '\0';
}
#endif /* WIN32 */

/**
 * Maps a URI to a file. The returned file will never have a trailing file separator
 * character, so mapping '/' will return the document root itself.
 *
 * @param docroot document root
 * @param uri URI
 * @param file buffer capable of storing at least <code>PATH_MAX</code> characters
 * @param strip_ext flag indicating whether to strip an extension in <code>uri</code>
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure, i.e. the mapped file exceeds <code>file_len</code>
 */
static int map_uri_to_file(const char *docroot, const char *uri, char *file, int strip_ext)
{
    const char *path_sep, *ext, *in;
    char ch, lastch = 0, *out, mapped[PATH_MAX];
    size_t i, uri_len = 0;

    if (*uri != '/') {
        /* URI is not canonical */
        errno = EINVAL;
        return -1;
    }
    if (strip_ext) {
        /* Strip any extension in the last path segment */
        if ((path_sep = strrchr(uri, '/')) == NULL) {
            path_sep = uri;
        }
        if ((ext = strchr(path_sep, '.')) != NULL) {
            uri_len = ext - uri;
        }
    }
    if (!uri_len) {
        uri_len = strlen(uri);
    }
    if (uri_len >= sizeof mapped - 1) {
        /* URI itself is too long */
        errno = ENAMETOOLONG;
        return -1;
    }
    in = uri; out = mapped;
    for (i = 0; i < uri_len; i++) {
        if ((ch = *in++) == '/') {
            if (lastch == FILE_SEPARATOR_CHAR) {
                /* Do not copy consecutive file separators */
                continue;
            }
            ch = FILE_SEPARATOR_CHAR;
        }
        *out++ = lastch = ch;
    }
    *out = 0;

    /* Remove trailing file separators */
    out = mapped + strlen(mapped) - 1;
    while (out >= mapped && *out == FILE_SEPARATOR_CHAR) {
        *out-- = 0;
    }

    if (snprintf(file, PATH_MAX, "%s%s", docroot, mapped) >= PATH_MAX) {
        /* Combined path is too long */
        errno = ENAMETOOLONG;
        return -1;
    }
#ifdef WIN32
    /* Remove trailing spaces and dots */
    trim_filepath(file + strlen(docroot));
#endif
    return 0;
}

/**
 * Delete a file in the cache, given its pathname. On Windows, we can not simply delete the
 * file as it might still be accessed by the web server.
 *
 * @param path path name
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
static int delete_file(struct log_context *lc, const char *path)
{
#ifdef WIN32
    /*
     Removing a directory entry to a file that is currently being
     accessed will fail on Windows. We therefore rename
     the file first and then delete it. This will postpone the
     actual directory entry removal to the moment when the last
     handle to the file is closed but with the renaming step
     we're sure the file is not opened again.
     */

    struct stat stat;
    char tmp_path[PATH_MAX];
    const char *sep, *generated;
    size_t len;

    /* Check the file actually exists */
    if (stat(path, &stat) < 0) {
        return -1;
    }

    /* Create a new unique name for this file */
    if ((sep = strrchr(path, FILE_SEPARATOR_CHAR)) == NULL) {
        WARN("Unable to determine parent directory of %s", path);
        return -1;
    }
    len = (size_t) (sep - path) + 1;

    /* Verify path with a generated old.XXXXXX file will not be too long */
    if (len >= PATH_MAX - 10 - 1) {
        WARN("Unable to generate temporary name for %s: " \
                  "parent path's length exceeds %d", path, PATH_MAX - 10 - 1);
        return -1;
    }
    strncpy(tmp_path, path, len);
    strcpy(tmp_path + len, "old.XXXXXX");

    if ((generated = mktemp(tmp_path)) == NULL) {
        WARN("Unable to generate temporary name for %s: %s", tmp_path, strerror(errno));
        return -1;
    }
    if (rename(path, generated)) {
        WARN("Unable to rename %s to %s: %s", path, generated, strerror(errno));
        generated = path;
    }
    if (remove(generated)) {
        WARN("Unable to delete file %s: %s", generated, strerror(errno));
        return -1;
    }
    return 0;
#else
    /* This is straightforward */
    return remove(path);
#endif
}

/**
 * Deletes a file or directory.
 *
 * @param path path to file or directory
 * @param timeline optional, if non-zero, more recent files are not deleted
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
static int delete_file_or_directory(struct log_context *lc, const char *path, time_t timeline)
{
    struct stat st;
    DIR *dir;
    struct dirent *e;
    int empty = 1, symlink = 0;
    char *path_end, resolved[PATH_MAX];

    if (lstat(path, &st)) {
        return 0;
    }
    if (S_ISLNK(st.st_mode)) {
        symlink = 1;

        if (stat(path, &st)) {
            DBG("Unable to stat destination of %s: %s", path, strerror(errno));
            return -1;
        }
    }
    if (S_ISDIR(st.st_mode)) {
        if (realpath(path, resolved) == NULL) {
            WARNE("Unable to obtain real path of %s: %s", path, strerror(errno));
            return -1;
        }
        if (strcmp(path, resolved) != 0 && !strncmp(path, resolved, strlen(resolved))) {
            DBG("Loop detected in %s: target path is ancestor: %s", path, resolved);
            return -1;
        }
        if (symlink) {
            TRACE("Following symbolic link %s -> %s", path, resolved);
        }
        if ((dir = opendir(resolved)) == NULL) {
            WARNE("Unable to get directory contents of %s: %s", resolved, strerror(errno));
            return -1;
        }
        path_end = resolved + strlen(resolved);
        while ((e = readdir(dir)) != NULL) {
            if (!strcmp(e->d_name, ".") || !strcmp(e->d_name, "..")) {
                continue;
            }
            *path_end = FILE_SEPARATOR_CHAR;
            strcpy(path_end + 1, e->d_name);
            if (delete_file_or_directory(lc, resolved, timeline)) {
                empty = 0;
            }
        }
        closedir(dir);
    }
    if (!empty) {
        DBG("Skipped %s: not empty", path);
    } else if (symlink) {
        DBG("Skipped %s: is a symbolic link", path);
    } else if (timeline && st.st_mtime >= timeline) {
        DBG("Skipped %s: newer than timeline", path);
    } else if (!delete_file(lc, path)) {
        INFO("Evicted %s", path);
        return 0;
    }
    return -1;
}

/**
 * Deletes the contents of a directory.
 *
 * @param path path to directory. This should have at least space
 *             for PATH_MAX characters and will be changed on subsequent
 *             recursive invocations.
 * @param timeline optional, if non-zero, more recent files are not deleted
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
static int delete_contents(struct log_context *lc, char *path, time_t timeline)
{
    struct stat st;
    DIR *dir;
    struct dirent *e;
    char *path_end;

    if (stat(path, &st) || !S_ISDIR(st.st_mode)) {
        return 0;
    }
    if ((dir = opendir(path)) == NULL) {
        WARNE("Unable to get directory contents of %s: %s", path, strerror(errno));
        return -1;
    }
    path_end = path + strlen(path);
    while ((e = readdir(dir)) != NULL) {
        if (!strcmp(e->d_name, ".") || !strcmp(e->d_name, "..")) {
            continue;
        }
        *path_end = FILE_SEPARATOR_CHAR;
        strcpy(path_end + 1, e->d_name);
        delete_file_or_directory(lc, path, timeline);
        *path_end = '\0';
    }
    closedir(dir);
    return 0;
}

/**
 * Delete all files and directories that have the same basefilename as
 * a given pathname, that is <code>rm pathname.*</code>.
 *
 * @param pathname pathname
 * @param timeline optional, if non-zero, more recent files are not flush
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
static int flush_basefiles(struct log_context *lc, const char *pathname, time_t timeline)
{
    char directory[PATH_MAX], path[PATH_MAX];
    const char *filename;
    DIR *dir;
    struct dirent *e;
    size_t filename_len;

    if (dirname2(pathname, directory)) {
        ERR("Unable to get directory name of %s.", pathname);
        return -1;
    }
    if ((filename = strrchr(pathname, FILE_SEPARATOR_CHAR)) != NULL) {
        filename++;
    } else {
        filename = pathname;
    }
    filename_len = strlen(filename);

    /* Delete all files inside this directory that have the same basefilename */
    if ((dir = opendir(directory)) != NULL) {
        while ((e = readdir(dir)) != NULL) {
            if (!strcmp(e->d_name, ".") || !strcmp(e->d_name, "..")) {
                continue;
            }
            if (!strncmp(e->d_name, filename, filename_len) && e->d_name[filename_len] == '.') {
                if (snprintf(path, sizeof path, "%s%c%s",
                        directory, FILE_SEPARATOR_CHAR, e->d_name) >= (int) sizeof path) {
                    WARN("Unable to flush %s: pathname too big.", e->d_name);
                } else {
                    delete_file_or_directory(lc, path, timeline);
                }
            }
        }
        closedir(dir);
    }
    /* Remove an eventual _jcr_content subdirectory */
    if (snprintf(path, sizeof path, "%s%c_jcr_content", pathname, FILE_SEPARATOR_CHAR) >= (int) sizeof path) {
        WARN("Unable to flush _jcr_content: pathname too big.");
    } else {
        delete_file_or_directory(lc, path, timeline);
    }

    /* If not on Windows, remove jcr:content as well */
#ifndef WIN32
    if (snprintf(path, sizeof path, "%s%cjcr:content", pathname, FILE_SEPARATOR_CHAR) >= (int) sizeof path) {
        WARN("Unable to flush jcr:content: pathname too big.");
    } else {
        delete_file_or_directory(lc, path, timeline);
    }
#endif

    return 0;
}

/**
 * Flush all files in the cache associated with a given URI.
 *
 * @param docroot document root
 * @param uri URI
 * @param action flush action
 * @param timeline optional, if non-zero, more recent files are not flush
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
static int flush_uri(struct log_context *lc, const char *docroot, const char *uri, enum flush_action action, time_t timeline)
{
    char pathname[PATH_MAX];
    unsigned is_docroot;

    /* Check prerequisites */
    if (canonical(uri)) {
        ERR("URI not canonical: %s.", uri);
        return -1;
    }
    if (map_uri_to_file(docroot, uri, pathname, action == ACTION_ACTIVATE)) {
        ERRE("Unable to map URI to file: %s", strerror(errno));
        return -1;
    }
    is_docroot = strcmp(docroot, pathname) == 0 ? 1 : 0;

    switch (action) {
    case ACTION_ACTIVATE:
        if (!is_docroot) {
            flush_basefiles(lc, pathname, timeline);
        }
        break;
    case ACTION_DEACTIVATE:
    case ACTION_DELETE:
        if (!is_docroot) {
            delete_file_or_directory(lc, pathname, timeline);
            flush_basefiles(lc, pathname, timeline);
        } else {
            delete_contents(lc, pathname, timeline);
        }
        break;
    default:
        return -1;
    }
    return 0;
}

/**
 * Touch a file.
 *
 * @param filename file name
 * @param createdir whether to create intermediate directories
 * @param mode permissions, as in chmod
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
static int touch_file(struct log_context *lc, const char *file, int createdir, int mode)
{
    char directory[PATH_MAX];
    struct stat buf;
    int fd;

    /* Determine directory and create if required */
    if (dirname2(file, directory)) {
        WARNE("Unable to extract directory part of %s: %s", file, strerror(errno));
        return -1;
    }
    if (createdir && mkdirs(directory, mode)) {
        WARNE("Unable to create parent directory of %s: %s", file, strerror(errno));
        return -1;
    }

    /* If directory does not exist or is not a directory, stop */
    if (stat(directory, &buf) || !S_ISDIR(buf.st_mode)) {
        return -1;
    }

    if (stat(file, &buf)) {
        if ((fd = open(file, O_CREAT, mode & 0666)) == -1) {
            WARNE("Unable to create file %s: %s", file, strerror(errno));
            return -1;
        }
        close(fd);
    } else if (utime(file, NULL)) {
        WARNE("Unable to touch file %s: %s", file, strerror(errno));
        return -1;
    }
    return 0;
}

/**
 * Touch a file associated with a URI.
 *
 * @param docroot document root
 * @param uri URI
 * @param mtime where to return new modification time of cache file, may be <code>NULL</code>
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
static int touch_mapped_file(struct log_context *lc, const char *docroot, const char *uri, time_t *mtime)
{
    char filename[PATH_MAX];
    struct stat st;

    /* Check prerequisites */
    if (canonical(uri)) {
        ERR("URI not canonical: %s.", uri);
        return -1;
    }
    if (map_uri_to_file(docroot, uri, filename, 0)) {
        ERRE("Unable to map URI to file: %s", strerror(errno));
        return -1;
    }
    if (stat(filename, &st)) {
        return -1;
    }
    if (utime(filename, NULL)) {
        WARNE("Unable to touch cache file %s: %s", filename, strerror(errno));
        return -1;
    } else {
        DBG("Touched %s", filename);
    }
    if (stat(filename, &st)) {
        WARNE("Unable to fetch stat for %s after touching: %s", filename, strerror(errno));
        return -1;
    }
    if (mtime) {
        *mtime = st.st_mtime;
    }
    return 0;
}

/**
 * Touch all stat files down a given URI to some level.
 *
 * @param docroot document root
 * @param uri URI
 * @param level level, must be non-negative
 * @param mode permissions, as in chmod
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
static int touch_level_stats(struct log_context *lc, const char *docroot, const char *uri, int level, int mode)
{
    char file[PATH_MAX], statfile[PATH_MAX];
    const char *p, *sep;
    int i, file_len;

    /* Check prerequisites */
    if (canonical(uri)) {
        ERR("URI not canonical: %s.", uri);
        return -1;
    }
    if (map_uri_to_file(docroot, uri, file, 0)) {
        ERRE("Unable to map URI to file: %s", strerror(errno));
        return -1;
    }

    /* Append a file separator if we're on the document root, to make below algorithm uniform */
    if (!strcmp(file, docroot)) {
        file_len = (int) strlen(file);
        if (file_len + 2 >= PATH_MAX) {
            ERR("Unable to map URI to file: %s", strerror(ENAMETOOLONG));
            return -1;
        }
        strcpy(file + file_len, FILE_SEPARATOR);
    }

    /* Start iteration on first file separator following document root */
    p = file + strlen(docroot) + 1;

    /* Descend into file */
    for (i = 0; i <= level; i++) {
        if (snprintf(statfile, sizeof statfile, "%.*s%s", (int) (p - file), file, ".stat") >= (int) sizeof statfile) {
            ERR("Unable to get statfile: target file length exceeds %ld.", sizeof statfile);
            return -1;
        }
        if (touch_file(lc, statfile, 0, mode)) {
            return -1;
        }
        INFO("Touched %s", statfile);
        if ((sep = strchr(p, FILE_SEPARATOR_CHAR)) == NULL) {
            break;
        }
        p = sep + 1;
    }
    return 0;
}

/**
 * Touch the cache stat file or files that are associated with a certain
 * uri. If a statfileslevel has been specified, this may result in
 * multiple stat files that must be touched.
 *
 * @param farm respective farm
 * @param uri uri
 * @param mode permissions, as in chmod
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
static int touch_stats(struct log_context *lc, struct cache *cache, const char *uri)
{
    int ret, level;

    /* Check prerequisites */
    if ((level = cache->statLevel) == -1) {
        if ((ret = touch_file(lc, cache->statfile, 1, cache->mode)) == 0) {
            INFO("Touched %s", cache->statfile);
        }
        return ret;
    }
    return touch_level_stats(lc, cache->docroot, uri, level, cache->mode);
}

/**
 * Move a temporary file to its final location.
 *
 * @param src source pathname
 * @param dest destination pathname
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
static int move_file(struct log_context *lc, const char *src, const char *dest)
{
#ifdef WIN32
    /* On Windows, we try it several times */
#define MAX_TRIES 5
#else
#define MAX_TRIES 1
#endif

    int tries, last_errno;
    struct stat st;

    for (tries = 0; tries < MAX_TRIES; tries++) {
        if (!rename(src, dest)) {
            return 0;
        }
        last_errno = errno;

        /* Failed to rename the file: this is most probably caused by the
           target already created by some other thread */
        if (!stat(dest, &st)) {
            /* File already exists */
            break;
        }

        /* File couldn't be renamed, even though target does not exist */
        WARN("Unable to rename generated cache file %s to %s: %s",
                src, dest, strerror(last_errno));

#ifdef WIN32
        /* Wait some time before retrying */
        Sleep(100);
#endif
    }

    if (!stat(src, &st) && remove(src)) {
        ERRE("Unable to remove temporary file %s: %s", src, strerror(errno));
        return -1;
    }
    return 0;
}

/**
 * Refetch a file from a backend, with optional headers.
 *
 * @param lc log context
 * @param farm associated farm
 * @param uri URI
 * @param query query string (or <code>NULL</code>)
 * @param headers headers to send along when refetching, may be <code>NULL</code>
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
static int refetch_file(struct log_context *lc, struct farm *farm, const char *uri,
                        const char *query, struct hdrarray *headers)
{
    const char *sline, *name, *value, *line, *qaexec = NULL;
    char file[PATH_MAX], encoded_url[4096];
    struct endpoint ep;
    struct http_client *hc;
    int ret, status, i, size;
    struct cache *cache = farm->cache;

    urlenc_ex(encoded_url, sizeof encoded_url, uri, NULL);

    /* Check prerequisites */
    if (canonical(uri)) {
        ERR("URI not canonical: %s.", encoded_url);
        return -1;
    }
    if (!cache_acl_allowed(lc, cache->rules_acl, uri, &qaexec)) {
        ERR("URI not in cache rules: %s", encoded_url);
        return -1;
    }
    if (map_uri_to_file(cache->docroot, uri, file, 0)) {
        ERRE("Unable to map URI to file: %s", strerror(errno));
        return -1;
    }

    /* Connect to some backend */
    memset(&ep, 0, sizeof ep);
    ep.file  = encoded_url;
    ep.query = query;

    if ((hc = farm_connect(lc, farm, &ep, NULL, NULL, NULL, NULL)) == NULL) {
        ERR("No backend available.");
        return -1;
    }

    /* Add all headers but content length and expect */
    if (headers) {
        size = hdrarray_size(headers);
        for (i = 0; i < size; i++) {
            hdrarray_at(headers, i, &name, &value);
            if (!strcasecmp("content-length", name)) {
                continue;
            }
            http_client_add_header(hc, name, value);
        }
    }
    http_client_add_header(hc, "Server-Agent", "Communique-Dispatcher");

    /* Check response status */
    if ((status = http_client_get_status(hc, &sline)) != HTTP_OK) {
        switch (status) {
        case HC_ESEND:
            WARN("Unable to send request to remote server.");
            break;
        case HC_ERECV:
            WARN("Unable to receive response from remote server.");
            break;
        default:
            WARN("Remote server returned: %s", sline);
            break;
        }
        http_client_free(hc);
        return -1;
    }

    /* Check whether response contains cache control */
    if (cache_control_denies(hc, &line)) {
        WARN("Backend forbids caching: %s, sent: %s", uri, line);
        http_client_free(hc);
        return -1;
    }

    /* Write file */
    ret = cache_write_file(lc, cache, hc, file, qaexec, NULL);
    http_client_free(hc);

    return ret;
}

/**
 * Delete the file associated with a URI.
 *
 * @param docroot document root
 * @param uri URI
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
static int delete_mapped_file(struct log_context *lc, const char *docroot, const char *uri)
{
    char file[PATH_MAX];
    struct stat buf;

    if (canonical(uri)) {
        ERR("URI not canonical: %s.", uri);
        return -1;
    }
    if (map_uri_to_file(docroot, uri, file, 0)) {
        ERRE("Unable to map URI to file: %s", strerror(errno));
        return -1;
    }
    if (stat(file, &buf)) {
        return 0;
    }
    return delete_file(lc, file);
}

/**
 * Return the cache path for some URI.
 *
 * @param cache cache settings, may be <code>NULL</code>
 * @param uri URI
 * @param safe_uri URI that is safe for logging
 * @param file where to return file, must be at least
 *             <code>PATH_MAX</code> big
 *
 * @return <code>CA_REASON_NONE (0)</code> if the document can be cached;
 *         some other CA_REASON_XXX otherwise
 */
static int get_cache_path(struct log_context *lc, struct cache *cache,
                          const char *uri, const char *safe_uri, char *file)
{
    char relative_path[PATH_MAX], tmppath[PATH_MAX];
    size_t pathlen, urilen;

    if (cache == NULL) {
        return CA_REASON_NO_DOCUMENT_ROOT;
    }

    urilen = strlen(uri);

    pathlen = strlen(cache->docroot);
    pathlen += urilen;
    if (pathlen + 1 > PATH_MAX) {
        WARN("Unable to cache file, file path too long: %s", safe_uri);
        return CA_REASON_FILE_PATH_TOO_LONG;
    }

    strcpy(relative_path, uri);
    relative_path[urilen] = '\0';
    NORMALIZE_FILENAME(relative_path);

    snprintf(file, PATH_MAX, "%s%s", cache->docroot, relative_path);

#ifdef WIN32
        {
            /*
             * Canonicalize cache path, removing any trailing dots
             * or spaces, since they will lead to illegal path names
             * that can not be deleted easily. (see bug #8667)
             */
            char *f = &file[strlen(cache->docroot)];
            char *s;
            char *p;
            char *q;

            /*
             * Remove any trailing '.'. Also, blow away any
             * directories with 3 or more '.'
             */
            for (p = f, s = f; *s; s++, p++) {
                if (*s == FILE_SEPARATOR_CHAR) {
                    q = p;
                    while (p> f && *(p - 1) == '.')
                        p--;
                    if (p == f && q - p <= 2 && *p == '.')
                        p = q;
                    else if (p> f && p < q && *(p - 1) == FILE_SEPARATOR_CHAR) {
                        if (q - p> 2)
                        p--;
                        else
                        p = q;
                    }
                }
                *p = *s;
            }
            *p = '\0';

            /*
             * Blow away any final trailing '.' since on Win32
             * foo.bat == foo.bat. == foo.bat... etc.
             * Also blow away any trailing spaces since
             * "filename" == "filename "
             */
            q = p;
            while (p> f && (*(p - 1) == '.' || *(p - 1) == ' '))
                p--;
            if ((p> f) || (p == f && q - p> 2))
                *p = '\0';

            pathlen = strlen(file);
        }
#endif /* WIN32 */

    /* check length */
    if (create_temp_file(lc, file, tmppath, NULL, cache->mode)) {
        return CA_REASON_TEMP_FILE_PATH_TOO_LONG;
    }
    return 0;
}

static enum flush_action parse_flush_action(const char *action)
{
    switch (*action++) {
    case 'A':
    case 'a':
        return !strcasecmp(action, "ctivate") ? ACTION_ACTIVATE : ACTION_NONE;
    case 'D':
    case 'd':
        if (!strcasecmp(action, "eactivate")) {
            return ACTION_DEACTIVATE;
        } else if (!strcasecmp(action, "elete")) {
            return ACTION_DELETE;
        }
        return ACTION_NONE;
    case 'T':
    case 't':
        return !strcasecmp(action, "est") ? ACTION_TEST : ACTION_NONE;
    default:
        return ACTION_NONE;
    }
}

static enum action_scope parse_action_scope(const char *scope)
{
    switch (*scope++) {
    case 'R':
    case 'r':
        return !strcasecmp(scope, "esourceOnly") ? SCOPE_RESOURCE_ONLY : SCOPE_NONE;
    default:
        return SCOPE_NONE;
    }
}

static int parse_flush_request(struct log_context *lc, const char *shandle, const char *saction,
                               const char *sscope, char **uri,
                               enum flush_action *action, enum action_scope *scope)
{
    char *s;

    /* if no action was specified, we assume this is an activation */
    *action = saction != NULL ? parse_flush_action(saction) : ACTION_ACTIVATE;
    if (*action == ACTION_NONE) {
        WARN("Unknown action: %s, flush ignored", saction);
        return -1;
    }

    /* if no scope was specified, we assume this is standard scope */
    *scope = sscope != NULL ? parse_action_scope(sscope) : SCOPE_ALL;
    if (*scope == SCOPE_NONE) {
        WARN("Unknown scope: %s, flush ignored", sscope);
        return -1;
    }

    s = strdup(shandle);
    if (url_unescape(s)) {
        WARN("Unable to unescape URL: bad escape or escaped slash in \"%s\"", shandle);
        free(s);
        return -1;
    }

    *uri = s;
    return 0;
}

static int read_from_ws(void *context, void *p, size_t len)
{
    return ws_net_read((struct dispatcher *) context, p, len, NULL);
}

/**
 * Read URIs from request body.
 *
 * @param d dispatcher
 *
 * @return first element in list of strings
 */
static struct ptrarray *read_uris(struct dispatcher *d)
{
    struct ptrarray *uris = NULL;
    struct in_buffer *b;
    const char *ctype;
    char line[2048];

    if (strcasecmp(d->info.method, "post")) {
        /* Not a POST */
        return NULL;
    }
    ctype = ws_get_header(d, "content-type");
    if (ctype == NULL || strcasecmp(ctype, "text/plain")) {
        /* Not a content type known to carry a list of URIs in its body */
        return NULL;
    }
    if (create_in_buffer(&b, sizeof line, read_from_ws, d)) {
        return NULL;
    }
    while (buffer_readline(b, line, sizeof line) > 0) {
        if (*line != '/') {
            /* Skip non-canonical URLs */
            continue;
        }
        if (!uris && create_ptrarray(&uris, 100, free)) {
            return NULL;
        }
        ptrarray_add(uris, strdup(line));
    }
    in_buffer_close(b);
    return uris;
}

/**
 * Return a flag indicating whether the current request contains any
 * authorization information.
 *
 * @param d dispatcher
 * @return <code>1</code> if the request contains authorization;
 *         <code>0</code> otherwise
 */
static int contains_authorization(struct dispatcher *d)
{
    const char *value;

    /* 1. Check authorization request header */
    if (ws_get_header(d, "authorization") != NULL) {
        return 1;
    }

    /* 2. Check authorization cookie */
    value = ws_get_header(d, "cookie");
    if (value != NULL) {
        if (strstr(value, "authorization=") != NULL ||
                strstr(value, "login-token=") != NULL) {
            return 1;
        }
    }
    return 0;
}

/**
 * Return the cache stat file that is associated with a certain uri.
 * If a statfileslevel has been specified, this is the nearest statfile
 * available in the hierarchy. Otherwise, the configured statfile will
 * be returned.
 *
 * @param cache cache settings
 * @param uri uri
 * @param statfile stat file name, at least PATH_MAX characters
 *
 * @return <code>0</code> to indicate success; <code>1</code> otherwise
 */
static int get_stat_file(struct cache *cache, const char *uri, char *statfile)
{
    int level;
    size_t available, chunklen;
    const char *current, *next, *end;
    char directory[PATH_MAX];

    /* if a simple stat file was specified, return that */
    if (cache->statLevel == -1) {
        strcpy(statfile, cache->statfile);
        return 0;
    }

    available = sizeof(directory) - strlen(cache->docroot) - 1 -
            strlen(_stat_file_name) - 1;
    level = 0;
    current = uri;
    end = current + strlen(current);

    if (*current == '/') {
        current++;
    }
    directory[0] = '\0';

    /* walk down the URI until we are on the correct level */
    while (level < cache->statLevel && current < end) {
        next = strchr(current, '/');
        if (!next) {
            break;
        }
        chunklen = next - current;
        if (chunklen == 0) {
            current = next + 1;
            continue;
        }
        if (chunklen > available) {
            break;
        }

        strcat(directory, FILE_SEPARATOR);
        strncat(directory, current, chunklen);
        available -= chunklen;

        current = next + 1;
        level++;
    }

    snprintf(statfile, PATH_MAX, "%s%s%c%s", cache->docroot,
            directory, FILE_SEPARATOR_CHAR, _stat_file_name);
    return 0;
}

/**
 * Return a flag indicating whether a given query should be ignored based on
 * the farm's configuration.
 *
 * @param params_acl ignored URL params ACL, may be <code>NULL</code>
 * @param query query string
 *
 * @return <code>1</code> if the query can be ignored;
 *         <code>0</code> otherwise
 */
static int ignore_query(struct log_context *lc, struct acl * params_acl, const char *query)
{
    char *queryc, *start, *qsep, *nvsep, *end;

    if (params_acl == NULL) {
        return 0;
    }
    if ((queryc = strdup(query)) == NULL) {
        return 0;
    }
    start = queryc;
    end = start + strlen(start);

    while (start < end) {
        if ((qsep = strchr(start, '&')) == NULL) {
            qsep = end;
        }
        *qsep = 0;

        if ((nvsep = strchr(start, '=')) == NULL) {
            nvsep = qsep;
        }
        *nvsep = 0;

        /* TODO check parameter name for escapes (e.g. %xx and +) */
        if (!acl_allowed(lc, params_acl, start)) {
            DBG("Name not in ignored URL parameters ACL: %s", start);
            free(queryc);
            return 0;
        }
        start = qsep + 1;
    }
    DBG("Query string ignored: %s", query);
    free(queryc);
    return 1;
}

/**
 * Handles a potential flush request. If the request contains a flush request,
 * the respective cache file is flushed.
 *
 * @param d dispatcher
 * @return <code>0</code> if the request still needs to be handled;
 *         some HTTP status code otherwise
 */
static int process_flush_request(struct dispatcher *d)
{
    struct log_context *lc = d->lc;
    struct ptrarray *uris;
    struct farm *farm = d->farm;
    struct cache *cache = farm->cache;
    struct client_info *info = &d->info;
    const char *shandle, *saction, *sscope;
    char *uri;
    struct hdrarray *pt_headers;
    enum flush_action action;
    enum action_scope scope;

    DBG("checking [%s]", d->info.safe_uri);

    if ((shandle = ws_get_header(d, "cq-handle")) == NULL) {
        shandle = ws_get_header(d, "handle");
    }
    if ((saction = ws_get_header(d, "cq-action")) == NULL) {
        saction = ws_get_header(d, "action");
    }
    sscope = ws_get_header(d, "cq-action-scope");

    if (shandle == NULL && saction == NULL) {
        /* neither handle nor action available */
        return 0;
    }

    /* check for client filter */
    if (info->client_ip && acl_denied(cache->flush_clients_acl, info->client_ip)) {
        WARN("Flushing rejected from %s", info->client_ip);
        return HTTP_FORBIDDEN;
    }

    /* if no handle was specified, use requested URI itself */
    if (!shandle) {
        shandle = info->uri;
    }

    if (parse_flush_request(lc, shandle, saction, sscope, &uri, &action, &scope)) {
        return HTTP_BAD_REQUEST;
    }

    INFO("Activation detected: action=%s [%s]", saction ? saction : "<nothing>", uri);

    /* read URIs from the request body and flush, unless action is test */
    uris = read_uris(d);
    if (action != ACTION_TEST) {
        if ((pt_headers = get_pt_headers(d)) == NULL) {
            WARN("Unable to retrieve headers of flush request");
        }
        if (cache->invalidate_handler) {
            const char* argv[] = { shandle, saction, sscope };
            int ret;

            ret = exec_command(lc, cache->invalidate_handler, 3, argv);
            if (ret) {
                WARN("Invalidate script exited with status %d.", ret);
            }
        }
        cache_flush(lc, farm, uri, action, scope, (const char **) ptrarray_get(uris), pt_headers);
        hdrarray_free(pt_headers);
    }
    ptrarray_free(uris);
    free(uri);

    /* propagate request to other modules and/or remote server, if flag is set */
    if (farm->propSyndPost) {
        return 0;
    }

    /* respond ok and quit */
    ws_set_status(d, HTTP_OK, "HTTP/1.1 200 OK");
    ws_set_header(d, "Server", "Communique/2.6.3 (build 5221)");
    ws_set_header(d, "Content-Type", "text/html");
    ws_start_response(d);

    /* IIS does not send response headers as long as we don't supply a body */
    ws_net_write(d, "\r\n<H1>OK</H1>", 13);

    DBG("cache flushed");
    d->action = CACHE_ACTION_PURGED;

    return HTTP_OK;
}

/**
 * Return a flag indicating whether some cache file is stale.
 *
 * @param d dispatcher
 * @param cache cache
 * @param uri requested URI
 * @param st stat for cache file
 *
 * @return <code>1</code> if it is stale;
 *         <code>0</code> otherwise
 */
static unsigned is_stale(struct dispatcher *d, struct cache *cache, const char *uri, struct stat *st)
{
    struct log_context *lc = d->lc;
    struct stat lastflush;
    char statfile[PATH_MAX];
    int expired;
    time_t expiry;
    int isNotExpired = 0;
    if (cache->ttl_enabled) {
        expired = cache_expiry_is_expired(d->cachepath, &expiry);
        if (expired >= 0) {
            DBG("cache file has %s: %s", expired ? "expired" : "not expired", d->cachepath);
            if (expired) {
                d->reason = CA_REASON_TTL_EXPIRED;
                if (!d->info.head) {
                    /* temporarily touch expiry file so that concurrent requests will be served
                     * with stale cache file while it is being flushed
                     */
                    d->prev_time = expiry;
                    if (!cache_expiry_set(lc, d->cachepath, time(NULL) + 5)) {
                        d->touch_time = st->st_mtime;
                    }
                }
                return (unsigned) expired;
            } 
            isNotExpired = 1;
        }
    }
    if (acl_allowed(lc, cache->invalidate_acl, uri)) {
        get_stat_file(cache, uri, statfile);
        if (!stat(statfile, &lastflush)) {
            if (lastflush.st_mtime > st->st_mtime) {
                /* Stat file was modified AFTER cache file was created */
                if (cache->grace_period) {
                    long time_in_secs = (long) (gettimemillis() / 1000);
                    if (time_in_secs - lastflush.st_mtime <= cache->grace_period) {
                        DBG("Last activation occurred less than %d seconds ago, keeping cache file [%s].",
                            cache->grace_period, d->cachepath);
                        return 0;
                    }
                }
                d->reason = CA_REASON_STAT_FILE_NEWER;

                if (!d->info.head) {
                    /* temporarily touch cache file so that requests will be served
                     * with current (outdated) cache file while it is being flushed
                     */
                    d->prev_time = st->st_mtime;
                    utime(d->cachepath, 0);
                    if (!stat(d->cachepath, &lastflush)) {
                        d->touch_time = lastflush.st_mtime;
                    }
                }
                DBG("cache file is older than lastflush -> flush [%s]", d->cachepath);
                if( isNotExpired) {
                    d->reason = CA_REASON_TTL_EXPIRED;
                    if (!d->info.head) {
                        /* temporarily touch expiry file so that concurrent requests will be served
                        * with stale cache file while it is being flushed
                        */
                        d->prev_time = expiry;
                        if (!cache_expiry_set(lc, d->cachepath, time(NULL) + 5)) {
                            d->touch_time = st->st_mtime;
                        }
                    }
                }
                return 1;
            } else {
                /* Stat file was modified BEFORE cache file was created */
                DBG("cache file is newer than lastflush -> use cache [%s]", d->cachepath);
            }
        } else {
            /* Stat file does not exist */
            DBG("never flushed [%s] -> use cache [%s]", statfile, d->cachepath);
        }
    }
    return 0;
}

static enum cache_action get_cache_action(struct dispatcher *d)
{
    struct log_context *lc = d->lc;
    struct farm *farm = d->farm;
    struct cache *cache = farm->cache;
    const char *uri = d->info.uri, *safe_uri = d->info.safe_uri, *method, *query;
    struct stat st, *pst = NULL;
    char *ext;

    /* do not cache without extension, or with an extension followed by
     * another directory delimiter */
    if ((ext = strrchr(uri, '.')) == NULL || strchr(ext + 1, '/')) {
        d->reason = CA_REASON_NO_EXTENSION;
        DBG("%s: %s", _ca_reasons[d->reason], safe_uri);
        return CACHE_ACTION_NONE;
    }
    /* only cache, if HTTP method is 'GET' or 'HEAD' */
    method = d->info.method;
    if (strcasecmp(method, "GET") && !d->info.head) {
        d->reason = CA_REASON_NOT_GET_HEAD;
        DBG("%s: %s", _ca_reasons[d->reason], method);
        return CACHE_ACTION_NONE;
    }
    /* only cache, if no query parameters */
    query = d->info.query;
    if (query != NULL && !ignore_query(lc, cache->ignored_params_acl, query)) {
        d->reason = CA_REASON_QUERY_STRING;
        DBG("%s: %s", _ca_reasons[d->reason], query);
        return CACHE_ACTION_NONE;
    }
    /* only cache, if matches cache rules */
    if (!cache_acl_allowed(lc, cache->rules_acl, uri, &d->qaexec)) {
        d->reason = CA_REASON_NOT_IN_RULES;
        DBG("%s: %s", _ca_reasons[d->reason], safe_uri);
        return CACHE_ACTION_NONE;
    }
    /* check whether authorization headers deny caching */
    if (!cache->cache_authorized) {
        if (farm->sessionMgr) {
            d->session = sessmgr_get_session(farm->sessionMgr, d);
            if (!d->session) {
                d->reason = CA_REASON_SESSION_MANAGER_NO_AUTH;
                DBG(_ca_reasons[d->reason]);
                return CACHE_ACTION_NONE;
            }
        } else if (contains_authorization(d) && !farm->auth_checker) {
            /* do not cache pages that are restricted through authorization */
            d->reason = CA_REASON_AUTHORIZATION;
            DBG(_ca_reasons[d->reason]);
            return CACHE_ACTION_NONE;
        }
    }
    /* finally, give web server an opportunity to override */
    if (ws_get_cache_action(d)) {
        return d->action;
    }

    if (stat(d->cachepath, &st)) {
        DBG("cachefile does not exist: %s", d->cachepath);
    } else if (S_ISDIR(st.st_mode)) {
        DBG("cachefile is a directory: %s", d->cachepath);
    } else {
        pst = &st;
    }
    if (!pst) {
        if (d->info.head) {
            /* Unable to create a new cache file with a HEAD request */
            return CACHE_ACTION_NONE;
        }
        DBG("try to create new cachefile: %s", d->cachepath);
        return CACHE_ACTION_CREATE;
    }

    /* At this point, we know that the cache target exists */
    if (is_stale(d, cache, uri, &st)) {
        /* Unable to create a new cache file with a HEAD request */
        return d->info.head ? CACHE_ACTION_NONE : CACHE_ACTION_CREATE;
    }
    return CACHE_ACTION_DELIVER;
}

/**
 * Replace a cache file with a temporary file containing its new contents.
 *
 * @param tmppath temporary path
 * @param path cache file path
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
static int replace_file(struct log_context *lc, const char *tmppath, const char *path)
{
    char buf[PATH_MAX];

    strcpy(buf, path);

#ifdef WIN32
    /* on Windows, a move fails if the target exists */
    delete_file_or_directory(lc, buf, 0);
#else
    {
        struct stat st;
        if (!stat(path, &st) && S_ISDIR(st.st_mode)) {
            /* on Unix, a move of a file fails if the target is a directory */
            delete_file_or_directory(lc, buf, 0);
        }
    }
#endif
    return move_file(lc, tmppath, path);
}


/*----------------------------------------------------------- Public methods */


struct cache *cache_create(struct log_context *lc, struct any_item *config)
{
    struct cache *p;
    const char *s;
    char *tail;
    struct any_item *child;
    int mode;

    /* read the document root */
    if ((s = any_get_string(config, "docroot")) == NULL) {
        return NULL;
    }
    p = malloc(sizeof(struct cache));
    memset(p, 0, sizeof(struct cache));

    p->docroot = strdup(s);
    NORMALIZE_FILENAME(p->docroot);

    /* read the value of statfileslevel */
    p->statLevel = any_get_number(lc, config, "statfileslevel", -1);

    /* read the stat file name */
    if ((s = any_get_string(config, "statfile"))) {
        if (p->statLevel >= 0) {
            WARN("statfileslevel specified: statfile setting ignored.");
        } else {
            strcpy(p->statfile, s);
            NORMALIZE_FILENAME(p->statfile);
        }
    } else if (p->statLevel == -1) {
        /* use default stat level */
        p->statLevel = 0;
    }

    /* read ACLs */
    if ((child = any_get_first_child(config, "rules"))) {
        p->rules_acl = cache_acl_create(lc, child, "Cache rule");
    }
    if ((child = any_get_first_child(config, "invalidate"))) {
        p->invalidate_acl = acl_create(lc, child, NULL);
    }
    if ((child = any_get_first_child(config, "allowedClients"))) {
        p->flush_clients_acl = acl_create(lc, child, NULL);
    }
    if ((child = any_get_first_child(config, "ignoreUrlParams"))) {
        p->ignored_params_acl = acl_create(lc, child, NULL);
    }

    /* read booleans */
    p->cache_authorized = any_get_boolean(config, "allowAuthorized");
    p->serve_stale_on_error = any_get_boolean(config, "serveStaleOnError");

    /* read script value */
    if ((s = any_get_string(config, "invalidateHandler"))) {
        p->invalidate_handler = strdup(s);
    }

    /* read mode */
    p->mode = 0755;
    if ((s = any_get_string(config, "mode"))) {
        mode = (int) strtol(s, &tail, 8);
        if (*tail != '\0') {
            WARN("Permissions mode ignored, octal value expected: %s", s);
        } else {
            p->mode = mode;
        }
    }

    /* read headers */
    if ((child = any_get_first_child(config, "headers"))) {
        p->headers = cache_headers_create(lc, child);
    }
    p->grace_period = any_get_number(lc, config, "gracePeriod", 0);
    p->ttl_enabled = any_get_boolean(config, "enableTTL");

    return p;
}

int cache_quick_handler(struct dispatcher *d)
{
    struct log_context *lc = d->lc;
    const char *uri = d->info.uri, *file, *safe_uri = d->info.safe_uri;
    struct farm *farm = d->farm;
    struct cache *cache = farm->cache;
    int sc;

    d->reason = get_cache_path(lc, cache, uri, safe_uri, d->cachepath);
    if (d->reason != CA_REASON_NONE) {
        return 0;
    }

    if ((file = strrchr(uri, '/')) != NULL && !strcasecmp(file + 1, _stat_file_name)) {
        INFO("Denying access to stat file: %s", safe_uri);
        return HTTP_NOT_FOUND;
    }

    /* Deny requests to cache header files */
    if ((cache->headers != NULL && cache_headers_is_private(d->cachepath)) ||
            (cache->ttl_enabled && cache_expiry_is_private(d->cachepath))) {
        INFO("Denying access to cache headers/TTL file: %s", uri);
        return HTTP_NOT_FOUND;
    }

    /* Stop if cache processed a flush */
    if ((sc = process_flush_request(d))) {
        return sc;
    }

    /* Allow poller to run */
    if (farm->poller) {
        poller_run(lc, farm->poller, uri);
    }

    d->action = get_cache_action(d);
    if (d->action == CACHE_ACTION_DELIVER && farm->auth_checker) {
        switch (authchk_check(farm->auth_checker, d)) {
        case 1:
            /* A response was generated */
            return HTTP_OK;
        case 0:
            /* Access is granted, allowed to deliver file */
            break;
        case -1:
            /* Not allowed to deliver file, request must be proxied to backend */
            d->action = CACHE_ACTION_NONE;
            d->reason = CA_REASON_AUTH_CHECKER;
            INFO("%s: %s", _ca_reasons[d->reason], d->cachepath);
            break;
        default:
            break;
        }
    }

    /* if user has an invalid session, connect to backend and deliver its response */
    if (d->session && !session_is_valid(d->session) && d->action == CACHE_ACTION_DELIVER) {
        /* not allowed to spool from cache */
        d->action = CACHE_ACTION_NONE;
        d->reason = CA_REASON_SESSION_NOT_VALID;
    }

    DBG("cache-action for [%s]: %s", safe_uri, _cache_actions[d->action]);
    if (d->action == CACHE_ACTION_DELIVER) {
        DBG("request declined");
        d->hit = 1;
        ws_deliver(d);
        session_free(d->session);
        return DECLINED;
    }
    return 0;
}

int cache_fixup(struct dispatcher *d, int sc)
{
    struct log_context *lc = d->lc;
    struct farm *farm = d->farm;
    struct cache *cache = farm->cache;
    struct stat st;
    struct utimbuf ut;

    /* stop if cache was not configured */
    if (cache == NULL) {
        return sc;
    }

    /* change cache action if request was rejected */
    if (d->rejected && d->action == CACHE_ACTION_CREATE) {
        d->action = CACHE_ACTION_NONE;
        d->reason = CA_REASON_REJECTED;
    }

    /* touch session if we have a successful request */
    if (d->session && (sc == OK || (sc == DECLINED && !d->rejected) || (sc >= HTTP_OK && sc < HTTP_MULTIPLE_CHOICES))) {
        session_touch(lc, d->session);
    }
    session_free(d->session);

    /* if proxying a request to backend was rejected but auth_checker
     * is managing a resource, then do not allow access */
    if (d->rejected && farm->auth_checker && authchk_protects(lc, farm->auth_checker, d->info.uri)) {
        DBG("Denying access to authorization checker protected resource '%s' as access to backend was rejected.", d->info.safe_uri);
        return HTTP_NOT_FOUND;
    }

    /* eventually undo the touch in is_stale(), either by deleting the
     * cache file, or serving it as stale content, but ensure that the file
     * didn't change in the meantime.
     */
    if (sc == DECLINED || !d->touch_time) {
        /* we didn't touch a stale cache file */
        return sc;
    }
    if (stat(d->cachepath, &st) || st.st_mtime != d->touch_time) {
        /* stale cache file no longer available or updated */
        return sc;
    }
    if (cache->serve_stale_on_error && HTTP_STALE(sc)) {
        if (d->reason == CA_REASON_TTL_EXPIRED) {
            cache_expiry_set(lc, d->cachepath, d->prev_time);
        } else {
            ut.actime = ut.modtime = d->prev_time;
            utime(d->cachepath, &ut);
        }

        DBG("Returning stale file: %s", d->cachepath);
        d->serve_stale = 1;
        ws_set_header(d, "Warning", "111 Revalidation failed");
        d->hit = 1;
        ws_deliver(d);
        return DECLINED;
    }

    /* conditions not met to return stale file, so delete it */
    DBG("Deleting temporarily touched cache file: %s", d->cachepath);
    delete_file(lc, d->cachepath);
    return sc;
}

/**
 * A refetch URI possibly contains an ignored query string, so we can still cache the response.
 */
struct refetch_uri {
    /* Incoming URI */
    const char *uri;
    /* URI path, without query string */
    char *path;
    /* Ouery string or <code>NULL</code> */
    char *query;
};

static void refetch_uri_free(void *p)
{
    struct refetch_uri *ruri = (struct refetch_uri *) p;

    if (ruri == NULL) {
        return;
    }
    if (ruri->query != NULL) {
        // If we have a non-NULL query, the path is self-allocated
        free(ruri->path);
    }
    free(ruri);
}

static struct ptrarray *split_refetch_uris(struct log_context *lc, struct cache *cache, const char **refetch_uris)
{
    struct ptrarray *ruris;
    struct refetch_uri *ruri;
    const char **p, *uri, *query;
    size_t query_index;

    if (refetch_uris == NULL) {
        return NULL;
    }

    create_ptrarray(&ruris, 10, refetch_uri_free);
    for (p = refetch_uris; p != NULL && *p; p++) {
        uri = *p;

        query = strchr(uri, '?');
        if ((query != NULL)) {
            if (!ignore_query(lc, cache->ignored_params_acl, query + 1)) {
                INFO("Skipping refetch URI because query string is not ignored: %s", uri);
                continue;
            }
            query_index = query - uri;
        }

        ruri = malloc(sizeof(struct refetch_uri));
        ruri->uri = uri;

        if (query == NULL) {
            ruri->path = (char *) uri;
            ruri->query = NULL;
        } else {
            ruri->path = strdup(uri);
            ruri->query = &ruri->path[query_index];
            *ruri->query++ = 0;
        }
        ptrarray_add(ruris, ruri);
    }
    return ruris;
}

int cache_flush(struct log_context *lc, struct farm *farm, const char *uri, enum flush_action action,
                enum action_scope scope, const char **refetch_uris, struct hdrarray *headers)
{
    time_t mtime, timeline = 0;
    struct ptrarray *ruris;
    struct refetch_uri *ruri;
    struct cache *cache;
    int i;

    /** Check prerequisites */
    if ((cache = farm->cache) == NULL) {
        WARN("Farm %s has no document root: flush ignored", farm->label);
        return 0;
    }

    /** Touch all level stat files associated with this URI */
    if (scope != SCOPE_RESOURCE_ONLY) {
        touch_stats(lc, cache, uri);
    }

    /** Parse refetch uris */
    ruris = split_refetch_uris(lc, cache, refetch_uris);

    /** Touch existing cache files that should be re-fetched later */
    for (i = 0; i < ptrarray_size(ruris); i++) {
        ruri = (struct refetch_uri *) ptrarray_at(ruris, i);

        if (!touch_mapped_file(lc, cache->docroot, ruri->path, &mtime)) {
            if (!timeline || mtime < timeline) {
                timeline = mtime;
            }
        }
    }

    /** Flush existing files, skipping the ones touched above */
    flush_uri(lc, cache->docroot, uri, action, timeline);

    /** Refetch files */
    for (i = 0; i < ptrarray_size(ruris); i++) {
        ruri = (struct refetch_uri *) ptrarray_at(ruris, i);

        DBG("Refetching URI: %s", ruri->uri);
        if (refetch_file(lc, farm, ruri->path, ruri->query, headers)) {
            DBG("Deleting refetched URI: %s", ruri->uri);
            if (delete_mapped_file(lc, cache->docroot, ruri->path)) {
                WARN("Unable to remove cache entry: %s", ruri->uri);
            }
        } else {
            INFO("Refetched URI: %s", ruri->uri);
        }
    }
    ptrarray_free(ruris);

    return 0;
}

int cache_get_info(enum cache_action action, enum ca_reason reason, char *buf, size_t buf_len, int detailed)
{
    const char *saction = _cache_actions2[action];
    const char *sreason = _ca_reasons[reason];

    if (sreason == NULL || !detailed) {
        return snprintf(buf, buf_len, "%s", saction);
    } else {
        return snprintf(buf, buf_len, "%s; %s", saction, sreason);
    }
}

int cache_deliver(struct cache *cache, struct dispatcher *d)
{
    if (cache->headers) {
        cache_headers_deliver(cache->headers, d);
    }
    if (cache->ttl_enabled) {
        cache_expiry_deliver(d);
    }
    return 0;
}

static const char *_cache_control_denied_values[] = {
    "private", "no-cache", NULL
};

int cache_control_denies(struct http_client *hc, const char **line)
{
    struct http_headers *headers = http_client_get_headers(hc);
    if (http_headers_is(headers, "dispatcher", "no-cache", line) ||
            http_headers_is_one_of(headers, "cache-control", _cache_control_denied_values, line) ||
            http_headers_is(headers, "pragma", "no-cache", line)) {
        return 1;
    }
    return 0;
}

int cache_write_file(struct log_context *lc, struct cache *cache, struct http_client *hc,
                     const char *path, const char *cmd, FILE **fptemp)
{
    char tmppath[PATH_MAX];
    FILE *fp;
    int ret;
    struct stat st;
    struct http_headers *headers;

    if (create_temp_file(lc, path, tmppath, &fp, cache->mode)) {
        return -1;
    }

    ret = http_client_store(hc, fp, tmppath);
    if (!ret && stat(tmppath, &st)) {
        if (fptemp) {
            DBG("Temporary cache file no longer exists, trying to stream...");
            rewind(fp);
            *fptemp = fp;
            return -3;
        }
    }
    fclose(fp);

    if (ret) {
        unlink(tmppath);
        return ret;
    }

    headers = http_client_get_headers(hc);
    if (cache->headers) {
        cache_headers_store(lc, cache->headers, headers, path, cache->mode);
    }
    if (cache->ttl_enabled) {
        cache_expiry_store(lc, headers, path, cache->mode);
    }

    if (cmd) {
        const char *argv[] = { tmppath, path };

        if (exec_command(lc, cmd, 2, argv)) {
            unlink(tmppath);
            return -1;
        }
    }
    return replace_file(lc, tmppath, path);
}

void cache_free(struct cache *cache)
{
    if (cache == NULL) {
        return;
    }

    free(cache->docroot);
    cache_acl_free(cache->rules_acl);
    acl_free(cache->invalidate_acl);
    acl_free(cache->flush_clients_acl);
    acl_free(cache->ignored_params_acl);
    free(cache->invalidate_handler);
    cache_headers_free(cache->headers);

    free(cache);
}

