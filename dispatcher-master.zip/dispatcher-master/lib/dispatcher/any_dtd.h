/*
 * Copyright (c) 2008 Day Management AG
 * Barfuesserplatz 6, 4001 Basel, Switzerland
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Day Management AG, ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Day.
 */
#ifndef __ANY_DTD_H__
#define __ANY_DTD_H__

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * This is the string representation of the dispatcher.any document structure,
 * given in any representation.
 *
 * Note: - if a value is unquoted (VALUE), a string is expected
 *       - if a value is quoted ("VALUE"), an array of strings is expected
 */
static const char *ANY_DTD =
"/name VALUE \n"
"/ignoreEINTR VALUE \n"
"/farms {\n"
  "/LABEL {\n"
    "/numberOfRetries VALUE \n"
    "/retryDelay VALUE \n"
    "/unavailablePenalty VALUE \n"
    "/homepage VALUE \n"
    "/sessionmanagement {\n"
      "/directory VALUE \n"
      "/encode VALUE \n"
      "/header VALUE \n"
      "/timeout VALUE \n"
    "}\n"
    "/poller {\n"
      "/url VALUE \n"
      "/frequency VALUE \n"
    "}\n"
    "/auth_checker {\n"
      "/url VALUE \n"
      "/filter {\n"
        "/LABEL {\n"
          "/glob VALUE \n"
          "/type VALUE \n"
        "}\n"
      "}\n"
      "/headers {\n"
        "/LABEL {\n"
          "/glob VALUE \n"
          "/type VALUE \n"
        "}\n"
      "}\n"
    "}\n"
    "/clientheaders { \"VALUE\" }\n"
    "/virtualhosts { \"VALUE\" }\n"
    "/renders {\n"
      "/LABEL {\n"
        "/hostname VALUE \n"
        "/port VALUE \n"
        "/timeout VALUE \n"
        "/receiveTimeout VALUE \n"
        "/secure VALUE \n"
        "/always-resolve VALUE \n"
        "/ipv4 VALUE \n"
      "}\n"
    "}\n"
    "/statistics {\n"
      "/categories {\n"
        "/LABEL {\n"
          "/glob VALUE \n"
        "}\n"
      "}\n"
    "}\n"
    "/filter {\n"
      "/LABEL {\n"
        "/type VALUE \n"
        "/glob VALUE \n"
        "/method 'REGEXP' \n"
        "/url 'REGEXP' \n"
        "/query 'REGEXP' \n"
        "/protocol 'REGEXP' \n"
        "/path 'REGEXP' \n"
        "/selectors 'REGEXP' \n"
        "/extension 'REGEXP' \n"
        "/suffix 'REGEXP' \n"
      "}\n"
    "}\n"
    "/cache {\n"
      "/docroot VALUE \n"
      "/mode VALUE\n"
      "/statfile VALUE \n"
      "/statfileslevel VALUE \n"
      "/allowAuthorized VALUE \n"
      "/rules {\n"
        "/LABEL {\n"
          "/type VALUE \n"
          "/glob VALUE \n"
          "/regex 'REGEXP'\n"
          "/path 'REGEXP' \n"
          "/selectors 'REGEXP' \n"
          "/extension 'REGEXP' \n"
          "/suffix 'REGEXP' \n"
        "}\n"
      "}\n"
      "/invalidate {\n"
        "/LABEL {\n"
          "/glob VALUE \n"
          "/type VALUE \n"
        "}\n"
      "}\n"
      "/allowedClients {\n"
        "/LABEL {\n"
          "/glob VALUE \n"
          "/type VALUE \n"
        "}\n"
      "}\n"
      "/serveStaleOnError VALUE\n"
      "/ignoreUrlParams {\n"
        "/LABEL {\n"
          "/glob VALUE \n"
          "/type VALUE \n"
        "}\n"
      "}\n"
      "/invalidateHandler VALUE \n"
      "/headers { \"VALUE\" }\n"
      "/gracePeriod VALUE\n"
      "/enableTTL VALUE\n"
    "}\n"
    "/propagateSyndPost VALUE \n"
    "/stickyConnectionsFor VALUE \n"
    "/stickyConnections {\n"
      "/domain VALUE \n"
      "/httpOnly VALUE\n"
      "/secure VALUE\n"
      "/path VALUE \n"
      "/paths { \"VALUE\" }\n"
    "}\n"
    "/health_check {\n"
      "/url VALUE \n"
    "}\n"
    "/failover VALUE \n"
    "/vanity_urls {\n"
      "/file VALUE \n"
      "/url VALUE \n"
      "/delay VALUE \n"
    "}\n"
    "/info VALUE \n"
  "}\n"
"}";

#ifdef __cplusplus
}
#endif

#endif /* __ANY_DTD_H__ */
