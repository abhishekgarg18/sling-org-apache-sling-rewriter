/*
 * Copyright (c) 1999 Day Management AG
 * Barfuesserplatz 6, 4001 Basel, Switzerland
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Day Management AG, ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Day.
 */
#include "base/base.h"

#include "any_dtd.h"
#include "dispatcher.h"
#include "farm.h"
#include "cache.h"
#include "filter_acl.h"
#include "vanity_urls.h"

/*---------------------------------------------------------< some globals >---*/

#ifndef DISPATCHER_VERSION
#define DISPATCHER_VERSION "internal"
#endif

#ifndef PLATFORM_DESC
#define PLATFORM_DESC "unknown"
#endif

/**
 * Comment appended to via header.
 */
static const char *_via_comment = "(dispatcher)";

/**
 * Transfer encoding header name.
 */
static const char *_transfer_encoding = "transfer-encoding";

/**
 * Chunked encoding header value.
 */
static const char *_chunked = "chunked";

/**
 * Dispatcher info header name.
 */
static const char *_dispatcher_info = "x-dispatcher-info";

/**
 * Number of requests so far.
 */
unsigned long req_total = 0;

/**
 * Number of cache hits.
 */
unsigned long req_hits = 0;

/**
 * Number of cache misses.
 */
unsigned long req_misses = 0;

/**
 * Last time cache ratio was displayed.
 */
static long long cache_ratio_ms = 0;

/**
 * Last request total when cache ratio was displayed.
 */
static unsigned long last_req_total = 0;

/**
 * Get information about the request being processed.
 *
 * @param d dispatcher
 * @return client info pointer, <b>NOT</b> to be freed;
 *         <code>NULL</code> if information is unavailable
 */
static struct client_info *get_client_info(struct dispatcher *d)
{
    struct log_context *lc = d->lc;
    const char *value;
    char *valueT, *c, *cend, subst;
    struct client_info *info = &d->info;

    /* call webserver-specific version */
    memset(info, 0, sizeof(struct client_info));
    ws_get_client_info(d, info);

    /* stop if some vital information was unavailable */
    if (info->method == NULL || info->protocol == NULL || (info->uri == NULL && info->raw_uri == NULL)) {
        return NULL;
    }

    /* quickly check for HEAD method */
    info->head = (strcasecmp(info->method, "HEAD") == 0 ? 1 : 0);

    /* check whether there is a renderid cookie */
    value = ws_get_header(d, "cookie");
    if (value != NULL) {
        valueT = strdup(value);
        subst = *(c = cend = valueT);
        while (qstrtok(&c, &cend, &subst, ";")) {
            if (!(value = strstr(c, "renderid="))) {
                continue;
            }
            strncpy(info->id, value + 9, sizeof(info->id));
            info->id[sizeof(info->id) - 1] = '\0';
            trim(info->id, " \t");
            DBG("Render-ID in cookie detected: %s", info->id);
        }
        free(valueT);
    }

    /* set default host if none set */
    if (!info->host) {
        info->host = "";
    }

    /* check whether we support HTTP 1.1 */
    info->http11 = (strcmp(info->protocol, "HTTP/1.1") == 0 ? 1 : 0);

    /* set server name to default */
    if (!info->server_name) {
        info->server_name = info->host;
    }
    if (info->uri) {
        urlenc_ex(info->safe_uri, sizeof(info->safe_uri), info->uri, NULL);
    }
    return info;
}

static int check_http_version(const char *ch)
{
    if (!strncmp(ch, "HTTP/", 5) && isdigit(ch[5])) {
        /* since HTTP/2, a minor version number is optional */
        if (ch[6] == '\0' || (ch[6] == '.' && isdigit(ch[7]) && ch[8] == '\0')) {
            return 0;
        }
    }
    /* this is malformed */
    return -1;
}

/**
 * Map a request to the best matching farm.
 *
 * @param d dispatcher
 *
 * @return best matching farm
 */
static struct farm *map_request_to_farm(struct dispatcher *d)
{
    struct log_context *lc = d->lc;
    struct domain_glob *dom, *dom_candidate = NULL;
    struct client_info *info = &d->info;

    for (dom = d->config->domain; dom; dom = dom->next) {
        if (strglobcasecmp(dom->hostname_pattern, info->host)) {
            continue;
        }
        /* hostname matched, save first candidate for later */
        if (!dom_candidate) {
            dom_candidate = dom;
        }
        /* if uri pattern does not match, continue searching */
        if (dom->uri_pattern && strglobcmp(dom->uri_pattern, info->uri)) {
            continue;
        }
        /* if protocol scheme does not match, continue searching */
        if (dom->scheme_mask && dom->https != info->https) {
            continue;
        }
        return dom->farm;
    }
    /* return candidate farm that matched hostname or first farm */
    if (dom_candidate == NULL && d->config->farms > 1) {
        WARN("No farm matches host '%s', selected last farm '%s'", info->host, d->config->farm->label);
    }
    return dom_candidate ? dom_candidate->farm : d->config->farm;
}

/**
 * Check preconditions that must be met before we handle a request.
 *
 * @param d dispatcher
 *
 * @return <code>0</code> if we can continue;
 *         some HTTP status if we should abort
 */
static int validate_request(struct dispatcher *d)
{
    struct log_context *lc = d->lc;
    struct client_info *info;
    const char *value;
    char buf[2048];

    /* get client information and quickly fail for invalid requests */
    if ((info = get_client_info(d)) == NULL) {
        ERR("Unable to obtain client info, request considered bad");
        return HTTP_BAD_REQUEST;
    }
    if (check_http_version(info->protocol) < 0) {
        INFO("HTTP version malformed: %s", info->protocol);
        return HTTP_BAD_REQUEST;
    }
    if (info->uri == NULL) {
        DBG("No canonical URI available, declining request to: %s", info->raw_uri);
        return DECLINED;
    }
    if (info->via) {
        snprintf(buf, sizeof buf, "%s%s %s", info->server_name, info->server_port, _via_comment);
        if (strstr(info->via, buf)) {
            INFO("Already forwarded by dispatcher (%s%s), declined.",
                    info->server_name, info->server_port);
            return DECLINED;
        }
    }
    if (!strncasecmp(info->method, "synd_", 5)) {
        INFO("Blocking method %s", info->method);
        return HTTP_BAD_REQUEST;
    }

    /* map request to farm */
    if ((d->farm = map_request_to_farm(d)) == NULL) {
        ERR("No farm matched the hostname pattern: %s", info->host);
        return HTTP_NOT_FOUND;
    }

    DBG("Found farm %s for %s", d->farm->label, info->host);

    /* retrieve more information */
    if (d->farm->info_enabled && ws_get_header(d, _dispatcher_info) != NULL) {
        d->tell_reason = 1;
    }
    if ((value = ws_get_header(d, _transfer_encoding))) {
        d->chunked = strcasecmp(value, _chunked) ? 0 : 1;
    }

    return 0;
}

/**
 * Proxy a request to some backend in the selected farm. Checks first whether
 * filter section allows forwarding this request.
 *
 * Note: there are customers using the refetch-on-flush feature handled in
 *       the cache_quick_handler, but deny all requests to the dispatcher,
 *       so we must not change this ordering.
 *
 * @param d dispatcher
 *
 * @return <code>DECLINED</code> if the request was declined;
 *         <code>HTTP_BAD_GATEWAY</code> if no backend returned a valid answer;
 *         some HTTP status code otherwise
 */
static int proxy_request(struct dispatcher *d)
{
    struct log_context *lc = d->lc;
    struct client_info *info = &d->info;
    struct farm *farm = d->farm;
    int i, sc = HTTP_BAD_GATEWAY;

    if (!filter_acl_allowed(lc, farm->filter_acl, info) && !vanity_urls_is(lc, farm->vanity_urls, farm, info)) {
        DBG("Filter rejects: %s %s %s", info->method, info->safe_uri, info->protocol);
        d->rejected = 1;
        return DECLINED;
    }

    for (i = 0; i < farm->retries; i++) {
        struct render *backend = NULL;

        if (i > 0) {
            /* if we already checked all backends once, make a pause */
            sleep(farm->retrydelay);
            DBG("no backends available....retrying %d/%d", i, farm->retries);
        }

        sc = farm_service(d, &backend);
        if (backend == NULL) {
            /* no backend was reached, retry */
            continue;
        }
        if ((!d->read || d->req_body != NULL) && !d->read_error && farm_failover(lc, backend, sc)) {
            /* client body still available and we should failover
             * to another backend, retry */
            continue;
        }
        d->backend = backend;
        break;
    }

    /* clean up request body */
    if (d->req_body) {
        free(d->req_body);
        d->req_body = NULL;
    }
    return sc;
}


/*----------------------------------------------------------- Public methods */


struct hdrarray *get_pt_headers(struct dispatcher *d)
{
    struct log_context *lc = d->lc;
    struct farm *farm = d->farm;
    struct hdrarray *pt_headers;

    if ((pt_headers = create_hdrarray(50)) == NULL) {
        ERR("Unable to create headers array.");
        return NULL;
    }

    ws_get_pt_headers(d, farm->pt_header, pt_headers);
    return pt_headers;
}

int is_hop_by_hop_header(const char *name)
{
    switch (*name++) {
    case 'C':
    case 'c':
        return !strcasecmp(name, "ontent-encoding") ||
                !strcasecmp(name, "onnection");
    case 'D':
    case 'd':
        return !strcasecmp(name, "ispatcher");
    case 'K':
    case 'k':
        return !strcasecmp(name, "eep-alive");
    case 'P':
    case 'p':
        return !strcasecmp(name, "roxy-authenticate") ||
                !strcasecmp(name, "roxy-authorization");
    case 'T':
    case 't':
        return !strcasecmp(name, "e") ||
                !strcasecmp(name, "railers") ||
                !strcasecmp(name, "ransfer-encoding");
    case 'U':
    case 'u':
        return !strcasecmp(name, "pgrade");
    }
    return 0;
}

int exec_command(struct log_context *lc, const char *cmd, int argc, const char *argv[])
{
    int exitcode, status, i;
    size_t n;
    char line[8192];

    n = strlen(cmd);
    if (n >= sizeof line) {
        ERR("Unable to exec command %.120s...: command too long.", cmd);
        return -1;
    }
    strcpy(line, cmd);
    for (i = 0; i < argc; i++) {
        const char *arg = argv[i];
        if (arg == NULL) {
            arg = "";
        }
        if (n + 3 > sizeof line) {
            ERR("Unable to add argument %.120s...: command line too long.", arg);
            return -1;
        }
        strcpy(line + n, " \"");
        n += 2;

        if (strescape(line + n, arg, sizeof line - n)) {
            ERR("Unable to add argument %.120s...: command line too long.", arg);
            return -1;
        }
        n += strlen(line + n);

        strcpy(line + n, "\"");
        n++;
    }

    DBG("Executing command: %.120s...", line);
    exitcode = system(line);

#ifndef WIN32
    status = WEXITSTATUS(exitcode);
#else
    status = exitcode;
#endif

    DBG("Command %s exited with code: %d, status: %d", cmd, exitcode, status);
    return status;
}

static void log_request(struct dispatcher *d, int sc)
{
    struct client_info *info = &d->info;
    const char *method, *safe_uri, *farm_label, *backend_label;
    char status[20], cache_info[20];

    switch (sc) {
    case OK:
        snprintf(status, sizeof status, "%d", d->status);
        break;
    case DECLINED:
        strcpy(status, "-");
        break;
    default:
        snprintf(status, sizeof status, "%d", sc);
        break;
    }

    if (d->rejected) {
        strcpy(cache_info, "blocked");
    } else {
        cache_get_info(d->action, d->reason, cache_info, sizeof cache_info, 0);
    }

    method = info->method ? info->method : "?";
    safe_uri = info->safe_uri[0] ? info->safe_uri : (info->raw_uri ? info->raw_uri : "?");
    farm_label = d->farm ? d->farm->label : "-";
    backend_label = d->backend ? d->backend->label : "-";

    ws_log_request(d, method, safe_uri, info->query, status, cache_info, d->req_ms, farm_label, backend_label);
}

static void update_ratio(struct dispatcher *d, long long req_stopms)
{
    struct log_context *lc = d->lc;

    if (cache_ratio_ms == 0) {
        cache_ratio_ms = req_stopms;
    } else if (req_stopms - cache_ratio_ms >= 60000L && req_total - last_req_total >= 100) {
        /* show cache ratio at most once a minute, but only on substantial changes */
        INFO("Current cache hit ratio: %.2lf %%", (100.0f * req_hits) / req_total);
        cache_ratio_ms = req_stopms;
        last_req_total = req_total;
    }
}

int dispatcher_init(struct log_context *lc, const char *config_file,
                    struct dispatcher_config *config, const char *ws_desc)
{
    struct any_item *root;
    int ret;

    if ((root = any_import(lc, config_file, NULL, NULL)) == NULL) {
        ERR("Unable to import config file: %s", config_file);
        return -1;
    }
    ret = dispatcher_init_config(lc, root, config, ws_desc);
    any_free(root);
    return ret;
}

int dispatcher_init_config(struct log_context *lc, struct any_item *root,
                           struct dispatcher_config *config, const char *ws_desc)
{
    struct any_item *dtd, *child;
    unsigned global_ignore_eintr;
    struct farm *farm;

    DBG("Dispatcher initializing (build %s/%s-%s)", DISPATCHER_VERSION, ws_desc, PLATFORM_DESC);

    if ((dtd = any_parse(lc, ANY_DTD))) {
        any_validate(lc, root, dtd);
        any_free(dtd);
    }

    /* get global configuration */
    global_ignore_eintr = any_get_boolean(root, "ignoreEINTR");

    /* parse all farm settings, store in reverse order for historical reasons */
    memset(config, 0, sizeof(struct dispatcher_config));

    for (child = any_get_first_child(root, "farms"); child; child = child->next) {
        if ((farm = farm_create(lc, child, &config->domain)) == NULL) {
            return -1;
        }
        farm->ignore_eintr = global_ignore_eintr;
        farm->next = config->farm;
        config->farm = farm;
        config->farms++;
    }

    INFO("Dispatcher initialized (build %s/%s-%s)", DISPATCHER_VERSION, ws_desc, PLATFORM_DESC);
    return 0;
}

static int dispatcher_service_internal(struct dispatcher *d)
{
    int sc;

    /* 1) check preconditions */
    if ((sc = validate_request(d))) {
        return sc;
    }

    /* 2) allow cache to quickly handle this request */
    if ((sc = cache_quick_handler(d))) {
        return sc == HTTP_OK ? OK : sc;
    }

    /* 3) proxy request to backend */
    sc = proxy_request(d);

    /* 4) let cache perform some fixup */
    return cache_fixup(d, sc);
}

int dispatcher_service(struct dispatcher *d)
{
    long long req_startms, req_stopms;
    int sc;

    req_startms = gettimemillis();
    req_total++;

    sc = dispatcher_service_internal(d);

    req_stopms = gettimemillis();
    d->req_ms = (long) (req_stopms - req_startms);

    if (d->hit) {
        req_hits++;
    } else if (d->miss) {
        req_misses++;
    }

    log_request(d, sc);
    update_ratio(d, req_stopms);

    return sc;
}

void dispatcher_terminate(struct dispatcher_config *config)
{
    struct farm *farm;
    struct domain_glob *domain;

    while (config->farm) {
        farm = config->farm;
        config->farm = farm->next;

        farm_free(farm);
    }

    while (config->domain) {
        domain = config->domain;
        config->domain = domain->next;

        free(domain->hostname_pattern);
        free(domain->uri_pattern);
        free(domain);
    }
}


/*---------------------------------------------------------- DLL entry point */


#ifdef WIN32

/*
 * Handle to the DLL instance: this is the base address of the DLL itself. This
 * must be known in order to load the module's version information.
 */
HINSTANCE g_hInstDll;

/**
 * Optional entry point into a dynamic-link library (DLL). If the function is
 * used, it is called by the system when processes and threads are initialized
 * and terminated, or upon calls to the LoadLibrary and FreeLibrary functions.
 * @param hInstDll handle to the DLL module
 * @param fdwReason reason for calling function
 * @param lpvReserved reserved
 * @return <code>true</code> if successful, else <code>false</code>
 */
BOOL WINAPI DllMain(HINSTANCE hInstDll, DWORD fdwReason, LPVOID lpvReserved)
{
  switch (fdwReason) {
    case DLL_PROCESS_ATTACH:
      g_hInstDll = hInstDll;
      break;
    case DLL_PROCESS_DETACH:
      break;
  }
  return TRUE;
}

#endif
