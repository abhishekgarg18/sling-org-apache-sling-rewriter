/*
 * Copyright (c) 2004 Day Management AG
 * Barfuesserplatz 6, 4001 Basel, Switzerland
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Day Management AG, ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Day.
 */
#include "base/base.h"

#include "dispatcher.h"
#include "sessmgr.h"
#include "session.h"


/**
 * Session management support. Stores session identifiers for authorized
 * users and returns cached content as long as the session is valid.
 */

/**
 * Encoding algorithms.
 */
enum encoding {
    MD5 = 0,
    HEX
};

/**
 * Structure holding a session manager.
 */
struct session_mgr {
    /* Directory where session information is stored */
    char *directory;
    /* Encoding algorithm used */
    enum encoding encoding;
    /* Header where client authorization information is passed in */
    char *header;
    /* Timeout in seconds for sessions to expire */
    int timeout;
};

/* Table used for hex encoding */
static const char _hextable[] = "0123456789ABCDEF";

/* Component name */
static const char *_component = "Session manager";

/**
 * Remove an entry inside the file system. If it is a directory, its
 * entries are removed first.
 * @param name file name
 */
static void delete_file_or_directory(const char *name)
{
    DIR *dir;
    char path[PATH_MAX];
    struct dirent *entry;
    struct stat filestat;

    if (stat(name, &filestat)) {
        return;
    }

    if (S_ISDIR(filestat.st_mode)) {
        dir = opendir(name);
        if (dir) {
            while ((entry = readdir(dir)) != NULL) {
                if (!strcmp(entry->d_name, ".") || !strcmp(entry->d_name, "..")) {
                    continue;
                }
                snprintf(path, sizeof path, "%s%c%s",
                        name, FILE_SEPARATOR_CHAR, entry->d_name);
                delete_file_or_directory(path);
            }
            closedir(dir);
        }
    }
    remove(name);
}

/**
 * Hex encode a value
 * @param value pointer to value
 * @param size size in bytes of value
 * @return pointer to zero terminated string containing hex encoded
 *         value
 */
static char *hex_encode(const char *value, size_t size)
{
    char *result;
    int i, j = 0;

    result = malloc(size * 2 + 1);

    for (i = 0; i < (int) size; i++) {
        char c = value[i];
        result[j++] = _hextable[(c & 0xF0) >> 4];
        result[j++] = _hextable[(c & 0x0F)];
    }
    result[j] = '\0';

    return result;
}

/**
 * Return the encoded value of an authorization or cookie identifier
 *
 * @param encoding encoding
 * @param id authorization or cookie identifier
 *
 * @return pointer to zero terminated string containing encoded
 *         identifier
 */
static char *do_encode(enum encoding encoding, const char *id)
{
    unsigned char digest[16];

    switch (encoding) {
    case MD5:
        md5_simple(digest, (char *) id);
        return hex_encode((const char *) digest, 16);
    case HEX:
        return hex_encode(id, strlen(id));
    default:
        return 0;
    }
}

/**
 * Extract authorization information from the request.
 *
 * @param header header where authorization is expected
 * @param d dispatcher
 * @return extracted authorization information; 0 if none was found.
 */
static char *extract_authorization(const char *header, struct dispatcher *d)
{
    char *authorization = NULL, *pattern;
    const char *name, *value, *cookie, *end;

    if (!strncmp(header, "HTTP:", strlen("HTTP:"))) {
        /* this is a HTTP header, e.g. HTTP:authorization */
        name = header + strlen("HTTP:");
        value = ws_get_header(d, name);
        if (value != NULL) {
            authorization = strdup(value);
        }
    } else if (!strncmp(header, "Cookie:", strlen("Cookie:"))) {
        /* this is a cookie, e.g. Cookie:SSID */
        name = header + strlen("Cookie:");
        if ((cookie = ws_get_header(d, "cookie"))) {
            pattern = malloc(strlen(name) + 2);
            strcpy(pattern, name);
            strcat(pattern, "=");

            if ((value = strstr(cookie, pattern))) {
                value += strlen(pattern);
                if ((end = strpbrk(value, " ;")) == NULL) {
                    end = value + strlen(value);
                }
                authorization = malloc(end - value + 1);
                memcpy(authorization, value, end - value);
                authorization[end - value] = '\0';
            }
            free(pattern);
        }
    }
    if (authorization != NULL) {
        // trim optional whitespace
        trim(authorization, " \t");
        if (strlen(authorization) == 0) {
            free(authorization);
            authorization = NULL;
        }
    }
    return authorization;
}


/*----------------------------------------------------------- Public methods */


struct session_mgr *sessmgr_create(struct log_context *lc, struct any_item *config)
{
    struct session_mgr *mgr;
    const char *ptr;
    char *directory;
    struct stat filestat;

    if ((ptr = any_get_string(config, "directory")) == NULL) {
        ERR("%s: directory not specified.", _component);
        return 0;
    }

    mgr = malloc(sizeof(struct session_mgr));
    memset(mgr, 0, sizeof(struct session_mgr));

    directory = strdup(ptr);
    NORMALIZE_FILENAME(directory);
    mgr->directory = directory;

    if (!stat(mgr->directory, &filestat)) {
        DIR *dir;
        struct dirent *entry;

        DBG("%s: cleaning sessions directory '%s'", _component, mgr->directory);

        if ((dir = opendir(mgr->directory))) {
            while ((entry = readdir(dir)) != NULL) {
                char path[PATH_MAX];
                if (!strcmp(entry->d_name, ".") || !strcmp(entry->d_name, "..")) {
                    continue;
                }
                snprintf(path, sizeof path, "%s%c%s",
                        mgr->directory, FILE_SEPARATOR_CHAR, entry->d_name);
                delete_file_or_directory(path);
            }
        }
        closedir(dir);
    }

    if ((ptr = any_get_string(config, "encode"))) {
        if (!strcmp(ptr, "md5")) {
            mgr->encoding = MD5;
        } else if (!strcmp(ptr, "hex")) {
            mgr->encoding = HEX;
        } else {
            ERR("%s: encoding algorithm unknown: %s", _component, ptr);
            free(mgr->directory);
            free(mgr);
            return 0;
        }
    } else {
        mgr->encoding = MD5;
    }

    if ((ptr = any_get_string(config, "header"))) {
        mgr->header = strdup(ptr);
    } else {
        mgr->header = strdup("HTTP:authorization");
    }

    mgr->timeout = any_get_number(lc, config, "timeout", 800);

    INFO("%s: initialized.", _component);

    DBG("%s: using directory: %s", _component, mgr->directory);
    DBG("%s: using encoding algorithm: %d", _component, mgr->encoding);
    DBG("%s: using header: %s", _component, mgr->header);
    DBG("%s: using timeout: %d", _component, mgr->timeout);

    return mgr;
}

struct session *sessmgr_get_session(struct session_mgr *mgr, struct dispatcher *d)
{
    struct log_context *lc = d->lc;
    struct session *session;
    struct stat filestat;
    struct timeval now;
    char current_folder[PATH_MAX], last_folder[PATH_MAX], state_file[PATH_MAX];
    char *authorization;
    char *id;
    long units;
    int valid = 0;

    authorization = extract_authorization(mgr->header, d);
    if (!authorization) {
        DBG("%s: no authorization information found.", _component);
        return NULL;
    }

    id = do_encode(mgr->encoding, authorization);
    free(authorization);

    gettimeofday(&now, 0);
    units = now.tv_sec / mgr->timeout;

    /*
     * Create the session management directory if it does not exist. This
     * has to be done inside a request, because we might be running as root
     * on initialization time which would lead to an inaccessible directory
     * after having switched to the nobody user.
     */
    if (stat(mgr->directory, &filestat)) {
        DBG("%s: creating sessions directory %s", _component, mgr->directory);
        if (mkdirs(mgr->directory, 0755)) {
            ERR("%s: unable to create sessions directory %s (%d)",
                     _component, mgr->directory, errno);
            return 0;
        }
    }

    /* Find session id inside either the current folder or the last one */
    snprintf(current_folder, sizeof current_folder, "%s%c%016lX",
            mgr->directory, FILE_SEPARATOR_CHAR, units);
    snprintf(last_folder, sizeof last_folder, "%s%c%016lX",
            mgr->directory, FILE_SEPARATOR_CHAR, units - 1);

    snprintf(state_file, sizeof state_file, "%s%c%s", current_folder,
            FILE_SEPARATOR_CHAR, id);
    if (!stat(state_file, &filestat)) {
        valid = 1;
    } else {
        snprintf(state_file, sizeof state_file, "%s%c%s", last_folder,
                FILE_SEPARATOR_CHAR, id);
        if (!stat(state_file, &filestat)) {
            valid = 1;
        }
    }

    /* Delete old directories if current folder does not yet exist */
    if (stat(current_folder, &filestat)) {
        DIR *dir;
        struct dirent *entry;

        if (mkdirs(current_folder, 0755)) {
            ERR("%s: unable to create current sessions subdirectory %s (%d)",
                     _component, current_folder, errno);
            return 0;
        }

        if ((dir = opendir(mgr->directory))) {
            while ((entry = readdir(dir)) != NULL) {
                char path[PATH_MAX];
                if (!strcmp(entry->d_name, ".") || !strcmp(entry->d_name, "..")) {
                    continue;
                }
                snprintf(path, sizeof path, "%s%c%s",
                        mgr->directory, FILE_SEPARATOR_CHAR, entry->d_name);
                if (strcmp(path, current_folder) && strcmp(path, last_folder)) {
                    DBG("%s: removing old sessions directory %s.",
                             _component, path);
                    delete_file_or_directory(path);
                }
            }
            closedir(dir);
        }
    }

    session = session_create(mgr, id, current_folder, valid);
    DBG("%s: initialized session %s, state: %s.",
            _component, id, valid ? "valid" : "invalid");
    free(id);

    return session;
}

void sessmgr_free(struct session_mgr *mgr)
{
    if (!mgr) {
        return;
    }
    free(mgr->directory);
    free(mgr->header);
    free(mgr);
}
