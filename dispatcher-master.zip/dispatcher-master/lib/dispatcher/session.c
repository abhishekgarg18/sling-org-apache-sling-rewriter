/*
 * Copyright (c) 2004 Day Management AG
 * Barfuesserplatz 6, 4001 Basel, Switzerland
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Day Management AG, ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Day.
 */
#include "base/base.h"

#include "dispatcher.h"
#include "sessmgr.h"
#include "session.h"


/**
 * A structure holding a session.
 */
struct session {
    /* Session Manager */
    struct session_mgr *mgr;
    /* ID */
    char *id;
    /* Folder where state file should be located */
    char *folder;
    /* Whether this session is valid */
    int valid;
};

/**
 * Component name
 */
static const char *_component = "Session manager";


/*----------------------------------------------------------- Public methods */


struct session *session_create(struct session_mgr *mgr, const char *id,
                          const char *folder, int valid)
{
    struct session *session;

    session = malloc(sizeof(struct session));
    memset(session, 0, sizeof(struct session));

    session->mgr = mgr;
    session->id = strdup(id);
    session->folder = strdup(folder);
    session->valid = valid;

    return session;
}

int session_is_valid(struct session * session)
{
    return session->valid;
}

int session_touch(struct log_context *lc, struct session *session)
{
    char state_file[PATH_MAX];
    struct stat st;
    int fd;

    DBG("%s: touching session %s", _component, session->id);

    snprintf(state_file, sizeof state_file, "%s%c%s",
            session->folder, FILE_SEPARATOR_CHAR, session->id);

    if (stat(state_file, &st)) {
        if ((fd = open(state_file, O_CREAT | O_RDWR, 0600)) == -1) {
            ERR("%s: unable to create session file %s (%d)",
                    _component, state_file, errno);
            return -1;
        }
        close(fd);
    } else if (utime(state_file, 0)) {
        DBG("%s: unable to touch session file %s (%d)",
                _component, state_file, errno);
        return -1;
    }
    return 0;
}

void session_free(struct session *session)
{
    if (!session) {
        return;
    }
    free(session->id);
    free(session->folder);
    free(session);
}
