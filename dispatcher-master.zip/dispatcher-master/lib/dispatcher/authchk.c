/*
 * Copyright (c) 2007 Day Management AG
 * Barfuesserplatz 6, 4001 Basel, Switzerland
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Day Management AG, ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Day.
 */
#include "base/base.h"

#include "dispatcher.h"
#include "farm.h"
#include "authchk.h"

/**
 * Component name.
 */
static const char *_component = "Authorization checker";

/**
 * Structure representing authorization checker.
 */
struct auth_checker {
    /* Parent farm */
    struct farm *farm;
    /* Configured URL to contact */
    char *url;
    /* URI ACL, containing URIs to check, may be <code>NULL</code> */
    struct acl *uri_acl;
    /* Headers ACL, containing headers to forward, may be <code>NULL</code> */
    struct acl *headers_acl;
};

/**
 * Send passthrough headers.
 *
 * @param hc HTTP client
 * @param d dispatcher
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
static int send_pt_headers(struct http_client *hc, struct dispatcher *d)
{
    struct hdrarray *headers;

    if ((headers = get_pt_headers(d)) == NULL) {
        return -1;
    }
    http_client_add_headers(hc, headers);
    hdrarray_free(headers);
    return 0;
}

/**
 * Set all response headers in the web server plugin that match the "headers" configuration section
 * of the authorization checker.
 *
 * @param auth_checker authorization checker
 * @param headers headers
 * @param d dispatcher
 */
static void set_response_headers(struct auth_checker *auth_checker, struct http_headers *headers, struct dispatcher *d)
{
    struct log_context *lc = d->lc;
    int i;
    char headerline[8192];

    if (!auth_checker->headers_acl) {
        return;
    }
    for (i = 0; i < http_headers_size(headers); i++) {
        struct http_header *header = http_headers_at(headers, i);

        snprintf(headerline, sizeof headerline, "%s: %s", header->name, header->value);

        if (!acl_allowed(lc, auth_checker->headers_acl, headerline)) {
            continue;
        }
        if (is_hop_by_hop_header(header->name)) {
            continue;
        }
        if (!strcasecmp(header->name, "Server")) {
            continue;
        }
        ws_set_header(d, header->name, header->value);
    }
}

/**
 * Do the actual check against a connected backend.
 *
 * @param auth_checker authorization checker
 * @param backend backend selected
 * @param hc HTTP client
 * @param d dispatcher
 *
 * @return <code>0</code> is access is granted;
 *         <code>1</code> if a response was generated;
 *         <code>-1</code> otherwise
 */
static int do_check(struct auth_checker *auth_checker, struct render *backend,
                    struct http_client *hc, struct dispatcher *d)
{
    struct log_context *lc = d->lc;
    struct http_headers *headers;
    int sc, i;
    const char *sline;

    if (send_pt_headers(hc, d)) {
        return -1;
    }

    sc = http_client_get_status(hc, &sline);
    if (sc != HTTP_OK && sc != HTTP_MOVED_TEMPORARILY) {
        DBG("%s: backend answered with status code: %d", _component, sc);
        return -1;
    }
    if ((headers = http_client_get_headers(hc)) == NULL) {
        ERR("%s: unable to obtain response headers.", _component);
        return -1;
    }
    if (sc == HTTP_OK) {
        set_response_headers(auth_checker, headers, d);
        return 0;
    }

    /* Send back redirect, including all headers that are not hop-by-hop */
    ws_set_status(d, sc, sline);

    for (i = 0; i < http_headers_size(headers); i++) {
        struct http_header *header = http_headers_at(headers, i);
        if (is_hop_by_hop_header(header->name)) {
            continue;
        }
        if (!strcasecmp(header->name, "Location") && render_process_location(d, backend,  header->value)) {
            continue;
        }
        if (!strcasecmp(header->name, "Server")) {
            continue;
        }
        ws_set_header(d, header->name, header->value);
    }
    return 1;
}

/*----------------------------------------------------------- Public methods */


struct auth_checker* authchk_create(struct log_context *lc, struct any_item *config, struct farm *farm)
{
    struct auth_checker *auth_checker;
    struct any_item *first_item;
    const char *ptr;

    if ((ptr = any_get_string(config, "url")) == NULL) {
        ERR("%s: URL not configured.", _component);
        return NULL;
    }

    auth_checker = malloc(sizeof(struct auth_checker));
    memset(auth_checker, 0, sizeof(struct auth_checker));

    auth_checker->farm = farm;
    auth_checker->url = strdup(ptr);

    first_item = any_get_first_child(config, "filter");
    if (first_item) {
        auth_checker->uri_acl = acl_create(lc, first_item, NULL);
    }
    first_item = any_get_first_child(config, "headers");
    if (first_item) {
        auth_checker->headers_acl = acl_create(lc, first_item, NULL);
    }

    DBG("%s: initialized with URL '%s'.", _component, auth_checker->url);
    return auth_checker;
}

int authchk_set_headers(struct auth_checker *auth_checker, const char *uri,
                        struct http_client *hc, struct dispatcher *d)
{
    struct log_context *lc = d->lc;
    struct http_headers *headers;

    if (!acl_allowed(lc, auth_checker->uri_acl, uri)) {
        return 0;
    }
    if ((headers = http_client_get_headers(hc)) == NULL) {
        ERR("%s: unable to obtain response headers.", _component);
        return -1;
    }

    set_response_headers(auth_checker, headers, d);
    return 0;
}

int authchk_protects(struct log_context *lc, struct auth_checker *auth_checker, const char *uri)
{
    return acl_allowed(lc, auth_checker->uri_acl, uri) ? 1 : 0;
}

int authchk_check(struct auth_checker *auth_checker, struct dispatcher *d)
{
    struct log_context *lc = d->lc;
    struct endpoint ep;
    struct http_client *hc;
    struct render *backend;
    char query[4096], *url;
    int ret;
    size_t query_prefix_len;
    const char *uri = d->info.uri, *safe_uri = d->info.safe_uri;

    if (!acl_allowed(lc, auth_checker->uri_acl, uri)) {
        DBG("%s: URI does not match filter, will not be checked: %s", _component, safe_uri);
        return 0;
    }

    memset(&ep, 0, sizeof ep);
    ep.file = auth_checker->url;
    ep.method = "HEAD";
    ep.protocol = HTTP_1_0;

    query_prefix_len = strlen("uri=");
    strncpy(query, "uri=", sizeof query);
    url = query + query_prefix_len;
    urlenc_ex(url, sizeof query - query_prefix_len, d->info.uri, "/:;");
    ep.query = query;

    hc = farm_connect(lc, auth_checker->farm, &ep, d->info.id, &backend, NULL, NULL);
    if (hc == NULL) {
        return -1;
    }

    DBG("%s: connected to backend %s (%s:%d)", _component, backend->label, backend->host, backend->port);

    ret = do_check(auth_checker, backend, hc, d);

    http_client_free(hc);
    return ret;
}

void authchk_free(struct auth_checker *ac)
{
    if (!ac) {
        return;
    }
    free(ac->url);
    acl_free(ac->uri_acl);
    acl_free(ac->headers_acl);
    free(ac);
}
