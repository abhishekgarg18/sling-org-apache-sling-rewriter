/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2013 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

#ifndef __FILTER_ACL_H__
#define __FILTER_ACL_H__

/**
 * @file filter_acl.h
 * @brief Filter ACLs used to determine whether a request should be handled.
 */

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * @defgroup filter_acl Access control lists
 * @{
 */

/**
 * Create a filter ACL from an any structure, starting at the first child.
 *
 * @param first first child of list
 * @param name optional name, may be <code>NULL</code>
 *
 * @return ACL or <code>NULL</code> if an error occurred
 */
struct filter_acl *filter_acl_create(struct log_context *lc, struct any_item *first, const char *name);

/**
 * Match a request against the elements in a filter ACL.
 *
 * @param acl ACL to scan, may be <code>NULL</code>
 * @param info client info
 *
 * @return <code>1</code> if the request is allowed, otherwise <code>0</code>.
 */
int filter_acl_allowed(struct log_context *lc, struct filter_acl *acl, struct client_info *info);

/**
 * Destroy a filter access control list.
 *
 * @param acl access control list, may be <code>NULL</code>
 */
void filter_acl_free(struct filter_acl *acl);

/** @} */

#ifdef __cplusplus
}
#endif

#endif /* __FILTER_ACL_H__ */
