/*
 * Copyright (c) 2004 Day Management AG
 * Barfuesserplatz 6, 4001 Basel, Switzerland
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Day Management AG, ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Day.
 */
#ifndef __SESSION_H__
#define __SESSION_H__

/**
 * @file session.h
 * @brief Session management
 */

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * @defgroup session Session management
 * @{
 */

/**
 * Initialize a session.
 *
 * @param mgr session manager
 * @param id session id
 * @param folder folder where to touch state file
 * @param valid whether this session is valid
 *
 * @return session
 */
struct session *session_create(struct session_mgr *mgr, const char *id, const char *folder, int valid);

/**
 * Return a flag indicating whether a session is valid.
 *
 * @param session session
 *
 * @return <>0 if the session is valid; otherwise 0
 */
int session_is_valid(struct session *session);

/**
 * Touch this session.
 *
 * @param session session to touch
 *
 * @return session
 */
int session_touch(struct log_context *lc, struct session *session);

/**
 * Free memory associated with a session.
 *
 * @param session session, may be <code>NULL</code>
 */
void session_free(struct session *session);

/** @} */

#ifdef __cplusplus
}
#endif

#endif  /* __SESSION_H__ */
