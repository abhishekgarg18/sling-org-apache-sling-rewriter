/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * __________________
 *
 *  Copyright 2015 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

#ifndef __STRARRAY_H___
#define __STRARRAY_H___

/**
 * @file strarray.h
 * @brief String array, with own memory allocation
 */

/**
 * Declaration of a string array.
 */
struct strarray;

/**
 * Create a string array.
 *
 * @param sa where to return array
 * @param capacity initial capacity of array
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
int create_strarray(struct strarray **sa, int capacity);

/**
 * Add a string.
 *
 * @param sa string array
 * @param s string
 */
void strarray_add(struct strarray *sa, const char *s);

/**
 * Return string at a given index.
 *
 * @param sa string array
 * @param index index
 *
 * @return string or <code>NULL</code>
 */
char *strarray_at(struct strarray *sa, int index);

/**
 * Return size of string array.
 *
 * @param sa string array
 *
 * @return size of array
 */
int strarray_size(struct strarray *sa);

/**
 * Return the internal string table, of type <code>char **</code>.
 *
 * @param sa string array
 *
 * @return internal string table, terminated by a <code>NULL</code> string
 */
char **strarray_get(struct strarray *sa);

/**
 * Sort the string array, in ascending order.
 *
 * @param sa string array
 */
void strarray_sort(struct strarray *sa);

/**
 * Free string array
 *
 * @param sa string array, may be <code>NULL</code>
 */
void strarray_free(struct strarray *sa);

/** @} */
/** @} */

#endif /* __STRARRAY_H___ */
