/*
 * Copyright (c) 1999 Day Management AG
 * Barfuesserplatz 6, 4001 Basel, Switzerland
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Day Management AG, ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Day.
 */
#include "base/base.h"


/*----------------------------------------------------------- Public methods */


char *trim(char *string, const char *ws)
{
    char *ptr = string, *ptr1;

    while (*ptr && strchr(ws, *ptr)) {
        ptr++;
    }
    if (!(*ptr)) {
        *string = 0;
        return string;
    }
    ptr1 = string;
    while (*ptr) {
        *ptr1++ = *ptr++;
    }
    *ptr1-- = 0;
    while (ptr1 > string && strchr(ws, *ptr1)) {
        ptr1--;
    }
    *(++ptr1) = 0;
    return string;
}

int strglobcmp(const char *pattern, const char *string)
{
    register const char *p = pattern, *n = string;
    register char c;

    while ((c = *p++) != '\0') {
        switch (c) {
        case '?':
            if (*n == '\0')
                return 1;
            break;

        case '*':
            for (c = *p++; c && (c == '?' || c == '*'); c = *p++) {
                if (c == '?') {
                    /* A ? needs to match one character.  */
                    if (*n == '\0')
                        return 1; /* There isn't another character; no match.  */
                    /* One character of the string is consumed in matching
                     this ? wildcard, so *??? won't match if there are
                     less than three characters.  */
                    else
                        ++n;
                }
            }

            if (c == '\0')
                return 0;
            else {
                char c1 = c;
                for (--p; *n != '\0'; ++n)
                    if ((c == '[' || *n == c1) && strglobcmp(p, n) == 0)
                        return 0;
                return 1;
            }

        case '[': {
            /* Nonzero if the sense of the character class is inverted.  */
            register int not;
            if (*n == '\0')
                return 1;
            not = (*p == '!' || *p == '^');
            if (not)
                ++p;
            c = *p++;
            for (;;) {
                register char cstart = c, cend = c;
                if (c == '\0')
                    return 1; /* [ (unterminated) loses.  */
                c = *p++;
                if (c == '-' && *p != ']') {
                    cend = *p++;
                    if (cend == '\0')
                        return 1;
                    c = *p++;
                }
                if (*n >= cstart && *n <= cend)
                    goto matched;
                /* BEURK - GOTO... */
                if (c == ']')
                    break;
            }
            if (!not)
                return 1;
            break;

            matched:
            /* Skip the rest of the [...] that already matched.  */
            while (c != ']') {
                if (c == '\0')
                    return 1; /* [... (unterminated) loses.  */
                c = *p++;
            }
            if (not)
                return 1;
        }
            break;

        default:
            if (c != *n)
                return 1;
        }
        ++n;
    }
    if (*n == '\0')
        return 0;

    return 1;
}

int strglobcasecmp(const char *pattern, const char *string)
{
    register const char *p = pattern, *s = string;
    register char c;
    register int not;   /* Nonzero if the sense of the character class is inverted.  */

    while ((c = *p++) != '\0') {
        switch (c) {
        case '?':
            if (*s == '\0')
                return 1;
            break;

        case '*':
            /* skip single or multi globbing character(s) */
            for (c = *p++; c && (c == '?' || c == '*'); c = *p++) {
                if (c == '?') {
                    /* A ? needs to match one character.  */
                    if (*s == '\0')
                        return 1; /* There isn't another character; no match.  */

                    /* One character of the string is consumed in matching
                     this ? wildcard, so *??? won't match if there are
                     less than three characters.  */
                    else
                        ++s;
                }
            }
            if (c == '\0')
                return 0;
            else {
                char c1 = tolower(c);
                for (--p; *s != '\0'; ++s)
                    if ((c == '[' || tolower(*s) == c1) && !strglobcasecmp(p, s))
                        return 0;
                return 1;
            }
            break;

        case '[':
            if (*s == '\0')
                return 1;
            not = (*p == '!' || *p == '^');
            if (not)
                ++p;
            c = *p++;
            for (;;) {
                register char cstart = tolower(c), cend = cstart, s1;
                if (c == '\0')
                    return 1; /* [ (unterminated) loses.  */
                c = *p++;
                if (c == '-' && *p != ']') {
                    cend = tolower(*p++);
                    if (cend == '\0')
                        return 1;
                    c = *p++;
                }
                s1 = tolower(*s);
                if (s1 >= cstart && s1 <= cend)
                    goto matched; /* BEURK - GOTO... */
                if (c == ']')
                    break;
            }
            if (!not)
                return 1;
            break;

            matched:
            /* Skip the rest of the [...] that already matched.  */
            while (c != ']') {
                if (c == '\0')
                    return 1; /* [... (unterminated) loses.  */
                c = *p++;
            }
            if (not)
                return 1;
            break;

        default:
            if (tolower(c) != tolower(*s))
                return 1;
        }
        ++s;
    }
    if (*s == '\0')
        return 0;

    return 1;
}

char *mallocbinfile(const char *filename)
{
    int fd, len, off;
    struct stat st;
    char *p = NULL;

    if ((fd = open(filename, O_RDONLY, 0)) < 0) {
        return NULL;
    }
    if (!fstat(fd, &st) && !S_ISDIR(st.st_mode)) {
        p = malloc(st.st_size + 1);
        off = 0;

        while (off < st.st_size) {
            if ((len = read(fd, p + off, st.st_size - off)) == 0) {
                break;
            } else if (len < 0) {
                /* some error occurred */
                free(p);
                p = NULL;
                break;
            } else {
                off += len;
            }
        }
        if (p) {
            p[off] = 0;
        }
    }
    close(fd);
    return p;
}

char *qstrtok(char **ptrc, char **ptrcend, char *subst, char *delim)
/*
   a threadsafe strtok (from uncled, slightly enhanced)

   usage:
   char *c = stringtoparse, *cend = c, subst = *c;
   qstrtok(&c, &cend, &subst, delim);
   while(c)
     {
     do_something();
     qstrtok(&c, &cend, &subst, delim);
     }

*/
{
    char *c;
    char *cend;

    c = *ptrcend;
    cend = *ptrcend;

    if (ptrc && *ptrc && ptrcend && *subst) {
        *cend = *subst;
        while (*c && strchr(delim, *c))
            c++;
        if (*c) {
            for (cend = c + 1; *cend && !strchr(delim, *cend); cend++)
                ;
            *subst = *cend;
            *cend = 0;
        } else
            c = 0;
    } else
        c = 0;

    *ptrc = c;
    *ptrcend = cend;
    return (c);
}

int strlwrcpy(char *dest, const char *src)
{
    int i = 0;
    while ((*dest++ = tolower(*src++))) {
        i++;
    }
    return i;
}

int strlwrncpy(char *dest, size_t dest_len, const char *src)
{
    unsigned i;
    for (i = 0; i < dest_len; i++) {
        if ((dest[i] = (char) tolower(src[i])) == 0) {
            return i;
        }
    }
    dest[dest_len - 1] = 0;
    return dest_len - 1;
}

void strrep(char *s, char from, char to)
{
    for (;;) {
        s = strchr(s, from);
        if (!s) {
            break;
        }
        *s++ = to;
    }
}

int mkdirs(const char *path, int mode)
{
    char *c, *cend, subst, tmp[PATH_MAX];

    strncpy(tmp, path, PATH_MAX);
    tmp[PATH_MAX - 1] = 0;

    subst = *(c = cend = tmp);

#ifdef WIN32
    /* Special handling for UNC paths */
    if (!strncmp(tmp, "\\\\", 2)) {
        char *sep = strchr(tmp + 2, '\\');
        if (sep == NULL) {
            /* server name only: invalid */
            errno = EINVAL;
            return -1;
        }
        sep = strchr(sep + 1, '\\');
        if (sep == NULL) {
            /* server and share name with no path: assume this exists */
            return 0;
        }
        subst = *(c = cend = sep);
    }
#endif

    while (qstrtok(&c, &cend, &subst, FILE_SEPARATOR)) {
        struct stat sb;
        if (!stat(tmp, &sb) && S_ISDIR(sb.st_mode)) {
            continue;
        }
        if (mkdir(tmp, mode) < 0 && errno != EEXIST) {
            return -1;
        }
    }
    return 0;
}

char* mktemp2(char *tmplt, int mode)
/* expects a filename of the form anyfileYYYYXXXXXX and replaces it with    */
/* a unique, random filename, generating a random string for YYYYYY and       */
/* calling mktemp with the generated filename                                 */
{
    int length, i, done = 0;
    long randvar;

    length = (int) strlen(tmplt);
    randvar = rand();

    if (length < 10)
        done = 1;

    if (!done)
        for (i = length-10; i < length - 6; i++)
            if (tmplt[i] != 'Y')
                done = 1;

    for (i = length-10; i < length - 6; i++) {
        tmplt[i] = (char)(randvar%26) + 'A';
        randvar = randvar / 26;
    }

#ifdef WIN32
    mktemp(tmplt);
#else
    int fd = mkstemp(tmplt);
    if (fd == -1) {
        return NULL;
    }
    fchmod(fd, mode);
    close(fd);
#endif
    return tmplt;
}

int dirname2(const char *path, char *dir)
{
    char *path_sep;
    size_t dir_len;
    int len;

    if ((path_sep = strrchr(path, FILE_SEPARATOR_CHAR)) == NULL) {
        strcpy(dir, ".");
        return 0;
    }
    dir_len = path_sep - path;

#ifdef WIN32
    /* Special handling for UNC paths */
    if (!strncmp(path, "\\\\", 2)) {
        if (path_sep == path + 1) {
            /* server name only: invalid */
            errno = EINVAL;
            return -1;
        } else if (strchr(path + 2, '\\') == path_sep) {
            /* do not walk above share name */
            strcpy(dir, path);
            return 0;
        }
    } else {
        /* Do not remove trailing slash on directories such as 'C:\\' */
        if (path_sep == path + 2 && path[1] == ':') {
            dir_len++;
        }
    }
#endif
    /* Do not remove trailing slash on root directory '/' */
    if (path_sep == path) {
        dir_len++;
    }
    if ((len = snprintf(dir, PATH_MAX, "%.*s", (int) dir_len, path)) >= PATH_MAX) {
        errno = ENAMETOOLONG;
        return -1;
    }
    return 0;
}

static const char Base64[] =
  "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
static const char Pad64 = '=';

int base64_dec(char const *src, unsigned char *target, size_t targsize)
{
    size_t tarindex;
    int state, ch;
    char *pos;

    state = 0;
    tarindex = 0;

    while ((ch = *src++) != '\0') {
        if (isspace(ch)) /* Skip whitespace anywhere. */
            continue;

        if (ch == Pad64)
            break;

        pos = strchr(Base64, ch);
        if (pos == 0) /* A non-base64 character. */
            return (-1);

        switch (state) {
        case 0:
            if (target) {
                if (tarindex >= targsize)
                    return (-1);
                target[tarindex] = (unsigned char) ((pos - Base64) << 2);
            }
            state = 1;
            break;

        case 1:
            if (target) {
                if (tarindex + 1 >= targsize)
                    return (-1);
                target[tarindex] |= (pos - Base64) >> 4;
                target[tarindex + 1] = (unsigned char) (((pos - Base64) & 0x0f) << 4);
            }
            tarindex++;
            state = 2;
            break;

        case 2:
            if (target) {
                if (tarindex + 1 >= targsize)
                    return (-1);
                target[tarindex] |= (pos - Base64) >> 2;
                target[tarindex + 1] = (unsigned char) (((pos - Base64) & 0x03) << 6);
            }
            tarindex++;
            state = 3;
            break;

        case 3:
            if (target) {
                if (tarindex >= targsize)
                    return (-1);
                target[tarindex] |= (pos - Base64);
            }
            tarindex++;
            state = 0;
            break;

        default:
            abort();
        }
    }

    /*
     * We are done decoding Base-64 chars.  Let's see if we ended
     * on a byte boundary, and/or with erroneous trailing characters.
     */

    if (ch == Pad64) { /* We got a pad char. */
        ch = *src++; /* Skip it, get next. */
        switch (state) {
        case 0: /* Invalid = in first position */
        case 1: /* Invalid = in second position */
            return (-1);

        case 2: /* Valid, means one byte of info */
            /* Skip any number of spaces. */
            while (ch != '\0') {
                if (!isspace(ch))
                    break;
                ch = *src++;
            }
            /* Make sure there is another trailing = sign. */
            if (ch != Pad64)
                return (-1);
            ch = *src++; /* Skip the = */
            /* Fall through to "single trailing =" case. */
            /* FALLTHROUGH */

        case 3: /* Valid, means two bytes of info */
            /*
             * We know this char is an =.  Is there anything but
             * whitespace after it?
             */
            while (ch != '\0') {
                if (!isspace(ch))
                    return (-1);
                ch = *src++;
            }
            /*
             * Now make sure for cases 2 and 3 that the "extra"
             * bits that slopped past the last full byte were
             * zeros.  If we don't check them, they become a
             * subliminal channel.
             */
            if (target && target[tarindex] != 0)
                return (-1);
        }
    } else {
        /*
         * We ended by seeing the end of the string.  Make sure we
         * have no partial bytes lying around.
         */
        if (state != 0)
            return (-1);
    }
    return (int) tarindex;
}

int base64_enc(unsigned char const *src, char *target, size_t targsize)
{
    size_t datalength = 0;
    size_t srclength, i;
    unsigned char input[3];
    unsigned char output[4];

    srclength = strlen((char *) src);
    while (2 < srclength) {
        input[0] = *src++;
        input[1] = *src++;
        input[2] = *src++;
        srclength -= 3;

        output[0] = input[0] >> 2;
        output[1] = ((input[0] & 0x03) << 4) + (input[1] >> 4);
        output[2] = ((input[1] & 0x0f) << 2) + (input[2] >> 6);
        output[3] = input[2] & 0x3f;

        if (datalength + 4 > targsize)
            return (-1);
        target[datalength++] = Base64[output[0]];
        target[datalength++] = Base64[output[1]];
        target[datalength++] = Base64[output[2]];
        target[datalength++] = Base64[output[3]];
    }

    /* Now we worry about padding. */
    if (0 != srclength) {
        /* Get what's left. */
        input[0] = input[1] = input[2] = '\0';
        for (i = 0; i < srclength; i++)
            input[i] = *src++;

        output[0] = input[0] >> 2;
        output[1] = ((input[0] & 0x03) << 4) + (input[1] >> 4);
        output[2] = ((input[1] & 0x0f) << 2) + (input[2] >> 6);

        if (datalength + 4 > targsize)
            return (-1);
        target[datalength++] = Base64[output[0]];
        target[datalength++] = Base64[output[1]];
        if (srclength == 1)
            target[datalength++] = Pad64;
        else
            target[datalength++] = Base64[output[2]];
        target[datalength++] = Pad64;
    }
    if (datalength >= targsize)
        return (-1);
    target[datalength] = '\0'; /* Returned value doesn't count \0. */
    return (int) datalength;
}

#define ISDOT(a)  (a[0] == '.' && (!a[1] || (a[1] == '.' && !a[2])))

/**
 * TODO: method is overly complex and has some undocumented behavior, i.e. a
 *       starting '/' in glob is simply discarded. It also does not work with
 *       more than 2 levels with wild characters in glob.
 */
static int find_paths_internal(const char *basedir, char *glob, struct strarray *sa)
{
    DIR *dir;
    const char *tok;
    struct stat st;
    char tmppath[PATH_MAX], fullpath[PATH_MAX], basis[PATH_MAX];
    char *ptr, *lastslash, *nextslash;
    struct dirent *entry;
    size_t basedir_len;

    /* find last slash before first joker */
    ptr = lastslash = glob;

    basedir_len = strlen(basedir);
    if (basedir_len + 2 > sizeof basis) {
        /* size of input string too big */
        return -1;
    }
    strncpy(basis, basedir, sizeof basis);
    if (basis[basedir_len - 1] != FILE_SEPARATOR_CHAR) {
        strcat(basis, FILE_SEPARATOR);
    }

    while ((*ptr) && (*ptr != '*') && (*ptr != '?') && (*ptr != '[') && (*ptr != ']')) {
        if (*ptr == '/') {
            lastslash = ptr;
        }
        ptr++;
    }

    if (!(*ptr)) {
        /* no joker, just do a stat */
        if (glob[0] == '/') {
            snprintf(tmppath, sizeof tmppath, "%s%s", basis, glob + 1);
        } else {
            snprintf(tmppath, sizeof tmppath, "%s%s", basis, glob);
        }
        if (!stat(tmppath, &st) && !S_ISDIR(st.st_mode)) {
            strarray_add(sa, tmppath);
        }
        return 0;
    }

    /* find base path */
    if (lastslash != glob) {
        *lastslash = 0;
        if (glob[0] == '/') {
            snprintf(tmppath, sizeof tmppath,
                     "%s%s%c", basis, glob + 1, FILE_SEPARATOR_CHAR);
        } else {
            snprintf(tmppath, sizeof tmppath,
                     "%s%s%c", basis, glob, FILE_SEPARATOR_CHAR);
        }
        *lastslash++ = '/';
    } else {
        snprintf(tmppath, sizeof tmppath, "%s", basis);
        if (*lastslash == '/') {
            lastslash++;
        }
    }

    /* get next slash */
    nextslash = 0;
    while ((*ptr) && (*ptr != '/')) {
        ptr++;
    }
    if (*ptr) {
        *(nextslash = ptr) = 0;
    }

    if ((dir = opendir(tmppath)) == NULL) {
        return 0;
    }

    while ((entry = readdir(dir)) != NULL) {
        tok = entry->d_name;
        if (ISDOT(tok)) {
            continue;
        }
        /* check glob */
        if (strglobcmp(lastslash, tok)) {
            continue;
        }
        snprintf(fullpath, sizeof fullpath, "%s%s", tmppath, tok);
        if (stat(fullpath, &st)) {
            continue;
        }
        /* if directory, step into */
        if (S_ISDIR(st.st_mode)) {
            if (nextslash) {
                *nextslash = '/';
                find_paths_internal(fullpath, nextslash, sa);
                *nextslash = 0;
            }
        } else if (!nextslash) {
            strarray_add(sa, fullpath);
        }
    }
    closedir(dir);
    return 0;
}

int find_files(const char *basedir, char *glob, struct strarray **result)
{
    struct strarray *sa;

    if (create_strarray(&sa, 50)) {
        return -1;
    }
    if (find_paths_internal(basedir, glob, sa)) {
        strarray_free(sa);
        return -1;
    }
    strarray_sort(sa);
    *result = sa;
    return 0;
}

#define ISURLCHAR(c) ((c) >= 'a' && (c) <= 'z') || ((c) >= 'A' && (c) <= 'Z') || \
                     ((c) >= '0' && (c) <= '9') || ((c) == '_') || \
                     ((c)=='-') || ((c)=='.') || ((c) == '~')

char *urlenc_ex(char *dst, size_t dstlen, const char *src, const char *spare)
{
    size_t i = 0;
    const char *s = src, *default_spare = ";/:~$-_.+!*'(),@&=";

    if (spare == NULL) {
        spare = default_spare;
    }

    while (*s && i < dstlen - 1) {
        if (ISURLCHAR(*s) || strchr(spare, *s) != NULL) {
            dst[i++] = *s++;
        } else if (i + 3 < dstlen) {
            i += sprintf(&(dst[i]), "%%%02x", (unsigned char) *s++);
        } else {
            break;
        }
    }
    dst[i] = 0;
    return dst;
}

int url_unescape(char *url)
{
    register int badesc, badpath;
    char *x, *y, digit;

    badesc = 0;
    badpath = 0;
    /* Initial scan for first '%'. Don't bother writing values before
     * seeing a '%' */
    y = strchr(url, '%');
    if (y == NULL) {
        return 0;
    }
    for (x = y; *y; ++x, ++y) {
        if (*y != '%')
            *x = *y;
        else {
            if (!isxdigit(*(y + 1)) || !isxdigit(*(y + 2))) {
                badesc = 1;
                *x = '%';
            }
            else {
                digit = ((y[1] >= 'A') ? ((y[1] & 0xdf) - 'A') + 10 : (y[1] - '0'));
                digit *= 16;
                digit += (y[2] >= 'A' ? ((y[2] & 0xdf) - 'A') + 10 : (y[2] - '0'));
                *x = digit;
                y += 2;
                if (*x == '/' || *x == '\0')
                    badpath = 1;
            }
        }
    }
    *x = '\0';
    return (badesc || badpath) ? -1 : 0;
}

char *strnumdup(const char *s, size_t n)
{
    char *result;

    result = malloc(n + 1);
    strncpy(result, s, n);
    result[n] = '\0';

    return result;
}

int strescape(char *s1, const char *s2, size_t n)
{
    char *p = s1;
    if (n == 0) {
        return 0;
    }
    while (*s2 && n > 1) {
        char ch = *s2++;
        switch (ch) {
        case '"':
        case '\\':
        case '`':
        case '$':
            if (n <= 2) {
                /* not enough space left to escape character, stop */
                *p = 0;
                return -1;
            }
            *p++ = '\\';
            n--;
            /* fall through */
#ifdef WIN32
        case '%':
            /* unable to escape this, so just skip */
            *p++ = ' ';
            n--;
            break;
#endif
        default:
            *p++ = ch;
            n--;
            break;
        }
    }
    *p = 0;
    return *s2 == 0 ? 0 : -1;
}

#ifdef WIN32

long long gettimemillis()
{
    FILETIME ft;
    __int64 ns100;

    GetSystemTimeAsFileTime (&ft);
    ns100 = (__int64)ft.dwHighDateTime << 32 | ft.dwLowDateTime;
    ns100 = (ns100 - 116444736000000000L) / 10000;
    return ns100;
}

#else

long long gettimemillis()
{
    struct timeval tv;

    if (!gettimeofday(&tv, NULL)) {
        return ((long long) tv.tv_sec * 1000) + (tv.tv_usec / 1000);
    }
    return 0;
}

#endif /* WIN32 */

/**
 * Pattern used to generate unique temporary file names.
 */
const char *_tmp_pattern = "_YYYYXXXXXX";


int create_temp_file(struct log_context *lc, const char *path, char *filename, FILE **fp, int mode)
{
    char directory[PATH_MAX];
    FILE *file;

    if ((snprintf(filename, PATH_MAX, "%s%s", path, _tmp_pattern)) >= PATH_MAX) {
        ERR("Unable to generate temporary filename for %s: combined path exceeds %d characters.", path, PATH_MAX);
        return -1;
    }
    if (fp == NULL) {
        return 0;
    }

    if (dirname2(filename, directory)) {
        ERR("Unable to get directory name of %s.", filename);
        return -1;
    }
    if (mkdirs(directory, mode)) {
        ERRE("Unable to create parent directory %s: %s", directory, strerror(errno));
        return -1;
    }
    if (mktemp2(filename, mode & 0666) == NULL) {
        ERRE("Unable to generate temporary file for %s: %s", filename, strerror(errno));
        return -1;
    }

    if ((file = fopen(filename, "a+b")) == NULL) {
        ERRE("Unable to open temporary file %s: %s", filename, strerror(errno));
        return -1;
    }

    *fp = file;
    return 0;
}

void decompose_url(const char *url, char **rpath, const char **selectors, const char **extension, char **suffix)
{
    char *dot, *last_dot, *slash;

    *rpath = *suffix = NULL;
    *selectors = *extension = NULL;

    *rpath = strdup(url);

    dot = strchr(*rpath, '.');
    if (dot == NULL) {
        /* no extension at all, we're finished */
        return;
    }
    slash = strchr(dot, '/');
    if (slash != NULL) {
        *suffix = strdup(slash);
        *slash = 0;
    }

    *dot++ = 0;
    if (*dot == 0) {
        /* empty extension, we're finished */
        return;
    }

    *extension = dot;

    last_dot = strrchr(*extension, '.');
    if (last_dot != NULL) {
        *selectors = *extension;

        for (;;) {
            dot = strchr(dot, '.');
            if (dot == last_dot) {
                break;
            }
            *dot++ = 0;
        }
        *last_dot++ = 0;
        *extension = last_dot;
    }
}

char * strip_field(const char *value, const char *prefix, int delimeter)
{
    const char *before, *after, *end = value + strlen(value);
    char *new_value, *p;
    size_t prefix_len, suffix_len;

    before = strstr(value, prefix);
    if (before == NULL) {
        return NULL;
    }
    after = strchr(before, delimeter);
    if (after == NULL) {
        after = end;
    }
    while (*before != delimeter && before != value) {
        before--;
    }
    while (*after == delimeter || *after == ' ') {
        after++;
    }

    prefix_len = before - value;
    suffix_len = end - after;

    /* reserve space for delimeter and zero terminator */
    p = new_value = malloc(prefix_len + 2 + suffix_len + 1);

    memcpy(p, value, prefix_len); p += prefix_len;
    if (prefix_len != 0 && suffix_len != 0) {
        memcpy(p, ", ", 2); p += 2;
    }
    memcpy(p, after, suffix_len); p += suffix_len;
    *p = 0;

    return new_value;
}

int str_iseq(const char *s1, const char *s2)
{
    int             m = 0;
    volatile size_t i = 0;
    volatile size_t j = 0;
    volatile size_t k = 0;

    if (s1 == NULL || s2 == NULL)
        return -1;

    while (1) {
        m |= s1[i]^s2[j];

        if (s1[i] == '\0')
            break;
        i++;

        if (s2[j] != '\0')
            j++;
        if (s2[j] == '\0')
            k++;
    }

    return m == 0 ? 0 :1;
}