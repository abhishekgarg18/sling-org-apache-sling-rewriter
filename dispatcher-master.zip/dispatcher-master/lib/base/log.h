/*
 * Copyright (c) 2008 Day Management AG
 * Barfuesserplatz 6, 4001 Basel, Switzerland
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Day Management AG, ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Day.
 */
#ifndef __LOG_H__
#define __LOG_H__

/**
 * @file log.h
 * @brief Logging
 */

/**
 * @defgroup base Base functionality
 * @{
 */

/**
 * @defgroup log Logging
 * @{
 */

/**
 * An opaque structure passed to every function that needs logging.
 */
struct log_context;

/**
 * An enumeration representing a log level.
 */
enum log_level {
    /** Error level */
    LL_ERROR = 1,
    /** Warning level */
    LL_WARN,
    /** Info level */
    LL_INFO,
    /** Debug level */
    LL_DEBUG,
    /** Trace level */
    LL_TRACE
};


/** Log an error */
#define ERR(...)   log_out(lc, LL_ERROR, 0, __VA_ARGS__)
#define ERRE(...)  log_out(lc, LL_ERROR, errno, __VA_ARGS__)

/** Log a warning */
#define WARN(...)  log_out(lc, LL_WARN,  0, __VA_ARGS__)
#define WARNE(...) log_out(lc, LL_WARN,  errno, __VA_ARGS__)

/** Log an informational message */
#define INFO(...)  log_out(lc, LL_INFO,  0, __VA_ARGS__)

/** Log a debug message */
#define DBG(...)   log_out(lc, LL_DEBUG, 0, __VA_ARGS__)

/** Log a trace message */
#define TRACE(...) log_out(lc, LL_TRACE, 0, __VA_ARGS__)

/** @} */

/**
 * Init simple log context.
 *
 * @param lc where to return log context
 * @param level default level
 * @param do_log custom log method or <code>NULL</code>
 */
void log_init(struct log_context **lc, enum log_level level,
    void (*do_log)(enum log_level level, int errnum, const char *msg));

/**
 * Log a message.
 *
 * @param lc log context
 * @param level level
 * @param errnum errno number or <code>0</code>
 * @param fmt message format
 * @param ... arguments
 */
void log_out(struct log_context *lc, enum log_level level, int errnum, const char *fmt, ...);

/**
 * Check whether a log level is enabled, before actually composing a message that might not be
 * shown anyway.
 *
 * @param lc log context
 * @param level level to check
 * @return <code>1</code> if that level is enabled;
 *         <code>0</code> otherwise
 */
int log_is_enabled(struct log_context *lc, enum log_level level);

/**
 * Set log level. Only available in standalone applications.
 *
 * @param lc log context
 * @param level level to set
 */
void set_log_level(struct log_context *lc, enum log_level level);

/**
 * Parse log level from a string. If the given string is <code>NULL</code>
 * or not a valid level name, the <code>default_level</code> is returned.
 *
 * @param s string
 * @param default_level default level
 *
 * @return log level parsed or default level
 */
enum log_level parse_log_level(const char *s, enum log_level default_level);

/** @} */
/** @} */

#endif /* __LOG_H__ */
