/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * __________________
 *
 *  Copyright 2013 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

#ifndef __SSLSOCKET_H__
#define __SSLSOCKET_H__

/**
 * @file sslsocket.h
 * @brief I/O routines
 */

/**
 * @defgroup base Base functionality
 * @{
 */

/**
 * @defgroup socket SSL Socket library
 * @{
 */

/**
 * Initialize SSL sockets with a client certificate and CA file.
 *
 * @param cert_file certificate file
 * @param ca_file CA file
 * @param check_peer_cn whether to check the peer CN
 * @param threaded flag indicating whether application is threaded
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> otherwise
 */
int sslsockets_init(struct log_context *lc, const char *cert_file, const char *ca_file, int check_peer_cn, unsigned is_threaded);

/**
 * Create a new socket.
 *
 * @param ai address info
 * @param hostname host name used if host should be verified,
 *                 may be <code>NULL</code>
 *
 * @return new socket, or <code>NULL</code>
 */
struct socket *sslsocket_create(struct log_context *lc, struct addrinfo *ai, const char *hostname);

/**
 * Cleanup resources that were acquired in this process and need to be freed
 * on exit.
 */
void sslsockets_cleanup();

/** @} */
/** @} */

#endif /* __SSLSOCKET_H__ */
