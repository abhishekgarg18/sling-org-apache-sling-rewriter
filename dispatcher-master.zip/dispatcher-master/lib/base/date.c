/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2011 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

#include <ctype.h>
#include <string.h>
#include <time.h>

/*
 * Compare a string to a mask
 * Mask characters (arbitrary maximum is 256 characters, just in case):
 *   @ - uppercase letter
 *   $ - lowercase letter
 *   & - hex digit
 *   # - digit
 *   ~ - digit or space
 *   * - swallow remaining characters
 *  <x> - exact match for any other character
 */
static int _date_checkmask(const char *data, const char *mask)
{
    int i;
    char d;

    for (i = 0; i < 256; i++) {
        d = data[i];
        switch (mask[i]) {
        case '\0':
            return (d == '\0');

        case '*':
            return 1;

        case '@':
            if (!isupper(d))
                return 0;
            break;
        case '$':
            if (!islower(d))
                return 0;
            break;
        case '#':
            if (!isdigit(d))
                return 0;
            break;
        case '&':
            if (!isxdigit(d))
                return 0;
            break;
        case '~':
            if ((d != ' ') && !isdigit(d))
                return 0;
            break;
        default:
            if (mask[i] != d)
                return 0;
            break;
        }
    }
    return 0;          /* We only get here if mask is corrupted (exceeds 256) */
}

/**
 * a structure similar to ANSI struct tm with the following differences:
 *  - tm_usec isn't an ANSI field
 *  - tm_gmtoff isn't an ANSI field (it's a bsdism)
 */
struct _time_exp {
    /** microseconds past tm_sec */
    unsigned int tm_usec;
    /** (0-61) seconds past tm_min */
    unsigned int tm_sec;
    /** (0-59) minutes past tm_hour */
    unsigned int tm_min;
    /** (0-23) hours past midnight */
    unsigned int tm_hour;
    /** (1-31) day of the month */
    unsigned int tm_mday;
    /** (0-11) month of the year */
    unsigned int tm_mon;
    /** year since 1900 */
    int tm_year;
    /** (0-6) days since sunday */
    unsigned int tm_wday;
    /** (0-365) days since jan 1 */
    unsigned int tm_yday;
    /** daylight saving time */
    unsigned int tm_isdst;
    /** seconds east of UTC */
    unsigned int tm_gmtoff;
};

static int _time_exp_get(time_t *t, struct _time_exp *xt)
{
    time_t year = xt->tm_year;
    time_t seconds;
    static const int dayoffset[12] =
    {306, 337, 0, 31, 61, 92, 122, 153, 184, 214, 245, 275};

    /* shift new year to 1st March in order to make leap year calc easy */

    if (xt->tm_mon < 2)
        year--;

    /* Find number of days since 1st March 1900 (in the Gregorian calendar). */

    seconds = year * 365 + year / 4 - year / 100 + (year / 100 + 3) / 4;
    seconds += dayoffset[xt->tm_mon] + xt->tm_mday - 1;
    seconds -= 25508;              /* 1 jan 1970 is 25508 days since 1 mar 1900 */

    seconds = ((seconds * 24 + xt->tm_hour) * 60 + xt->tm_min) * 60 + xt->tm_sec;

    if (seconds < 0) {
        return -1;
    }
    *t = seconds;
    return 0;
}


/*----------------------------------------------------------- Public methods */


time_t date_parse_http(const char *date)
{
    struct _time_exp ds;
    time_t result;
    int mint, mon;
    const char *monstr, *timstr;
    static const int months[12] =
    {
    ('J' << 16) | ('a' << 8) | 'n', ('F' << 16) | ('e' << 8) | 'b',
    ('M' << 16) | ('a' << 8) | 'r', ('A' << 16) | ('p' << 8) | 'r',
    ('M' << 16) | ('a' << 8) | 'y', ('J' << 16) | ('u' << 8) | 'n',
    ('J' << 16) | ('u' << 8) | 'l', ('A' << 16) | ('u' << 8) | 'g',
    ('S' << 16) | ('e' << 8) | 'p', ('O' << 16) | ('c' << 8) | 't',
    ('N' << 16) | ('o' << 8) | 'v', ('D' << 16) | ('e' << 8) | 'c'};

    if (!date)
        return -1;

    while (*date && isspace(*date))    /* Find first non-whitespace char */
        ++date;

    if (*date == '\0')
        return -1;

    if ((date = strchr(date, ' ')) == NULL)       /* Find space after weekday */
        return -1;

    ++date;        /* Now pointing to first char after space, which should be */

    /* start of the actual date information for all 4 formats. */

    if (_date_checkmask(date, "## @$$ #### ##:##:## *")) {
        /* RFC 1123 format with two days */
        ds.tm_year = ((date[7] - '0') * 10 + (date[8] - '0') - 19) * 100;
        if (ds.tm_year < 0)
            return -1;

        ds.tm_year += ((date[9] - '0') * 10) + (date[10] - '0');

        ds.tm_mday = ((date[0] - '0') * 10) + (date[1] - '0');

        monstr = date + 3;
        timstr = date + 12;
    }
    else if (_date_checkmask(date, "##-@$$-## ##:##:## *")) {
        /* RFC 850 format */
        ds.tm_year = ((date[7] - '0') * 10) + (date[8] - '0');
        if (ds.tm_year < 70)
            ds.tm_year += 100;

        ds.tm_mday = ((date[0] - '0') * 10) + (date[1] - '0');

        monstr = date + 3;
        timstr = date + 10;
    }
    else if (_date_checkmask(date, "@$$ ~# ##:##:## ####*")) {
        /* asctime format */
        ds.tm_year = ((date[16] - '0') * 10 + (date[17] - '0') - 19) * 100;
        if (ds.tm_year < 0)
            return -1;

        ds.tm_year += ((date[18] - '0') * 10) + (date[19] - '0');

        if (date[4] == ' ')
            ds.tm_mday = 0;
        else
            ds.tm_mday = (date[4] - '0') * 10;

        ds.tm_mday += (date[5] - '0');

        monstr = date;
        timstr = date + 7;
    }
    else if (_date_checkmask(date, "# @$$ #### ##:##:## *")) {
        /* RFC 1123 format with one day */
        ds.tm_year = ((date[6] - '0') * 10 + (date[7] - '0') - 19) * 100;
        if (ds.tm_year < 0)
            return -1;

        ds.tm_year += ((date[8] - '0') * 10) + (date[9] - '0');

        ds.tm_mday = (date[0] - '0');

        monstr = date + 2;
        timstr = date + 11;
    }
    else
        return -1;

    if (ds.tm_mday <= 0 || ds.tm_mday > 31)
        return -1;

    ds.tm_hour = ((timstr[0] - '0') * 10) + (timstr[1] - '0');
    ds.tm_min = ((timstr[3] - '0') * 10) + (timstr[4] - '0');
    ds.tm_sec = ((timstr[6] - '0') * 10) + (timstr[7] - '0');

    if ((ds.tm_hour > 23) || (ds.tm_min > 59) || (ds.tm_sec > 61))
        return -1;

    mint = (monstr[0] << 16) | (monstr[1] << 8) | monstr[2];
    for (mon = 0; mon < 12; mon++)
        if (mint == months[mon])
            break;

    if (mon == 12)
        return -1;

    if ((ds.tm_mday == 31) && (mon == 3 || mon == 5 || mon == 8 || mon == 10))
        return -1;

    /* February gets special check for leapyear */
    if ((mon == 1) &&
        ((ds.tm_mday > 29) ||
        ((ds.tm_mday == 29)
        && ((ds.tm_year & 3)
        || (((ds.tm_year % 100) == 0)
        && (((ds.tm_year % 400) != 100)))))))
        return -1;

    ds.tm_mon = mon;

    /* ap_mplode_time uses tm_usec and tm_gmtoff fields, but they haven't
     * been set yet.
     * It should be safe to just zero out these values.
     * tm_usec is the number of microseconds into the second.  HTTP only
     * cares about second granularity.
     * tm_gmtoff is the number of seconds off of GMT the time is.  By
     * definition all times going through this function are in GMT, so this
     * is zero.
     */
    ds.tm_usec = 0;
    ds.tm_gmtoff = 0;
    if (_time_exp_get(&result, &ds))
        return -1;

    return result;
}
