/*
 * Copyright (c) 2010 Day Management AG
 * Barfuesserplatz 6, 4001 Basel, Switzerland
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Day Management AG, ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Day.
 */
#include "base/base.h"

/**
 * Pointer array
 */
struct ptrarray {
    /* current size of array */
    int size;
    /* capacity of array */
    int capacity;
    /* method to call when disposing pointers */
    void (*free_p)(void *p);
    /* pointers */
    void **p;
};

/**
 * Array returned from <code>ptrarray_get</code> if <code>ptrarray</code> is <code>NULL</code>.
 */
static void *_empty[] = { NULL };


/*----------------------------------------------------------- Public methods */


int create_ptrarray(struct ptrarray **pa, int capacity, void (*free_p)(void *p))
{
    struct ptrarray *result;

    result = malloc(sizeof(struct ptrarray));
    result->size = 0;
    result->capacity = capacity;
    result->free_p = free_p;
    result->p = malloc(capacity * sizeof(void *));
    memset(result->p, 0, capacity * sizeof(void *));

    *pa = result;
    return 0;
}

void ptrarray_add(struct ptrarray *pa, void *p)
{
    int capacity;

    if (pa->size >= pa->capacity - 1) {
        capacity = 2 * pa->capacity;
        pa->p = realloc(pa->p, capacity * sizeof(char *));
        memset(pa->p + pa->size, 0, (capacity - pa->size) * sizeof(void *));
        pa->capacity = capacity;
    }
    pa->p[pa->size++] = p;
}

void *ptrarray_at(struct ptrarray *pa, int index)
{
    if (pa && index < pa->size) {
        return pa->p[index];
    }
    return NULL;
}

int ptrarray_size(struct ptrarray *pa)
{
    if (pa) {
        return pa->size;
    }
    return 0;
}

void **ptrarray_get(struct ptrarray *pa)
{
    if (pa) {
        return pa->p;
    }
    return _empty;
}

void ptrarray_clear(struct ptrarray *pa)
{
    int i;

    if (pa) {
        if (pa->free_p) {
            for (i = 0; i < pa->size; i++) {
                pa->free_p(pa->p[i]);
            }
        }
        pa->size = 0;
    }
}

void ptrarray_free(struct ptrarray *pa)
{
    int i;

    if (pa) {
        if (pa->free_p) {
            for (i = 0; i < pa->size; i++) {
                pa->free_p(pa->p[i]);
            }
        }
        free(pa->p);
        free(pa);
    }
}
