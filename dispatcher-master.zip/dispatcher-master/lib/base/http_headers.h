/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * __________________
 *
 *  Copyright 2018 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

#ifndef __HTTP_HEADERS_H___
#define __HTTP_HEADERS_H___

/**
 * @file http_headers.h
 * @brief HTTP headers
 */

/**
 * @defgroup base Base functionality
 * @{
 */

/**
 * @defgroup http_headers HTTP headers
 * @{
 */

/** Opaque structure holding a collection of HTTP headers. */
struct http_headers;

/** A single HTTP header */
struct http_header {
    /* header line, may be <code>NULL</code> */
    char *line;
    /* header name */
    char *name;
    /* header value */
    char *value;
    /* next header of the same name or <code>NULL</code> */
    struct http_header *next;
};

/**
 * Create a new HTTP headers structure.
 *
 * @return HTTP headers
 */
struct http_headers *create_http_headers();

/**
 * Add a name/value pair to the HTTP headers.
 *
 * @param headers HTTP headers
 * @param name name
 * @param value value
 *
 * @return new HTTP header
 */
struct http_header *http_headers_add_nv(struct http_headers *headers, const char *name, const char *value);

/**
 * Add an unparsed line as HTTP header.
 *
 * @param headers HTTP headers
 * @param line header line
 *
 * @return new HTTP header or <code>NULL</code> if no ':' separator was found
 */
struct http_header *http_headers_add(struct http_headers *headers, const char *line);

/**
 * Return the first HTTP header matching a given name
 *
 * @param headers HTTP headers
 * @param name header name, lower case
 *
 * @return first HTTP header or <code>NULL</code>
 */
struct http_header *http_headers_get(struct http_headers *headers, const char *name);

/**
 * Return the value of some HTTP header, as a time.
 *
 * @param headers HTTP headers
 * @param name header name, lower case
 *
 * @return time value or <code>-1</code> if the header does not exist or the value is malformed
 */
time_t http_headers_get_date(struct http_headers *headers, const char *name);

/**
 * Return the value of some HTTP header, as a long long.
 *
 * @param headers HTTP headers
 * @param name header name, lower case
 *
 * @return long long value or <code>-1</code> if the header does not exist
 */
long long http_headers_get_llong(struct http_headers *headers, const char *name);

/**
 * Return a flag indicating whether a header exists with the given name and value
 *
 * @param headers HTTP headers
 * @param name header name, lower case
 * @param value header value
 * @param line if a match is found, return the complete header line (optional)
 *
 * @return <code>1</code> if the header exists, <code>0</code> otherwise
 */
int http_headers_is(struct http_headers *headers, const char *name, const char *value, const char **line);

/**
 * Return a flag indicating whether a header exists with the given name and one of the values given
 *
 * @param headers HTTP headers
 * @param name header name, lower case
 * @param values values to be checked against, terminated by a NULL pointer
 * @param line if a match is found, return the complete header line (optional)
 *
 * @return <code>1</code> if the header exists, <code>0</code> otherwise
 */
int http_headers_is_one_of(struct http_headers *headers, const char *name, const char **values, const char **line);

/**
 * Return a header at some position
 *
 * @param headers HTTP headers
 * @param index index
 *
 * @return header or <code>NULL</code> if index is out of range
 */
struct http_header *http_headers_at(struct http_headers *headers, int index);

/**
 * Return the number of headers
 *
 * @param headers HTTP headers
 *
 * @return number of headers
 */
int http_headers_size(struct http_headers *headers);

/**
 * Clear all headers
 *
 * @param headers HTTP headers
 */
void http_headers_clear(struct http_headers *headers);

/**
 * Free a HTTP headers structure
 *
 * @param headers HTTP headers, may be <code>NULL</code>
 */
void http_headers_free(struct http_headers *headers);

/** @} */
/** @} */

#endif /* __HTTP_HEADERS_H___ */
