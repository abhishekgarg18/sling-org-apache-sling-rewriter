/*
 * Copyright (c) 2010 Day Management AG
 * Barfuesserplatz 6, 4001 Basel, Switzerland
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Day Management AG, ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Day.
 *
 */
#ifndef __HTTP_CLIENT_H__
#define __HTTP_CLIENT_H__

/**
 * @file http_client.h
 * @brief HTTP client
 */

/**
 * @defgroup base Base functionality
 * @{
 */

/**
 * @defgroup http_client HTTP client
 * @{
 */

/** Opaque structure holding an HTTP client. */
struct http_client;
struct http_headers;

/**
 * Protocol enumeration.
 */
enum http_protocol {
    /** HTTP 1.1 */
    HTTP_1_1,
    /** HTTP 1.0 */
    HTTP_1_0
};

/**
 * Endpoint definition.
 */
struct endpoint {
    /** hostname */
    const char *host;
    /** port */
    int port;
    /** file */
    const char *file;
    /** query (optional) */
    const char *query;
    /** method, e.g. GET (optional) */
    const char *method;
    /** protocol, e.g. HTTP/1.1 (optional) */
    enum http_protocol protocol;
    /** address info (optional) */
    struct addrinfo *ai;
    /** connect timeout (optional) */
    unsigned timeout;
    /** receive timeout (optional) */
    unsigned receive_timeout;
    /** secure flag (optional) */
    unsigned secure:1;
    /** IPv4 flag (optional) */
    unsigned ipv4:1;
};

/**
 * @defgroup error_codes Error codes
 * @{
 */

/** Connection failed. */
#define HC_ECONN -1

/** Sending failed. */
#define HC_ESEND -2

/** Receiving failed. */
#define HC_ERECV -3

/** @} */

/**
 * Create HTTP client.
 *
 * @palam lc log context
 * @param ep endpoint
 *
 * @return HTTP client or <code>NULL</code> if an error occurred
 */
struct http_client *create_http_client(struct log_context *lc, struct endpoint *ep);

/**
 * @defgroup options Options
 * @{
 */

/** Option: do not send Expect: 100-continue to server */
#define OPTION_DISABLE_CONTINUE 0x00000001

/**
 * Set some options.
 *
 * @param hc HTTP client
 * @param mask options or'ed together
 * @param on whether to set or unset
 */
void http_client_set_options(struct http_client *hc, unsigned mask, int on);

/**
 * When some function returns a failure, return an error message associated with
 * the failure.
 *
 * @param hc HTTP client
 *
 * @return error message
 */
const char *http_client_get_error(struct http_client *hc);

/**
 * Add a header to to be sent.
 *
 * @param hc HTTP client
 * @param name name, caller allocated
 * @param value value, caller allocated
 */
void http_client_add_header(struct http_client *hc, const char *name, const char *value);

/**
 * Add headers to be sent
 *
 * @param hc HTTP client
 * @param headers header array
 */
void http_client_add_headers(struct http_client *hc, struct hdrarray *headers);

/**
 * Write some data to the request body. This implicitly sends the request
 * line and all request headers.
 *
 * @param hc HTTP clent
 * @param p buffer
 * @param len number of bytes, must not be <code>0</code>
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
int http_client_write(struct http_client *hc, const void *p, size_t len);

/**
 * Connect to the remote server.
 *
 * @param hc HTTP client
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
int http_client_connect(struct http_client *hc);

/**
 * Send all request headers to the server. This implicitly sends an
 * <code>Expect: 100-continue</code> header.
 *
 * @param hc HTTP client
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> if sending the headers failed;
 *         some status code other than HTTP_CONTINUE
 */
int http_client_send_headers(struct http_client *hc);

/**
 * Return the HTTP response status. This implicitely sends the request line and
 * all request headers.
 *
 * @param hc HTTP clent
 * @param sline where to return status line, may be <code>NULL</code>
 *
 * @return HTTP status;
 *         <code>HC_ECONN</code> if connecting to the remote server fails
 *         <code>HC_ESEND</code> if sending the request fails
 *         <code>HC_ERECV</code> if receiving the response fails
 */
int http_client_get_status(struct http_client *hc, const char **sline);

/**
 * Return all HTTP response headers.  This implicitly sends the request line and all request headers.
 *
 * @param hc HTTP client
 *
 * @return headers header array or <code>NULL</code> on failure
 */
struct http_headers *http_client_get_headers(struct http_client *hc);

/**
 * Return the content length of the response.
 *
 * @param hc HTTP client
 *
 * @return a non-negative integer if a content length is available;
 *         otherwise <code>-1</code>
 */
long long http_client_get_clen(struct http_client *hc);

/**
 * Tell client to returned body compressed. Without this, the body is automatically
 * decompress, if gzipped
 */
void http_client_keep_compressed(struct http_client *hc);

/**
 * Read some data from the response body. This implicitely sends the request
 * line and all request headers.
 *
 * @param hc HTTP clent
 * @param p buffer
 * @param len number of bytes to read
 *
 * @return number of bytes actually read;
 *         <code>0</code> on EOF;
 *         <code>-1</code> if an error occurred
 */
int http_client_read(struct http_client *hc, void *p, size_t len);

/**
 * Read some line from the response body. This implicitely sends the request
 * line and all request headers.
 *
 * @param hc HTTP clent
 * @param p buffer
 * @param len number of bytes available in p
 *
 * @return number of bytes in line;
 *         <code>0</code> if line is empty or EOF
 *         <code>-1</code> if an error occurred
 */
int http_client_readline(struct http_client *hc, char *p, size_t len);

/**
 * Write the body of a HTTP response to an open file.
 *
 * @param hc HTTP client
 * @param fp file pointer
 * @param path file path, used in error message
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> if writing the cache file fails;
 *         <code>-2</code> if reading from the backend fails or content length
 *                         and bytes read do not match;
 */
int http_client_store(struct http_client *hc, FILE *fp, const char *path);

/**
 * When reading data fails, return the actual socket errno.
 *
 * @param hc HTTP client
 *
 * @return socket errno
 */
int http_client_get_errno(struct http_client *hc);

/**
 * Return the number of bytes read from the response body.
 *
 * @param hc HTTP client
 *
 * @return number of bytes read
 */
long long http_client_get_read(struct http_client *hc);

/**
 * Free HTTP client.
 *
 * @param hc HTTP client
 */
void http_client_free(struct http_client *hc);

/**
 * Setup the HTTP client to retry a request.
 *
 * @param hc HTTP client
 */
int http_client_init_retry(struct http_client *hc);

/** @} */
/** @} */

#endif  /* __HTTP_CLIENT_H__ */
