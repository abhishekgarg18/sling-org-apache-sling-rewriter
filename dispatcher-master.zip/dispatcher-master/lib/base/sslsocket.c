/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * __________________
 *
 *  Copyright 2013 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

#include "base/base.h"

#include <openssl/ssl.h>
#include <openssl/err.h>
#include <openssl/x509.h>
#include <openssl/x509v3.h>

#if defined(WIN32)
/* nothing to include */
#elif defined(SOLARIS)
# include <synch.h>
# include <thread.h>
#else
# include <pthread.h>
#endif

#if (OPENSSL_VERSION_NUMBER & 0x10F00000L) != WITH_SSL_VERSION
# error Bad OpenSSL version detected
#endif

#include "base/socket_private.h"

/**
 * Define functions that were introduced in OpenSSL 1.1 with their fallbacks
 */
#if (OPENSSL_VERSION_NUMBER < 0x10100000L)
#define X509_STORE_get0_objects(cert_store) cert_store->objs
#define X509_OBJECT_get0_X509(obj) (obj->type == X509_LU_X509 ? obj->data.x509 : NULL)
#endif

/**
 * SSL Socket type.
 */
struct sslsocket {
    /** Base socket type */
    struct socket base;
    /** Host name */
    const char *hostname;

    /** SSL connection */
    SSL *con;
};

/**
 * SSL context, setup once.
 */
static SSL_CTX *ssl_ctx = NULL;

/**
 * SSL app data index, setup once.
 */
static int app_data_index = -1;

/**
 * Flag indicating whether to check the peer CN.
 */
static int ssl_check_peer_cn = 0;

/*----------------------------------------------------------- thread support */

/**
 * Locking callback.
 */
static void locking_callback(int mode, int type, const char *file, int line);

/**
 * Function returning unique identifier for current thread.
 */
static unsigned long get_thread_id();

#if defined(WIN32)

static HANDLE *lock_cs = NULL;

static int CRYPTO_thread_setup()
{
    int i;

    lock_cs = OPENSSL_malloc(CRYPTO_num_locks() * sizeof(HANDLE));
    if (lock_cs == NULL) {
        return -1;
    }
    for (i = 0; i < CRYPTO_num_locks(); i++) {
        lock_cs[i] = CreateMutex(NULL, FALSE, NULL);
    }

    CRYPTO_set_locking_callback(locking_callback);
    /* id callback defaults to GetCurrentThreadId() */

    return 0;
}

static void CRYPTO_thread_cleanup(void)
{
    int i;

    if (lock_cs == NULL) {
        return;
    }
    CRYPTO_set_locking_callback(NULL);
    for (i = 0; i < CRYPTO_num_locks(); i++) {
        CloseHandle(lock_cs[i]);
    }
    OPENSSL_free(lock_cs);
}

static void locking_callback(int mode, int type, const char *file, int line)
{
    if (mode & CRYPTO_LOCK) {
        WaitForSingleObject(lock_cs[type], INFINITE);
    } else {
        ReleaseMutex(lock_cs[type]);
    }
}

#elif defined(SOLARIS)

static mutex_t *lock_cs = NULL;
static long *lock_count;

static int CRYPTO_thread_setup(void)
{
    int i;

    lock_cs = OPENSSL_malloc(CRYPTO_num_locks() * sizeof(mutex_t));
    if (lock_cs == NULL) {
        return -1;
    }
    lock_count = OPENSSL_malloc(CRYPTO_num_locks() * sizeof(long));
    for (i = 0; i < CRYPTO_num_locks(); i++) {
        lock_count[i] = 0;
        mutex_init(&(lock_cs[i]), USYNC_THREAD, NULL);
    }
    CRYPTO_set_id_callback(get_thread_id);
    CRYPTO_set_locking_callback(locking_callback);

    return 0;
}

static void CRYPTO_thread_cleanup(void)
{
    int i;

    if (lock_cs == NULL) {
        return;
    }
    CRYPTO_set_locking_callback(NULL);
    for (i = 0; i < CRYPTO_num_locks(); i++) {
        mutex_destroy(&(lock_cs[i]));
    }
    OPENSSL_free(lock_cs);
    OPENSSL_free(lock_count);
}

static void locking_callback(int mode, int type, const char *file, int line)
{
    if (mode & CRYPTO_LOCK) {
        mutex_lock(&(lock_cs[type]));
        lock_count[type]++;
    } else {
        mutex_unlock(&(lock_cs[type]));
    }
}

static unsigned long get_thread_id(void)
{
    return (unsigned long) thr_self();
}

#else /* PTHREADS */

static pthread_mutex_t *lock_cs = NULL;
static long *lock_count;

static int CRYPTO_thread_setup(void)
{
    int i;

    lock_cs = OPENSSL_malloc(CRYPTO_num_locks() * sizeof(pthread_mutex_t));
    if (lock_cs == NULL) {
        return -1;
    }
    lock_count = OPENSSL_malloc(CRYPTO_num_locks() * sizeof(long));
    for (i = 0; i < CRYPTO_num_locks(); i++) {
        lock_count[i] = 0;
        pthread_mutex_init(&(lock_cs[i]), NULL);
    }
    CRYPTO_set_id_callback(get_thread_id);
    CRYPTO_set_locking_callback(locking_callback);

    return 0;
}

static void CRYPTO_thread_cleanup(void)
{
    int i;

    if (lock_cs == NULL) {
        return;
    }
    CRYPTO_set_locking_callback(NULL);
    for (i = 0; i < CRYPTO_num_locks(); i++) {
        pthread_mutex_destroy(&(lock_cs[i]));
    }
    OPENSSL_free(lock_cs);
    OPENSSL_free(lock_count);
}

static void locking_callback(int mode, int type, const char *file, int line)
{
    if (mode & CRYPTO_LOCK) {
        pthread_mutex_lock(&(lock_cs[type]));
        lock_count[type]++;
    } else {
        pthread_mutex_unlock(&(lock_cs[type]));
    }
}

static unsigned long get_thread_id(void)
{
    return (unsigned long) pthread_self();
}

#endif

/** TEST */

/*------------------------------------------------------ forward declarations */

static int do_setup();
static int do_connect(struct log_context *lc, struct socket *base, int timeout);
static int do_read(struct log_context *lc, struct socket *base, void *buf, int num);
static int do_write(struct log_context *lc, struct socket *base, const void *buf, size_t num);
static void do_shutdown(struct log_context *lc, struct socket *base);

/*----------------------------------------------------------- Public methods */

struct socket *sslsocket_create(struct log_context *lc, struct addrinfo *ai, const char *hostname)
{
    struct sslsocket *s;

    s = malloc(sizeof(struct sslsocket));
    memset(s, 0, sizeof(struct sslsocket));

    if (socket_init(lc, &s->base, ai)) {
        free(s);
        return NULL;
    }
    s->hostname = hostname;

    s->base.connect = do_connect;
    s->base.read = do_read;
    s->base.write = do_write;
    s->base.shutdown = do_shutdown;

    return &s->base;
}

static int print_errors_cb_lc(const char *str, size_t len, void *u)
{
    struct log_context *lc = (struct log_context *) u;

    ERR("%s", str);

    return 0;
}

static int print_errors_cb(const char *str, size_t len, void *u)
{
    struct sslsocket *s = (struct sslsocket *) u;

    if (s != NULL) {
        if (s->base.err_string == NULL) {
            socket_set_errstring(&s->base, str);
        }
    }
    return 0;
}

static int do_setup(struct log_context *lc)
{
    SSL_CTX *ctx;

    if (ssl_ctx) {
        /* Already initialized */
        return 0;
    }

    /* Initialize OpenSSL system. */
    SSL_library_init();

    /* Initialize cipher and digest subsystems according to OpenSSL
     * compile-time definitions (NO_RSA, NO_IDEA, NO_SHA1, NO_DSA, etc.).
     * If your application suddenly starts complaining that it doesn't
     * recognize OIDs like md5WithRSAEncryption etc., it's generally
     * because you forgot to call this function.
     */
    OpenSSL_add_all_algorithms();

    /* Make sure ERR_error_string() in ERR_print_errors() and its
     * brethren show you nice shiny text instead of dull old numbers.
     */
    SSL_load_error_strings();

    /* Create and configure SSL_CTX. */
    /* Initialize protocol version. SSL_CTX_new() does not set a default
     * for NULL SSL_METHOD* argument.  You must supply one of these methods.
     */
    if ((ctx = SSL_CTX_new(SSLv23_client_method())) == NULL) {
        ERR("Cannot create new SSL context.");
        ERR_print_errors_cb(print_errors_cb_lc, lc);
        return -1;
    }

    app_data_index = SSL_get_ex_new_index(0, "app_data_index", NULL, NULL, NULL);

    SSL_CTX_set_default_verify_paths(ctx);
    SSL_CTX_set_options(ctx, SSL_OP_NO_SSLv2);
    ssl_ctx = ctx;
    DBG("New SSL context created");

    return 0;
}

static int matches_common_name(struct log_context *lc, X509 *certificate, const char *hostname)
{
    X509_NAME *name;
    ASN1_STRING *tmp;
    int idx, n = -1, match = 0;
    unsigned char *peer_CN = NULL;

    if ((name = X509_get_subject_name(certificate)) == NULL) {
        WARN("Unable to verify host: server certificate has no subject.");
        return 0;
    }
    if ((idx = X509_NAME_get_index_by_NID(name, NID_commonName, -1)) < 0) {
        WARN("Unable to verify host: server certificate's subject has no CN.");
        return 0;
    }
    if ((tmp = X509_NAME_ENTRY_get_data(X509_NAME_get_entry(name, idx)))) {
        n = ASN1_STRING_to_UTF8(&peer_CN, tmp);
    }
    if (!peer_CN || ((int) strlen((char *) peer_CN) != n)) {
        WARN("Unable to verify host: unable to retrieve CN in server certificate's subject.");
    } else {
        if (strchr((char *) peer_CN, '*')) {
            match = !strglobcasecmp((char *) peer_CN, hostname) ? 1 : 0;
        } else {
            match = !strcasecmp((char *) peer_CN, hostname) ? 1 : 0;
        }
        DBG("CN in Server certificate's subject [%s] %s expected hostname [%s]", peer_CN,
            match ? "matches" : "does not match", hostname);
    }
    OPENSSL_free(peer_CN);
    return match;
}

static int matches_alternate_name(struct log_context *lc, X509 *certificate, const char *hostname)
{
    GENERAL_NAMES *ialt;
    GENERAL_NAME *gen;
    X509_EXTENSION *ext;
    int i, idx, n, match = 0;

    if ((idx = X509_get_ext_by_NID(certificate, NID_subject_alt_name, -1)) < 0) {
        DBG("Certificate does not contain a subject alternate name extension.");
        return 0;
    }
    if (!(ext = X509_get_ext(certificate, idx)) || !(ialt = X509V3_EXT_d2i(ext))) {
        WARN("Unable to verify host: unable to retrieve subject alternate name extension.");
        return 0;
    }

    for (i = 0; i < sk_GENERAL_NAME_num(ialt); i++) {
        unsigned char *DNSName = NULL;

        gen = sk_GENERAL_NAME_value(ialt, i);
        if (gen->type != GEN_DNS) {
            continue;
        }
        n = ASN1_STRING_to_UTF8(&DNSName, gen->d.dNSName);
        if (!DNSName || ((int) strlen((char *) DNSName) != n)) {
            WARN("Unable to verify host: unable to retrieve subject alternate name DNS.");
        } else {
            TRACE("Checking whether subject alternate name DNS [%s] matches expected hostname [%s]", DNSName, hostname);
            if (strchr((char *) DNSName, '*')) {
                match = !strglobcasecmp((char *) DNSName, hostname) ? 1 : 0;
            } else {
                match = !strcasecmp((char *) DNSName, hostname) ? 1 : 0;
            }
            if (match) {
                DBG("Subject alternate name DNS [%s] matches expected hostname [%s]", DNSName, hostname);
            }
        }
        OPENSSL_free(DNSName);

        if (match) {
            break;
        }
    }
    sk_GENERAL_NAME_free(ialt);
    return match;
}

static int verify_host(struct log_context *lc, struct sslsocket *s)
{
    X509 *peer_cert;
    int match = 0;
    char buf[256], name_buf[256];

    if ((peer_cert = SSL_get_peer_certificate(s->con)) == NULL) {
        socket_set_errstring(&s->base, "Unable to verify host: no server certificate available.");
        return -1;
    }
    X509_NAME_oneline(X509_get_subject_name(peer_cert), name_buf, sizeof name_buf);

    TRACE("Scanning certificate [%s] for expected hostname [%s].", name_buf, s->hostname);
    if (matches_common_name(lc, peer_cert, s->hostname) || matches_alternate_name(lc, peer_cert, s->hostname)) {
        match = 1;
    } else {
        snprintf(buf, sizeof buf, "Neither common name nor any subject alternate name match expected hostname [%s]", s->hostname);
        socket_set_errstring(&s->base, buf);
    }
    X509_free(peer_cert);
    return match ? 0 : -1;
}

static int verify_callback(int ok, X509_STORE_CTX *ctx)
{
    X509 *err_cert;
    int err, depth;
    SSL *con;
    struct sslsocket *s = NULL;
    char buf[512], name_buf[256];

    if (app_data_index != -1) {
        con = X509_STORE_CTX_get_ex_data(ctx, SSL_get_ex_data_X509_STORE_CTX_idx());
        s = SSL_get_ex_data(con, app_data_index);
    }

    if (!ok && ssl_check_peer_cn) {
        err_cert = X509_STORE_CTX_get_current_cert(ctx);
        err = X509_STORE_CTX_get_error(ctx);
        depth = X509_STORE_CTX_get_error_depth(ctx);

        X509_NAME_oneline(X509_get_subject_name(err_cert), name_buf, sizeof name_buf);
        snprintf(buf, sizeof buf, "Verifying certificate [%s] failed: %s", name_buf,
                 X509_verify_cert_error_string(err));
        print_errors_cb(buf, strlen(buf), s);
    }
    return ok;
}

static int do_connect(struct log_context *lc, struct socket *base, int timeout)
{
    struct sslsocket *s = (struct sslsocket *) base;
    int i, l, e;

    if (!ssl_ctx) {
        ERR("No SSL context available.");
        return -1;
    }

    /* Create and configure SSL connection. */
    if ((s->con = SSL_new(ssl_ctx)) == NULL) {
        ERR("Cannot create new SSL connection.");
        ERR_print_errors_cb(print_errors_cb, base);
        return -1;
    }

    SSL_set_verify(s->con, ssl_check_peer_cn ? SSL_VERIFY_PEER : SSL_VERIFY_NONE, verify_callback);
    SSL_set_ex_data(s->con, app_data_index, s);

    /** Support SNI, some servers appear to require it. */
    SSL_set_tlsext_host_name(s->con, s->hostname);

    /** Associate connection with socket */
    SSL_set_fd(s->con, (int) base->socket);

    /* Set SSL to work in client mode. */
    SSL_set_connect_state(s->con);

    /* Now that we've finally finished customizing the context and the
     * connection, go ahead and see if it works.  This function call
     * invokes all the SSL connection handshake and key exchange logic,
     * (which is why there's so much to report on after it completes).
     */
    l = SSL_connect(s->con);
    switch (e = SSL_get_error(s->con, l)) {
    case SSL_ERROR_NONE:
        break;
    case SSL_ERROR_SYSCALL:
        if ((l != 0) && (i = socket_errno())) {
            ERR("SSL handshake successful: connect errno=%d\n", i);
        } else {
            ERR("SSL handshake unsuccessful.");
        }
        /* fall through */
    case SSL_ERROR_WANT_WRITE:
    case SSL_ERROR_WANT_READ:
    case SSL_ERROR_WANT_X509_LOOKUP:
    case SSL_ERROR_ZERO_RETURN:
    case SSL_ERROR_SSL:
    default:
        ERR_print_errors_cb(print_errors_cb, base);
        return -1;
    }

    /* Verify host if necessary */
    if (ssl_check_peer_cn) {
        return verify_host(lc, s);
    }
    return 0;
}

static int do_read(struct log_context *lc, struct socket *base, void *buf, int num)
{
    struct sslsocket *s = (struct sslsocket *) base;
    int r, e, i;

    r = SSL_read(s->con, buf, num);
    if (!r && !socket_errno()) {
        /* interpret this as silent EOF */
        return 0;
    }

    switch (e = SSL_get_error(s->con, r)) {
    case SSL_ERROR_NONE:
    case SSL_ERROR_ZERO_RETURN:
        break;
    case SSL_ERROR_SYSCALL:
        if ((i = socket_errno()))
            ERR("Read errno=%d", i);
        /* fall through */
    case SSL_ERROR_WANT_WRITE:
    case SSL_ERROR_WANT_READ:
    case SSL_ERROR_WANT_X509_LOOKUP:
    case SSL_ERROR_SSL:
        ERR("SSL_read returns=%d", e);
        ERR_print_errors_cb(print_errors_cb, base);
        return -1;
    }
    return r;
}

static int do_write(struct log_context *lc, struct socket *base, const void *buf, size_t num)
{
    struct sslsocket *s = (struct sslsocket *) base;
    int r, e, i;

    r = SSL_write(s->con, buf, (int) num);

    switch (e = SSL_get_error(s->con, r)) {
    case SSL_ERROR_NONE:
        break;
    case SSL_ERROR_SYSCALL:
        if ((r != 0) && (i = socket_errno()))
            INFO("Write errno=%d\n", i);
        /* fall through */
    case SSL_ERROR_WANT_WRITE:
    case SSL_ERROR_WANT_READ:
    case SSL_ERROR_WANT_X509_LOOKUP:
    case SSL_ERROR_ZERO_RETURN:
    case SSL_ERROR_SSL:
    default:
        INFO("SSL_Write returns=%d", e);
        ERR_print_errors_cb(print_errors_cb, base);
        return -1;
    }
    return r;
}

static void do_shutdown(struct log_context *lc, struct socket *base)
{
    struct sslsocket *s = (struct sslsocket *) base;

    if (s->con != NULL) {
        SSL_shutdown(s->con);
        SSL_free(s->con);
        s->con = NULL;
    }
}

/**
 * Load all certificates and private keys from a file.
 *
 * @param sk stack of X509 infos
 * @param filename file
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> otherwise
 */
static int X509_INFO_load_file(STACK_OF(X509_INFO) *sk, const char *filename)
{
    BIO *in;

    if (!(in = BIO_new(BIO_s_file()))) {
        return -1;
    }

    if (BIO_read_filename(in, filename) <= 0) {
        BIO_free(in);
        return -1;
    }

    ERR_clear_error();

    PEM_X509_INFO_read_bio(in, sk, NULL, NULL);

    BIO_free(in);

    return 0;
}

static int load_certificates(struct log_context *lc, SSL_CTX *ctx, const char *cert_file, const char *ca_file)
{
    STACK_OF(X509_INFO) *sk;
    X509_INFO *inf;
    char name_buf[256];
    int n, ncerts;
    X509_OBJECT *obj;
    X509 *x509;

    if (cert_file) {
        sk = sk_X509_INFO_new_null();

        if ((X509_INFO_load_file(sk, cert_file))) {
            ERR_print_errors_cb(print_errors_cb_lc, lc);
            return -1;
        }

        if (sk_X509_INFO_num(sk) <= 0) {
            sk_X509_INFO_free(sk);
            WARN("No client certificates found in %s", cert_file);
            return 0;
        }

        inf = sk_X509_INFO_value(sk, 0);
        if (!inf->x509 || !inf->x_pkey || !inf->x_pkey->dec_pkey || inf->enc_data) {
            sk_X509_INFO_free(sk);
            ERR("Incomplete client certicate configured in %s "
                    "(missing or encrypted private key?)", cert_file);
            return -1;
        }

        DBG("Loaded client certificate: %s",
            X509_NAME_oneline(X509_get_subject_name(inf->x509), name_buf, sizeof name_buf));
        SSL_CTX_use_certificate(ctx, inf->x509);
        SSL_CTX_use_PrivateKey(ctx, inf->x_pkey->dec_pkey);
    }

    if (ca_file) {
        X509_STORE *cert_store;
        STACK_OF(X509_OBJECT) *objs;

        if (!SSL_CTX_load_verify_locations(ctx, ca_file, NULL)) {
            ERR_print_errors_cb(print_errors_cb_lc, NULL);
            return -1;
        }
        cert_store = SSL_CTX_get_cert_store(ctx);
        objs = X509_STORE_get0_objects(cert_store);

        ncerts = sk_X509_OBJECT_num(objs);
        for (n = 0; n < ncerts; n++) {
            obj = sk_X509_OBJECT_value(objs, n);
            x509 = X509_OBJECT_get0_X509(obj);
            if (x509) {
                DBG("Loaded CA certificate: %s",
                    X509_NAME_oneline(X509_get_subject_name(x509), name_buf, sizeof name_buf));
            }
        }
    }
    return 0;
}

int sslsockets_init(struct log_context *lc, const char *cert_file, const char *ca_file, int check_peer_cn, unsigned is_threaded)
{
    if (sockets_init(is_threaded)) {
        return -1;
    }
    if (is_threaded) {
        CRYPTO_thread_setup();
    }
    if (do_setup(lc)) {
        return -1;
    }
    ssl_check_peer_cn = check_peer_cn;
    return load_certificates(lc, ssl_ctx, cert_file, ca_file);
}

void sslsockets_cleanup()
{
    if (ssl_ctx != NULL) {
        SSL_CTX_free(ssl_ctx);
        ssl_ctx = NULL;
    }
    CRYPTO_thread_cleanup();
}
