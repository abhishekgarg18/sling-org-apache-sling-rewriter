/*
 * Copyright (c) 2004 Day Management AG
 * Barfuesserplatz 6, 4001 Basel, Switzerland
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Day Management AG, ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Day.
 */
#ifndef __ANY_H__
#define __ANY_H__

/**
 * @file any.h
 * @brief Any file parsing and validation
 */

/**
 * @defgroup base Base functionality
 * @{
 */

/**
 * @defgroup any Any file parsing and validation
 * @{
 */

/**
 * Node type enumeration
 */
enum any_type {
    /** Number */
    NUMBER = 1,
    /** String */
    STRING,
    /** Regular expression */
    REGEXP,
    /** Node */
    NODE
};


/**
 * Structure holding an any item
 */
struct any_item {
    /** Type */
    enum any_type type;
    /** Label */
    const char *label;
    /** First child node */
    struct any_item *first;
    /** Last child node */
    struct any_item *last;
    /** Next sibling */
    struct any_item *next;
    /** Parent node */
    struct any_item *parent;
    /** File where this item was defined */
    const char *filename;
    /** Line number (1-based) where this item was defined */
    int line;

    /** Value */
    union {
        /** Valid if @link any_item::type @endlink is
         * @link any_type::NUMBER @endlink */
        int d;
        /** Valid if @link any_item::type @endlink is
         * @link any_type::STRING @endlink or @link any_type::REGEXP @endlink */
        char *p;

    } value;
};

/**
 * Import an any file and return a deserialized object containing
 * all nodes in a hierarchical order
 *
 * @param filename file to parse
 * @param resolve optional callback used when resolving variables
 * @param u user data, to be passed to callback
 * @return root node
 */
struct any_item *any_import(struct log_context *lc, const char *filename, char *(resolve(const char *, void *)), void *u);

/**
 * Parse a string and return a deserialized object containing
 * all nodes in a hierarchical order.
 *
 * @param s string to parse
 * @return root node.
 */
struct any_item *any_parse(struct log_context *lc, const char *s);

/**
 * Return an item inside the any hierarchy.
 *
 * @param parent parent item
 * @param path path to item
 * @return item found; 0 if no item matches
 */
struct any_item *any_get_item(struct any_item *parent, const char *path);

/**
 * Return a string value of an item inside the any hierarchy. The returned
 * string is owned by the any file and should therefore be considered
 * read-only.
 *
 * @param parent parent item
 * @param path path to item
 * @return string found; 0 if no item matches or item is not of required type
 */
const char *any_get_string(struct any_item *parent, const char *path);

/**
 * Return a regular expression value of an item inside the any hierarchy.
 * The returned string is owned by the any file and should therefore be considered
 * read-only.
 *
 * @param parent parent item
 * @param path path to item
 * @return regular expression found; 0 if no item matches or item is not of required type
 */
const char *any_get_regex(struct any_item *parent, const char *path);

/**
 * Return a boolean value of an item inside the any hierarchy. The item
 * itself is considered to be of type string and cast into a boolean
 * number.
 *
 * @param parent parent item
 * @param path path to item
 * @return boolean value; 0 if no item matches or item is not of required type
 */
int any_get_boolean(struct any_item *parent, const char *path);

/**
 * Return a numeric value of an item inside the any hierarchy.
 *
 * @param parent parent item
 * @param path path to item
 * @param defvalue default value
 *
 * @return number stored or default value
 */
int any_get_number(struct log_context *lc, struct any_item *parent, const char *path, int defvalue);

/**
 * Return the first child of a node inside the any hierarchy.
 *
 * @param parent parent item
 * @param path path to item
 * @return first item found; 0 if no node matches or if the node has no children
 */
struct any_item *any_get_first_child(struct any_item *parent, const char *path);

/**
 * Dump an any file to the standard output
 * @param parent item where to start
 * @param level starting indentation level
 */
void any_dump(struct any_item *parent, int level);

/**
 * Validate an any item against its document structure.
 *
 * @param any any item
 * @param dtd dtd item
 */
void any_validate(struct log_context *lc, struct any_item *any, struct any_item *dtd);

/**
 * Free memory associated with an any item.
 *
 * @param item item to free, may be <code>NULL</code>
 */
void any_free(struct any_item *item);

/** @} */
/** @} */

#endif /* __ANY_H__ */
