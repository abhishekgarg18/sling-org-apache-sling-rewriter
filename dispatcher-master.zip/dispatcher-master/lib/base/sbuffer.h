/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2019 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

#ifndef __SBUFFER_H__
#define __SBUFFER_H__

/**
 * Opaque struct.
 */
struct sbuffer;

/**
 * Create a string buffer with a given initial capacity.
 */
struct sbuffer *create_sbuffer(int size);

/**
 * Append a string to this buffer.
 */
void sbuffer_append(struct sbuffer *sb, const char *s);

/**
 * Return the string.
 */
const char * sbuffer_to_string(struct sbuffer *sb);

/**
 * Return the string length.
 */
size_t sbuffer_len(struct sbuffer *sb);

/**
 * Free a string buffer.
 */
void sbuffer_free(struct sbuffer *sb);

#endif // __SBUFFER_H__
