/*
 * Copyright (c) 2010 Day Management AG
 * Barfuesserplatz 6, 4001 Basel, Switzerland
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Day Management AG, ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Day.
 */
#include "base/base.h"

/**
 * Hashtable entry.
 */
struct ht_entry {
    /** parent table */
    struct hashtable *ht;
    /** hash code */
    unsigned hash;
    /** key */
    char *key;
    /** value (for pointers) */
    void *p;
    /** method to call when disposing value */
    void (*free_p)(void *p);
    /** next entry in chain */
    struct ht_entry *next;
};

/**
 * Hashtable object.
 */
struct hashtable {
    /** number of elements in hashtable */
    int size;
    /** table size */
    int table_size;

    /** pointer to entry table */
    struct ht_entry **table;
};

/**
 * Duplicate a hashtable entry.
 *
 * @param ht parent hashtable
 * @param e source entry
 *
 * @return duplicate
 */
static struct ht_entry *dup_entry(struct hashtable *ht, struct ht_entry *e)
{
    struct ht_entry *copy;

    copy = malloc(sizeof(struct ht_entry) + strlen(e->key) + 1);
    copy->ht = ht;
    copy->hash = e->hash;
    copy->next = NULL;
    copy->key = (char *) (copy + 1);
    strcpy(copy->key, e->key);
    copy->p = strdup(e->p);
    copy->free_p = free;

    return copy;
}

/**
 * Compute the hash code of a zero-terminated string.
 *
 * @param key key whose hash code should be computed
 *
 * @return hash code
 */
static unsigned hash_key(const char *key)
{
    unsigned h = 0;

    while (*key) {
        h = (h * 31) + *key++;
    }
    return h;
}

/**
 * Return the entry associated with a given key.
 *
 * @param h hashtable
 * @param key key
 * @param create flag indicating whether to create the entry if necessary
 *
 * @return entry
 */
static struct ht_entry *get_entry(struct hashtable *ht, const char *key, int create)
{
    struct ht_entry *entry;
    unsigned hash;
    int index;

    hash = hash_key(key);
    index = hash % ht->table_size;

    entry = ht->table[index];
    while (entry) {
        if (entry->hash == hash && !strcmp(entry->key, key)) {
            return entry;
        }
        entry = entry->next;
    }
    if (create) {
        entry = malloc(sizeof(struct ht_entry) + strlen(key) + 1);
        entry->ht = ht;
        entry->hash = hash;
        entry->next = ht->table[index];
        entry->key = (char *) (entry + 1);
        strcpy(entry->key, key);
        entry->p = NULL;
        entry->free_p = NULL;
        ht->table[index] = entry;
    }
    return entry;
}


/*----------------------------------------------------------- Public methods */


int create_hashtable(struct hashtable **ht, int size)
{
    struct hashtable *result = malloc(sizeof(struct hashtable) + size * sizeof(struct ht_entry *));
    result->size = 0;
    result->table_size = size;
    result->table = (struct ht_entry **) (result + 1);
    memset(result->table, 0, size * sizeof(struct ht_entry *));

    *ht = result;
    return 0;
}

int hashtable_dup(struct hashtable **dest, struct hashtable *src)
{
    struct hashtable *ht;
    struct ht_entry *e, *copy, *last;
    int i;

    ht = malloc(sizeof(struct hashtable) + src->table_size * sizeof(struct ht_entry *));
    ht->size = src->size;
    ht->table_size = src->table_size;
    ht->table = (struct ht_entry **) (ht + 1);
    memset(ht->table, 0, ht->table_size * sizeof(struct ht_entry *));

    for (i = 0; i < src->table_size; i++) {
        last = NULL;
        for (e = src->table[i]; e; e = e->next) {
            copy = dup_entry(ht, e);
            if (last) {
                last->next = copy;
            } else {
                ht->table[i] = copy;
            }
            last = copy;
        }
    }

    *dest = ht;
    return 0;
}

const char *hashtable_gets(struct hashtable *ht, const char *s)
{
    return (const char *) hashtable_get(ht, s);
}

char *hashtable_puts(struct hashtable *ht, const char *s, const char *p)
{
    return (char *) hashtable_put(ht, s, strdup(p), free);
}

void *hashtable_get(struct hashtable *ht, const char *s)
{
    struct ht_entry *entry;

    entry = get_entry(ht, s, 0);
    if (entry) {
        return entry->p;
    }
    return NULL;
}

void *hashtable_put(struct hashtable *ht, const char *s, void *p, void (*free_p)(void *p))
{
    struct ht_entry *entry;
    void *old;

    entry = get_entry(ht, s, 1);
    old = entry->p;
    entry->p = p;
    entry->free_p = free_p;

    if (!old) {
        ht->size++;
    }
    return old;
}

struct ht_entry *hashtable_first(struct hashtable *ht)
{
    int i;

    for (i = 0; i < ht->table_size; i++) {
        if (ht->table[i]) {
            return ht->table[i];
        }
    }
    return NULL;
}

struct ht_entry *hashtable_next(struct ht_entry *last)
{
    struct hashtable *ht;
    int i, index;

    if (last->next) {
        return last->next;
    }
    ht = last->ht;
    index = last->hash % ht->table_size;

    for (i = index + 1; i < ht->table_size; i++) {
        if (ht->table[i]) {
            return ht->table[i];
        }
    }
    return NULL;
}

void hashtable_getentry(struct ht_entry *entry, const char **key, const void **p)
{
    *key = entry->key;
    *p = entry->p;
}

int hashtable_remove(struct hashtable *ht, const char *key)
{
    struct ht_entry *e, *last = NULL;
    unsigned hash;
    int index;

    hash = hash_key(key);
    index = hash % ht->table_size;

    for (e = ht->table[index]; e; e = e->next) {
        if (e->hash == hash && !strcmp(e->key, key)) {
            break;
        }
        last = e;
    }
    if (e) {
        if (last) {
            last->next = e->next;
        } else {
            ht->table[index] = e->next;
        }
        if (e->free_p && e->p) {
            e->free_p(e->p);
        }
        free(e);
        ht->size--;
    }
    return e ? 0 : -1;
}

void hashtable_clear(struct hashtable *ht)
{
    struct ht_entry *entry, *next;
    int i;

    for (i = 0; i < ht->table_size; i++) {
        entry = ht->table[i];
        while (entry) {
            next = entry->next;
            if (entry->free_p && entry->p) {
                entry->free_p(entry->p);
            }
            free(entry);
            entry = next;
        }
    }
    memset(ht->table, 0, ht->table_size * sizeof(struct ht_entry *));

    ht->size = 0;
}

int hashtable_size(struct hashtable *ht)
{
    return ht->size;
}

void hashtable_free(struct hashtable *ht)
{
    struct ht_entry *entry, *next;
    int i;

    if (ht) {
        for (i = 0; i < ht->table_size; i++) {
            entry = ht->table[i];
            while (entry) {
                next = entry->next;
                if (entry->free_p && entry->p) {
                    entry->free_p(entry->p);
                }
                free(entry);
                entry = next;
            }
        }
        free(ht);
    }
}
