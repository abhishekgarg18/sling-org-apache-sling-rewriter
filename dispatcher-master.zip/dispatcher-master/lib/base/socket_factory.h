/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2019 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

#ifndef __SOCKET_FACTORY_H__
#define __SOCKET_FACTORY_H__

/**
 * Initialize the socket factory.
 *
 * @param lc log context
 * @param pooled whether to pool connections
 * @param timeout timeout to keep pooled connections alive
 */
void init_socket_factory(struct log_context *lc, int pooled, int timeout);

/**
 * Return the socket factory. If not initialized, returns a non-pooled
 * factory.
 *
 * @return socket factory
 */
struct connection_factory *get_socket_factory();

/**
 * Free the current (global) socket factory. Mainly used for tests that
 * need to make sure all resources are freed.
 */
void free_socket_factory();

#endif // __SOCKET_FACTORY_H__