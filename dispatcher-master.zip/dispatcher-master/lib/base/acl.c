/*
 * Copyright (c) 2008 Day Management AG
 * Barfuesserplatz 6, 4001 Basel, Switzerland
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Day Management AG, ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Day.
 */
#include "base/base.h"

/**
 * Structure representing ACE.
 */
struct ace {
    /* label, <code>NULL</code> if not in trace mode */
    char *label;
    /* glob */
    char *glob;
    /* next ace item */
    struct ace *next;
    /* 1 if allowed, 0 if denied  */
    unsigned allowed:1;
};

/**
 * Structure representing ACL.
 */
struct acl {
    /* first ace item */
    struct ace *ace;
    /* optional name */
    char *name;
    /* flag indicating trace is enabled */
    unsigned trace:1;
};

/**
 * Create an ACE.
 *
 * @param glob glob
 * @param item parent item, used to iterate on further properties
 *
 * @return ACE or <code>NULL</code> if an error occurred
 */
static struct ace *ace_create(const char *glob, struct any_item *item)
{
    const char *type;
    struct ace *ace;

    ace = malloc(sizeof(struct ace));
    memset(ace, 0, sizeof(struct ace));

    ace->glob = strdup(glob);

    type = any_get_string(item, "type");
    ace->allowed = type && !strcasecmp("allow", type) ? 1 : 0;

    return ace;
}

/**
 * Free memory associated with an access control entry.
 *
 * @return ace access control entry
 */
static void ace_free(struct ace *ace)
{
    if (ace) {
        free(ace->glob);
        free(ace->label);
        free(ace);
    }
}


/*----------------------------------------------------------- Public methods */


struct acl *acl_create(struct log_context *lc, struct any_item *first, const char *name)
{
    struct ace *ace, *last = NULL;
    struct acl *acl;
    const char *s;

    acl = malloc(sizeof(struct acl));
    memset(acl, 0, sizeof(struct acl));

    if (name) {
        acl->name = strdup(name);
        acl->trace = log_is_enabled(lc, LL_TRACE);
    }

    while (first) {
        ace = NULL;
        if ((s = any_get_string(first, "glob"))) {
            ace = ace_create(s, first);
        }
        if (ace != NULL) {
            if (acl->trace) {
                ace->label = strdup(first->label);
            }
            if (last) {
                last->next = ace;
            } else {
                acl->ace = ace;
            }
            last = ace;
        }
        first = first->next;
    }
    return acl;
}

struct ace *acl_allowed(struct log_context *lc, struct acl *acl, const char *s)
{
    struct ace *ace, *match_ace = NULL;

    if (acl == NULL) {
        return NULL;
    }
    for (ace = acl->ace; ace != NULL; ace = ace->next) {
        if (!strglobcmp(ace->glob, s)) {
            match_ace = ace;
        }
    }
    if (match_ace && acl->trace) {
        TRACE("%s entry /%s %s '%s'", acl->name ? acl->name : "ACL", match_ace->label,
              match_ace->allowed ? "allowed" : "blocked", s);
    }
    return match_ace && match_ace->allowed ? match_ace : NULL;
}

struct ace *acl_denied(struct acl *acl, const char *s)
{
    struct ace *ace, *match_ace = NULL;

    if (acl == NULL) {
        return NULL;
    }
    for (ace = acl->ace; ace != NULL; ace = ace->next) {
        if (!strglobcmp(ace->glob, s)) {
            match_ace = ace;
        }
    }
    return match_ace && !match_ace->allowed ? match_ace : NULL;
}

void acl_free(struct acl *acl)
{
    struct ace *ace, *next;

    if (!acl) {
        return;
    }
    ace = acl->ace;
    while (ace) {
        next = ace->next;
        ace_free(ace);
        ace = next;
    }
    free(acl->name);
    free(acl);
}
