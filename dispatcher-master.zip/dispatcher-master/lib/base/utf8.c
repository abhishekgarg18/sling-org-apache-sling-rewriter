/*
 * Copyright (c) 2010 Day Management AG
 * Barfuesserplatz 6, 4001 Basel, Switzerland
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Day Management AG, ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Day.
 */
#include <string.h>

#include "base/utf8.h"

/**
 * Convert a UTF-8 encoded multi-byte character string to Unicode.
 *
 * @param in input
 * @param inbytes number of bytes in input
 * @param out output
 * @param outwords number of words in output
 *
 * @return <code>0</code> if successful; <code>-1</code> otherwise
 */
static int _conv_utf8_to_ucs2(const char *in, size_t *inbytes, wchar_t *out, size_t *outwords)
{
    long newch, mask;
    size_t expect, eating;
    int ch;

    while (*inbytes && *outwords)
    {
        ch = (unsigned char)(*in++);
        if (!(ch & 0200)) {
            /* US-ASCII-7 plain text
             */
            --*inbytes;
            --*outwords;
            *(out++) = ch;
        }
        else
        {
            if ((ch & 0300) != 0300) {
                /* Multibyte Continuation is out of place
                 */
                return -1;
            }
            else
            {
                /* Multibyte Sequence Lead Character
                 *
                 * Compute the expected bytes while adjusting
                 * or lead byte and leading zeros mask.
                 */
                mask = 0340;
                expect = 1;
                while ((ch & mask) == mask) {
                    mask |= mask >> 1;
                    if (++expect > 3) /* (truly 5 for ucs-4) */
                        return -1;
                }
                newch = ch & ~mask;
                eating = expect + 1;
                if (*inbytes <= expect)
                    return -1;
                /* Reject values of excessive leading 0 bits
                 * utf-8 _demands_ the shortest possible byte length
                 */
                if (expect == 1) {
                    if (!(newch & 0036))
                        return -1;
                }
                else {
                    /* Reject values of excessive leading 0 bits
                     */
                    if (!newch && !((unsigned char)*in & 0077 & (mask << 1)))
                        return -1;
                    if (expect == 2) {
                        /* Reject values D800-DFFF when not utf16 encoded
                         * (may not be an appropriate restriction for ucs-4)
                         */
                        if (newch == 0015 && ((unsigned char)*in & 0040))
                            return -1;
                    }
                    else if (expect == 3) {
                        /* Short circuit values > 110000
                         */
                        if (newch > 4)
                            return -1;
                        if (newch == 4 && ((unsigned char)*in & 0060))
                            return -1;
                    }
                }
                /* Where the boolean (expect > 2) is true, we will need
                 * an extra word for the output.
                 */
                if (*outwords < (size_t)(expect > 2) + 1)
                    break; /* buffer full */
                while (expect--)
                {
                    /* Multibyte Continuation must be legal */
                    if (((ch = (unsigned char)*(in++)) & 0300) != 0200)
                        return -1;
                    newch <<= 6;
                    newch |= (ch & 0077);
                }
                *inbytes -= eating;
                /* newch is now a true ucs-4 character
                 *
                 * now we need to fold to ucs-2
                 */
                if (newch < 0x10000)
                {
                    --*outwords;
                    *(out++) = (wchar_t) newch;
                }
                else
                {
                    *outwords -= 2;
                    newch -= 0x10000;
                    *(out++) = (wchar_t) (0xD800 | (newch >> 10));
                    *(out++) = (wchar_t) (0xDC00 | (newch & 0x03FF));
                }
            }
        }
    }
    /* Buffer full 'errors' aren't errors, the client must inspect both
     * the inbytes and outwords values
     */
    return 0;
}

/**
 * Convert a Unicode string to UTF-8.
 *
 * @param in input
 * @param inwords number of words in input
 * @param out output
 * @param outbytes number of bytes in output
 *
 * @return <code>0</code> if successful; <code>-1</code> otherwise
 */
static int _conv_ucs2_to_utf8(wchar_t *in, size_t *inwords, char *out, size_t *outbytes)
{
    long newch, require;
    size_t need;
    char *invout;
    int ch;

    while (*inwords && *outbytes)
    {
        ch = (unsigned short)(*in++);
        if (ch < 0x80)
        {
            --*inwords;
            --*outbytes;
            *(out++) = (unsigned char) ch;
        }
        else
        {
            if ((ch & 0xFC00) == 0xDC00) {
                /* Invalid Leading ucs-2 Multiword Continuation Character
                 */
                return -1;
            }
            if ((ch & 0xFC00) == 0xD800) {
                /* Leading ucs-2 Multiword Character
                 */
                if (*inwords < 2) {
                    /* Missing ucs-2 Multiword Continuation Character
                     */
                    return -1;
                }
                if (((unsigned short)(*in) & 0xFC00) != 0xDC00) {
                    /* Invalid ucs-2 Multiword Continuation Character
                     */
                    return -1;
                }
                newch = (ch & 0x03FF) << 10 | ((unsigned short)(*in++) & 0x03FF);
                newch += 0x10000;
            }
            else {
                /* ucs-2 Single Word Character
                 */
                newch = ch;
            }
            /* Determine the absolute minimum utf-8 bytes required
             */
            require = newch >> 11;
            need = 1;
            while (require)
                require >>= 5, ++need;
            if (need >= *outbytes)
                break; /* Insufficient buffer */
            *inwords -= (need > 2) + 1;
            *outbytes -= need + 1;
            /* Compute the utf-8 characters in last to first order,
             * calculating the lead character length bits along the way.
             */
            ch = 0200;
            out += need + 1;
            invout = out;
            while (need--) {
                ch |= ch >> 1;
                *(--invout) = (unsigned char)(0200 | (newch & 0077));
                newch >>= 6;
            }
            /* Compute the lead utf-8 character and move the dest offset
             */
            *(--invout) = (unsigned char)(ch | newch);
        }
    }
    /* Buffer full 'errors' aren't errors, the client must inspect both
     * the inwords and outbytes values
     */
    return 0;
}



/*----------------------------------------------------------- Public methods */


size_t utf8_to_ucs2(wchar_t *out, const char *in, size_t count)
{
    size_t inbytes, outwords;

    inbytes = strlen(in);
    outwords = count - 1;
    _conv_utf8_to_ucs2(in, &inbytes, out, &outwords);
    * (out + count - outwords - 1) = 0;
    return count - outwords;
}

size_t ucs2_to_utf8(char *out, const wchar_t *in, size_t count)
{
    size_t total, inwords, outbytes;

    total = inwords = wcslen(in);
    outbytes = count - 1;
    _conv_ucs2_to_utf8((wchar_t *) in, &inwords, out, &outbytes);
    * (out + count - outbytes - 1) = 0;
    return total - inwords;
}
