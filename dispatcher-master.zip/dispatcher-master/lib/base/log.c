/*
 * Copyright (c) 2008 Day Management AG
 * Barfuesserplatz 6, 4001 Basel, Switzerland
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Day Management AG, ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Day.
 */
#include <stdarg.h>

#include "base/base.h"

/**
 * Display name of log levels
 */
static const char *log_level_names[] = {
    NULL,
    "error",
    "warn",
    "info",
    "debug",
    "trace"
};

/**
 * Our log context.
 */
struct log_context {
    /* log level */
    enum log_level level;
    /* custom log callback */
    void (*do_log)(enum log_level level, int errnum, const char *msg);
};

/**
 * Initialize our log context.
 */
static struct log_context default_lc = { LL_WARN, NULL };

/**
 * Pointer will be set on init.
 */
static struct log_context *init_lc = NULL;

/*----------------------------------------------------------- Public methods */

void log_init(struct log_context **lc, enum log_level level,
              void (*do_log)(enum log_level level, int errnum, const char *msg))
{
    if (init_lc != NULL) {
        printf("log_init() called twice\n");
    } else {
        default_lc.level = level;
        default_lc.do_log = do_log;
        init_lc = &default_lc;
    }
    *lc = init_lc;
}

void log_out(struct log_context *lc, enum log_level level, int errnum, const char *fmt, ...)
{
    char *date, msg[2048];
    time_t now;
    va_list args;

    if (init_lc == NULL) {
        printf("log_init() has never been called\n");
        abort();
    }
    if (lc != init_lc) {
        printf("Bad log context, expected: %p, actual: %p\n", init_lc, lc);
        abort();
    }
    if (level > lc->level) {
        return;
    }

    va_start(args, fmt);
    vsnprintf(msg, sizeof(msg), fmt, args);
    va_end(args);

    if (lc->do_log != NULL) {
        lc->do_log(level, errnum, msg);
        return;
    }

    now = time(NULL);
    date = ctime(&now);
    if (date != NULL && strlen(date) == 25) {
        printf("[%.24s] [%s] %s\n", date, log_level_names[level], msg);
    } else {
        printf("[%s] %s\n", log_level_names[level], msg);
    }
}

int log_is_enabled(struct log_context *lc, enum log_level level)
{
    return level <= lc->level ? 1 : 0;
}

void set_log_level(struct log_context *lc, enum log_level level)
{
    lc->level = level;
}

enum log_level parse_log_level(const char *s, enum log_level default_level)
{
    enum log_level level;

    if (s == NULL) {
        return default_level;
    }
    for (level = LL_ERROR; level <= LL_TRACE; level++) {
        if (!strcasecmp(log_level_names[level], s)) {
            return level;
        }
    }
    return default_level;
}
