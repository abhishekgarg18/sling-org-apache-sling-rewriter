/*
 * Copyright (c) 2010 Day Management AG
 * Barfuesserplatz 6, 4001 Basel, Switzerland
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Day Management AG, ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Day.
 */
#ifndef __HDRARRAY_H___
#define __HDRARRAY_H___

/**
 * @file hdrarray.h
 * @brief Header array
 */

/**
 * @defgroup base Base functionality
 * @{
 */

/**
 * @defgroup hdrarray Header array
 * @{
 */

/**
 * Create a header array.
 *
 * @param capacity initial capacity of array
 *
 * @return header array or <code>NULL</code>
 */
struct hdrarray *create_hdrarray(int capacity);

/**
 * Add a name/value pair, with caller-supplied memory, i.e. name and
 * value are not duplicated and should therefore remain valid for the
 * entire lifetime of this header array.
 *
 * @param hdra header array
 * @param name name
 * @param value value
 */
void hdrarray_add(struct hdrarray *hdra, const char *name, const char *value);

/**
 * Return name/value at an index.
 *
 * @param hdra header array
 * @param index index
 * @param name where to return name
 * @param value where to return value
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
int hdrarray_at(struct hdrarray *hdra, int index, const char **name, const char **value);

/**
 * Return size of header array.
 *
 * @param hdra header array
 *
 * @return size of array
 */
int hdrarray_size(struct hdrarray *hdra);

/**
 * Free header array
 *
 * @param hdra header array
 */
void hdrarray_free(struct hdrarray *hdra);

/** @} */
/** @} */

#endif /* __HDRARRAY_H___ */
