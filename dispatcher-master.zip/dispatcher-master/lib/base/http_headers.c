/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2018 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

#include <string.h>
#include <stdlib.h>

#include "base.h"

/**
 * A structure holding a collection of HTTP headers.
 */
struct http_headers {
    /* array of http_headers */
    struct ptrarray *array;
    /* map associating names with element chain in headers */
    struct hashtable *names;
};


/*---------------------------------------------------------- Private methods */

/**
 * Add a pre-filled header.
 *
 * @param headers HTTP headers
 * @param header header
 */
static void add_header(struct http_headers *headers, struct http_header *header) {
    struct http_header *sibling;
    char lwrname[8192];

    strlwrncpy(lwrname, sizeof(lwrname), header->name);

    sibling = hashtable_get(headers->names, lwrname);
    while (sibling && sibling->next) {
        sibling = sibling->next;
    }
    if (sibling) {
        sibling->next = header;
    } else {
        hashtable_put(headers->names, lwrname, header, NULL);
    }
    ptrarray_add(headers->array, header);
}

/**
 * Callback used to free a single HTTP header.
 *
 * @param header header to free, may be <code>NULL</code>
 */
static void free_header(struct http_header *header) {
    if (header) {
        free(header->line);
        free(header->name);
        free(header->value);
        free(header);
    }
}


/*----------------------------------------------------------- Public methods */

struct http_headers *create_http_headers() {
    struct http_headers *headers;

    headers = malloc(sizeof(struct http_headers));
    memset(headers, 0, sizeof(struct http_headers));

    if (create_ptrarray(&headers->array, 50, (void (*)(void *)) free_header) ||
        create_hashtable(&headers->names, 20)) {

        return NULL;
    }
    return headers;
}

struct http_header * http_headers_add_nv(struct http_headers *headers, const char *name, const char *value) {
    struct http_header *header;

    header = malloc(sizeof(struct http_header));
    memset(header, 0, sizeof(struct http_header));

    header->name = strdup(name);
    header->value = strdup(value);

    add_header(headers, header);
    return header;
}

struct http_header *http_headers_add(struct http_headers *headers, const char *line) {
    struct http_header *header;
    const char *name = line, *value;

    value = strchr(line, ':');
    if (!value) {
        return NULL;
    }

    header = malloc(sizeof(struct http_header));
    memset(header, 0, sizeof(struct http_header));

    header->line = strdup(line);
    header->name = strnumdup(name, (size_t) (value - name));

    value++;
    while (WS(*value)) {
        value++;
    }
    header->value = strdup(value);

    add_header(headers, header);
    return header;
}

struct http_header *http_headers_get(struct http_headers *headers, const char *name) {
    return (struct http_header *) hashtable_get(headers->names, name);
}

time_t http_headers_get_date(struct http_headers *headers, const char *name) {
    struct http_header *header;

    if ((header = hashtable_get(headers->names, name)) == NULL) {
        return -1;
    }
    return date_parse_http(header->value);
}

long long http_headers_get_llong(struct http_headers *headers, const char *name) {
    struct http_header *header;

    if ((header = hashtable_get(headers->names, name)) == NULL) {
        return -1;
    }
    return atoll(header->value);
}

int http_headers_is(struct http_headers *headers, const char *name, const char *value, const char **line)  {
    struct http_header *header;

    header = hashtable_get(headers->names, name);
    while (header) {
        if (!strcmp(header->value, value)) {
            if (line) {
                *line = header->line;
            }
            return 1;
        }
        header = header->next;
    }
    return 0;
}

int http_headers_is_one_of(struct http_headers *headers, const char *name, const char **values, const char **line)  {
    struct http_header *header;
    const char **s;

    header = hashtable_get(headers->names, name);
    while (header) {
        for (s = values; *s != NULL; s++) {
            if (strstr(header->value, *s) != NULL) {
                if (line) {
                    *line = header->line;
                }
                return 1;
            }
        }
        header = header->next;
    }
    return 0;
}

struct http_header *http_headers_at(struct http_headers *headers, int index) {
    return ptrarray_at(headers->array, (unsigned) index);
}

int http_headers_size(struct http_headers *headers) {
    return ptrarray_size(headers->array);
}

void http_headers_clear(struct http_headers *headers) {
    ptrarray_clear(headers->array);
    hashtable_clear(headers->names);
}

void http_headers_free(struct http_headers *headers) {
    if (headers) {
        ptrarray_free(headers->array);
        hashtable_free(headers->names);
        free(headers);
    }
}
