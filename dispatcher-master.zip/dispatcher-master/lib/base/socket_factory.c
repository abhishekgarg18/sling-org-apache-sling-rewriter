/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2019 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

#include "base/base.h"

/**
 * Structures
 */
struct socket_factory {
    struct connection_factory base;
    struct hashtable *pool;
    struct lock *lock;
    int pooled;
    int timeout;
    char errormsg[256];
};

struct socket_connection {
    struct connection base;
    struct socket_factory *factory;
    struct socket *sock;
    struct log_context *lc;
    char key[256];
    time_t lastused;
};

/**
 * Macros
 */
#define SET_FERR(fmt, ...) snprintf(factory->errormsg, sizeof factory->errormsg, fmt, __VA_ARGS__)

/**
 * Forward declarations
 */
static void connection_close(struct connection * base, int reuse);
static void connection_free(struct socket_connection *conn);

/**
 * Pool methods
 */
static const char * pool_hash(struct endpoint *ep, char *buf, size_t buf_len)
{
    snprintf(buf, buf_len, "%s:%d", ep->host, ep->port);
    return buf;
}

static struct connection *pool_get(struct log_context *lc, struct socket_factory *factory,
                                   struct endpoint *ep)
{
    struct socket_connection *conn;
    struct ptrlist *conns;
    time_t now;
    double t;
    char key[256];

    if (lock_acquire(factory->lock)) {
        return NULL;
    }

    conns = hashtable_get(factory->pool, pool_hash(ep, key, sizeof(key)));
    if (conns == NULL) {
        /* Backend was never contacted before */
        lock_release(factory->lock);
        return NULL;
    }

    for (;;) {
        conn = ptrlist_remove(conns);
        if (conn == NULL) {
            /* No more pooled sockets left */
            lock_release(factory->lock);
            return NULL;
        }

        time(&now);
        t = difftime(now, conn->lastused);

        if (t < factory->timeout) {
            lock_release(factory->lock);
            conn->lc = lc;
            return &conn->base;
        }

        DBG("Dropping socket after %.0f seconds of inactivity: %s", t, key);
        connection_free(conn);
    }
}

static void pool_put(struct log_context *lc, struct socket_factory *factory,
                     struct socket_connection *conn)
{
    struct ptrlist *conns;

    if (lock_acquire(factory->lock)) {
        WARN("Unable to put connection back in pool, closing: %s", conn->key);
        connection_free(conn);
        return;
    }
    conns = hashtable_get(factory->pool, conn->key);
    if (conns == NULL) {
        create_ptrlist(&conns, NULL);
        hashtable_put(factory->pool, conn->key, conns, NULL);
    }

    conn->lastused = time(NULL);
    conn->lc = NULL;
    ptrlist_add(conns, conn);

    lock_release(factory->lock);
}

static void pool_clear(struct socket_factory *factory)
{
    struct ptrlist *conns;
    struct ptr_entry *conn;
    struct ht_entry *entry;
    const char *key;
    const void *value;

    if (lock_acquire(factory->lock)) {
        return;
    }
    for (entry = hashtable_first(factory->pool); entry != NULL; entry = hashtable_next(entry)) {
        hashtable_getentry(entry, &key, &value);

        conns = (struct ptrlist *) value;
        for (conn = ptrlist_first(conns); conn != NULL; conn = ptrlist_next(conn)) {
            connection_free((struct socket_connection *) ptrlist_get(conn));
        }
        ptrlist_free(conns);
    }
    hashtable_clear(factory->pool);
    lock_release(factory->lock);
}

/**
 * Addrinfo methods
 */
static struct addrinfo * get_addrinfo(
    struct socket_factory *factory, struct endpoint *ep, struct addrinfo **freeai
) {
    struct addrinfo *ai = ep->ai, hints;
    struct ip_info_vtable *vtbl = ep->ipv4 ? &IPv4_VTABLE : &IPv6_VTABLE;
    int ret;
    char service[10];

    *freeai = NULL;
    if (!ai) {
        memset(&hints, 0, sizeof hints);
        hints.ai_family = AF_UNSPEC;
        hints.ai_socktype = SOCK_STREAM;
        hints.ai_flags = AI_NUMERICSERV;
        snprintf(service, sizeof(service), "%d", ep->port);

        if ((ret = vtbl->getaddrinfo(ep->host, service, &hints, &ai))) {
            SET_FERR("Looking up host failed (%s): %s.", ep->host, vtbl->gai_strerror(ret));
            return NULL;
        }
        *freeai = ai;
    }
    return ai;
}

static void free_addrinfo(struct endpoint *ep, struct addrinfo *ai)
{
    struct ip_info_vtable *vtbl = ep->ipv4 ? &IPv4_VTABLE : &IPv6_VTABLE;
    if (ai != NULL) {
        vtbl->freeaddrinfo(ai);
    }
}

/**
 * Connection methods
 */
static int connection_read(struct connection *base, void *buf , size_t buf_len)
{
    struct socket_connection *conn = (struct socket_connection *) base->reserved;
    return socket_recv(conn->lc, conn->sock, buf, buf_len, 1);
}

static int connection_write(struct connection *base, const void *buf,
                            size_t buf_len)
{
    struct socket_connection *conn = (struct socket_connection *) base->reserved;
    return socket_send(conn->lc, conn->sock, buf, buf_len);
}

static int connection_flush(struct connection *base)
{
    struct socket_connection *conn = (struct socket_connection *) base->reserved;
    return socket_flush(conn->lc, conn->sock);
}

static int connection_errcode(struct connection *base)
{
    return socket_errno();
}

static const char * connection_errmsg(struct connection *base)
{
    struct socket_connection *conn = (struct socket_connection *) base->reserved;
    return socket_errstring(conn->sock);
}

static int connection_reused(struct connection *base)
{
    struct socket_connection *conn = (struct socket_connection *) base->reserved;
    return conn->lastused != 0;
}

static struct connection connection_base = {
    connection_read,
    connection_write,
    connection_flush,
    connection_close,
    connection_errcode,
    connection_errmsg,
    connection_reused,
    NULL
};

static struct connection *make_connection(struct log_context *lc, struct socket_factory *factory,
                                          struct endpoint *ep, struct addrinfo *ai)
{
    struct socket_connection *conn;
    struct socket *sock;
    int flag;

#ifdef WITH_SSL
    if (ep->secure) {
        sock = sslsocket_create(lc, ai, ep->host);
    } else
#endif
    {
        sock = socket_create(lc, ai);
    }
    if (sock == NULL) {
        SET_FERR("Unable to create socket: %s", socket_errstring(NULL));
        return NULL;
    }

    if (socket_connect(lc, sock, ai->ai_addr, ai->ai_addrlen, ep->timeout)) {
        SET_FERR("Unable to connect socket to %s:%d: %s", ep->host, ep->port, socket_errstring(sock));
        socket_close(lc, sock);
        return NULL;
    }

    socket_set_receive_timeout(sock, ep->receive_timeout);
    flag = 1;
    socket_set_option(sock, IPPROTO_TCP, TCP_NODELAY, (char *) &flag, sizeof(int));

    conn = malloc(sizeof(struct socket_connection));
    memset(conn, 0, sizeof(struct socket_connection));

    memcpy(&conn->base, &connection_base, sizeof(connection_base));
    conn->base.reserved = conn;
    conn->factory = factory;
    conn->sock = sock;
    conn->lc = lc;
    pool_hash(ep, conn->key, sizeof(conn->key));

    return &conn->base;
}

static void connection_free(struct socket_connection *conn)
{
    socket_close(conn->lc, conn->sock);
    free(conn);
}

static void connection_close(struct connection *base, int reuse)
{
    struct socket_connection *conn = (struct socket_connection *) base->reserved;
    struct log_context *lc = conn->lc;

    if (reuse && conn->factory->pooled) {
        DBG("Storing socket for later reuse: %s", conn->key);
        pool_put(lc, conn->factory, conn);
    } else {
        connection_free(conn);
    }
}

/**
 * Global instance of our socket factory
 */
static struct socket_factory socket_factory;

/**
 * Factory methods
 */
static struct connection *connection_create(struct log_context *lc, struct connection_factory *base,
                                            void *params, size_t params_len, int reuse)
{
    struct socket_factory *factory = (struct socket_factory *) base->reserved;
    struct endpoint *ep = (struct endpoint *) params;
    struct connection *conn = NULL;
    struct addrinfo *ai, *freeai, *current;

    // Find a pooled connection if any
    if (factory->pooled && reuse) {
        conn = pool_get(lc, factory, ep);
        if (conn != NULL) {
            DBG("Reusing connection: %s:%d", ep->host, ep->port);
            return conn;
        }
        DBG("Creating new connection: %s:%d", ep->host, ep->port);
    }

    // No pooled connection, need to make a new one
    ai = get_addrinfo(factory, ep, &freeai);
    if (ai == NULL) {
        return NULL;
    }
    for (current = ai; current != NULL; current = current->ai_next) {
        conn = make_connection(lc, factory, ep, current);
        if (conn != NULL) {
            break;
        }
    }
    free_addrinfo(ep, freeai);
    return conn;
}

static const char * factory_errmsg(struct connection_factory *base)
{
    struct socket_factory *factory = (struct socket_factory *) base->reserved;
    return factory->errormsg;
}

int factory_keepalive(struct connection_factory *base)
{
    struct socket_factory *factory = (struct socket_factory *) base->reserved;
    return factory->pooled;
}

static struct connection_factory factory_base = {
    connection_create,
    factory_keepalive,
    factory_errmsg,
    NULL
};

void init_socket_factory(struct log_context *lc, int pooled, int timeout)
{
    struct socket_factory *factory = &socket_factory;
    struct connection_factory *base;

    base = &factory->base;
    if (base->create != NULL) {
        return;
    }

    memcpy(base, &factory_base, sizeof(factory_base));
    base->reserved = factory;

    if (pooled) {
        factory->lock = create_lock(lc);
        if (factory->lock != NULL) {
            factory->timeout = timeout;
            create_hashtable(&factory->pool, 10);
        } else {
            pooled = 0;
        }
    }
    factory->pooled = pooled;
}

struct connection_factory *get_socket_factory()
{
    struct connection_factory *factory;

    factory = &socket_factory.base;
    if (factory->create == NULL) {
        init_socket_factory(NULL, 0, 0);
    }
    return &socket_factory.base;
}

void free_socket_factory()
{
    struct socket_factory *factory = &socket_factory;
    struct connection_factory *base;

    base = &factory->base;
    if (base->create != NULL) {
        if (factory->pooled) {
            pool_clear(factory);
            lock_free(factory->lock);
            hashtable_free(factory->pool);
        }
    }
    memset(&socket_factory, 0, sizeof socket_factory);
}
