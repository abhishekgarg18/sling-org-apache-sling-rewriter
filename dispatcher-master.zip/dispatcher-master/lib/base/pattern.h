/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * __________________
 *
 *  Copyright 2016 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

#ifndef __PATTERN_H__
#define __PATTERN_H__

#ifdef WIN32
/*************************************************
 *      Perl-Compatible Regular Expressions      *
 *************************************************/

/*
This is a library of functions to support regular expressions whose syntax
and semantics are as close as possible to those of the Perl 5 language. See
the file Tech.Notes for some information on the internals.

This module is a wrapper that provides a POSIX API to the underlying PCRE
functions.

Written by: Philip Hazel <ph10@cam.ac.uk>

           Copyright (c) 1997-2004 University of Cambridge

-----------------------------------------------------------------------------
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice,
      this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.

    * Neither the name of the University of Cambridge nor the names of its
      contributors may be used to endorse or promote products derived from
      this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
-----------------------------------------------------------------------------
*/

#   include <pcreposix.h>
#else
#   include <regex.h>
#endif

/**
 * @file pattern.h
 * @brief Glob patterns and regular expressions.
 */

/**
 * @defgroup base Base functionality
 * @{
 */

/**
 * @defgroup pattern Glob patterns and regular expressions.
 * @{
 */

/**
 * Pattern type enumeration
 */
enum pattern_type {
    /** Glob */
    GLOB = 1,
    /** Regular expression */
    REGEX,
    /** NONE (i.e. it matches the NULL string only) */
    NONE,
    /** ANY (i.e. it matches everything, including NULL) */
    ANY
};

/**
 * Pattern declaration. Memory for this structure is user allocated and initialized
 * on <code>create_pattern</code>.
 */
struct pattern {
    /* A pattern is either a glob pattern or a regular expression */
    union {
        /* A glob pattern */
        char *glob;
        /* A regular expression */
        regex_t regex;
    };
    /* Pattern type */
    enum pattern_type type;
};

/**
 * Create pattern from an any item. Depending on the type of the item (STRING or REGEXP),
 * a glob pattern or regular expression is created.
 *
 * @param p pattern to initialize
 * @param item to create pattern from.
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
int create_pattern(struct log_context *lc, struct pattern *p, struct any_item *item);

/**
 * Create glob pattern from a string.
 *
 * @param p pattern to initialize
 * @param glob glob pattern
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
int create_glob_pattern(struct pattern *p, const char *glob);

/**
 * Create regular expression pattern from a string.
 *
 * @param p pattern to initialize
 * @param regex regular expression
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
int create_regex_pattern(struct log_context *lc, struct pattern *p, const char *regex);

/**
 * Match an input string against a pattern, which is either a regular
 * expression or a glob pattern.
 *
 * @param p pattern
 * @param s input string
 *
 * @return <code>1</code> if there's a match;
 *         <code>0</code> otherwise
 */
int pattern_match(struct log_context *lc, struct pattern *p, const char *s);

/**
 * Free pattern.
 *
 * @param p pattern
 */
void pattern_free(struct pattern *p);

/** @} */
/** @} */

#endif /* _PATTERN_H__ */
