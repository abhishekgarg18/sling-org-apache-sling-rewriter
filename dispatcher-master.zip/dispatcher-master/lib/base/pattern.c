/*
 * Copyright (c) 2010 Day Management AG
 * Barfuesserplatz 6, 4001 Basel, Switzerland
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Day Management AG, ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Day.
 */
#include "base/base.h"


/*----------------------------------------------------------- Public methods */


int create_pattern(struct log_context *lc, struct pattern *p, struct any_item *item)
{
    const char *s;

    if (item == NULL || item->value.p == NULL) {
        p->type = ANY;
        return 0;
    }
    s = item->value.p;
    switch (item->type) {
        case REGEXP:
            return create_regex_pattern(lc, p, s);
        case STRING:
            return create_glob_pattern(p, s);
        default:
            return -1;
    }
}

int create_glob_pattern(struct pattern *p, const char *glob)
{
    if (!strcmp(glob, "")) {
        p->type = NONE;
    } else {
        p->glob = strdup(glob);
        p->type = GLOB;
    }
    return 0;
}

/**
 * Compile a regular expression, delimiting it with BOL and EOL symbols ('^<expr>$')
 *
 * @param expr expression to compile
 * @param regex where to store regular expression
 *
 * @return <code>0</code> on success; otherwise call regerror() to get error reason
 */
static int anchored_regcomp(const char *expr, regex_t *regex)
{
    char *anchored_expr;
    size_t anchored_expr_len;
    int ret;

    anchored_expr_len = strlen(expr) + 3;
    anchored_expr = malloc(anchored_expr_len);
    snprintf(anchored_expr, anchored_expr_len, "^%s$", expr);
    ret = regcomp(regex, anchored_expr, REG_EXTENDED | REG_NOSUB);
    free(anchored_expr);

    return ret;
}

int create_regex_pattern(struct log_context *lc, struct pattern *p, const char *regex)
{
    char msg[256];
    int ret;

    if (!strcmp(regex, "")) {
        /* An empty regular expression will not compile anyway: use it as a "NULL" match */
        p->type = NONE;
    } else {
        ret = anchored_regcomp(regex, &p->regex);
        if (ret != 0) {
            regerror(ret, &p->regex, msg, sizeof msg);
            ERR("Compiling regular expression '%s' failed: %s.", regex, msg);
            return -1;
        }
        p->type = REGEX;
    }
    return 0;
}

int pattern_match(struct log_context *lc, struct pattern *p, const char *s)
{
    int ret;

    if (s == NULL) {
        /* A NULL input matches a NULL pattern or a missing entry */
        return p->type == ANY || p->type == NONE ? 1 : 0;
    }
    switch (p->type) {
        case REGEX:
            ret = regexec(&p->regex, s, 0, NULL, 0);
            switch (ret) {
                case 0:
                    return 1;
                case REG_NOMATCH:
                    return 0;
                default:
                    WARN("Executing regular expression with input '%s' failed.", s);
                    return 0;
            }
        case GLOB:
            return strglobcmp(p->glob, s) == 0 ? 1 : 0;
        case ANY:
            return 1;
        case NONE:
            return 0;
    }
    /* Avoid compiler warning */
    return 0;
}

void pattern_free(struct pattern *p)
{
    switch (p->type) {
        case REGEX:
            regfree(&p->regex);
            break;
        case GLOB:
            free(p->glob);
            break;
        default:
            break;
    }
}
