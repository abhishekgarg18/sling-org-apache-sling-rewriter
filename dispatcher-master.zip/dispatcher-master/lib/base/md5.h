/*
 * Copyright (c) 2008 Day Management AG
 * Barfuesserplatz 6, 4001 Basel, Switzerland
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Day Management AG, ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Day.
 */
#ifndef __MD5_H__
#define __MD5_H__

/**
 * @file md5.h
 * @brief MD5 encoding/decoding
 */

/**
 * @defgroup base Base functionality
 * @{
 */

/**
 * @defgroup md5 MD5 encoding/decoding
 * @{
 */

/**
 * Compute MD5 digest of input.
 *
 * @param digest digest
 * @param input input
 */
void md5_simple(unsigned char digest[16], char *input);

/** @} */
/** @} */

#endif /* __MD5_H__ */
