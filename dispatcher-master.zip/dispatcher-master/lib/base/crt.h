/*
 * Copyright (c) 2008 Day Management AG
 * Barfuesserplatz 6, 4001 Basel, Switzerland
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Day Management AG, ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Day.
 */
#ifndef __CRT_H__
#define __CRT_H__

#ifdef __cplusplus
extern "C"
{
#endif

/* Maximum size for path, given in characters */
#undef PATH_MAX
#define PATH_MAX 4096

#ifndef NAME_MAX
#define NAME_MAX 255
#endif

/* Define S_ISDIR macro */
#undef S_ISDIR
#define S_ISDIR(m) (((m) & _S_IFDIR) != 0)

/* Define S_IFLNK and S_ISLNK macros */
#define _S_IFLNK 0x0800
#define S_ISLNK(m) (((m) & _S_IFLNK) != 0)

/**
 * Directory stream API: opendir/readdir_r/closedir
 */
#ifndef HAVE_OPENDIR

/* Directory entry structure */
struct dirent {
    /* entry name */
    char d_name[260];
    /* entry type */
    short d_type;
};

#define DT_UNKNOWN  0
#define DT_DIR      4
#define DT_REG      8

/* Directory stream */
typedef struct DIR DIR;

DIR *opendir(const char *dirname);
struct dirent *readdir(DIR *dirp);
int readdir_r(DIR *dirp, struct dirent *entry, struct dirent **result);
int closedir(DIR *dirp);

#endif /* HAVE_OPENDIR */

/**
 * Sleep for an amount of seconds.
 */
#ifndef HAVE_SLEEP
unsigned int sleep(unsigned int seconds);
#endif /* HAVE_SLEEP */

/* Functions not available in Windows CRT */
char *realpath(const char *filename, char *resolved);
int utime(const char *path, struct utimbuf *times);
int fstat(int fildes, struct stat *buf);
int lstat(const char *filename, struct stat *stat);

#ifndef __MINGW32__
int gettimeofday(struct timeval *tv, struct timezone *tz);
#define atoll _atoi64
#endif

/* Function replacements */
int crt_open(const char *filename, int oflag, int pmode);
FILE *crt_fopen(const char *filename, const char *mode);
int crt_mkdir(const char *dirname);
int crt_stat(const char *filename, struct stat *stat);
int crt_rename(const char *old, const char *new);
int crt_remove(const char *path);
int crt_unlink(const char *path);
char *crt_mktemp(char *template);
int crt_snprintf(char *str, size_t str_m, const char *fmt, /*args*/ ...);
time_t crt_time(time_t *tloc);

/* Redefine CRT functions to use replacements */
#ifndef __CRT_C__

#define open(f,o,p) crt_open(f,o,p)
#define fopen(f,m)  crt_fopen(f,m)
#define mkdir(p,m)  crt_mkdir(p)
#define stat(f,s)   crt_stat(f,s)
#define rename(o,n) crt_rename(o,n)
#define remove(p)   crt_remove(p)
#define unlink(p)   crt_unlink(p)
#define mktemp(t)   crt_mktemp(t)
#define time(t)     crt_time(t)
#define snprintf    crt_snprintf

/* MSVCRT.LIB does not export getpid, although it is declared */
#define getpid      GetCurrentProcessId

/* Define CRT functions with their _ counterpart */
#define vsnprintf   _vsnprintf

/* Define strcasecmp/strncasecmp */
#ifndef strcasecmp
#define strcasecmp  stricmp
#endif

#ifndef strncasecmp
#define strncasecmp strnicmp
#endif

#endif /* __CRT_C__ */

#ifdef __cplusplus
}
#endif

#endif /* __CRT_H__ */
