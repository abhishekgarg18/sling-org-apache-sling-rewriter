/*
 * Copyright (c) 2010 Day Management AG
 * Barfuesserplatz 6, 4001 Basel, Switzerland
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Day Management AG, ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Day.
 */
#ifndef __HASHTABLE_H___
#define __HASHTABLE_H___

/**
 * @file hashtable.h
 * @brief Hashtable
 */

/**
 * @defgroup base Base functionality
 * @{
 */

/**
 * @defgroup hash Hashtable
 * @{
 */

/**
 * Declaration of a hash table.
 */
struct hashtable;

/**
 * Declaration of a hash table entry.
 */
struct ht_entry;

/**
 * Create a hash table.
 *
 * @param ht where to return hash table
 * @param size size of table
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
int create_hashtable(struct hashtable **ht, int size);

/**
 * Duplicate a hash table.
 *
 * @param dest where to return the duplicate
 * @param src source hash table
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
int hashtable_dup(struct hashtable **dest, struct hashtable *src);

/**
 * Return string associated with a key. The value returned must not
 * be modified.
 *
 * @param ht hash table
 * @param s key
 *
 * @return value or <code>NULL</code>
 */
const char *hashtable_gets(struct hashtable *ht, const char *s);

/**
 * Associate a string with a key.
 *
 * @param ht hash table
 * @param s key
 * @param p value
 *
 * @return previous value (must be freed by caller) or <code>NULL</code>
 */
char *hashtable_puts(struct hashtable *ht, const char *s, const char *p);

/**
 * Return value associated with a key.
 *
 * @param ht hash table
 * @param s key
 *
 * @return value or <code>NULL</code>
 */
void *hashtable_get(struct hashtable *ht, const char *s);

/**
 * Associate a value with a key.
 *
 * @param ht hash table
 * @param s key
 * @param p value
 * @param free_p method to call when disposing value
 *
 * @return previous value (must be freed by caller) or <code>NULL</code>
 */
void *hashtable_put(struct hashtable *ht, const char *s, void *p, void (*free_p)(void *p));

/**
 * Return first entry for iterating over hashtable entries.
 *
 * @return first entry or <code>NULL</code> if the table is empty
 */
struct ht_entry *hashtable_first(struct hashtable *ht);

/**
 * Return next entry for iterating over hashtable entries.
 *
 * @param last entry obtained
 *
 * @return next entry or <code>NULL</code> if there is no next entry
 */
struct ht_entry *hashtable_next(struct ht_entry *last);

/**
 * Return name and value associated with entry
 *
 * @param entry entry
 * @param key where to return key
 * @param p where to return value
 */
void hashtable_getentry(struct ht_entry *entry, const char **key, const void **p);

/**
 * Remove an entry from the hashtable.
 *
 * @param ht hash table
 * @param key key to entry to remove
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
int hashtable_remove(struct hashtable *ht, const char *key);

/**
 * Clear all entries in a hashtable.
 *
 * @param ht hashtable
 */
void hashtable_clear(struct hashtable *ht);

/**
 * Return the size of a hashtable.
 *
 * @param ht hashtable
 */
int hashtable_size(struct hashtable *ht);

/**
 * Free memory associated with a hash table.
 *
 * @param ht hash table, may be <code>NULL</code>
 */
void hashtable_free(struct hashtable *ht);

/** @} */
/** @} */

#endif /* __HASHTABLE_H___ */
