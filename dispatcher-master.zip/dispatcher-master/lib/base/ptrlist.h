/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * __________________
 *
 *  Copyright 2016 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

#ifndef __PTRLIST_H___
#define __PTRLIST_H___

/**
 * @file ptrlist.h
 * @brief Pointer list
 */

/**
 * @defgroup base Base functionality
 * @{
 */

/**
 * @defgroup ptrlist Pointer list
 * @{
 */

/**
 * Declaration of a pointer list.
 */
struct ptrlist;

/**
 * Declaration of a pointer entry.
 */
struct ptr_entry;

/**
 * Create a pointer list.
 *
 * @param pl where to return list
 * @param free_p method to call when disposing pointers
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
int create_ptrlist(struct ptrlist **pl, void (*free_p)(void *p));

/**
 * Return the first entry in list
 *
 * @param pl pointer list
 *
 * @return first entry in list or <code>NULL</code> if the list is empty
 */
struct ptr_entry *ptrlist_first(struct ptrlist *pl);

/**
 * Return the next entry in list, given some entry
 *
 * @param last last entry returned
 *
 * @return next entry in list or <code>NULL</code> if there are no more entries
 */
struct ptr_entry *ptrlist_next(struct ptr_entry *last);

/**
 * Return a pointer given its entry
 *
 * @param entry pointer entry
 *
 * @return pointer
 */
void *ptrlist_get(struct ptr_entry *entry);

/**
 * Add a pointer to the end of the list.
 *
 * @param pl pointer list
 * @param p pointer
 */
void ptrlist_add(struct ptrlist *pl, void *p);

/**
 * Remove the first pointer from the list and return it.
 *
 * @param pl pointer list
 *
 * @return first pointer in list or <code>NULL</code> if the list is empty
 */
void *ptrlist_remove(struct ptrlist *pl);

/**
 * Return size of pointer list.
 *
 * @param pl pointer list
 *
 * @return size of list
 */
int ptrlist_size(struct ptrlist *pl);

/**
 * Free pointer list
 *
 * @param pl pointer list, may be <code>NULL</code>
 */
void ptrlist_free(struct ptrlist *pl);

/** @} */
/** @} */

#endif /* __PTRLIST_H___ */
