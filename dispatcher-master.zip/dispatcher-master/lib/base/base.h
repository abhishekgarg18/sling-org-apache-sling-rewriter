/*
 * Copyright (c) 1999 Day Management AG
 * Barfuesserplatz 6, 4001 Basel, Switzerland
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Day Management AG, ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Day.
 */
#ifndef __BASE_H__
#define __BASE_H__

/**
 * @file base.h
 * @brief Utility routines
 */

/**
 * @defgroup base Base functionality
 * @{
 */

/**
 * @defgroup util Utility routines
 * @{
 */

#include <ctype.h>
#include <fcntl.h>
#include <limits.h>
#include <memory.h>
#include <string.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>

#ifndef WIN32
#include <arpa/inet.h>
#include <dirent.h>

#ifdef _AIX
/* required so hstrerror() is defined */
#define _USE_IRS
#endif /* _AIX */

#include <netdb.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <poll.h>
#include <unistd.h>
#include <utime.h>
#include <sys/resource.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <sys/wait.h>
#else
#include <io.h>
#include <winsock2.h>
#include <ws2tcpip.h>

#ifdef __GNUC__
#include <sys/time.h>
#endif

#include <sys/utime.h>
#endif /* !WIN32 */

#ifdef _CRTDBG_MAP_ALLOC
#include <crtdbg.h>
#endif

#include "base/log.h"
#include "base/acl.h"
#include "base/any.h"
#include "base/buffer.h"
#include "base/connection.h"
#include "base/hashtable.h"
#include "base/hdrarray.h"
#include "base/http_client.h"
#include "base/http_headers.h"
#include "base/lock.h"
#include "base/md5.h"
#include "base/pattern.h"
#include "base/ptrarray.h"
#include "base/ptrlist.h"
#include "base/sbuffer.h"
#include "base/socket.h"
#include "base/socket_factory.h"
#include "base/strarray.h"
#include "base/utf8.h"

#ifdef WITH_SSL
#include "base/sslsocket.h"
#endif

#ifdef WIN32
#include "base/crt.h"
/* avoid including direct.h */
#define _INC_DIRECT
#endif

/**
 * @defgroup util Utility routines
 * @{
 */

/** Definition for whitespace */
#define WS(c)   (c==' ' || c=='\r' || c=='\n' || c=='\t')

/** Definition for non-whitespace */
#define NWS(c)  (!(c==' ' || c=='\r' || c=='\n' || c=='\t' || c==(char)EOF || c==0))

#if (defined(NT) || defined(WIN32))
    /** File separator char */
    #define FILE_SEPARATOR_CHAR '\\'
    /** File separator string */
    #define FILE_SEPARATOR "\\"
#else
    /** File separator char */
    #define FILE_SEPARATOR_CHAR '/'
    /** File separator string */
    #define FILE_SEPARATOR "/"
#endif

/**
 * Trim a string from the left and the right in-place and return a pointer
 * to it.
 *
 * @param string string
 * @param ws array of characters considered whitespace
 * @return pointer to trimmed string
 */
char *trim(char *string, const char *ws);

/**
 * Compare a string against a pattern.
 *
 * @param pattern pattern
 * @param string string
 * @return 0 if the pattern matches; <>0 otherwise
 */
int strglobcmp(const char *pattern, const char *string);

/**
 * Compare a string against a pattern, case-insensitive.
 *
 * @param pattern pattern
 * @param string string
 * @return 0 if the pattern matches; <>0 otherwise
 */
int strglobcasecmp(const char *pattern, const char *string);

/**
 * Read the contents of a file into memory and return a pointer to it.
 *
 * @param filename file to read
 * @return pointer to file contents in memory, NULL if an error occurs
 */
char *mallocbinfile(const char *filename);

/**
 * Thread-safe strtok() replacement.
 */
char *qstrtok(char **ptrc, char **ptrcend, char *subst, char *delim);

/**
 * Convert all characters in <b>src</b> to lower-case and copies them to <b>dest</b>.
 * It is valid to specify the same pointer in <b>src</b> and <b>dest</b>
 *
 * @param dest destination
 * @param src source
 *
 * @return number of characters copied, not including the zero terminator.
 */
int strlwrcpy(char *dest, const char *src);

/**
 * Convert all characters in <b>src</b> to lower-case and copies them to <b>dest</b>.
 * It is valid to specify the same pointer in <b>src</b> and <b>dest</b>. Converts
 * up to <b>dest_len</b> characters, always terminated by a zero.
 *
 * @param dest destination
 * @param dest_len maximum number of bytes to convert
 * @param src source
 *
 * @return number of characters copied, not including the zero terminator.
 */
int strlwrncpy(char *dest, size_t dest_len, const char *src);

/**
 * Make a directory, creating intermediate directories if necessary.
 *
 * @param pathname directory to create
 * @param mode directory creation mode (rwx flags)
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
int mkdirs(const char *pathname, int mode);

/**
 * Create a temporary file. Expects a filename of the form anyfileYYYYXXXXXX and
 * replaces it with a unique, random filename, generating a random string for
 * YYYYYY and calling mktemp(3) with the generated filename.
 *
 * @param tmplt template string
 * @param mode creation mode (rwx flags)
 *
 * @return unique temporary file name or <code>NULL</code> if an error occurred
 */
char *mktemp2(char* tmplt, int mode);

/**
 * Extract the directory part of a pathname. If the path does not contain any path
 * separator characters, <code>.</code> is returned.
 *
 * @param path path name
 * @param dir buffer capable of storing <code>PATH_MAX</code> characters
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure, namely if the directory is too large
 *
 * @note there already is a method called dirname(3)
 */
int dirname2(const char *path, char *dir);

/**
 * Base64 decode.
 *
 * @param src input
 * @param target output
 * @param targsize size of target
 * @return number of decoded bytes
 */
int base64_dec(char const *src, unsigned char *target, size_t targsize);

/**
 * Base64 encode.
 *
 * @param src input
 * @param target output
 * @param targsize size of target
 * @return number of encoded bytes
 */
int base64_enc (unsigned char const *src, char *target, size_t targsize);

/**
 * Find all files in a directory that match a given pattern.
 *
 * @param basedir base directory, that MUST NOT contain glob characters
 * @param glob pattern that may contain '/' as well
 * @param result string array containing all matching files as full path names,
 *               sorted in ascending order
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
int find_files(const char *basedir, char *glob, struct strarray **result);

/**
 * URL encode.
 *
 * @param dst destination buffer
 * @param dstlen sizeof destination
 * @param src source
 * @param spare characters to copy uninterpreted from src to dst, use default set if NULL
 * @return destination
 */
char *urlenc_ex(char *dst, size_t dstlen, const char *src, const char *spare);

/**
 * URL unescape, converting %xx escapes back to UTF-8 characters.
 *
 * @param url url to unencode, in place
 * @return <code>0</code> on success;
 *         <code>-1</code> if a bad escape is found
 */
int url_unescape(char *url);

/**
 * Replace all occurrences of a character in a null-terminated string
 * with another character.
 * @param s string
 * @param from character to find
 * @param to character to replace with
 */
void strrep(char *s, char from, char to);

/**
 * Duplicates at most <b>n</b> characters of a string.
 *
 * @param s source string
 * @param n number of characters
 *
 * @return null-terminated string, containing at most <b>n</b> characters of the
 *         source string.
 */
char *strnumdup(const char *s, size_t n);

/**
 * Escape a string that will be passed as argument in double quotes to a shell.
 *
 * @param s1 output buffer
 * @param s2 input string
 * @param n number of characters in s1
 *
 * @return <code>0</code> if all bytes in s2 were escaped;
 *         <code>-1</code> otherwise
 */
int strescape(char *s1, const char *s2, size_t n);

/**
 * Normalize file name, replacing '/' with '\\' if necessary
 */
#define NORMALIZE_FILENAME(s) \
    if ('/' != FILE_SEPARATOR_CHAR) { strrep((s), '/', FILE_SEPARATOR_CHAR); }

/**
 * Parses an HTTP date in one of three standard forms:
 *
 *     Sun, 06 Nov 1994 08:49:37 GMT  ; RFC 822, updated by RFC 1123
 *     Sunday, 06-Nov-94 08:49:37 GMT ; RFC 850, obsoleted by RFC 1036
 *     Sun Nov  6 08:49:37 1994       ; ANSI C's asctime() format
 *
 * and returns the time_t number of seconds since 1 Jan 1970 GMT,
 * or -1 if this would be out of range or if the date is invalid.
 *
 * The restricted HTTP syntax is
 *
 *     HTTP-date    = rfc1123-date | rfc850-date | asctime-date
 *
 *     rfc1123-date = wkday "," SP date1 SP time SP "GMT"
 *     rfc850-date  = weekday "," SP date2 SP time SP "GMT"
 *     asctime-date = wkday SP date3 SP time SP 4DIGIT
 *
 *     date1        = 2DIGIT SP month SP 4DIGIT
 *                    ; day month year (e.g., 02 Jun 1982)
 *     date2        = 2DIGIT "-" month "-" 2DIGIT
 *                    ; day-month-year (e.g., 02-Jun-82)
 *     date3        = month SP ( 2DIGIT | ( SP 1DIGIT ))
 *                    ; month day (e.g., Jun  2)
 *
 *     time         = 2DIGIT ":" 2DIGIT ":" 2DIGIT
 *                    ; 00:00:00 - 23:59:59
 *
 *     wkday        = "Mon" | "Tue" | "Wed"
 *                  | "Thu" | "Fri" | "Sat" | "Sun"
 *
 *     weekday      = "Monday" | "Tuesday" | "Wednesday"
 *                  | "Thursday" | "Friday" | "Saturday" | "Sunday"
 *
 *     month        = "Jan" | "Feb" | "Mar" | "Apr"
 *                  | "May" | "Jun" | "Jul" | "Aug"
 *                  | "Sep" | "Oct" | "Nov" | "Dec"
 *
 * However, for the sake of robustness (and Netscapeness), we ignore the
 * weekday and anything after the time field (including the timezone).
 *
 * This routine is intended to be very fast; 10x faster than using sscanf.
 *
 * Originally from Andrew Daviel <andrew@vancouver-webpages.com>, 29 Jul 96
 * but many changes since then.
 */
time_t date_parse_http(const char *date);

/**
 * Return the current time in milliseconds, since Jan. 1, 1970.
 *
 * @return current time in milliseconds
 */
long long gettimemillis();

/**
 * Create a temporary file, starting with the same path as a given file, or check whether
 * a temporary filename can be generated.
 *
 * @param path pathname
 * @param filename generated name, must be at least <code>PATH_MAX</code> characters long
 * @param fp where to return file. if <code>NULL</code>, just checks whether a temporary
 *           filename can be generated
 * @param mode permissions for intermediate directories, as in chmod
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
int create_temp_file(struct log_context *lc, const char *path, char *filename, FILE **fp, int mode);

/**
 * Decompose a URL, returning resource path, selectors, extension and suffix. After evaluating
 * the result, pointers in rpath and suffix need to be freed.
 *
 * @param url URL
 * @param rpath where to return resource path
 * @param selectors where to return selectors. This is a pointer into space allocated by rpath.
 * @param extension where to return extension. This is a pointer into space allocated by rpath.
 * @param suffix where to return suffix
 */
void decompose_url(const char *url, char **rpath, const char **selectors, const char **extension, char **suffix);

/**
 * In a string containing multiple value separated by some delimeter, remove one field
 * matching a certain prefix, e.g. strip_field("private, max-age=300", "max-age", ',');
 *
 * @param value
 * @param prefix prefix to find
 * @param delimeter delimeter
 * @return new value or <code>NULL</code> if the value wasn't found
 */
char *strip_field(const char *value, const char *prefix, int delimeter);

/**
 * compare two strings in constant time.
 *
 * @param string1
 * @param string2
 * @return 0 if both are equal,-1 if either one is NULL else 1
 */
int str_iseq(const char *s1, const char *s2) ;

/** @} */
/** @} */

#endif /* __BASE_H__ */
