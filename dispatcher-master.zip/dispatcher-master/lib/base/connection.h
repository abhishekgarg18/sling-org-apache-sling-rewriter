/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2019 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

#ifndef __CONNECTION_H__
#define __CONNECTION_H__

/**
 * A connection
 */
struct connection {
    /**
     * Read bytes from a connection
     *
     * @param conn connection
     * @param buf buffer to fill
     * @param buf_len space in buffer
     *
     * @return number of bytes actually received;
     *         <code>0</code> if no more data is available (EOF)
     *         <code>-1</code> if an error occurred
     */
    int (*read)(struct connection *conn, void *buf , size_t buf_len);

    /**
     * Writes bytes to a connection
     *
     * @param conn connection
     * @param buf buffer to write
     * @param buf_len number of bytes to write
     *
     * @return <code>0</code> on success; <code>-1</code> on error
     */
    int (*write)(struct connection *conn, const void *buf, size_t buf_len);

    /**
     * Flush all bytes
     *
     * @param conn connection
     *
     * @return <code>0</code> on success; <code>-1</code> on error
     */
    int (*flush)(struct connection *conn);

    /**
     * Close a connection
     *
     * @param conn connection
     * @param reuse whether to keep the connection in pool
     */
    void (*close)(struct connection *conn, int reuse);

    /**
     * Return the error code of the last failed operation
     *
     * @param conn connection
     *
     * @return an error code
     */
    int (*errcode)(struct connection *conn);

    /**
     * Return the error message of the last failed operation
     *
     * @param conn connection
     *
     * @return error message
     */
    const char *(*errmsg)(struct connection *conn);

    /**
     * Return a flag indicating whether we're using a pooled connection
     *
     * @param conn connection
     *
     * @return <code>1</code> if the connection is pooled; <code>0</code> otherwise
     */
    int (*reused)(struct connection *conn);

    /**
     * Pointer reserved for implementation
     */
    void *reserved;
};

/**
 * A connection factory
 */
struct connection_factory {
    /**
     * Create a connection
     *
     * @param factory factory
     * @param params parameters
     * @param params_len size of parameters passed
     * @param reuse whether it's ok to get a pooled connection
     *
     * @return connection or <code>NULL</code>
     */
    struct connection *(*create)(struct log_context *lc, struct connection_factory *factory,
                                 void *params, size_t params_len, int reuse);

    /**
     * Return a flag indicating whether we're using a factory with pooled connections
     *
     * @param factory factory
     *
     * @return <code>1</code> if the factory supports pooled connections; <code>0</code> otherwise
     */
    int (*keepalive)(struct connection_factory *factory);

    /**
     * Return the error message of the last failed operation
     *
     * @param conn connection
     *
     * @return error message
     */
    const char *(*errmsg)(struct connection_factory *factory);

    /**
     * Pointer reserved for implementation
     */
    void *reserved;
};

#endif // __CONNECTION_H__
