/*
 * Copyright (c) 2004 Day Management AG
 * Barfuesserplatz 6, 4001 Basel, Switzerland
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Day Management AG, ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Day.
 */
#include "base/base.h"

/**
 * Display name of ANY_TYPE enums.
 */
static const char *any_type_names[] = {
    "",
    "NUMBER",
    "STRING",
    "REGEXP",
    "NODE"
};

/**
 * Filename used for any files given as strings.
 */
static const char *internal_name = "internal";

/**
 * Empty label.
 */
static const char *empty_label = "";

/**
 * Maximum length of a label. Exceeding characters are ignored
 */
#define LABEL_MAX 64

/**
 * Valid characters in a label
 */
#define ISVALIDLABELCHAR(c)  ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '_' || c == '-')

/**
 * Parse context.
 */
struct parse_context {
    struct log_context *lc;
    char *(*resolve)(const char *, void *);
    void *u;
};

/**
 * Forward declarations
 */
static int parse_input(const char *parent_dir, struct any_item *parent,
                       const char *pc, const char *filename, struct parse_context *ctx);

/**
 * Return the parent directory of a file.
 *
 * @param filename file to return parent directory of
 * @param buf buffer where to return parent directory. Should be at
 *        least PATH_MAX characters long
 *
 * @return pointer to parent directory if successful;
 *         otherwise <code>NULL</code>
 */
static char *get_parent_dir(const char *filename, char *buf)
{
    const char *sep;
    char resolved_name[PATH_MAX];

    if (realpath(filename, resolved_name) == 0) {
        return 0;
    }
    sep = strrchr(resolved_name, FILE_SEPARATOR_CHAR);
    if (sep == 0) {
        errno = EINVAL;
        return 0;
    }
    strncpy(buf, resolved_name, sep - resolved_name);
    buf[sep - resolved_name] = 0;
    return buf;
}

/**
 * Include a file and add its contents to a parent item.
 *
 * @param parent parent item
 * @param filename file to include
 * @param ctx parse context
 *
 * @return <code>0</code> if the file was included;
 *         <code>-1</code> if an error occurred
 */
static int include_file(struct any_item *parent, const char *filename, struct parse_context *ctx)
{
    struct log_context *lc = ctx->lc;
    char parent_dir[PATH_MAX];
    char *filebuf;

    if ((filebuf = mallocbinfile(filename)) == NULL) {
        WARNE("Unable to read file %s: %s", filename, strerror(errno));
        return -1;
    }
    if (get_parent_dir(filename, parent_dir) == NULL) {
        WARNE("Unable to obtain parent directory of %s: %s", filename, strerror(errno));
        free(filebuf);
        return -1;
    }
    if (parse_input(parent_dir, parent, filebuf, strdup(filename), ctx)) {
        free(filebuf);
        return -1;
    }
    free(filebuf);
    return 0;
}

/**
 * Create a new item.
 * @param parent parent item
 * @param type item type
 * @param label item label
 * @param filename file name
 * @param line line number
 *
 * @return new item
 */
static struct any_item *create_item(struct log_context *lc,
                                    struct any_item *parent, enum any_type type,
                                    const char *label, const char *filename, int line)
{
    struct any_item *item;

    if (parent && strlen(label) > 0) {
        item = any_get_item(parent, label);
        if (item) {
            WARN("%s:%d: parent already contains an item with label \"%s\"",
                    filename, line, label);
            WARN("    this is the location of the previous definition: %s:%d",
                    item->filename, item->line);
        }
    }

    item = malloc(sizeof(struct any_item));
    memset(item, 0, sizeof(struct any_item));

    item->type = type;
    item->label = (!strcmp(label, "")) ? empty_label : strdup(label);
    item->first = item->last = item->next = 0;
    item->parent = parent;
    item->filename = filename;
    item->line = line;

    if (parent) {
        if (parent->first) {
            parent->last->next = item;
            parent->last = item;
        } else {
            parent->first = parent->last = item;
        }
    }
    return item;
}

/**
 * Split a glob pattern, containing an absolute path name, into a directory
 * part with no glob characters and a glob pattern.
 *
 * @param pattern pattern
 * @param directory where to return directory pathname
 * @param glob where to return glob
 */
static void splitglob(const char *pattern, char *directory, char *glob)
{
    const char *ptr, *lastdir;
    size_t directory_len;

    if (pattern[0] != '/') {
        /* exit if we were not given an absolute path name */
        directory[0] = '\0';
        strcpy(glob, pattern);
        return;
    }

    ptr = pattern + 1;
    lastdir = NULL;

    while (*ptr) {
        char c = *ptr;
        if (c == '*' || c == '?' || c == '[' || c == ']') {
            break;
        }
        if (c == '/') {
            lastdir = ptr;
        }
        ptr++;
    }
    if (lastdir == NULL) {
        /* nothing can be split but the root directory */
        strcpy(directory, "/");
        strcpy(glob, pattern + 1);
    }
    else {
        /* we have something to split */
        directory_len = (size_t) (lastdir - pattern);
        strncpy(directory, pattern, directory_len);
        directory[directory_len] = '\0';
        strcpy(glob, lastdir + 1);
    }
}

/**
 * Replace all environment variables, e.g. ${PWD} found in a string.
 *
 * @param p string where to replace environment variables
 * @param filename file name
 * @param line number
 * @param ctx parse context
 *
 * @return newly allocated string with all variables replaced;
 *         <code>NULL</code> if nothing was replaced
 */
static char *replace_envvars(const char *p, const char *filename, int line,
                             struct parse_context *ctx)
{
    struct log_context *lc = ctx->lc;
    const char *start, *last = p, *value;
    char buf[4096], name[256];
    size_t buf_len = 0, name_len, len;

    for (;;) {
        start = strstr(last, "${");
        if (start == NULL) {
            break;
        }

        len = (size_t) (start - last);
        if (buf_len + len >= sizeof(buf) - 1) {
            WARN("%s:%d: size of processed string value exceeds %d bytes",
                    filename, line, sizeof(buf));
            return NULL;
        }
        strncpy(buf + buf_len, last, len);
        buf[buf_len += len] = 0;

        last = strchr(start, '}');
        if (last == NULL) {
            last = start;
            break;
        }

        name_len = last - start - 2;
        if (name_len >= sizeof(name) - 1) {
            WARN("%s:%d: environment variable name length exceeds %d bytes",
                    filename, line, sizeof(name));
            return NULL;
        }

        strncpy(name, start + 2, name_len);
        name[name_len] = 0;

        if (ctx && ctx->resolve) {
            value = ctx->resolve(name, ctx->u);
        } else {
            value = getenv(name);
        }
        if (value == NULL) {
            WARN("%s:%d: variable not defined: %s", filename, line, name);
            value = "";
        }

        len = strlen(value);
        if (buf_len + len >= sizeof(buf) - 1) {
            WARN("%s:%d: size of processed string value exceeds %d bytes",
                    filename, line, sizeof(buf));
            return NULL;
        }
        strncpy(buf + buf_len, value, len);
        buf[buf_len += len] = 0;

        last++;
    }

    if (last == p) {
        /* no replacement took place at all */
        return NULL;
    }

    len = strlen(last);
    if (buf_len + len >= sizeof(buf) - 1) {
        WARN("%s:%d: size of processed string value exceeds %d bytes",
                filename, line, sizeof(buf));
        return NULL;
    }
    strcpy(buf + buf_len, last);
    return strdup(buf);
}

/**
 * Lexer tokens, some values are deliberately chosen:
 * - EOF should be <code>0</code> to end parse loop,
 * - UNKNOWN should be <code>-1<code> to indicate error
 */
#define TOKEN_EOF        0
#define TOKEN_LABEL      1
#define TOKEN_VALUE      2
#define TOKEN_REGEXP     3
#define TOKEN_START      4
#define TOKEN_END        5
#define TOKEN_DIRECTIVE  6
#define TOKEN_UNKNOWN   -1

/**
 * Read label at current character position.
 *
 * @param ppc pointer to character pointer
 * @param buf buffer to fill
 * @param buf_len number of characters in buffer
 * @param filename filename
 * @param line line number
 *
 * @return <code>TOKEN_LABEL</code> if successful;
 *         <code>TOKEN_UNKNOWN</code> otherwise
 *
 * @note only LABEL_MAX characters are copied
 */
static int read_label(struct log_context *lc,
                      const char **ppc, char *buf, size_t buf_len,
                      const char *filename, int line)
{
    const char *extra = NULL;
    int i = 0;

    if (buf_len > LABEL_MAX) {
        /* Legacy: we never read more than that many characters */
        buf_len = LABEL_MAX;
    }

    while (ISVALIDLABELCHAR(**ppc)) {
        if (i < (int) (buf_len - 1)) {
            buf[i++] = **ppc;
        } else {
            if (extra == NULL) {
                extra = *ppc;
            }
        }
        (*ppc)++;
    }
    buf[i] = 0;

    /* skip extra characters */
    while (NWS(**ppc)) {
        if (extra == NULL) {
            extra = *ppc;
        }
        (*ppc)++;
    }

    if (extra) {
        WARN("%s:%d: extra characters following label \"%s\" are ignored.",
                filename, line, buf);
    }
    return TOKEN_LABEL;
}

/**
 * Read comment, input will be discarded.
 *
 * @param ppc pointer to character pointer
 */
static void read_comment(const char **ppc)
{
    char ch;

    for (;;) {
        ch = **ppc;
        if (ch == 0 || ch == '\n') {
            return;
        }
        (*ppc)++;
    }
}

/**
 * Read directive at current character position.
 *
 * @param ppc pointer to character pointer
 * @param buf buffer to fill
 * @param buf_len number of characters in buffer
 * @param filename filename
 * @param line line number
 *
 * @return <code>TOKEN_DIRECTIVE</code> if successful;
 *         <code>TOKEN_UNKNOWN</code> otherwise
 */
static int read_directive(struct log_context *lc,
                          const char **ppc, char *buf, size_t buf_len,
                          const char *filename, int line)
{
    unsigned i = 0;
    char ch;

    while (**ppc) {
        ch = **ppc;
        if (strchr("/#${} \r\n\t", ch)) {
            break;
        }
        (*ppc)++;
        if (i < buf_len - 1) {
            buf[i++] = ch;
        } else {
            ERR("%s:%d: directive too long, only %d characters accepted",
                    filename, line, buf_len);
            return TOKEN_UNKNOWN;
        }
    }
    buf[i] = 0;
    return TOKEN_DIRECTIVE;
}

/**
 * Read value at current character position.
 *
 * @param ppc pointer to character pointer
 * @param start first character
 * @param buf buffer to fill
 * @param buf_len number of characters in buffer
 * @param filename filename
 * @param line line number
 *
 * @return <code>TOKEN_VALUE</code> if successful;
 *         <code>TOKEN_UNKNOWN</code> otherwise
 */
static int read_value(struct log_context *lc,
                      const char **ppc, char start, char *buf, size_t buf_len,
                      const char *filename, int line)
{
    unsigned i = 0, quoted = 0;
    char ch = 0;

    switch (start) {
        case '"':
        case '\'':
            quoted = 1;
            break;
        default:
            buf[i++] = start;
            break;
    }

    while (**ppc) {
        ch = **ppc;

        if (!quoted && strchr("/#${} \r\n\t", ch)) {
            break;
        }
        if (ch == '\r' || ch == '\n') {
            /* Automatically terminate quoted value at EOL */
            WARN("%s:%d: missing double quotes at end of value", filename , line);
            break;
        }
        (*ppc)++;
        if (quoted && ch == start) {
            break;
        }
        if (ch == '\\' && **ppc) {
            ch = **ppc;
            switch (ch) {
            case 'r':
                ch = '\r';
                break;
            case 'n':
                ch = '\n';
                break;
            case 't':
                ch = '\t';
                break;
            default:
                break;
            }
            (*ppc)++;
        }
        if (i < buf_len - 1) {
            buf[i++] = ch;
        } else {
            ERR("%s:%d: value too long, only %d characters accepted",
                    filename, line, buf_len);
            return TOKEN_UNKNOWN;
        }
    }
    buf[i] = 0;

    /* Swallow non-separators following quoted string (e.g. "Cache-Control", ) */
    if (quoted && ch == start) {
        const char *extra = *ppc;
        while (**ppc) {
            ch = **ppc;

            if (strchr("/#${}'\" \r\n\t", ch)) {
                break;
            }
            (*ppc)++;
        }
        if (extra != *ppc) {
            WARN("%s:%d: extra characters following string \"%s\" are ignored.", filename, line, buf);
        }
    }
    return start == '\'' ? TOKEN_REGEXP : TOKEN_VALUE;
}

/**
 * Read the next token.
 *
 * @param ppc pointer to character pointer
 * @param buf buffer to fill
 * @param buf_len number of characters in buffer
 * @param filename filename
 * @param line line number
 *
 * @return some <code>TOKEN_xxx</code> value
 */
static int next_token(struct log_context *lc, const char **ppc, char *buf, size_t buf_len,
                      const char *filename, int *line)
{
    char ch;

    for (;;) {
        ch = **ppc;
        if (ch == 0) {
            return TOKEN_EOF;
        }
        (*ppc)++;
        if (ch == '\n') {
            (*line)++;
        }
        if (WS(ch)) {
            continue;
        }
        switch (ch) {
        case '/':
            return read_label(lc, ppc, buf, buf_len, filename, *line);
        case '#':
            read_comment(ppc);
            break;
        case '$':
            return read_directive(lc, ppc, buf, buf_len, filename, *line);
        case '{':
            return TOKEN_START;
        case '}':
            return TOKEN_END;
        default:
            return read_value(lc, ppc, ch, buf, buf_len, filename, *line);
        }
    }
}

/**
 * Process all files in an array.
 *
 * @param sa string array
 * @param parent parent item where all items processed should be attached to
 * @param ctx parse context
 *
 * @return number of files processed;
 *         <code>-1</code> on failure
 */
static int process_files(struct strarray *sa, struct any_item *parent, struct parse_context *ctx)
{
    unsigned i, size;

    size = strarray_size(sa);
    for (i = 0; i < size; i++) {
        if (include_file(parent, strarray_at(sa, i), ctx)) {
            return -1;
        }
    }
    return size;
}

/**
 * Include all files in a directory that match a given pattern, and parse
 * their contents.
 *
 * @param parent_dir parent directory
 * @param parent parent item where all items processed should be attached to
 * @param pattern filename pattern
 * @param ctx parse_context
 *
 * @return number of matched files found;
 *         <code>-1</code> on failure
 */
static int include_files(const char *parent_dir, struct any_item *parent, char *pattern,
                         struct parse_context *ctx)
{
    char directory[PATH_MAX], glob[PATH_MAX];
    struct strarray *sa;
    int ret;

    if (*pattern == '/') {
        splitglob(pattern, directory, glob);
        parent_dir = directory;
        pattern = glob;
    }
    if (find_files(parent_dir, pattern, &sa)) {
        return -1;
    }
    ret = process_files(sa, parent, ctx);
    strarray_free(sa);
    return ret;
}

/**
 * Parse input passed in a character pointer.
 *
 * @param parent_dir parent directory of the current file, may be <code>NULL</code>
 * @param parent parent item where all items processed should be attached to
 * @param pc character pointer to file contents
 * @param filename filename
 * @param ctx parse context
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
static int parse_input(const char *parent_dir, struct any_item *parent,
                       const char *pc, const char *filename, struct parse_context *ctx)
{
    struct log_context *lc = ctx->lc;
    char buf[2048], label[LABEL_MAX], *p;
    struct any_item *item, *current = parent;
    int token, matches, line = 1;

    label[0] = '\0';

    while ((token = next_token(lc, &pc, buf, sizeof buf, filename, &line))) {
        switch (token) {
        case TOKEN_LABEL:
            strncpy(label, buf, sizeof label);
            break;
        case TOKEN_VALUE:
            item = create_item(lc, current, STRING, label, filename, line);
            if ((p = replace_envvars(buf, filename, line, ctx))) {
                item->value.p = p;
            } else {
                item->value.p = strdup(buf);
            }
            label[0] = 0;
            break;
        case TOKEN_REGEXP:
            item = create_item(lc, current, REGEXP, label, filename, line);
            item->value.p = strdup(buf);
            label[0] = 0;
            break;
        case TOKEN_START:
            current = create_item(lc, current, NODE, label, filename, line);
            label[0] = '\0';
            break;
        case TOKEN_END:
            if (current == parent) {
                ERR("%s:%d: unbalanced closing tag '}'", filename, line);
                return -1;
            }
            current = current->parent;
            break;
        case TOKEN_DIRECTIVE:
            if (strcmp("include", buf)) {
                ERR("%s:%d: unknown directive: %s", filename, line, buf);
                return -1;
            }
            if (parent_dir == 0) {
                ERR("%s:%d: include directive not supported when "
                        "no parent directory is known", filename, line);
                return -1;
            }
            token = next_token(lc, &pc, buf, sizeof buf, filename, &line);
            if (token != TOKEN_VALUE) {
                ERR("%s:%d: include directive must be followed by "
                            "a filename pattern", filename, line);
                return -1;
            }
            p = replace_envvars(buf, filename, line, ctx);
            matches = include_files(parent_dir, current, p != NULL ? p : buf, ctx);
            free(p);

            if (matches == -1) {
                return -1;
            } else if (matches == 0) {
                /* If "buf" contained environment variables that were undefined, a separate
                 * warning will have been issued (see replace_envvars). */
                WARN("%s:%d: pattern \"%s\" has no matches", filename, line, buf);
            }
            break;
        default:
            return -1;
        }
    }
    return 0;
}

/*----------------------------------------------------------- Public methods */


struct any_item *any_import(struct log_context *lc, const char *filename,
                            char * (resolve(const char *, void *)), void *u)
{
    char fullpath[PATH_MAX];
    struct any_item *root;
    struct parse_context ctx;

    if (!realpath(filename, fullpath)) {
        WARN("File not found: %s", filename);
        return NULL;
    }

    ctx.lc = lc;
    ctx.resolve = resolve;
    ctx.u = u;

    root = create_item(lc, 0, NODE, "", 0, 0);
    if (include_file(root, fullpath, &ctx) < 0) {
        any_free(root);
        return 0;
    }
    return root;
}

struct any_item *any_parse(struct log_context *lc, const char *s)
{
    struct any_item *root;
    struct parse_context pc;

    memset(&pc, 0, sizeof(struct parse_context));
    pc.lc = lc;

    root = create_item(lc, 0, NODE, "", 0, 0);
    parse_input(0, root, s, internal_name, &pc);

    return root;
}

struct any_item *any_get_item(struct any_item *parent, const char *path)
{
    const char *start = path;
    const char *end = path + strlen(path);

    while (start < end) {
        struct any_item *child;
        const char *sep;

        sep = strchr(start, '.');
        if (sep == 0) {
            sep = end + 1;
        }

        child = parent->first;
        while (child != 0) {
            if (!strncmp(child->label, start, sep - start)) {
                break;
            }
            child = child->next;
        }

        if (child == 0) {
            return 0;
        }

        parent = child;
        start = sep + 1;
    }

    return parent;
}

const char *any_get_string(struct any_item *parent, const char *path)
{
    struct any_item *child;

    child = any_get_item(parent, path);
    if (child != 0 && child->type == STRING) {
        return child->value.p;
    }

    return 0;
}

const char *any_get_regex(struct any_item *parent, const char *path)
{
    struct any_item *child;

    child = any_get_item(parent, path);
    if (child != 0 && child->type == REGEXP) {
        return child->value.p;
    }

    return 0;
}

int any_get_boolean(struct any_item *parent, const char *path)
{
    const char *value;

    value = any_get_string(parent, path);
    if (value) {
        return atoi(value) != 0 ? 1 : 0;
    }

    return 0;
}

int any_get_number(struct log_context *lc, struct any_item *parent, const char *path, int defvalue)
{
    struct any_item *child;
    char *start, *end;
    long val;

    child = any_get_item(parent, path);
    if (child == NULL) {
        return defvalue;
    }
    switch (child->type) {
    case NUMBER:
        return child->value.d;
    case STRING:
        start = child->value.p;
        val = strtol(start, &end, 10);
        if (*end == '\0' && start != end) {
            return (int) val;
        }
        WARN("%s:%d: unable to convert the string found into a number: %s",
                child->filename, child->line, start);
        break;
    default:
        WARN("%s:%d: a number was expected in %s.",
                child->filename, child->line, path);
        break;
    }
    return defvalue;
}

struct any_item *any_get_first_child(struct any_item *parent, const char *path)
{
    struct any_item *child;

    child = any_get_item(parent, path);
    if (child != 0 && child->type == NODE) {
        return child->first;
    }

    return 0;
}

void any_free(struct any_item *item)
{
    struct any_item *child;

    if (!item) {
        return;
    }
    child = item->first;
    while (child) {
        struct any_item *next = child->next;
        any_free(child);
        child = next;
    }

    if (item->label != empty_label) {
        free((void *) item->label);
    }
    if (item->type == STRING || item->type == REGEXP) {
        free(item->value.p);
    }
    free(item);
}

void any_dump(struct any_item *parent, int level)
{
    struct any_item *current = parent->first;
    int i;

    while (current != 0) {
        for (i = 0; i < level; i++) {
            printf("  ");
        }
        if (strcmp(current->label, "")) {
            printf("/%s ", current->label);
        }
        switch (current->type) {
            case NUMBER:
                printf("%d\n", current->value.d);
                break;
            case STRING:
                printf("\"%s\"\n", current->value.p);
                break;
            case REGEXP:
                printf("\'%s\'\n", current->value.p);
                break;
            case NODE:
                printf("{\n");
                any_dump(current, level + 1);
                for (i = 0; i < level; i++) {
                    printf("  ");
                }
                printf("}\n");
                break;
        }
        current = current->next;
    }
}

void any_validate(struct log_context *lc, struct any_item *any, struct any_item *dtd)
{
    struct any_item *child, *dtd_entry;

    for (child = any->first; child; child = child->next) {
        if (!strcmp(child->label, "")) {
            if ((dtd_entry = any_get_item(dtd, ".")) == NULL || strcmp(dtd_entry->label, "") != 0) {
                WARN("%s:%d: unlabelled %s entry not recognized",
                        child->filename, child->line, any_type_names[child->type]);
            } else if (child->type != dtd_entry->type) {
                WARN("%s:%d: entry type unexpected '%s': expected %s, found %s",
                        child->filename, child->line, child->label,
                        any_type_names[dtd_entry->type],
                        any_type_names[child->type]);
            }
        } else {
            if ((dtd_entry = any_get_item(dtd, child->label)) == NULL) {
                dtd_entry = any_get_item(dtd, "LABEL");
            }
            if (dtd_entry == NULL) {
                WARN("%s:%d: entry not recognized: '%s'",
                        child->filename, child->line, child->label);
            } else if (child->type != dtd_entry->type) {
                if (child->type == STRING && dtd_entry->type == REGEXP) {
                    /* using a string in place of a RE is allowed */
                } else {
                    WARN("%s:%d: unexpected type for '%s': expected %s, found %s",
                         child->filename, child->line, child->label,
                         any_type_names[dtd_entry->type],
                         any_type_names[child->type]);
                }
            } else if (child->type == NODE) {
                any_validate(lc, child, dtd_entry);
            }
        }
    }
}
