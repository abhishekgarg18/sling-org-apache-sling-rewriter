/*
 * Copyright (c) 2010 Day Management AG
 * Barfuesserplatz 6, 4001 Basel, Switzerland
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Day Management AG, ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Day.
 */
#ifndef __UTF8_H___
#define __UTF8_H___

#include <wchar.h>

/**
 * @file hdrarray.h
 * @brief utf8.h UTF-8 conversion
 */

/**
 * @defgroup base Base functionality
 * @{
 */

/**
 * @defgroup utf8 UTF-8 conversion
 * @{
 */

/**
 * Replacement for <code>mbstowcs</code> that converts a UTF-8 encoded string to UCS-2.
 *
 * @param out out wide character string
 * @param in in UTF-8 character string, zero-terminated
 * @param count number of available wide characters in <code>out</code>
 *
 * @return number of converted wide characters
 */
size_t utf8_to_ucs2(wchar_t *out, const char *in, size_t count);

/**
 * Replacement for <code>wcstombs</code> that converts a UCS-2 encoded string to UTF-8.
 *
 * @param out out UTF-8 character string
 * @param in in wide character string, zero-terminated
 * @param count number of available bytes in <code>out</code>
 *
 * @return number of converted wide characters
 */
size_t ucs2_to_utf8(char *out, const wchar_t *in, size_t count);

/** @} */
/** @} */

#endif /* __UTF8_H___ */
