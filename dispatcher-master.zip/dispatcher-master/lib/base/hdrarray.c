/*
 * Copyright (c) 2010 Day Management AG
 * Barfuesserplatz 6, 4001 Basel, Switzerland
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Day Management AG, ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Day.
 */
#include "base/base.h"

/**
 * Header array
 */
struct hdrarray {
    /* current size of array */
    int size;
    /* capacity of array */
    int capacity;
    /* header array */
    const char **p;
};


/*----------------------------------------------------------- Public methods */


struct hdrarray *create_hdrarray(int capacity)
{
    struct hdrarray *hdra;

    hdra = malloc(sizeof(struct hdrarray));
    hdra->size = 0;
    hdra->capacity = capacity;
    hdra->p = malloc(capacity * 2 * sizeof(const char *));

    return hdra;
}

void hdrarray_add(struct hdrarray *hdra, const char *name, const char *value)
{
    int capacity;
    const char **p;

    if (hdra->size == hdra->capacity) {
        capacity = 2 * hdra->capacity;
        hdra->p = realloc((void *) hdra->p, capacity * 2 * sizeof(const char *));
        hdra->capacity = capacity;
    }
    p = hdra->p + 2 * hdra->size;
    *p++ = name;
    *p++ = value;
    hdra->size++;
}

int hdrarray_at(struct hdrarray *hdra, int index, const char **name, const char **value)
{
    const char **p;

    if (index < hdra->size) {
        p = hdra->p + 2 * index;
        *name  = *p++;
        *value = *p++;
        return 0;
    }
    return -1;
}

int hdrarray_size(struct hdrarray *hdra)
{
    return hdra->size;
}

void hdrarray_free(struct hdrarray *hdra)
{
    if (hdra) {
        free((void *) hdra->p);
        free(hdra);
    }
}
