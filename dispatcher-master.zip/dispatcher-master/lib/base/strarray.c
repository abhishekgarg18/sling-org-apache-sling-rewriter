/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * __________________
 *
 *  Copyright 2015 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

#include "base/base.h"

/**
 * String array
 */
struct strarray {
    /* current size of array */
    int size;
    /* capacity of array */
    int capacity;
    /* strings */
    char **p;
};


/*----------------------------------------------------------- Public methods */


int create_strarray(struct strarray **sa, int capacity)
{
    struct strarray *result;

    result = malloc(sizeof(struct strarray));
    result->size = 0;
    result->capacity = capacity;
    result->p = malloc(capacity * sizeof(char *));
    memset(result->p, 0, capacity * sizeof(char *));

    *sa = result;
    return 0;
}

void strarray_add(struct strarray *sa, const char *s)
{
    int capacity;

    if (sa->size >= sa->capacity - 1) {
        capacity = 2 * sa->capacity;
        sa->p = realloc(sa->p, capacity * sizeof(char *));
        memset(sa->p + sa->size, 0, (capacity - sa->size) * sizeof(void *));
        sa->capacity = capacity;
    }
    sa->p[sa->size++] = strdup(s);
}

char *strarray_at(struct strarray *sa, int index)
{
    if (index < sa->size) {
        return sa->p[index];
    }
    return NULL;
}

int strarray_size(struct strarray *sa)
{
    return sa->size;
}

char **strarray_get(struct strarray *sa)
{
    return sa->p;
}

static int compare_entries(const void *p1, const void *p2)
{
    return strcmp(*((char **) p1), *((char **) p2));
}

void strarray_sort(struct strarray *sa)
{
    qsort(sa->p, sa->size, sizeof (char *), compare_entries);
}

void strarray_free(struct strarray *sa)
{
    int i;

    if (sa) {
        for (i = 0; i < sa->size; i++) {
            free(sa->p[i]);
        }
        free(sa->p);
        free(sa);
    }
}
