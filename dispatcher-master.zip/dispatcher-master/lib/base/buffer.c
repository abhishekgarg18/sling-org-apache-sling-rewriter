/*
 * Copyright (c) 2010 Day Management AG
 * Barfuesserplatz 6, 4001 Basel, Switzerland
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Day Management AG, ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Day.
 */
#include "base/base.h"

/**
 * Input buffer structure.
 */
struct in_buffer {
    /* character array */
    char *p;
    /* current offset in buffer. */
    unsigned off;
    /* number of valid characters in buffer. */
    unsigned len;
    /* size of buffer */
    unsigned size;
    /* fill method */
    int (*fill)(void *context, void *p, size_t len);
    /* context to pass to fill method */
    void *context;
};


/*----------------------------------------------------------- Public methods */


int create_in_buffer(struct in_buffer **b, unsigned size,
                     int (*fill)(void *context, void *p, size_t len), void *context)
{
    struct in_buffer *result = malloc(sizeof(struct in_buffer) + size);

    result->p = (char *) (result + 1);
    result->off = result->len = 0;
    result->size = size;
    result->fill = fill;
    result->context = context;

    *b = result;
    return 0;
}

int buffer_read(struct in_buffer *b, void *p, size_t len)
{
    int ret;
    unsigned n, avail;

    if (!len) {
        return 0;
    }
    avail = b->len - b->off;
    if (!avail) {
        ret = b->fill(b->context, b->p, b->size);
        if (ret <= 0) {
            return ret;
        }
        avail = ret;
        b->off = 0;
        b->len = avail;
    }
    n = (unsigned) (len < avail ? len : avail);
    memcpy(p, b->p + b->off, n);
    b->off += n;
    return n;
}

int buffer_readb(struct in_buffer *b)
{
    int avail;

    avail = b->len - b->off;
    if (!avail) {
        avail = b->fill(b->context, b->p, b->size);
        if (avail < 0) {
            return -2;
        } else if (avail == 0) {
            return -1;
        }
        b->off = 0;
        b->len = avail;
    }
    return 0x0ff & b->p[b->off++];
}

/**
 * Parse state constants.
 */
#define PS_START    0
#define PS_AFTER_CR 1
#define PS_AFTER_LF 2

int buffer_readline(struct in_buffer *b, char *p, size_t len)
{
    int state = PS_START, c;
    unsigned index = 0;

    while (state != PS_AFTER_LF) {
        c = buffer_readb(b);
        if (c == -2) {
            /* failure */
            return -1;
        } else if (c == -1) {
            /* EOF */
            if (index == 0) {
                return 0;
            }
            break;
        } else {
            switch (state) {
            case PS_START:
                if (c == '\r') {
                    state = PS_AFTER_CR;
                } else if (c == '\n') {
                    state = PS_AFTER_LF;
                }
                break;
            case PS_AFTER_CR:
                if (c == '\n') {
                    state = PS_AFTER_LF;
                    break;
                }
                break;
            }
            if (state == PS_START && index < len - 1) {
                p[index++] = c;
            }
        }
    }
    p[index++] = '\0';
    return index;
}

void in_buffer_close(struct in_buffer *b)
{
    free(b);
}

/**
 * Output buffer structure.
 */
struct out_buffer {
    /* character array */
    char *p;
    /* current offset in buffer. */
    unsigned off;
    /* number of valid characters in buffer. */
    unsigned len;
    /* flush method */
    int (*flush)(void *context, char *p, size_t len);
    /* context to pass to flush method */
    void *context;
};

int create_out_buffer(struct out_buffer **b, unsigned size,
                      int (*flush)(void *context, char *p, size_t len), void *context)
{
    struct out_buffer *result = malloc(sizeof(struct out_buffer) + size);

    result->p = (char *) (result + 1);
    result->off = 0;
    result->len = size;
    result->flush = flush;
    result->context = context;

    *b = result;
    return 0;
}

int buffer_write(struct out_buffer *b, const char *p, size_t len)
{
    unsigned start = 0, n, rem, avail;

    while (start < len) {
        if (b->off == b->len) {
            if (buffer_flush(b)) {
                return -1;
            }
        }

        rem = (unsigned) (len - start);
        avail = b->len - b->off;

        n = rem < avail ? rem : avail;
        memcpy(b->p + b->off, p + start, n);

        b->off += n;
        start += n;
    }
    return 0;
}

int buffer_avail(struct out_buffer *b)
{
    return b->off;
}

int buffer_flush(struct out_buffer *b)
{
    if (b->flush(b->context, b->p, b->off)) {
        return -1;
    }
    b->off = 0;
    return 0;
}

int out_buffer_close(struct out_buffer* b, int flush)
{
    if (flush) {
        if (buffer_flush(b)) {
            perror("Unable to flush buffer");
        }
    }
    free(b);
    return 0;
}
