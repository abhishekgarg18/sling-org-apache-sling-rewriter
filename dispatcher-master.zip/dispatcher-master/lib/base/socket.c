/*
 * Copyright (c) 1999 Day Management AG
 * Barfuesserplatz 6, 4001 Basel, Switzerland
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Day Management AG, ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Day.
 */
#include "base/base.h"

#ifndef WIN32

#include <pthread.h>
#include <signal.h>

#endif /* !WIN32 */

#include "base/socket_private.h"

/*---------------------------------------------------------- global variables */

/**
 * Flag indicating whether we're in a threaded environment
 */
static int _is_threaded = 0;

/*------------------------------------------------------ forward declarations */

static int do_read(struct log_context *lc, struct socket *s, void *buf, int num);
static int do_write(struct log_context *lc, struct socket *s, const void *buf, size_t num);

/** Default send timeout: 600000ms = 600s = 10min */
static const int tcp_sendTimeout = 600000;

/** Default recv timeout: 600000ms = 600s = 10min */
static const int tcp_recvTimeout = 600000;

static int _output_ready(struct socket *s)
{
#ifdef WIN32
    const struct timeval timeOut = { s->send_timeout / 1000, 0 };
    struct fd_set fd;

    fd.fd_count = 1;
    fd.fd_array[0] = s->socket;
    if (select(0, 0, &fd, 0, (PTIMEVAL) &timeOut) != 1) {
        return 0;
    }
#else
    struct pollfd poll_fd;

    poll_fd.fd = s->socket;
    poll_fd.events = POLLOUT;
    poll_fd.revents = 0;
    if (poll(&poll_fd, 1, s->send_timeout) <= 0) {
        return 0;
    }
#endif
    return 1;
}

static int do_write(struct log_context *lc, struct socket *s, const void *buf, size_t num)
{
    return send(s->socket, buf, (int) num, 0);
}

/**
 * Check whether we have some input on a socket.
 *
 * @param s socket to test
 * @param timeout number of milliseconds to wait, <code>0</code> to wait indefinitely
 *
 * @return <code>1</code> if some input is available;
 *         <code>0</code> otherwise, with errno set
 */
static int _input_ready(struct socket *s, int timeout)
{
    int rv;

#ifdef WIN32
    {
        /* check if socket is ready to receive */
        /* at the moment this is only done for insecure sockets */
        const struct timeval timeOut = { timeout / 1000, 0};
        struct fd_set fd;

        fd.fd_count = 1;
        fd.fd_array[0] = s->socket;
        rv = select(0, &fd, 0, 0, timeout == 0 ? NULL : (PTIMEVAL) &timeOut);
        if (rv < 0) {
            return 0;
        } else if (rv == 0) {
            WSASetLastError(WSAETIMEDOUT);
            return 0;
        }
    }
#else
    {
        struct timespec timespec = {timeout / 1000, 0};
        sigset_t mask;

        /* Ignore SIGUSR1 to not drop connections prematurely in case of graceful restart */
        if (_is_threaded) {
            pthread_sigmask(0, NULL, &mask);
        } else {
            sigprocmask(0, NULL, &mask);
        }
        sigaddset(&mask, SIGUSR1);

#ifdef __APPLE__
        {
            /* Darwin doesn't support ppoll() */
            fd_set fds;

            FD_ZERO(&fds);
            FD_SET(s->socket, &fds);

            rv = pselect(s->socket + 1, &fds, NULL, NULL, timeout == 0 ? NULL : &timespec, &mask);
        }
#else
        {
            struct pollfd fds;

            fds.fd = s->socket;
            fds.events = POLLIN | POLLPRI;
            fds.revents = 0;

            rv = ppoll(&fds, 1, timeout == 0 ? NULL : &timespec, &mask);
        }
#endif /* __APPLE__ */

        if (rv < 0) {
            return 0;
        } else if (rv == 0) {
            errno = ETIMEDOUT;
            return 0;
        }
    }
#endif /* WIN32 */
    return 1;
}

static int do_read(struct log_context *lc, struct socket * s, void *buf, int num)
{
    return recv(s->socket, buf, num, 0);
}


/*----------------------------------------------------------- Public methods */

int sockets_init(unsigned is_threaded)
{
    _is_threaded = is_threaded;

    return 0;
}

struct socket *socket_create(struct log_context *lc, struct addrinfo *ai)
{
    struct socket *s;

    s = malloc(sizeof(struct socket));
    memset(s, 0, sizeof(struct socket));

    if (socket_init(lc, s, ai)) {
        free(s);
        return NULL;
    }
    return s;
}

int socket_init(struct log_context *lc, struct socket *s, struct addrinfo *ai)
{
    s->socket = socket(ai->ai_family, ai->ai_socktype, ai->ai_protocol);
    if (SOCKET_INVALID(s->socket)) {
        ERR("Unable to create socket: %s", socket_errstring(s));
        return -1;
    }

    s->send_timeout = tcp_sendTimeout;
    s->recv_timeout = tcp_recvTimeout;

#ifdef WIN32
    /*
     * Make sure socket handles are not inherited:
     *
     * This function is not implemented under Windows9.x but
     * this does not represent a problem as socket handles
     * in Windows9.x are not inherited anyway
     * (see KB article Q150523)
     */
    SetHandleInformation((HANDLE) s->socket, HANDLE_FLAG_INHERIT, 0);
#endif

    s->read = do_read;
    s->write = do_write;

    return 0;
}

void socket_set_receive_timeout(struct socket *s, int timeout)
{
    s->recv_timeout = timeout;
}

int socket_set_option(struct socket *s, int level, int option_name, void *option_value, socklen_t option_len)
{
    return setsockopt(s->socket, level, option_name, option_value, option_len);
}

static int internal_send(struct log_context *lc, struct socket *s, const char *buffer, size_t length)
{
    size_t num = 0;
    int res;

    while (num < length) {
        if (!num && !_output_ready(s)) {
            return -1;
        }
        res = s->write(lc, s, buffer + num, (int) length - num);
        if (res < 0) {
            if (socket_errno() != SOCKET_EWOULDBLOCK) {
                return -1;
            }
        } else {
            num += (size_t) res;
        }
    }
    return 0;
}

int socket_send(struct log_context *lc, struct socket *s, const char *buffer, size_t length)
{
    /* 1) if everything fits, just copy into buffer */
    size_t avail = sizeof(s->buffer) - s->pos;
    if (avail >= length) {
        memcpy(s->buffer + s->pos, buffer, length);
        s->pos += length;
        return 0;
    }

    /* 2) otherwise flush buffer first */
    if (socket_flush(lc, s)) {
        return -1;
    }

    /* 3) if it fits now, copy into buffer */
    if (sizeof(s->buffer) >= length) {
        memcpy(s->buffer + s->pos, buffer, length);
        s->pos += length;
        return 0;
    }

    /* 4) no, so just send it directly */
    return internal_send(lc, s, buffer, length);
}

int socket_flush(struct log_context *lc, struct socket *s)
{
    if (s->pos > 0) {
        if (internal_send(lc, s, s->buffer, s->pos)) {
            return -1;
        }
        s->pos = 0;
    }
    return 0;
}

int socket_recv(struct log_context *lc, struct socket *s, void *buffer, int length, int ignore_eintr)
{
    int r, e;

    if (!_input_ready(s, s->recv_timeout)) {
        return -1;
    }
    for (;;) {
        if ((r = s->read(lc, s, buffer, length)) >= 0) {
            return r;
        }
        e = socket_errno();
        if (e == SOCKET_EWOULDBLOCK) {
            /* should actually not happen due to 'poll' in socket_recv */
            DBG("Receive on socket blocked (ignored)");
        } else if (e == SOCKET_EINTR && ignore_eintr) {
            DBG("Receive on socket interrupted (ignored)");
        } else {
            return r;
        }
    }
}

#ifdef WIN32

int socket_connect(struct log_context *lc, struct socket *s, const struct sockaddr *name, size_t length, int timeout)
{
    int connect_res;

    if (timeout <= 0) {
        connect_res = connect(s->socket, (struct sockaddr *) name, (int) length);
        if (connect_res == SOCKET_ERROR) {
            connect_res = WSAGetLastError();
        }
    } else {
        unsigned long optval;
        int optlen = sizeof(optval);

        /* make socket non-blocking */
        optval = 1;
        ioctlsocket(s->socket, FIONBIO, &optval );

        /* initiate the connect */
        connect_res = connect(s->socket, (struct sockaddr *) name, (int) length);
        if (connect_res == SOCKET_ERROR) {
            if (WSAGetLastError() != WSAEWOULDBLOCK) {
                connect_res = WSAGetLastError();
            } else {
                fd_set wr, ex;
                struct timeval t;

                FD_ZERO(&wr);
                FD_ZERO(&ex);
                FD_SET(s->socket, &wr);
                FD_SET(s->socket, &ex);
                t.tv_sec = timeout / 1000;
                t.tv_usec = (timeout % 1000) * 1000;

                /*
                 * Wait for timout, connection established or
                 * connection failed.
                 */
                connect_res = select((int) (s->socket + 1), NULL, &wr, &ex, &t);

                /*
                 * Timeout before connection is established/failed so
                 * we throw exception and shutdown input/output to prevent
                 * socket from being used.
                 * The socket should be closed immediately by the caller.
                 */
                if (connect_res == 0) {
                    shutdown(s->socket, SD_BOTH);

                    /* make socket blocking again - just in case */
                    optval = 0;
                    ioctlsocket(s->socket, FIONBIO, &optval );
                    WSASetLastError(WSAETIMEDOUT);
                    return -1;
                }

                /*
                 * We must now determine if the connection has been established
                 * or if it has failed. The logic here is designed to work around
                 * bug on Windows NT whereby using getsockopt to obtain the
                 * last error (SO_ERROR) indicates there is no error. The workaround
                 * on NT is to allow winsock to be scheduled and this is done by
                 * yielding and retrying. As yielding is problematic in heavy
                 * load conditions we attempt up to 3 times to get the error reason.
                 */
                if (!FD_ISSET(s->socket, &ex)) {
                    connect_res = 0;
                } else {
                    int retry;
                    for (retry = 0; retry < 3; retry++) {
                        getsockopt(s->socket, SOL_SOCKET, SO_ERROR,
                                (char*) &connect_res, &optlen);
                        if (connect_res) {
                            break;
                        }
                        Sleep(0);
                    }

                    if (connect_res == 0) {
                        WSASetLastError(WSAEFAULT);
                        return -1;
                    }
                }
            }
        }

        /* make socket blocking again */
        optval = 0;
        ioctlsocket(s->socket, FIONBIO, &optval);
    }

    if (connect_res == 0 && s->connect != NULL) {
       connect_res = s->connect(lc, s, timeout);
    }
    if (connect_res != 0) {
        WSASetLastError(connect_res);
        return -1;
    }
    return 0;
}

#else

#define SET_NONBLOCKING(fd) {           \
        int flags = fcntl(fd, F_GETFL); \
        flags |= O_NONBLOCK;            \
        fcntl(fd, F_SETFL, flags);      \
}

#define SET_BLOCKING(fd) {              \
        int flags = fcntl(fd, F_GETFL); \
        flags &= ~O_NONBLOCK;           \
        fcntl(fd, F_SETFL, flags);      \
}

int socket_connect(struct log_context *lc, struct socket *s, const struct sockaddr *name,
                   size_t length, int timeout)
{
    int connect_rv = -1;

    if (timeout <= 0) {
        connect_rv = connect(s->socket, (struct sockaddr *) name, length);
    } else {
        /*
         * A timeout was specified. We put the socket into non-blocking
         * mode, connect, and then wait for the connection to be
         * established, fail, or timeout.
         */
        SET_NONBLOCKING(s->socket);

        connect_rv = connect(s->socket, (struct sockaddr *) name, length);

        /* connection not established immediately */
        if (connect_rv != 0) {
            int optlen;
            long long prevTime = gettimemillis();

            if (errno != EINPROGRESS) {
                /* connect failed */
                SET_BLOCKING(s->socket);
                return -1;
            }

            /*
             * Wait for the connection to be established or a
             * timeout occurs. poll/select needs to handle EINTR in
             * case lwp sig handler redirects any process signals to
             * this thread.
             */
            while (1) {
                long long newTime;
                struct pollfd fds[1];

                fds[0].fd = s->socket;
                fds[0].events = POLLOUT;

                errno = 0;
                connect_rv = poll(fds, 1, timeout);

                if (connect_rv >= 0) {
                    break;
                }
                if (errno != EINTR) {
                    break;
                }

                /*
                 * The poll was interrupted so adjust timeout and
                 * restart
                 */
                newTime = gettimemillis();
                timeout -= (newTime - prevTime);
                if (timeout <= 0) {
                    connect_rv = 0;
                    break;
                }
                prevTime = newTime;

            } /* while */

            if (connect_rv == 0) {
                /*
                 * Timeout out but connection may still be established.
                 * At the high level it should be closed immediately but
                 * just in case we make the socket blocking again and
                 * shutdown input & output.
                 */
                SET_BLOCKING(s->socket);
                shutdown(s->socket, 2);
                errno = ETIMEDOUT;
                return -1;
            }

            /* has connection been established */
            optlen = sizeof(connect_rv);
            if (getsockopt(s->socket, SOL_SOCKET, SO_ERROR,
                    (void *) &connect_rv, (socklen_t *) &optlen) < 0) {
                connect_rv = errno;
            }
        }

        /* make socket blocking again */
        SET_BLOCKING(s->socket);

        /* restore errno */
        if (connect_rv != 0) {
            errno = connect_rv;
            connect_rv = -1;
        }
    }
    if (connect_rv == 0 && s->connect != NULL) {
       connect_rv = s->connect(lc, s, timeout);
    }
    return connect_rv == 0 ? 0 : -1;
}

#endif /* WIN32 */

int socket_close(struct log_context *lc, struct socket *s)
{
    int err = 0;
    if (!s) {
        return 0;
    }
    if (s->shutdown) {
        s->shutdown(lc, s);
    }

#ifndef WIN32
    err = close(s->socket);
#else /* !WIN32 */
    err = closesocket (s->socket);
#endif /* WIN32 */

    free(s->err_string);
    free(s);

    return err;
}

int socket_errno()
{
    int err;
#ifndef WIN32
    err = errno;
#else /* WIN32 */
    err = WSAGetLastError();
#endif /* WIN32 */
    return (err);
}

#ifndef WIN32

const char *socket_errstring(struct socket *s)
{
    char *errstring;

    if (s != NULL && s->err_string != NULL) {
        return s->err_string;
    }
    errstring = strerror(socket_errno());
    return errstring != NULL ? errstring : "";
}

#else /* WIN32 */

const char *hstrerror(int n)
{
    static char buff[256 + 1];

    FormatMessageA(FORMAT_MESSAGE_FROM_SYSTEM
                  |FORMAT_MESSAGE_IGNORE_INSERTS
                  |FORMAT_MESSAGE_MAX_WIDTH_MASK,
                  NULL,
                  n,
                  MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
                  (LPSTR)buff,
                  256,
                  NULL);

    return buff;
}

const char *socket_errstring(struct socket *s)
{
    if (s != NULL && s->err_string != NULL) {
        return s->err_string;
    }
    return hstrerror(WSAGetLastError());
}

#endif /* WIN32 */

void socket_set_errstring(struct socket *s, const char *str)
{
    if (s->err_string) {
        free(s->err_string);
        s->err_string = NULL;
    }
    if (str != NULL) {
        int str_len = (int) strlen(str);
        if (str[str_len - 1] == '\n') {
            str_len--;
        }
        s->err_string = strnumdup(str, (size_t) str_len);
    }
}

/**
 * Translates a host/port combination to an IPv4 address. This can
 * be passed to socket_connect and should be freed by calling
 * freeaddrinfo_ipv4.
 *
 * @param hostname hostname
 * @param servname service name
 * @param hints hints
 * @param res contains linked list of infos on return
 *
 * @return <code>0</code> if successful;
 *         <code>-1</code> if unsuccessful
 */
static int STDCALL getaddrinfo_ipv4(const char *hostname, const char *servname,
        const struct addrinfo *hints, struct addrinfo **res)
{
    struct hostent *hp;
    struct in_addr **addr_list;
    struct sockaddr_in *sin;
    struct addrinfo *ai, *last = NULL;
    int i;

    if ((hp = gethostbyname(hostname)) == NULL) {
        return h_errno;
    }

    addr_list = (struct in_addr **) hp->h_addr_list;
    for (i = 0; addr_list[i] != NULL; i++) {
        ai = malloc(sizeof(struct addrinfo));
        memset(ai, 0, sizeof(struct addrinfo));

        ai->ai_family = hp->h_addrtype;
        ai->ai_socktype = SOCK_STREAM;
        ai->ai_addrlen = sizeof(struct sockaddr_in);

        ai->ai_addr = malloc(ai->ai_addrlen);
        sin = (struct sockaddr_in *) ai->ai_addr;
        memset(sin, 0, ai->ai_addrlen);

        memcpy(&sin->sin_addr, addr_list[i], hp->h_length);
        sin->sin_family = hp->h_addrtype;
        sin->sin_port = htons(atoi(servname));

        if (last) {
            last->ai_next = ai;
            last = ai;
        } else {
            *res = last = ai;
        }
    }
    return 0;
}

/**
 * Resolve an address into a hostname and port.
 *
 * @param sa address
 * @param salen number of bytes in sa
 * @param host hostname
 * @param hostlen number of available characters in host
 * @param serv service name
 * @param hostlen number of available characters in ser
 * @param flags flags
 *
 * @return <code>0</code> if successful;
 *         <code>-1</code> if unsuccessful
 */
static int STDCALL getnameinfo_ipv4(const struct sockaddr *sa, socklen_t salen,
        char *host, SOCKLEN_TYPE hostlen, char *serv, SOCKLEN_TYPE servlen, int flags)
{
    struct sockaddr_in *sin;

    sin = (struct sockaddr_in *) sa;
    strncpy(host, inet_ntoa(sin->sin_addr), hostlen);
    snprintf(serv, servlen, "%d", ntohs(sin->sin_port));

    return 0;
}

/**
 * Free address info returned by getaddrinfo_ipv4.
 *
 * @param ai address info
 */
static void STDCALL freeaddrinfo_ipv4(struct addrinfo *ai)
{
    struct addrinfo *p;

    while (ai) {
        p = ai;
        ai = ai->ai_next;

        free(p->ai_addr);
        free(p);
    }
}

/**
 * Get error message from error code.
 *
 * @param n error code
 *
 * @return error message
 */
static const char *gai_strerror_ipv4(int n)
{
    return hstrerror(n);
}

struct ip_info_vtable IPv4_VTABLE = {
    getaddrinfo_ipv4,
    getnameinfo_ipv4,
    freeaddrinfo_ipv4,
    gai_strerror_ipv4
};

struct ip_info_vtable IPv6_VTABLE = {
    getaddrinfo,
    getnameinfo,
    freeaddrinfo,
    gai_strerror,
};

