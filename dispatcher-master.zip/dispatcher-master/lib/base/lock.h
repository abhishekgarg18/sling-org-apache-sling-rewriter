/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2018 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

#ifndef __LOCK_H___
#define __LOCK_H___

/**
 * @file lock.h
 * @brief Lock
 */

/**
 * @defgroup base Base functionality
 * @{
 */

/**
 * @defgroup lock Lock
 * @{
 */

/** Opaque structure holding a lock */
struct lock;

/**
 * Create a new lock.
 *
 * @return lock or <code>NULL</code> if an error occurs
 */
struct lock * create_lock(struct log_context *lc);

/**
 * Acquire a lock.
 *
 * @param lock lock
 *
 * @return <code>0</code> on success, otherwise an error occurred
 */
int lock_acquire(struct lock *lock);

/**
 * Release a lock.
 *
 * @param lock lock
 */
void lock_release(struct lock *lock);

/**
 * Free a lock.
 *
 * @param lock lock
 */
void lock_free(struct lock *lock);

#endif /* __LOCK_H___ */
