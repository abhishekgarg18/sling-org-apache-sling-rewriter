/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * __________________
 *
 *  Copyright 2013 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

#ifndef __SOCKET_PRIVATE_H__
#define __SOCKET_PRIVATE_H__

/**
 * @file base_io.h
 * @brief I/O routines
 */

/**
 * @defgroup base Base functionality
 * @{
 */

/**
 * @defgroup socket Private Socket header
 * @{
 */

#ifdef WIN32

/* Info methods are __stdcall */
#define STDCALL __stdcall

/* getnameinfo expects DWORD instead of socklen_t */
typedef DWORD SOCKLEN_TYPE;

/* socket is not a file descriptor but a handle */
typedef SOCKET SOCKET_TYPE;

/* socket() returns INVALID_SOCKET in failure */
#define SOCKET_INVALID(s) (s == INVALID_SOCKET)

#else

#define STDCALL
typedef socklen_t SOCKLEN_TYPE;
typedef int SOCKET_TYPE;
#define SOCKET_INVALID(s) (s == -1)

#endif /* WIN32 */


/**
 * Socket type.
 */
struct socket {
    /** OS socket */
    SOCKET_TYPE socket;
    /** Write buffer */
    char buffer[4096];
    /** Write buffer position */
    size_t pos;
    /** send timeout, default is 600 secs */
    int send_timeout;
    /** recv timeout, default is 600 secs */
    int recv_timeout;
    /** last socket error string */
    char *err_string;
    /** connect method, invoked after socket connect */
    int (*connect)(struct log_context *, struct socket *, int);
    /** read method */
    int (*read)(struct log_context *, struct socket *, void *, int);
    /** write method */
    int (*write)(struct log_context *, struct socket *, const void *, size_t);
    /** shutdown method, invoked before socket close */
    void (*shutdown)(struct log_context *, struct socket *);
};


int socket_init(struct log_context *lc, struct socket *s, struct addrinfo *ai);

/**
 * Set socket error string.
 *
 * @param s socket
 * @param str error string
 */
void socket_set_errstring(struct socket *s, const char *str);

/** @} */
/** @} */

#endif /* __SOCKET_PRIVATE_H__ */
