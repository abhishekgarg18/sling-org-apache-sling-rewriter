/*
 * Copyright (c) 2010 Day Management AG
 * Barfuesserplatz 6, 4001 Basel, Switzerland
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Day Management AG, ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Day.
 */
#ifndef __PTRARRAY_H___
#define __PTRARRAY_H___

/**
 * @file ptrarray.h
 * @brief Pointer array
 */

/**
 * @defgroup base Base functionality
 * @{
 */

/**
 * @defgroup ptrarray Pointer array
 * @{
 */

/**
 * Declaration of a pointer array.
 */
struct ptrarray;

/**
 * Create a pointer array.
 *
 * @param pa where to return array
 * @param capacity initial capacity of array
 * @param free_p method to call when disposing pointers
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
int create_ptrarray(struct ptrarray **pa, int capacity, void (*free_p)(void *p));

/**
 * Add a pointer.
 *
 * @param pa pointer array
 * @param p pointer
 */
void ptrarray_add(struct ptrarray *pa, void *p);

/**
 * Return pointer at a given ndex.
 *
 * @param pa pointer array, may be <code>NULL</code>
 * @param index index
 *
 * @return pointer or <code>NULL</code>
 */
void *ptrarray_at(struct ptrarray *pa, int index);

/**
 * Return size of pointer array.
 *
 * @param pa pointer array, may be <code>NULL</code>
 *
 * @return size of array
 */
int ptrarray_size(struct ptrarray *pa);

/**
 * Return the internal pointer table, of type <code>void **</code>.
 *
 * @param pa pointer array, may be <code>NULL</code>
 *
 * @return internal pointer table, terminated by a <code>NULL</code> pointer
 */
void **ptrarray_get(struct ptrarray *pa);

/**
 * Clear the pointer array, removing all its items
 *
 * @param pa pointer array, may be <code>NULL</code>
 */
void ptrarray_clear(struct ptrarray *pa);

/**
 * Free pointer array
 *
 * @param pa pointer array, may be <code>NULL</code>
 */
void ptrarray_free(struct ptrarray *pa);

/** @} */
/** @} */

#endif /* __PARRAY_H___ */
