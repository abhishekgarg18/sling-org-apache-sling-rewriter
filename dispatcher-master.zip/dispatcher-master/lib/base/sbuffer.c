/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2019 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

#include "base/base.h"

/**
 * String buffer.
 */
struct sbuffer {
    /* default increment */
    int increment;
    /* size */
    int size;
    /* number of valid bytes */
    int count;
    /* pointer to data */
    char *p;
};

struct sbuffer *create_sbuffer(int size)
{
    struct sbuffer *sb = malloc(sizeof(struct sbuffer) + size);
    sb->size = sb->increment = size;
    sb->count = 0;
    sb->p = (char *) (sb + 1);
    *sb->p = 0;
    return sb;
}

void sbuffer_append(struct sbuffer *sb, const char *s)
{
    char *p;
    int len, inc;

    len = (int) strlen(s);
    if (len + sb->count + 1 >= sb->size) {
        inc = len + 1 >= sb->increment ? len +  1 : sb->increment;
        sb->size += inc;
        p = malloc(sb->size);
        memcpy(p, sb->p, sb->count + 1);
        if (sb->p != (char *) (sb + 1)) {
            free(sb->p);
        }
        sb->p = p;
    }
    strcpy(sb->p + sb->count, s);
    sb->count += len;
}

const char * sbuffer_to_string(struct sbuffer *sb)
{
    return sb->p;
}

size_t sbuffer_len(struct sbuffer *sb)
{
    return sb->count;
}

void sbuffer_free(struct sbuffer *sb)
{
    if (sb == NULL) {
        return;
    }
    if (sb->p != (char *) (sb + 1)) {
        free(sb->p);
    }
    free(sb);
}
