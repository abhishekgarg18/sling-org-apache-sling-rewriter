/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2014 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

#include "base.h"

#if defined(WIN32)
/* nothing to include */
#elif defined(SOLARIS)
# include <synch.h>
# include <thread.h>
#else
# include <pthread.h>
#endif

struct lock {
#ifdef WIN32
    CRITICAL_SECTION cs;
#elif defined(SOLARIS)
    mutex_t m;
#else /* PTHREAD */
    pthread_mutex_t m;
#endif
};

struct lock * create_lock(struct log_context *lc) {
    struct lock *lock = malloc(sizeof(struct lock));

#ifdef WIN32
    InitializeCriticalSection(&lock->cs);
#elif defined(SOLARIS)
    mutex_init(&lock->m, USYNC_THREAD, NULL);
#else /* PTHREAD */
    int ret;
    if ((ret = pthread_mutex_init(&lock->m, NULL)) != 0) {
        ERR("Unable to initialize mutex: %s", strerror(ret));
        free(lock);
        return NULL;
    }
#endif
    return lock;
}

int lock_acquire(struct lock *lock) {
#ifdef WIN32
    EnterCriticalSection(&lock->cs);
    return 0;
#elif defined(SOLARIS)
    return mutex_lock(&lock->m);
#else /* PTHREAD */
    return pthread_mutex_lock(&lock->m);
#endif
}

void lock_release(struct lock *lock) {
#ifdef WIN32
    LeaveCriticalSection(&lock->cs);
#elif defined(SOLARIS)
    mutex_unlock(&lock->m);
#else /* PTHREAD */
    pthread_mutex_unlock(&lock->m);
#endif
}

void lock_free(struct lock *lock) {
    if (lock != NULL) {
#ifdef WIN32
        DeleteCriticalSection(&lock->cs);
#elif defined(SOLARIS)
        mutex_destroy(&lock->m);
#else /* PTHREAD */
        pthread_mutex_destroy(&lock->m);
#endif
        free(lock);
    }
}
