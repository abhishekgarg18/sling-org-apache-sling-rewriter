/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * __________________
 *
 *  Copyright 2016 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

#include "base/base.h"

/**
 * Pointer entry.
 */
struct ptr_entry {
    /** parent list */
    struct ptrlist *pl;
    /** value */
    void *p;
    /** next entry in list */
    struct ptr_entry *next;
};

/**
 * Pointer list
 */
struct ptrlist {
    /* current size of list */
    int size;
    /* method to call when disposing pointers */
    void (*free_p)(void *p);
    /* first entry in list */
    struct ptr_entry *first;
    /* last entry in list */
    struct ptr_entry *last;
};


/*----------------------------------------------------------- Public methods */


int create_ptrlist(struct ptrlist **pl, void (*free_p)(void *))
{
    struct ptrlist *result;

    result = malloc(sizeof(struct ptrlist));
    result->size = 0;
    result->free_p = free_p;
    result->first = result->last = NULL;

    *pl = result;
    return 0;
}

struct ptr_entry *ptrlist_first(struct ptrlist *pl)
{
    return pl->first;
}

struct ptr_entry *ptrlist_next(struct ptr_entry *last)
{
    return last->next;
}

void *ptrlist_get(struct ptr_entry *entry)
{
    return entry->p;
}

void ptrlist_add(struct ptrlist *pl, void *p)
{
    struct ptr_entry *entry;

    entry = malloc(sizeof(struct ptr_entry));
    entry->pl = pl;
    entry->p = p;
    entry->next = NULL;

    if (pl->last) {
        pl->last->next = entry;
    } else {
        pl->first = entry;
    }
    pl->last = entry;
    pl->size++;
}

void *ptrlist_remove(struct ptrlist *pl)
{
    struct ptr_entry *entry;
    void *p;

    if (pl->first == NULL) {
        return NULL;
    }
    entry = pl->first;
    pl->first = pl->first->next;

    if (pl->first == NULL) {
        pl->last = NULL;
    }

    p = entry->p;
    free(entry);
    pl->size--;
    return p;
}

int ptrlist_size(struct ptrlist *pl)
{
    return pl->size;
}

void ptrlist_free(struct ptrlist *pl)
{
    struct ptr_entry *entry = pl->first, *current;

    while (entry != NULL) {
        current = entry;
        entry = entry->next;
        if (pl->free_p) {
            pl->free_p(current->p);
        }
        free(current);
    }
    free(pl);
}
