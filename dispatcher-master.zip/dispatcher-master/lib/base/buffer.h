/*
 * Copyright (c) 2010 Day Management AG
 * Barfuesserplatz 6, 4001 Basel, Switzerland
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Day Management AG, ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Day.
 */
#ifndef __BUFFER_H__
#define __BUFFER_H__

/**
 * @file buffer.h
 * @brief Input and Output Buffers
 */

/**
 * @defgroup base Base functionality
 * @{
 */

/**
 * @defgroup buffer Input and Output Buffers
 * @{
 */

/**
 * Input buffer declaration.
 */
struct in_buffer;

/**
 * Create input buffer.
 *
 * @param b where to return buffer
 * @param size size in bytes of buffer
 * @param fill fill method
 * @param context context passed to fill method
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
int create_in_buffer(struct in_buffer **b, unsigned size,
        int (*fill)(void *context, void *p, size_t len), void *context);

/**
 * Read some bytes from an input buffer.
 *
 * @param b buffer
 * @param p pointer to data
 * @param len number of bytes
 *
 * @return <code>-1</code> on failure;
 *         otherwise number of bytes read into <code>p</code>
 */
int buffer_read(struct in_buffer *b, void *p, size_t len);

/**
 * Read one byte from an input buffer.
 *
 * @param b buffer
 *
 * @return <code>-2</code> on failure;
 *         <code>-1</code> on end of input
 *         otherwise next byte
 */
int buffer_readb(struct in_buffer *b);

/**
 * Read a line from an input buffer.
 *
 * @param b input buffer
 * @param p pointer to data
 * @param len number of bytes at <b>p</b>
 *
 * @return number of bytes read (not including the zero terminator)
 */
int buffer_readline(struct in_buffer *b, char *p, size_t len);

/**
 * Close an input buffer.
 *
 * @param b buffer
 */
void in_buffer_close(struct in_buffer *b);


/**
 * Output buffer declaration.
 */
struct out_buffer;

/**
 * Create output buffer.
 *
 * @param b where to return buffer
 * @param size size in bytes of buffer
 * @param flush flush method
 * @param context context passed to flush method
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
int create_out_buffer(struct out_buffer **b, unsigned size, int (*flush)(void *context, char *p, size_t len), void *context);

/**
 * Write some bytes to an output buffer.
 *
 * @param b buffer
 * @param p pointer to data
 * @param len number of bytes
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
int buffer_write(struct out_buffer *b, const char *p, size_t len);

/**
 * Return the number of available bytes in an output buffer.
 *
 * @param b buffer
 *
 * @return number of available bytes
 */
int buffer_avail(struct out_buffer *b);

/**
 * Flush an output buffer.
 *
 * @param b buffer
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
int buffer_flush(struct out_buffer *b);

/**
 * Close an output buffer.
 *
 * @param b buffer
 * @param flush flag indicating whether to flush the buffer first
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
int out_buffer_close(struct out_buffer *b, int flush);

/** @} */
/** @} */

#endif /* __BUFFER_H__ */
