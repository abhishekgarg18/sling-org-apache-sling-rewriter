/*
 * Copyright (c) 2010 Day Management AG
 * Barfuesserplatz 6, 4001 Basel, Switzerland
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Day Management AG, ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Day.
 *
 */
#include "base/base.h"
#include "zlib.h"

/**
 * Content-Length header name (lower-case).
 */
static const char *_clen_name = "content-length";

/**
 * Transfer-Encoding header name (lower-case).
 */
static const char *_te_name = "transfer-encoding";

/**
 * Chunked Transfer-Encoding header value (lower-case).
 */
static const char *_chunked_value = "chunked";

/**
 * Content-Encoding header name (lower-case).
 */
static const char *_ce_name = "content-encoding";

/**
 * Gzip Content-Encoding header value (lower-case).
 */
static const char *_gzip_value = "gzip";

/**
 * Set an error message.
 */
#define SET_ERR(fmt, ...) snprintf(hc->msg, sizeof hc->msg, fmt, __VA_ARGS__)

/**
 * A structure holding a character buffer.
 */
struct buffer {
    /* input buffer */
    char buf[65536];
    /* current position */
    int pos;
    /* total available bytes */
    int count;
};

/**
 * A structure holding a chunk.
 */
struct chunk {
    /* size of the current chunk */
    int size;
    /* position inside chunk */
    int pos;
};

/**
 * Internal structure needed for in-memory decompression of gzipped content.
 */
struct gunzip_helper {
    /* zlib stream */
    z_stream strm;
    /* fill method */
    int (*fillf) OF((Byte * ptr, uLongf *size, void *context));
    /* user-supplied context */
    void *context;
    /* flag indicating end of stream */
    unsigned eos : 1;

    /* incoming buffer (compressed) */
    Byte in[4096];
    /* outgoing buffer (uncompressed) */
    Byte out[4096];
    /* address of next unconsumed byte */
    Byte *next_out;
};

/**
 * A structure holding a HTTP client.
 */
struct http_client {
    /** log context */
    struct log_context *lc;

    /** error message */
    char msg[512];
    /** errno */
    int socket_errno;
    /** Options */
    unsigned options;

    /* Connection section: connection factory */
    struct connection_factory *factory;
    /* connection */
    struct connection *conn;

    /** Request section: endpoint */
    struct endpoint ep;
    /* method */
    const char *method;
    /* headers */
    struct http_headers *req_headers;
    /* content length */
    long long req_clen;

    /** Response section: status line */
    char *sline;
    /* status code or one of the HC_Exxx values */
    int status;
    /* headers */
    struct http_headers *res_headers;
    /* content length */
    long long res_clen;
    /* number of bytes read from the body */
    long long read;
    /* input buffer */
    struct buffer in;
    /* chunk */
    struct chunk chunk;
    /* gunzip helper */
    struct gunzip_helper gh;

    /* whether we're connected */
    unsigned connected : 1;
    /* whether we've sent headers */
    unsigned headers_sent : 1;
    /* whether request body type was checked */
    unsigned req_body_type : 1;
    /* whether request is chunked */
    unsigned req_chunked : 1;
    /* whether response body type was checked */
    unsigned res_body_type : 1;
    /* whether we do not expect a response body */
    unsigned res_no_body : 1;
    /* whether response is chunked */
    unsigned res_chunked : 1;
    /* whether response is gzipped */
    unsigned gzipped : 1;
    /* whether helper was initialized */
    unsigned ginit : 1;
    /* whether response should be decompressed while reading */
    unsigned keep_compressed : 1;
    /* whether response from backend was read completely */
    unsigned complete : 1;
    /* whether this is a GET or head */
    unsigned get_or_head : 1;
    /* flag indicating whether trace is enabled */
    unsigned trace : 1;
    /* flag indicating whether connection should be closed */
    unsigned should_close : 1;
    /* flag indicating whether we reused a connection */
    unsigned connection_reused : 1;
    /* flag indicating whether the remote peer simply closed its side without sending a response */
    unsigned no_answer : 1;
};

/**
 * Add a request header to to be sent.
 *
 * @param hc HTTP client
 * @param name name
 * @param value value
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
static int add_request_header(struct http_client *hc, const char *name, const char *value)
{
    http_headers_add_nv(hc->req_headers, name, value);

    return 0;
}

/**
 * Send the request line and all request headers. This method uses our input
 * buffer to format the request line, which is ok because that input buffer
 * gets filled only later, when the response is parsed. In other words, we
 * always send a complete request and then fetch a complete response.
 *
 * @param hc HTTP client
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
static int send_request(struct http_client *hc)
{
    struct log_context *lc = hc->lc;
    struct endpoint *ep = &hc->ep;
    char *line = hc->in.buf;
    const size_t line_len = sizeof(hc->in.buf);
    int i, len;

    if (ep->query) {
        len = snprintf(line, line_len, "%s %s?%s %s\r\n",
                       hc->method, ep->file, ep->query, ep->protocol ? "HTTP/1.0" : "HTTP/1.1");
    } else {
        len = snprintf(line, line_len, "%s %s %s\r\n", hc->method, ep->file,
                       ep->protocol ? "HTTP/1.0" : "HTTP/1.1");
    }
    if (len >= (int) line_len) {
        errno = E2BIG;
        return -1;
    }

    if (hc->trace) {
        TRACE("request.uri = \"%s\"", ep->file);
    }
    if (hc->conn->write(hc->conn, line, strlen(line))) {
        return -1;
    }

    for (i = 0; i < http_headers_size(hc->req_headers); i++) {
        struct http_header *header = http_headers_at(hc->req_headers, i);
        if (hc->trace) {
            TRACE("request.headers[%s] = \"%s\"", header->name, header->value);
        }
        snprintf(line, line_len, "%s: %s\r\n", header->name, header->value);
        if (hc->conn->write(hc->conn, line, strlen(line))) {
            return -1;
        }
    }

    if (http_headers_get(hc->req_headers, "host") == NULL) {
        if ((ep->port == 80 && !ep->secure) || (ep->port == 443 && ep->secure)) {
            if (hc->trace) {
                TRACE("request.headers[Host] = \"%s\"", ep->host);
            }
            snprintf(line, line_len, "Host: %s\r\n", ep->host);
        } else {
            if (hc->trace) {
                TRACE("request.headers[Host] = \"%s:%d\"", ep->host, ep->port);
            }
            snprintf(line, line_len, "Host: %s:%d\r\n", ep->host, ep->port);
        }
        if (hc->conn->write(hc->conn, line, strlen(line))) {
            return -1;
        }
    }

    if (hc->conn->write(hc->conn, "\r\n", 2) || hc->conn->flush(hc->conn)) {
        return -1;
    }
    return 0;
}

/**
 * Read more bytes from the remote server into our internal buffer.
 *
 * @param hc HTTP client
 *
 * @return number of bytes actually read;
 *         <code>-1</code> if there was an error
 */
static int read_bytes(struct http_client *hc)
{
    struct buffer *in = &hc->in;
    int read;

    hc->socket_errno = 0;
    if ((read = hc->conn->read(hc->conn, in->buf, sizeof in->buf)) < 0) {
        SET_ERR("Reading from remote peer failed: %s", hc->conn->errmsg(hc->conn));
        hc->socket_errno = hc->conn->errcode(hc->conn);
        return -1;
    }
    in->pos = 0;
    in->count = read;
    return read;
}

/**
 * Read exactly <code>n</bytes> from the internal buffer, reading more data from
 * the remote server if necessary.
 *
 * @param hc HTTP client
 * @param p buffer
 * @param len number of bytes to read
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
static int read_fully(struct http_client *hc, char *p, size_t len)
{
    struct buffer *in = &hc->in;
    int n, read = 0;
    const int p_len = (int) len;

    while (read < p_len) {
        /* read more data from server no more available */
        if (in->pos >= in->count) {
            if (read_bytes(hc) <= 0) {
                return -1;
            }
        }
        /* crop if more data available than required */
        if ((n = in->count - in->pos) > p_len - read) {
            n = p_len - read;
        }
        memcpy(p + read, in->buf + in->pos, n);
        read += n;
        in->pos += n;
    }
    return 0;
}

/**
 * Set the response status line.
 *
 * @param hc HTTP client
 * @param line status line
 */
static void set_status_line(struct http_client *hc, const char *line)
{
    if (hc->sline) {
        free(hc->sline);
    }
    hc->sline = strdup(line);

    /* Skip protocol (e.g. HTTP/1.1) */
    while (*line && !WS(*line)) {
        line++;
    }
    /* Skip space */
    while (*line && WS(*line)) {
        line++;
    }
    hc->status = (int) strtol(line, NULL, 10);
}

/**
 * Add a response header parsed in the backend's response.
 *
 * @param hc HTTP client
 * @param line header line
 */
static void add_response_header(struct http_client *hc, char *line)
{
    struct http_header *header;

    header = http_headers_add(hc->res_headers, line);
    if (header != NULL && !strcasecmp(header->name, "connection") && !strcasecmp(header->value, "close")) {
        hc->should_close = 1;
    }
}

/**
 * Parse states.
 */
#define PS_PRE 0
#define PS_INIT 1
#define PS_START 2
#define PS_BEFORE_LF 3
#define PS_BEFORE_CR_2 4
#define PS_BEFORE_LF_2 5
#define PS_HEADER 6
#define PS_FINISHED 7

/**
 * Parse response until end of header section.
 *
 * @param hc HTTP client
 *
 * @return 0 if no error occurred; <>0 otherwise
 */
static int parse_response(struct http_client *hc)
{
    struct log_context *lc = hc->lc;
    struct buffer *in = &hc->in;
    char ch, *buf, line[8192];
    const int line_len = sizeof(line);
    int state, writeptr, read;
    const char *error;

    state = PS_PRE;
    buf = in->buf;
    writeptr = 0;
    error = NULL;

    while (state != PS_FINISHED && error == NULL) {
        if (in->pos >= in->count) {
            if ((read = read_bytes(hc)) == 0) {
                error = "no more bytes available (remote peer closed connection)";
                break;
            } else if (read < 0) {
                break;
            }
        }
        ch = buf[in->pos++];

        switch (state) {
        case PS_PRE:
            state = PS_INIT;
            /* fall through */
        case PS_INIT:
            // ignore possible leading garbage from a previous empty chunked response
            if (!WS(ch) && ch != '0') {
                if (ch == 'H') {
                    line[writeptr++] = ch;
                    state = PS_START;
                } else {
                    WARN("ignoring unexpected character %c", ch);
                }
            }
            break;
        case PS_START:
            if (ch == '\r' || ch == '\n') {
                line[writeptr] = '\0';
                set_status_line(hc, line);
                writeptr = 0;
                if (ch == '\r') {
                    state = PS_BEFORE_LF;
                } else if (ch == '\n') {
                    state = PS_BEFORE_CR_2;
                }
            } else if (writeptr >= line_len) {
                error = "request line too long";
            } else {
                line[writeptr++] = ch;
            }
            break;
        case PS_BEFORE_LF:
            if (ch == '\n') {
                state = PS_BEFORE_CR_2;
            } else if (ch == '\r') {
                state = PS_FINISHED;
            }
            break;
        case PS_BEFORE_CR_2:
            if (ch == '\r') {
                state = PS_BEFORE_LF_2;
            } else if (ch == '\n') {
                state = PS_FINISHED;
            } else {
                state = PS_HEADER;
                line[writeptr++] = ch;
            }
            break;
        case PS_BEFORE_LF_2:
            if (ch == '\n') {
                state = PS_FINISHED;
            } else {
                error = "no second CR LF";
            }
            break;
        case PS_HEADER:
            if (ch == '\r' || ch == '\n') {
                line[writeptr] = '\0';
                add_response_header(hc, line);
                writeptr = 0;
                if (ch == '\r') {
                    state = PS_BEFORE_LF;
                } else if (ch == '\n') {
                    state = PS_BEFORE_CR_2;
                }
            } else if (writeptr >= line_len) {
                error = "header too long";
            } else {
                line[writeptr++] = ch;
            }
            break;
        default:
            break;
        }
    }
    if (!error && state != PS_FINISHED) {
        error = "premature end in HTTP response";
    }
    if (error) {
        char msg[256];
        int msg_len;

        if (hc->sline) {
            msg_len = snprintf(msg, sizeof msg, "%s, status line: %s", error, hc->sline);
        } else {
            msg_len = snprintf(msg, sizeof msg, "%s", error);
        }
        if (hc->msg[0]) {
            snprintf(msg + msg_len, sizeof(msg) - msg_len, " (%s)", hc->msg);
        }
        SET_ERR("%s", msg);
        if (hc->msg[0]) {
            DBG("Unable to parse response: %s, state = %d", hc->msg, state);
        }
        if (state == PS_PRE) {
            hc->no_answer = 1;
        }
        return -1;
    }
    return 0;
}

/**
 * Read the chunk size.
 *
 * @param hc HTTP client
 *
 * @return chunk size or <code>-1</code> if an error occurs
 */
static int read_chunk_size(struct http_client *hc)
{
    struct chunk *chunk = &hc->chunk;
    char buf[10];
    int i, size = -1;
    const int buf_len = sizeof(buf);

    if (chunk->size) {
        /* read previous chunk end */
        if (read_fully(hc, buf, 2)) {
            return -1;
        }
        if (buf[0] != '\r' || buf[1] != '\n') {
            SET_ERR("Expected CR+LF at end of chunk, actual: %02X+%02X",
                    ((int) buf[0]) & 0xff, ((int) buf[1]) & 0xff);
            return -1;
        }
    }
    for (i = 0; i < buf_len; i++) {
        if (read_fully(hc, &buf[i], 1)) {
            return -1;
        }
        if (buf[i] == '\n') {
            buf[i] = 0;
            size = (int) strtol(buf, NULL, 16);
            break;
        }
    }
    if (size == -1) {
        return -1;
    } else if (size == 0) {
        return 0;
    }
    chunk->pos = 0;
    chunk->size = size;

    return size;
}

/**
 * Read bytes from the body of the response.
 *
 * @param hc HTTP client
 * @param p buffer
 * @param len number of bytes to read
 *
 * @return number of bytes actually read;
 *         <code>0</code> on EOF;
 *         <code>-1</code> if an error occurred
 */
static int read_body(struct http_client *hc, void *p, size_t len)
{
    struct chunk *chunk = &hc->chunk;
    struct buffer *in = &hc->in;
    int ret;
    int n = (int) len;

    /* check whether body is chunked */
    if (hc->res_chunked) {
        if (chunk->pos >= chunk->size) {
            if ((ret = read_chunk_size(hc)) <= 0) {
                return ret;
            }
        }
        if (n > chunk->size - chunk->pos) {
            n = chunk->size - chunk->pos;
        }
    } else if (hc->res_clen == hc->read) {
        return 0;
    }

    /* check how many bytes are available */
    if (in->pos >= in->count) {
        if ((ret = read_bytes(hc)) == 0) {
            return 0;
        } else if (ret < 0) {
            return -1;
        }
    }
    if (n > in->count - in->pos) {
        n = in->count - in->pos;
    }
    memcpy(p, in->buf + in->pos, n);

    /* increment position counters */
    in->pos += n;
    hc->read += n;
    chunk->pos += n;

    return n;
}

/**
 * Fill method for gunzip_read.
 *
 * @param ptr pointer to data
 * @param size number of available bytes in ptr on input;
 *             number of read bytes on output
 * @param context HTTP client
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> on failure
 */
static int gunzip_fill(Byte *ptr, uLongf *size, void *context)
{
    struct http_client *hc = (struct http_client *) context;
    int ret;

    if ((ret = read_body(hc, ptr, *size)) < 0) {
        return -1;
    }
    *size = (uLongf) ret;
    return 0;
}

/**
 * Initialize a helper.
 *
 * @param gh helper
 * @param fillf function to call when more bytes to decompress
 *              need to be provided
 * @param context context to pass to readf
 * @return Z_OK or some Z_ERROR
 */
static int gunzip_init(struct gunzip_helper *gh,
        int (*fillf) OF((Byte *, uLongf *, void *)), void *context)
{
    z_stream *strm;

    memset(gh, 0, sizeof(struct gunzip_helper));
    gh->fillf = fillf;
    gh->context = context;

    strm = &gh->strm;
    strm->next_in = gh->in;
    strm->avail_in = 0;
    strm->next_out = gh->next_out = gh->out;
    strm->avail_out = sizeof gh->out;

    /* initialize with gzip detection (16) and default window size (32768) */
    return inflateInit2(&gh->strm, 31);
}

/**
 * Read more bytes from the gzipped stream.
 *
 * @param gh helper
 * @param p memory pointer where to return data
 * @param len number of bytes at p
 *
 * @return number of bytes read, <code>0</code> on EOF,
 *         or a Z_ERROR
 */
static int gunzip_read(struct gunzip_helper *gh, void *p, size_t len)
{
    z_stream *strm = &gh->strm;
    uLongf size;
    int ret;
    size_t avail;

    for (;;) {
        if (gh->next_out < strm->next_out) {
            /* some bytes available, return them */
            avail = strm->next_out - gh->next_out;
            if (avail > len) {
                avail = len;
            }
            memcpy(p, gh->next_out, avail);
            gh->next_out += avail;
            return (int) avail;
        }
        if (gh->eos) {
            /* no more bytes available and EOS */
            return 0;
        }
        if (strm->avail_in == 0) {
            /* no more bytes to uncompress, read more */
            strm->next_in = gh->in;
            size = sizeof gh->in;
            if (gh->fillf(strm->next_in, &size, gh->context) < 0) {
                return Z_STREAM_ERROR;
            }
            strm->avail_in = (uInt) size;
        }
        if (strm->avail_out == 0) {
            /* no more space available, reset */
            strm->next_out = gh->next_out = gh->out;
            strm->avail_out = sizeof gh->out;
        }
        ret = inflate(strm, Z_FINISH);
        if (ret == Z_STREAM_END) {
            gh->eos = 1;
        } else if (ret != Z_BUF_ERROR) {
            return ret;
        }
    }
    return Z_OK;
}

/**
 * End using this helper.
 */
static int gunzip_end(struct gunzip_helper *gh)
{
    return inflateEnd(&gh->strm);
}

/**
 * Read content from the body of the response.
 *
 * @param hc HTTP client
 * @param p buffer
 * @param len number of bytes to read
 *
 * @return number of bytes actually read;
 *         <code>0</code> on EOF;
 *         <code>-1</code> if an error occurred
 */
static int read_content(struct http_client *hc, void *p, size_t len)
{
    int ret;

    if (hc->gzipped && !hc->keep_compressed) {
        if (!hc->ginit) {
            if ((ret = gunzip_init(&hc->gh, gunzip_fill, hc)) != Z_OK) {
                SET_ERR("%s", zError(ret));
                return -1;
            }
            hc->ginit = 1;
        }
        *hc->msg = 0;
        if ((ret = gunzip_read(&hc->gh, p, len)) < 0) {
            if (*hc->msg == 0) {
                SET_ERR("%s", zError(ret));
            }
            return -1;
        }
    } else {
        ret = read_body(hc, p, len);
    }
    /* Check for EOF */
    if (ret == 0) {
        hc->complete = 1;
    }
    return ret;
}

/*----------------------------------------------------------- Public methods */

struct http_client *create_http_client(struct log_context *lc, struct endpoint *ep)
{
    struct connection_factory *factory = get_socket_factory();
    struct http_client *hc;

    hc = malloc(sizeof(struct http_client));
    memset(hc, 0, sizeof(struct http_client));

    hc->lc = lc;
    hc->factory = factory;
    hc->req_clen = hc->res_clen = -1;
    hc->ep = *ep;
    hc->method = ep->method ? ep->method : "GET";
    hc->get_or_head = (!strcmp(hc->method, "GET") || !strcmp(hc->method, "HEAD")) ? 1 : 0;

    if ((hc->req_headers = create_http_headers()) == NULL ||
        (hc->res_headers = create_http_headers()) == NULL) {
        return NULL;
    }
    hc->trace = log_is_enabled(lc, LL_TRACE);
    return hc;
}

void http_client_set_options(struct http_client *hc, unsigned mask, int on)
{
    if (on) {
        hc->options |= mask;
    } else {
        hc->options &= (~mask);
    }
}

const char *http_client_get_error(struct http_client *hc)
{
    if (*hc->msg) {
        return hc->msg;
    }
    return strerror(errno);
}

void http_client_add_header(struct http_client *hc, const char *name, const char *value)
{
    struct log_context *lc = hc->lc;

    if (!strcasecmp(name, "expect") && !strcmp(value, "100-continue"))
    {
        /* Do not forward this header as we decide ourselves whether it is required */
        return;
    }
    // TODO: filter out "Connection: xx" and others as well, create inline
    //       table of headers that should be ignored

    if (!hc->trace) {
        /* Omit this if we trace the exact name/value combination anyway */
        DBG("Adding request header: %s", name);
    }
    add_request_header(hc, name, value);
}

void http_client_add_headers(struct http_client *hc, struct hdrarray *headers)
{
    const char *name, *value;
    int i;

    for (i = 0; i < hdrarray_size(headers); i++) {
        hdrarray_at(headers, i, &name, &value);
        http_client_add_header(hc, name, value);
    }
}

int http_client_connect(struct http_client *hc)
{
    struct log_context *lc = hc->lc;

    if (!hc->connected) {
        hc->conn = hc->factory->create(lc, hc->factory, &hc->ep, sizeof(struct endpoint), 1);
        if (hc->conn == NULL) {
            SET_ERR("%s", hc->factory->errmsg(hc->factory));
            hc->status = HC_ECONN;
            return -1;
        }
        hc->connected = 1;
    }
    return hc->status >= 0 ? 0 : -1;
}

int http_client_send_headers(struct http_client *hc)
{
    struct log_context *lc = hc->lc;
    struct http_header *header;
    short continue_expected = 0;

    if (http_client_connect(hc) < 0) {
        return -1;
    }
    if (!hc->headers_sent) {
        if (!hc->req_body_type) {
            if ((header = http_headers_get(hc->req_headers, _te_name)) && !strcasecmp(_chunked_value, header->value)) {
                hc->req_chunked = 1;
            } else {
                hc->req_clen = http_headers_get_llong(hc->req_headers, _clen_name);
            }
            if ((hc->req_chunked || hc->req_clen != -1) && !(hc->options & OPTION_DISABLE_CONTINUE)) {
                add_request_header(hc, "Expect", "100-continue");
                continue_expected = 1;
            }
            hc->req_body_type = 1;
        }
        if (send_request(hc)) {
            hc->status = HC_ESEND;
            return -1;
        }
        hc->headers_sent = 1;

        if (continue_expected) {
            if (parse_response(hc)) {
                WARN("Failed parsing expected 100 continue response: %s.", http_client_get_error(hc));
                return hc->status = HC_ERECV;
            } else if (hc->status == 100) {
                hc->status = 0;
            }
        }
    }
    return hc->status;
}

int http_client_write(struct http_client *hc, const void *p, size_t len)
{
    char buf[20];
    int ret;

    if (!hc->headers_sent && (ret = http_client_send_headers(hc))) {
        if (ret > 0) {
            SET_ERR("Server did not send 100 (Continue) response, but %d", hc->status);
        }
        return -1;
    }
    if (hc->req_chunked) {
        snprintf(buf, sizeof buf, "%04X\r\n", (unsigned) len);
        if (hc->conn->write(hc->conn, buf, strlen(buf)) ||
                hc->conn->write(hc->conn, p, len) ||
                hc->conn->write(hc->conn, "\r\n", 2)) {
            hc->status = HC_ESEND;
            return -1;
        }
    } else if (hc->conn->write(hc->conn, p, (unsigned) len)) {
        hc->status = HC_ESEND;
        return -1;
    }

    if (hc->conn->flush(hc->conn)) {
        hc->status = HC_ESEND;
        return -1;
    }
    return 0;
}

int http_client_get_status(struct http_client *hc, const char **sline)
{
    struct log_context *lc = hc->lc;
    if (hc->status == 0 && !http_client_send_headers(hc))
    {
        if (hc->req_chunked) {
            if (hc->conn->write(hc->conn, "0\r\n\r\n", 5) || hc->conn->flush(hc->conn)) {
                return hc->status = HC_ESEND;
            }
        }
        if (parse_response(hc)) {
            if (hc->connection_reused && hc->no_answer) {
                DBG("Remote peer provided no answer on reused connection, probably closed after "
                    "timeout expired.");
            } else {
                WARN("Failed parsing response: %s.", http_client_get_error(hc));
            }
            return hc->status = HC_ERECV;
        } else if (hc->status == 100) {
            DBG("Server sent 100 Continue status, fetching next response.");
            hc->status = 0;
            if (parse_response(hc)) {
                WARN("Failed parsing response after 100 continue: %s.", http_client_get_error(hc));
                return hc->status = HC_ERECV;
            }
        }
    }
    if (sline) {
        *sline = hc->sline;
    }
    return hc->status;
}

struct http_headers *http_client_get_headers(struct http_client *hc)
{
    if (http_client_get_status(hc, NULL) < 0) {
        return NULL;
    }
    return hc->res_headers;
}

long long http_client_get_clen(struct http_client *hc)
{
    return http_headers_get_llong(hc->res_headers, _clen_name);
}

void http_client_keep_compressed(struct http_client *hc)
{
    hc->keep_compressed = 1;
}

static int has_response_body(struct http_client *hc)
{
    struct log_context *lc = hc->lc;
    struct http_header *header;

    if (!hc->res_body_type) {
        if (hc->status < 200 || hc->status == 204 || hc->status == 304 || !strcmp(hc->method, "HEAD")) {
            /* HTTP/1.1 section 4.4: these response status codes or a HEAD
             * request MUST not be followed by a response body */
            hc->res_no_body = 1;
        } else {
            if ((header = http_headers_get(hc->res_headers, _te_name)) && !strcasecmp(_chunked_value, header->value)) {
                hc->res_chunked = 1;
            } else if ((hc->res_clen = http_headers_get_llong(hc->res_headers, _clen_name)) == 1) {
                DBG("Neither encoding nor content length present, waiting for server close: %s",
                    hc->ep.file);
            }
            if ((header = http_headers_get(hc->res_headers, _ce_name)) && !strcasecmp(_gzip_value, header->value)) {
                hc->gzipped = 1;
            }
        }
        hc->res_body_type = 1;
    }
    return !hc->res_no_body;
}

int http_client_read(struct http_client *hc, void *p, size_t len)
{
    if (http_client_get_status(hc, NULL) < 0) {
        return -1;
    }
    if (!has_response_body(hc)) {
        return 0;
    }
    return read_content(hc, p, len);
}

int http_client_readline(struct http_client *hc, char *p, size_t len)
{
    int i, ret;
    char ch, buf[1];
    const int p_len = (int) len;

    if (http_client_get_status(hc, NULL) < 0) {
        return -1;
    }
    if (!has_response_body(hc)) {
        return 0;
    }
    for (i = 0; i < p_len - 1; i++) {
        if ((ret = read_content(hc, buf, 1)) == 0) {
            break;
        } else if (ret == -1) {
            return -1;
        }
        if ((ch = *buf) == '\r') {
            continue;
        } else if (ch == '\n') {
            break;
        } else {
            *p++ = ch;
        }
    }
    *p = 0;
    return i;
}

int http_client_store(struct http_client *hc, FILE *fp, const char *path)
{
    struct log_context *lc = hc->lc;
    char buf[8192];
    int read, written;
    long long total = 0, clen;

    for (;;) {
        if ((read = http_client_read(hc, buf, sizeof buf)) < 0) {
            ERR("Error while reading from remote server: %s", http_client_get_error(hc));
            return -2;
        } else if (!read) {
            break;
        } else {
            written = (int) fwrite(buf, 1, (size_t) read, fp);
            if (written < read) {
                ERRE("Error while writing to file: %s", strerror(errno));
                return -1;
            }
        }
    }
    total = http_client_get_read(hc);
    if ((clen = http_client_get_clen(hc)) != -1 && clen != total) {
        ERR("Content length mismatch for %s, expected: %llu, actual: %llu", path, clen, total);
        return -2;
    }
    return 0;
}

int http_client_get_errno(struct http_client *hc)
{
    return hc->socket_errno;
}

long long http_client_get_read(struct http_client *hc)
{
    return hc->read;
}

int http_client_init_retry(struct http_client *hc)
{
    struct log_context *lc = hc->lc;

    if (hc->conn != NULL) {
        DBG("initializing retry, closing connection");
        hc->conn->close(hc->conn, 0);
        hc->conn = NULL;
    }

    hc->socket_errno = 0;

    hc->status = 0;
    hc->res_clen = -1;
    hc->read = 0;

    memset(&hc->in, 0, sizeof hc->in);
    memset(&hc->chunk, 0, sizeof hc->chunk);
    if (hc->ginit) {
        gunzip_end(&hc->gh);
        hc->ginit = 0;
    }
    http_headers_clear(hc->res_headers);

    hc->connected = 0;
    hc->headers_sent = 0;
    hc->res_body_type = 0;
    hc->complete = 0;
    hc->should_close = 0;
    hc->connection_reused = 0;
    hc->no_answer = 0;

    hc->conn = hc->factory->create(lc, hc->factory, &hc->ep, sizeof hc->ep, 0);
    if (hc->conn == NULL) {
        SET_ERR("%s", hc->factory->errmsg(hc->factory));
        return -1;
    }
    hc->connected = 1;
    return 0;
}

void http_client_free(struct http_client *hc)
{
    struct log_context *lc = hc->lc;
    int keep = 0;

    if (!hc) {
        return;
    }
    if (hc->ginit) {
        gunzip_end(&hc->gh);
    }

    free(hc->sline);

    if (hc->conn != NULL) {
        if (hc->factory->keepalive(hc->factory)) {
            if (!hc->res_no_body && !hc->complete) {
                DBG("No socket reuse: response body not fully consumed");
            } else if (!hc->get_or_head) {
                DBG("No socket reuse: neither GET nor HEAD");
            } else if (hc->should_close) {
                DBG("No socket reuse: backend asks to close connection");
            } else {
                keep = 1;
            }
        }
        hc->conn->close(hc->conn, keep);
    }

    http_headers_free(hc->req_headers);
    http_headers_free(hc->res_headers);

    free(hc);
}
