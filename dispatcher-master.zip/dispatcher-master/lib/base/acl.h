/*
 * Copyright (c) 2008 Day Management AG
 * Barfuesserplatz 6, 4001 Basel, Switzerland
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Day Management AG, ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Day.
 */
#ifndef __ACL_H__
#define __ACL_H__

struct any_item;

/**
 * @file acl.h
 * @brief Access control lists
 */

/**
 * @defgroup base Base functionality
 * @{
 */

/**
 * @defgroup acl Access control lists
 * @{
 */

/**
 * Create an access control list from an any structure, starting at the first child.
 *
 * @param first first child of list
\ * @param name optional name, may be <code>NULL</code>
 *
 * @return ACL or <code>NULL</code> if an error occurred
 */
struct acl *acl_create(struct log_context *lc, struct any_item *first, const char *name);

/**
 * Match an item against the globs in a ACL and return the last item of type
 * <b>allow</b> that matches a given string.
 *
 * @param acl ACL to scan, may be <code>NULL</code>
 * @param s string to match
 *
 * @return last matching item of type <b>allow</b>, otherwise <code>NULL</code>
 */
struct ace *acl_allowed(struct log_context *lc, struct acl *acl, const char *s);

/**
 * Match an item against the globs in a ACL and return the last item of type
 * <b>deny</b> that matches a given string.
 *
 * @param acl ACL to scan, may be <code>NULL</code>
 * @param s string to match
 *
 * @return last matching item of type <b>deny</b>, otherwise <code>NULL</code>
 */
struct ace *acl_denied(struct acl *acl, const char *s);

/**
 * Free memory associated with an access control list.
 *
 * @param acl access control list, may be <code>NULL</code>
 */
void acl_free(struct acl *acl);

/** @} */
/** @} */

#endif /* __ACL_H__ */
