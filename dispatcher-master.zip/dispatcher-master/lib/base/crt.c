/*
 * Copyright (c) 2008 Day Management AG
 * Barfuesserplatz 6, 4001 Basel, Switzerland
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Day Management AG, ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Day.
 */
#include <errno.h>
#include <fcntl.h>
#include <io.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>
#include <windows.h>
#include <sys/stat.h>
#include <sys/utime.h>

#include "utf8.h"

#define __CRT_C__
#include "crt.h"

/**
 * Replacements for Windows CRT functions that have a character string
 * representing a filename in their argument list. All those functions
 * are not able to handle long file names, exceeding 261 characters.
 *
 * The common pattern for our replacements is to convert a possibly relative
 * name into an absolute path name, composed of wide characters and prefixed
 * by "\\?\", and invoke the wide character version in MSVCRT.
 */

/* Prefix for long file names */
#define LFN_PFX     L"\\\\?\\"

/* Prefix length */
#define LFN_PFX_LEN 4

/* Prefix for UNC long file names */
#define UNC_PFX     L"UNC\\"

/* Prefix length for UNC long file names */
#define UNC_PFX_LEN 4

/* Maximal prefix length */
#define PFX_MAX_LEN 8

/* Maximum expected mode length in crt_fopen() */
#define MODE_MAX 10

/* Representation of Jan 1, 1980 as time */
static const int JAN_1_1980 = 0x12ce97f0;

/**
 * This is the error table that defines the mapping between OS error
 * codes and errno values
 */
struct errentry {
    unsigned long oscode;           /* OS return value */
    int errnocode;  /* System V error code */
};

static struct errentry errtable[] = {
    {  ERROR_INVALID_FUNCTION,       EINVAL    },  /* 1 */
    {  ERROR_FILE_NOT_FOUND,         ENOENT    },  /* 2 */
    {  ERROR_PATH_NOT_FOUND,         ENOENT    },  /* 3 */
    {  ERROR_TOO_MANY_OPEN_FILES,    EMFILE    },  /* 4 */
    {  ERROR_ACCESS_DENIED,          EACCES    },  /* 5 */
    {  ERROR_INVALID_HANDLE,         EBADF     },  /* 6 */
    {  ERROR_ARENA_TRASHED,          ENOMEM    },  /* 7 */
    {  ERROR_NOT_ENOUGH_MEMORY,      ENOMEM    },  /* 8 */
    {  ERROR_INVALID_BLOCK,          ENOMEM    },  /* 9 */
    {  ERROR_BAD_ENVIRONMENT,        E2BIG     },  /* 10 */
    {  ERROR_BAD_FORMAT,             ENOEXEC   },  /* 11 */
    {  ERROR_INVALID_ACCESS,         EINVAL    },  /* 12 */
    {  ERROR_INVALID_DATA,           EINVAL    },  /* 13 */
    {  ERROR_INVALID_DRIVE,          ENOENT    },  /* 15 */
    {  ERROR_CURRENT_DIRECTORY,      EACCES    },  /* 16 */
    {  ERROR_NOT_SAME_DEVICE,        EXDEV     },  /* 17 */
    {  ERROR_NO_MORE_FILES,          ENOENT    },  /* 18 */
    {  ERROR_LOCK_VIOLATION,         EACCES    },  /* 33 */
    {  ERROR_BAD_NETPATH,            ENOENT    },  /* 53 */
    {  ERROR_NETWORK_ACCESS_DENIED,  EACCES    },  /* 65 */
    {  ERROR_BAD_NET_NAME,           ENOENT    },  /* 67 */
    {  ERROR_FILE_EXISTS,            EEXIST    },  /* 80 */
    {  ERROR_CANNOT_MAKE,            EACCES    },  /* 82 */
    {  ERROR_FAIL_I24,               EACCES    },  /* 83 */
    {  ERROR_INVALID_PARAMETER,      EINVAL    },  /* 87 */
    {  ERROR_NO_PROC_SLOTS,          EAGAIN    },  /* 89 */
    {  ERROR_DRIVE_LOCKED,           EACCES    },  /* 108 */
    {  ERROR_BROKEN_PIPE,            EPIPE     },  /* 109 */
    {  ERROR_DISK_FULL,              ENOSPC    },  /* 112 */
    {  ERROR_INVALID_TARGET_HANDLE,  EBADF     },  /* 114 */
    {  ERROR_INVALID_HANDLE,         EINVAL    },  /* 124 */
    {  ERROR_WAIT_NO_CHILDREN,       ECHILD    },  /* 128 */
    {  ERROR_CHILD_NOT_COMPLETE,     ECHILD    },  /* 129 */
    {  ERROR_DIRECT_ACCESS_HANDLE,   EBADF     },  /* 130 */
    {  ERROR_NEGATIVE_SEEK,          EINVAL    },  /* 131 */
    {  ERROR_SEEK_ON_DEVICE,         EACCES    },  /* 132 */
    {  ERROR_DIR_NOT_EMPTY,          ENOTEMPTY },  /* 145 */
    {  ERROR_NOT_LOCKED,             EACCES    },  /* 158 */
    {  ERROR_BAD_PATHNAME,           ENOENT    },  /* 161 */
    {  ERROR_MAX_THRDS_REACHED,      EAGAIN    },  /* 164 */
    {  ERROR_LOCK_FAILED,            EACCES    },  /* 167 */
    {  ERROR_ALREADY_EXISTS,         EEXIST    },  /* 183 */
    {  ERROR_FILENAME_EXCED_RANGE,   ENOENT    },  /* 206 */
    {  ERROR_NESTING_NOT_ALLOWED,    EAGAIN    },  /* 215 */
    {  ERROR_NOT_ENOUGH_QUOTA,       ENOMEM    }    /* 1816 */
};

/* size of the table */
#define ERRTABLESIZE (sizeof(errtable)/sizeof(errtable[0]))

/* The following two constants must be the minimum and maximum
   values in the (contiguous) range of Exec Failure errors. */
#define MIN_EXEC_ERROR ERROR_INVALID_STARTING_CODESEG
#define MAX_EXEC_ERROR ERROR_INFLOOP_IN_RELOC_CHAIN

/* These are the low and high value in the range of errors that are
   access violations */
#define MIN_EACCES_RANGE ERROR_WRITE_PROTECT
#define MAX_EACCES_RANGE ERROR_SHARING_BUFFER_EXCEEDED

static void _map_errno(unsigned long oserrno)
{
    int i;

    /* check the table for the OS error code */
    for (i = 0; i < ERRTABLESIZE; ++i) {
        if (oserrno == errtable[i].oscode) {
            errno = errtable[i].errnocode;
            return;
        }
    }

    /* The error code wasn't in the table.  We check for a range of */
    /* EACCES errors or exec failure errors (ENOEXEC).  Otherwise   */
    /* EINVAL is returned.                                          */

    if (oserrno >= MIN_EACCES_RANGE && oserrno <= MAX_EACCES_RANGE)
        errno = EACCES;
    else if (oserrno >= MIN_EXEC_ERROR && oserrno <= MAX_EXEC_ERROR)
        errno = ENOEXEC;
    else
        errno = EINVAL;
}

/**
 * Convert a file time into a time.
 *
 * @param ft filetime
 * @return time
 */
static time_t _filetimeToTime(FILETIME *ft)
{
    ULONGLONG ns;
    time_t sec;

    ns = ((ULONGLONG) ft->dwHighDateTime << 32) + ((unsigned) ft->dwLowDateTime);
    if (ns == 0) {
        return 0;
    }
    ns -= 0x19db1ded53e8000;  /* number of 100ns between 1601 and 1970 */
    ns /= 10000000;           /* number of 100ns in a second */
    sec = (time_t) ns;

    return sec;
}

/**
 * Convert a (possibly relative) filename into a long file name. This
 * is an absolute path, composed of wide characters and having a "\\?\"
 * prefix.
 *
 * @param lfn destination, must be at least PATH_MAX + PFX_MAX_LEN long
 * @param filename source
 * @return 0 on success; -1 on error
 */
static int _tolfn(wchar_t *lfn, const char *filename)
{
    wchar_t wfilename[PATH_MAX];
    int unc = 0;

    /* Do not allow drive letter + ':' alone */
    if (strlen(filename) == 2 && filename[1] == ':') {
        errno = EINVAL;
        return -1;
    }
    /* Detect UNC path */
    if (!strncmp("\\\\", filename, 2)) {
        unc = 1;
    }

    if (utf8_to_ucs2(wfilename, filename, PATH_MAX) < 0) {
        return -1;
    }
    if (!unc) {
        if (_wfullpath(lfn + LFN_PFX_LEN, wfilename, PATH_MAX) == NULL) {
            return -1;
        }
        wcsncpy(lfn, LFN_PFX, LFN_PFX_LEN);
    } else {
        /* Store path two characters short to automatically get rid of double backslash */
        if (_wfullpath(lfn + LFN_PFX_LEN + UNC_PFX_LEN - 2, wfilename, PATH_MAX) == NULL) {
            return -1;
        }
        wcsncpy(lfn, LFN_PFX, LFN_PFX_LEN);
        wcsncpy(lfn + LFN_PFX_LEN, UNC_PFX, UNC_PFX_LEN);
    }
    return 0;
}

static void forge_stat(struct _stat* stat)
{
    stat->st_mtime = stat->st_atime = stat->st_ctime = JAN_1_1980;
    stat->st_mode = _S_IFDIR | _S_IEXEC | _S_IREAD | _S_IWRITE;
    stat->st_mode |= (stat->st_mode & 0700) >> 3;
    stat->st_mode |= (stat->st_mode & 0700) >> 6;
    stat->st_nlink = 1;
    stat->st_size = 0;
    stat->st_uid = stat->st_gid = stat->st_ino = 0;
    stat->st_rdev = stat->st_dev = 0;
}

/**
 * Replacement for _wstat(), because _wstat() rejects file names containing
 * joker characters (e.g. '?', '*'). Therefore, passing a long file name with
 * initial prefix "\\?\" will always return ENOENT (sigh!).
 *
 * @param filename long file name
 * @param stat file information
 * @return 0 on success; -1 on failure
 */
static int _crt_wstat(const wchar_t *filename, struct _stat* stat)
{
    WIN32_FIND_DATAW ffd;
    HANDLE hf;
    wchar_t *ext;
    const wchar_t *p, *sep;

    hf = FindFirstFileW(filename, &ffd);
    if (hf == INVALID_HANDLE_VALUE) {
        /* Check for root directory, e.g. "C:\" */
        p = filename + LFN_PFX_LEN;
        if (wcslen(p) == 3 && GetDriveTypeW(p) > 1) {
            forge_stat(stat);
            return 0;
        }
        /* Check for canonical \\server\share entry */
        if (!wcsncmp(p, UNC_PFX, UNC_PFX_LEN)) {
            sep = wcschr(p + UNC_PFX_LEN, L'\\');
            if (sep != NULL) {
                sep = wcschr(sep + 1, L'\\');
                if (sep == NULL) {
                    forge_stat(stat);
                    return 0;
                }
            }
        }
        /* Neither of the above, so it definitely does not exist */
        errno = ENOENT;
        return -1;
    }

    stat->st_mtime = _filetimeToTime(&ffd.ftLastWriteTime);
    if (ffd.ftLastAccessTime.dwLowDateTime || ffd.ftLastAccessTime.dwHighDateTime) {
        stat->st_atime = _filetimeToTime(&ffd.ftLastAccessTime);
    } else {
        stat->st_atime = stat->st_mtime;
    }
    if (ffd.ftCreationTime.dwLowDateTime || ffd.ftCreationTime.dwHighDateTime) {
        stat->st_ctime = _filetimeToTime(&ffd.ftCreationTime);
    } else {
        stat->st_ctime = stat->st_mtime;
    }

    /* check to see if this is a directory */
    if (ffd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
        stat->st_mode = _S_IFDIR | _S_IEXEC;
    } else {
        stat->st_mode = _S_IFREG;
    }

    /* If attribute byte does not have read-only bit, it is read-write */
    stat->st_mode |= _S_IREAD;
    if (!(ffd.dwFileAttributes & FILE_ATTRIBUTE_READONLY)) {
        stat->st_mode |= _S_IWRITE;
    }

    /* see if file appears to be executable - check extension of name */
    ext = wcsrchr(filename, L'.');
    if (ext) {
        if (!_wcsicmp(ext, L".exe") ||
                !_wcsicmp(ext, L".cmd") ||
                !_wcsicmp(ext, L".bat") ||
                !_wcsicmp(ext, L".com")) {
            stat->st_mode |= _S_IEXEC;
        }
    }

    /* propagate user read/write/execute bits to group/other fields */
    stat->st_mode |= (stat->st_mode & 0700) >> 3;
    stat->st_mode |= (stat->st_mode & 0700) >> 6;

    stat->st_nlink = 1;
    stat->st_size = ffd.nFileSizeLow;

    stat->st_uid = stat->st_gid = stat->st_ino = 0;
    stat->st_rdev = stat->st_dev = 0;

    FindClose(hf);
    return 0;
}

/**
 * Directory stream structure.
 */
struct DIR {

    /* handle returned by _wfindfirst */
    intptr_t handle;

    /* structure filled by _wfindfirst/_wfindnext */
    struct _wfinddata_t fileinfo;

    /* dirent structure */
    struct dirent entry;

    /* first name retrieved, returned on readdir_r */
    const wchar_t *name;

    /* first attribute retrieved */
    unsigned attrib;
};

/**
 * Read the next directory entry in a directory stream.
 *
 * @param dirp directory stream
 * @return entry or NULL if no more entries are available
 */
struct dirent *readdir(DIR *dirp)
{
    struct dirent *result;

    if (!readdir_r(dirp, &dirp->entry, &result)) {
        return result;
    }
    return NULL;
}


/*----------------------------------------------------------- Public methods */


int crt_open(const char *filename, int oflag, int pmode)
{
    wchar_t fullpath[PFX_MAX_LEN + PATH_MAX];

    if (_tolfn(fullpath, filename) < 0) {
        return -1;
    }
    oflag |= (O_BINARY | O_NOINHERIT);
    return _wopen(fullpath, oflag, pmode);
}

FILE *crt_fopen(const char *filename, const char *mode)
{
    wchar_t fullpath[PFX_MAX_LEN + PATH_MAX], wmode[MODE_MAX];
    size_t count;

    if (!stricmp(filename, "nul")) {
        /* internal file name, do not try to make it absolute */
        return fopen(filename, mode);
    }

    if (_tolfn(fullpath, filename) < 0) {
        return NULL;
    }
    count = strlen(mode) + 1;
    if (count > MODE_MAX) {
        return NULL;
    }
    if (utf8_to_ucs2(wmode, mode, count) < 0) {
        return NULL;
    }
    return _wfopen(fullpath, wmode);
}

int crt_mkdir(const char *dirname)
{
    wchar_t fullpath[PFX_MAX_LEN + PATH_MAX];

    /* if argument is simply a drive letter and ":", stop here;
     * otherwise _tolfn() will report a EINVAL
     */
    if (strlen(dirname) == 2 && dirname[1] == ':') {
        errno = EEXIST;
        return -1;
    }
    if (_tolfn(fullpath, dirname) < 0) {
        return -1;
    }
    return _wmkdir(fullpath);
}

int crt_stat(const char *filename, struct stat *stat)
{
    wchar_t fullpath[PFX_MAX_LEN + PATH_MAX];

    if (_tolfn(fullpath, filename) < 0) {
        return -1;
    }
    return _crt_wstat(fullpath, (struct _stat *) stat);
}

int fstat(int fildes, struct stat *buf)
{
    return _fstat(fildes, (struct _stat *) buf);
}

int lstat(const char *filename, struct stat *stat)
{
    wchar_t fullpath[PFX_MAX_LEN + PATH_MAX];
    int ret;
    DWORD attributes;

    if (_tolfn(fullpath, filename) < 0) {
        return -1;
    }
    if ((ret = _crt_wstat(fullpath, (struct _stat *) stat)) != 0) {
        return ret;
    }
    attributes = GetFileAttributesW(fullpath);
    if (attributes != INVALID_FILE_ATTRIBUTES) {
        if ((attributes & FILE_ATTRIBUTE_REPARSE_POINT) != 0) {
            stat->st_mode |= _S_IFLNK;
        }
    }
    return 0;
}

int crt_rename(const char *old, const char *new)
{
    wchar_t lfn_old[PFX_MAX_LEN + PATH_MAX], lfn_new[PFX_MAX_LEN + PATH_MAX];

    if (_tolfn(lfn_old, old) < 0 || _tolfn(lfn_new, new) < 0) {
        return -1;
    }
    /* _wrename() will fail if new already exists */
    if (!MoveFileExW(lfn_old, lfn_new, MOVEFILE_REPLACE_EXISTING)) {
        _map_errno(GetLastError());
        return -1;
    }
    return 0;
}

int crt_remove(const char *path)
{
    wchar_t fullpath[PFX_MAX_LEN + PATH_MAX];
    struct _stat stat;

    if (_tolfn(fullpath, path) < 0) {
        return -1;
    }
    if (_crt_wstat(fullpath, &stat) < 0) {
        return -1;
    }
    /* _wremove() works for files only */
    if (stat.st_mode & _S_IFDIR) {
        return _wrmdir(fullpath);
    }
    else {
        return _wremove(fullpath);
    }
}

int crt_unlink(const char *path)
{
    return crt_remove(path);
}

char *realpath(const char *filename, char *resolved)
{
    wchar_t fullpath[PFX_MAX_LEN + PATH_MAX], finalpath[PFX_MAX_LEN + PATH_MAX], *p;
    struct _stat stat;
    HANDLE hFile;

    if (_tolfn(fullpath, filename) < 0) {
        return NULL;
    }
    if (_crt_wstat(fullpath, &stat) == -1) {
        return NULL;
    }
    p = &fullpath[LFN_PFX_LEN];

    hFile = CreateFileW(fullpath, FILE_READ_EA, FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,
            NULL, OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS, NULL);
    if (hFile == INVALID_HANDLE_VALUE) {
        /* we hit a symbolic link whose target does not exist */
        _map_errno(GetLastError());
        return NULL;
    }
    if (GetFinalPathNameByHandleW(hFile, finalpath, sizeof(finalpath), VOLUME_NAME_DOS)) {
        /* should we return an error if that call fails? */
        p = &finalpath[LFN_PFX_LEN];
    }
    CloseHandle(hFile);

    /* Rebuild server/share syntax prefixed by two backslashes */
    if (!wcsncmp(p, UNC_PFX, UNC_PFX_LEN)) {
        p += 2;
        *p = L'\\';
    }

    if (ucs2_to_utf8(resolved, p, PATH_MAX) < 0) {
        return NULL;
    }
    return resolved;
}

DIR *opendir(const char *dirname)
{
    wchar_t fullpath[PFX_MAX_LEN + PATH_MAX + 2], *p;
    struct _stat stat;
    DIR *dir;
    intptr_t handle;
    size_t len;

    /* Do not allow joker characters in dirname */
    if (strpbrk(dirname, "?*") != NULL) {
        errno = ENOENT;
        return NULL;
    }
    if (_tolfn(fullpath, dirname) < 0) {
        return NULL;
    }

    /* If this is a proper directory (not e.g. C:\\), we remove an eventual '\\' terminator or _wstat fails */
    len = wcslen(fullpath);
    if (len > 7 && fullpath[len - 1] == L'\\') {
        fullpath[len - 1] = 0;
    }

    /* Stop here if this is not an directory */
    if (_crt_wstat(fullpath, &stat) == -1 || (stat.st_mode & _S_IFDIR) == 0) {
        errno = ENOTDIR;
        return NULL;
    }

    /* Append joker character for all entries in a directory */
    len = wcslen(fullpath);
    p = &fullpath[len - 1];
    if (*p++ != L'\\') {
        wcscpy(p++, L"\\");
    }
    wcscpy(p, L"*");

    dir = malloc(sizeof(DIR));
    if (dir == NULL) {
        return NULL;
    }

    handle = _wfindfirst(fullpath, &dir->fileinfo);
    if (handle == -1) {
        wprintf(L"_wfindfirst found nothing: %s\n", fullpath);
        free(dir);
        return NULL;
    }
    dir->handle = handle;
    dir->name = dir->fileinfo.name;
    dir->attrib = dir->fileinfo.attrib;

    return dir;
}

#define ATTRIB_TO_DTYPE(a) ((a) & _A_SUBDIR ? DT_DIR : DT_REG)

int readdir_r(DIR *dirp, struct dirent *entry, struct dirent **result)
{
    if (dirp->name) {
        ucs2_to_utf8(entry->d_name, dirp->name, 260);
        entry->d_type = ATTRIB_TO_DTYPE(dirp->attrib);
        dirp->name = NULL;
        *result = entry;
    }
    else if (!_wfindnext(dirp->handle, &dirp->fileinfo)) {
        ucs2_to_utf8(entry->d_name, dirp->fileinfo.name, 260);
        entry->d_type = ATTRIB_TO_DTYPE(dirp->fileinfo.attrib);
        *result = entry;
    }
    else {
        *result = NULL;
    }
    return 0;
}

int closedir(DIR *dirp)
{
    _findclose(dirp->handle);
    free(dirp);
    return 0;
}


/**
 * The debug library LIBCMTD.LIB exports a utime() function of its own.
 */
#ifndef _DEBUG

int utime(const char *path, struct utimbuf *times)
{
    wchar_t fullpath[PFX_MAX_LEN + PATH_MAX];

    if (_tolfn(fullpath, path) < 0) {
        return -1;
    }
    return _wutime(fullpath, (struct _utimbuf *) times);
}

#endif /* _DEBUG */


char *crt_mktemp(char *template)
{
    wchar_t fullpath[PFX_MAX_LEN + PATH_MAX], *ret, *wtemplate;
    size_t count;

    if (_tolfn(fullpath, template) < 0) {
        return NULL;
    }
    ret = _wmktemp(fullpath);
    if (ret == NULL) {
        return NULL;
    }
    /* Verify that return value still starts with \\?\ */
    if (wcsncmp(ret, LFN_PFX, LFN_PFX_LEN)) {
        return NULL;
    }
    wtemplate = ret + LFN_PFX_LEN;

    if (!wcsncmp(wtemplate, UNC_PFX, UNC_PFX_LEN)) {
        /* rebuild server/share syntax prefixed by two backslashes */
        wtemplate += 2;
        *wtemplate = L'\\';
    }

    /* Number of output bytes must be exactly the same as input bytes */
    count = strlen(template) + 1;

    if (ucs2_to_utf8(template, wtemplate, count) < 0) {
        return NULL;
    }
    return template;
}

time_t crt_time(time_t *tloc)
{
    FILETIME ft;
    time_t t;

    GetSystemTimeAsFileTime(&ft);
    t = _filetimeToTime(&ft);
    if (tloc) {
        *tloc = t;
    }
    return t;
}

unsigned int sleep(unsigned int seconds)
{
    Sleep(seconds * 1000);
    return 0;
}

#ifndef __MINGW32__

int gettimeofday(struct timeval *tv, struct timezone *tz)
{
    tv->tv_sec = (long) crt_time(0);
    tv->tv_usec = 0;
    return 0;
}

#endif // __MINGW32__

/**
 * Replacement for _snprintf() on Windows platforms, as it behaves differently
 * there: buffer is not always zero-terminated and return value is -1 if
 * buffer is too small.
 */
int crt_snprintf(char *str, size_t str_m, const char *fmt, /*args*/ ...)
{
    va_list args;
    int len;

    va_start(args, fmt);
    len = _vsnprintf(str, str_m, fmt, args);
    va_end(args);

    if (len == -1) {
        /* indicates that the buffer passed is too short. to keep things compatible
         * we insert a terminating 0 regardless of the length, and return the size
         * passed as argument to indicate the truncation. this allows to test for
         * buffer truncation with the following simple test:
         *
         *   if (snprintf(buf, size, fmt, ...) >= size) {
         *      printf("truncation occurred");
         *   }
         */
        str[str_m - 1] = '\0';
        len = (int) str_m;
    }
    return len;
}
