/*
 * Copyright (c) 1999 Day Management AG
 * Barfuesserplatz 6, 4001 Basel, Switzerland
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Day Management AG, ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Day.
 */
#ifndef __SOCKET_H__
#define __SOCKET_H__

/**
 * @file base_io.h
 * @brief I/O routines
 */

/**
 * @defgroup base Base functionality
 * @{
 */

/**
 * @defgroup socket Socket library
 * @{
 */

#ifndef WIN32

/** Platform-independent definition for: Operation would block */
#define SOCKET_EWOULDBLOCK   EWOULDBLOCK
/** Platform-independent definition for: Interrupted system call */
#define SOCKET_EINTR         EINTR
/** Platform-independent definition for: Timed out */
#define SOCKET_ETIMEDOUT     ETIMEDOUT

#else  /* WIN32 */

/** Platform-independent definition for: Operation would block */
#define SOCKET_EWOULDBLOCK   WSAEWOULDBLOCK
/** Platform-independent definition for: Interrupted system call */
#define SOCKET_EINTR         WSAEINTR
/** Platform-independent definition for: Timed out */
#define SOCKET_ETIMEDOUT     WSAETIMEDOUT

#endif /* WIN32 */


#if defined (_WIN32) && defined(__GNUC__)
/* Workaround for MinGW: AI_NUMERICSERV is currently undefined.
 */
#define AI_NUMERICSERV 0x00000008
#endif

/**
 * Abstract socket type, hiding implementation details between Unix and Win32
 */
struct socket;

/**
 * Initialize sockets.
 *
 * @param threaded flag indicating whether application is threaded
 *
 * @return <code>0</code> on success;
 *         <code>-1</code> otherwise
 */
int sockets_init(unsigned is_threaded);

/**
 * Create a new socket.
 *
 * @param ai address info
 * @param secure flag whether a SSL socket should be created
 *
 * @return new socket, or <code>NULL</code>
 */
struct socket *socket_create(struct log_context *lc, struct addrinfo * ai);

/**
 * Set receive timeout.
 *
 * @param s socket
 * @param timeout receive timeout in milliseconds
 */
void socket_set_receive_timeout(struct socket *s, int timeout);

/**
 * Set socket option, similar to setsockopt(2).
 *
 * @param s socket
 * @param level level
 * @param option_name option name
 * @param option_value option value
 * @param option_len option length
 *
 * @return 0 on success; <>0 on error
 */
int socket_set_option(struct socket *s, int level, int option_name, void *option_value, socklen_t option_len);

/**
 * Connect a socket to some endpoint.
 *
 * @param lc log context
 * @param s socket
 * @param name socket address
 * @param length socket address length
 * @param timeout connect timeout in milliseconds, 0 meaning infinite
 *
 * @return 0 on success; <>0 on error
 */
int socket_connect(struct log_context *lc, struct socket *s, const struct sockaddr *name,
                   size_t length, int timeout);

/**
 * Send data over a connected socket. The method does not return until all
 * of the provided data is sent.
 *
 * @param lc log context
 * @param s socket
 * @param buffer buffer containing data
 * @param length number of bytes in buffer
 *
 * @return <code>0</code> on success; <code>-1</code> on error
 */
int socket_send(struct log_context *lc, struct socket *s, const char *buffer, size_t length);

/**
 * Flush all data in the socket's buffer
 *
 * @param lc log context
 * @param s socket
 *
 * @return <code>0</code> on success; <code>-1</code> on error
 */
int socket_flush(struct log_context *lc, struct socket *s);

/**
 * Receive data over a connected socket.
 *
 * @param lc log context
 * @param s socket
 * @param buffer pointer where to return data
 * @param length maximum number of bytes to return
 * @param ignore_eintr whether to ignore EINTR
 *
 * @return number of bytes actually received;
 *         <code>0</code> if no more data is available (EOF)
 *         <code>-1</code> if an error occurred
 */
int socket_recv(struct log_context *lc, struct socket *s, void *buffer, int length, int ignore_eintr);

/**
 * Close a socket.
 *
 * @param lc log context
 * @param s socket
 */
int socket_close(struct log_context *lc, struct socket *s);

/**
 * Return the last socket error.
 *
 * @return last socket error
 */
int socket_errno();

/**
 * Return a pointer to a message describing the last socket error.
 *
 * @param s socket, may be {@code null}
 * @return message associated with last socket error
 */
const char *socket_errstring(struct socket *s);

/**
 * @private
 * IP info function table.
 */
#ifndef WIN32

struct ip_info_vtable {
    int (*getaddrinfo)(const char *, const char *, const struct addrinfo *, struct addrinfo **);
    int (*getnameinfo)(const struct sockaddr *, socklen_t, char *, socklen_t, char *, socklen_t, int);
    void (*freeaddrinfo)(struct addrinfo *);
    const char *(*gai_strerror)(int);
};

#else

/* On Windows, the info functions are all __stdcall. Moreover, getnameinfo is
 * defined with DWORD (unsigned long) instead of socklen_t (int), though
 * both are 4 bytes long on Windows x86 and x64, duh!
 */
struct ip_info_vtable {
    int (__stdcall *getaddrinfo)(const char *, const char *, const struct addrinfo *, struct addrinfo **);
    int (__stdcall *getnameinfo)(const struct sockaddr *, socklen_t, char *, DWORD, char *, DWORD, int);
    void (__stdcall *freeaddrinfo)(struct addrinfo *);
    const char *(*gai_strerror)(int);
};

#endif /* WIN32 */

/**
 * @private
 * Function table for IPv4 lookup.
 */
extern struct ip_info_vtable IPv4_VTABLE;

/**
 * @private
 * Function table for IPv6 lookup.
 */
extern struct ip_info_vtable IPv6_VTABLE;

/** @} */
/** @} */

#endif /* __SOCKET_H__ */
